# ValuPro — Interview Talking Points

For use in investment banking and private equity recruiting conversations.
Versions for: 30-second introduction, 3-minute deep-dive, and specific
technical questions from analysts and associates.

---

## The 30-second version

"I built an institutional equity valuation platform — a full software system
that runs the same quantitative workflows you'd use on a live deal. It fetches
live financial statements, builds a 10-year FCFF forecast across Bear, Base,
and Bull scenarios, computes WACC from CAPM, runs a full DCF with Gordon Growth
terminal value, screens a peer comps set using Tukey IQR fencing, and generates
a PDF report with seven charts and an AI-written investment memo. The entire
thing is running in production — containerised, tested, deployable. I built it
because I wanted to understand valuation methodology well enough to implement it,
not just apply it."

**Why this line works:** It opens with what the audience cares about (valuation)
before mentioning the software. It names the specific methodologies (FCFF, CAPM,
GGM, Tukey IQR) which signals that you know the concepts precisely. It ends with
intellectual curiosity — "I wanted to understand it well enough to implement it"
— which is a better reason than "to show off my coding skills."

---

## The 3-minute version (for a dedicated project slot)

### Part 1 — The problem it solves (30 sec)

"Most valuation tools are either spreadsheet templates — flexible but error-prone
and impossible to audit — or black-box platforms like Capital IQ where you can
run a comps screen but you can't see exactly how the outlier screening works or
what assumptions the WACC is using. I wanted to build something where every
formula is explicit, every assumption is traceable, and the methodology is
documented to the same standard as a Damodaran textbook."

### Part 2 — The financial methodology (90 sec)

"The core is a 10-year FCFF forecast. FCFF equals NOPAT plus D&A minus CapEx
minus the change in net working capital. I model each line separately: revenue
from a trend-derived CAGR fading to a long-run rate, EBITDA margins from
historical average with scenario deltas, D&A and CapEx as a percentage of
revenue, NWC as a percentage of revenue with change computed year-over-year.

The terminal value uses the Gordon Growth Model — FCFF in year 10 times
(1 + g) divided by (WACC minus g). I put a hard guard on the minimum spread
between WACC and g: if it drops below 30 basis points, the model flags it
as unreliable because the terminal value becomes hypersenitive. I also implemented
the reverse GGM — given the current market price, back-solve for what growth
rate the market is implying. That's one of the most useful things you can show
in a pitch: 'The market is pricing this at an implied terminal growth of 3.2%,
our model uses 2.5%, here's why we're more conservative.'

For comps, I use Tukey IQR fencing — lower fence at Q1 minus 1.5 times IQR —
which is the standard sell-side screening method. I compute EV/EBITDA, EV/Revenue,
EV/EBIT, P/E, and P/B, derive implied enterprise value and equity value at each
statistic, and put the full peer set in a table with excluded companies labelled
and the exclusion reason documented."

### Part 3 — The software (45 sec)

"On the engineering side, the interesting design choice was treating every
phase output as an immutable value object. The forecast produces a
`ForecastOutput`. The DCF engine consumes it and produces a `ValuationOutput`.
The comps engine produces a `CompsResult`. Nothing mutates anything — it's
purely functional. That makes the computation graph testable in isolation:
I can write a test for the Gordon Growth Model with known inputs and verify
the exact output without touching the database or the API. The test suite has
539 functions across all the valuation phases.

In production it runs on Docker with nginx handling TLS termination and
three-zone rate limiting — separate limits for general API calls, AI memo
generation which calls Claude and costs money, and PDF report generation
which is CPU-intensive."

### Part 4 — What I learned (30 sec)

"The most useful thing I learned is that implementing a model forces you to
confront every assumption you'd normally paper over in a spreadsheet. When
you're writing a function for terminal value and you have to decide what to
do when WACC minus g is negative — you can't just leave a cell blank. You
have to decide: is this an error, a warning, or a valid edge case? That kind
of rigour is exactly what the first year of banking teaches you, and building
this gave me a head start on thinking that way."

---

## Handling specific technical questions

### "Walk me through your DCF assumptions."

"My base-case WACC for AAPL using live data comes out around 9.1% — cost
of equity via CAPM with a 1.25 levered beta, 4.3% risk-free rate, 5.5%
equity risk premium, after-tax cost of debt around 3.1%. Terminal growth
at 2.5%, which is slightly below long-run nominal GDP of 3.5%. PV of
terminal value ends up around 71% of enterprise value — high, but consistent
with a mature high-cash-flow business. The sensitivity grid shows fair
value ranging from around $165 at a 11% WACC with 1.5% terminal growth
to $248 at a 7% WACC with 3.5% terminal growth."

### "How did you handle the peer comps screening?"

"The standard approach is Tukey IQR fencing, which is what Bloomberg and
most sell-side shops use informally. You compute Q1 and Q3 for the peer
multiple series, multiply the IQR by 1.5, and drop anything outside those
fences. I also apply hard sanity bounds first — EV/EBITDA between 2 and 60
times, P/E between 3 and 200 times — because a negative EBITDA company will
produce a nonsensical multiple that the IQR screen might not catch if the
peer set is otherwise well-behaved. Every excluded peer is documented with
the reason: whether it was the hard bounds or the IQR fence, and what the
excluded value was."

### "What would you add next?"

"The highest-value addition from a finance perspective would be a Monte Carlo
simulation — replace the point-estimate DCF with distributions for each
assumption and run 10,000 simulations. Instead of showing one base-case number,
you show a probability distribution of fair values with the 5th, 50th, and
95th percentiles. That's how equity derivatives desks and quant equity funds
actually think about valuation, and it's a direct extension of the sensitivity
analysis I've already built. Technically it's straightforward — the DCF engine
is stateless so I can just call it 10,000 times with perturbed inputs. The
interesting part is choosing the right distributions for each assumption.
Revenue growth is approximately log-normal. EBITDA margins have historical
mean reversion. WACC depends on interest rate uncertainty."

### "Why not just use Bloomberg or Capital IQ?"

"Those platforms are the right tool for live deal work. But they're black boxes.
If I run an EV/EBITDA comps screen on Bloomberg and one peer is excluded, I
don't know whether it was excluded because EBITDA was negative, because the
multiple was above the hard ceiling, or because it failed an IQR screen.
Building it myself means I know exactly what every number means and why.
That understanding is what I'm trying to demonstrate."

---

## If they ask why software specifically

"A DCF in Excel and a DCF in production software are testing different skills.
In Excel, you can leave a formula wrong for years and no one will know until the
deal is live. In a software system with a test suite, a wrong formula fails a
test the first time you run it. The discipline of writing testable, explicit
code has made me a more rigorous financial analyst, not a more distracted one."

---

## Red flags to avoid

**Don't say:** "I built a valuation app." Say: "I implemented institutional
valuation methodology in production software."

**Don't say:** "I used AI to generate parts of it." What's true is: "I
integrated Claude claude-sonnet-4-6 to generate an AI investment memo, where
every quantitative claim is grounded in the output of the valuation engine I
built. The AI is the last step, not the first."

**Don't over-index on lines of code.** 27,000 lines is a data point. The
interesting number is 539 tests — that signals rigour, not just volume.

**Don't claim it's production-ready for live deal use without qualifications.**
It's production-ready in the infrastructure sense. The right framing is:
"It uses the same methodology as live deal models, built to the same
implementation standard as production software."
