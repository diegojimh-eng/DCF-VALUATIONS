-- scripts/init.sql
-- PostgreSQL initialization — runs once on first container start.
-- Extend this when Alembic migrations are introduced.

-- Ensure the application user has full access to the database
GRANT ALL PRIVILEGES ON DATABASE valupro TO valupro;

-- Enable extensions needed for production use
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";    -- for uuid_generate_v4()
CREATE EXTENSION IF NOT EXISTS "pg_trgm";      -- for fuzzy text search on tickers
CREATE EXTENSION IF NOT EXISTS "btree_gin";    -- for composite index performance
