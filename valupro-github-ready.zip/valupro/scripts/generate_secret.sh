#!/bin/bash
# scripts/generate_secret.sh
# Generates all required production secrets in one run.
# Run once on a secure machine and store results in your secrets manager.

echo "=== ValuPro Production Secret Generator ==="
echo ""
echo "# Copy these into your production .env or secrets manager"
echo ""
echo "API_SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
echo "POSTGRES_PASSWORD=$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')"
echo "REDIS_PASSWORD=$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')"
echo "GRAFANA_ADMIN_PASSWORD=$(python3 -c 'import secrets; print(secrets.token_urlsafe(16))')"
echo ""
echo "# Remember to also set:"
echo "# FMP_API_KEY, ALPHA_VANTAGE_API_KEY, ANTHROPIC_API_KEY"
echo "# CORS_ALLOWED_ORIGINS, DATABASE_URL (with new password), REDIS_URL"
