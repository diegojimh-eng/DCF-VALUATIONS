#!/bin/bash
# scripts/entrypoint.sh
# Docker entrypoint — runs before uvicorn starts.
# Handles: DB readiness wait, future Alembic migrations.
set -euo pipefail

echo "[entrypoint] ValuPro API starting..."
echo "[entrypoint] APP_ENV=${APP_ENV:-development}"

# ── Wait for PostgreSQL ───────────────────────────────────────────────────────
if [[ -n "${DATABASE_URL:-}" ]]; then
    echo "[entrypoint] Waiting for PostgreSQL..."
    # Extract host and port from DSN
    DB_HOST=$(echo "$DATABASE_URL" | sed -n 's/.*@\([^:/]*\).*/\1/p')
    DB_PORT=$(echo "$DATABASE_URL" | sed -n 's/.*:\([0-9]*\)\/.*/\1/p')
    DB_PORT=${DB_PORT:-5432}

    until pg_isready -h "$DB_HOST" -p "$DB_PORT" -q 2>/dev/null; do
        echo "[entrypoint] PostgreSQL not ready — retrying in 2s..."
        sleep 2
    done
    echo "[entrypoint] PostgreSQL ready at ${DB_HOST}:${DB_PORT}"
fi

# ── Wait for Redis ────────────────────────────────────────────────────────────
if [[ -n "${REDIS_URL:-}" ]]; then
    REDIS_HOST=$(echo "$REDIS_URL" | sed -n 's/redis:\/\/[^@]*@\?\([^:/]*\).*/\1/p')
    REDIS_HOST=${REDIS_HOST:-localhost}
    echo "[entrypoint] Waiting for Redis at ${REDIS_HOST}..."
    until redis-cli -h "$REDIS_HOST" ping >/dev/null 2>&1; do
        echo "[entrypoint] Redis not ready — retrying in 2s..."
        sleep 2
    done
    echo "[entrypoint] Redis ready"
fi

# ── Database migrations ───────────────────────────────────────────────────────
# Uncomment when Alembic migrations are added:
# echo "[entrypoint] Running database migrations..."
# alembic upgrade head
# echo "[entrypoint] Migrations complete"

echo "[entrypoint] All dependencies ready — starting application"
exec "$@"
