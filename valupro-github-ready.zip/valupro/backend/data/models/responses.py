"""
data/models/responses.py
------------------------
Typed response envelopes returned by every API endpoint.

Every response carries:
  • status       — "ok" | "partial" | "error"
  • data         — the payload (None on error)
  • errors       — list of structured error dicts
  • meta         — provenance metadata (provider, latency, cache info)

This prevents callers from having to guess the shape of error responses.
"""

from __future__ import annotations

from datetime import datetime
from typing import Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class ProviderMeta(BaseModel):
    """Provenance metadata attached to every response."""

    provider: str = Field(..., description="Which data provider served this response")
    fetched_at: datetime = Field(default_factory=datetime.utcnow)
    cache_hit: bool = False
    cache_ttl_seconds: int | None = None
    latency_ms: float | None = None
    fallback_used: bool = False     # True if primary provider failed and fallback served
    fallback_provider: str | None = None


class DataError(BaseModel):
    """Structured error entry."""

    code: str                          # machine-readable, e.g. "PROVIDER_TIMEOUT"
    message: str                       # human-readable description
    field: str | None = None           # which field failed validation (if applicable)
    provider: str | None = None        # which provider raised this error


class DataResponse(BaseModel, Generic[T]):
    """
    Generic response envelope.

    Usage:
        response = DataResponse[IncomeStatement](
            status="ok",
            data=income_stmt,
            meta=ProviderMeta(provider="fmp"),
        )
    """

    status: str = Field(
        ...,
        pattern="^(ok|partial|error)$",
        description="'ok' = full data, 'partial' = some fields missing, 'error' = no data",
    )
    data: T | None = None
    errors: list[DataError] = Field(default_factory=list)
    meta: ProviderMeta

    @classmethod
    def ok(cls, data: T, meta: ProviderMeta) -> "DataResponse[T]":
        return cls(status="ok", data=data, meta=meta)

    @classmethod
    def partial(
        cls,
        data: T,
        meta: ProviderMeta,
        errors: list[DataError],
    ) -> "DataResponse[T]":
        return cls(status="partial", data=data, errors=errors, meta=meta)

    @classmethod
    def error(
        cls,
        meta: ProviderMeta,
        errors: list[DataError],
    ) -> "DataResponse[None]":
        return cls(status="error", data=None, errors=errors, meta=meta)


class FinancialsBundle(BaseModel):
    """
    Complete financial data bundle for a company.
    This is what the DataRouter returns to the valuation engine.
    """

    from .financial import (
        BalanceSheet,
        CashFlowStatement,
        IncomeStatement,
        MarketData,
    )
    from .company import CompanyProfile

    profile: CompanyProfile
    market_data: MarketData
    income_statements: list[IncomeStatement] = Field(
        default_factory=list,
        description="Ordered newest-first, up to 5 years annual",
    )
    balance_sheets: list[BalanceSheet] = Field(
        default_factory=list,
        description="Ordered newest-first, up to 5 years annual",
    )
    cash_flow_statements: list[CashFlowStatement] = Field(
        default_factory=list,
        description="Ordered newest-first, up to 5 years annual",
    )
    meta: ProviderMeta
    validation_warnings: list[str] = Field(default_factory=list)
