"""
data/models/financial.py
------------------------
Provider-agnostic Pydantic models for every financial data object the
valuation engine consumes.

Design principles:
  • All monetary fields are float | None — never str.
  • Ratios (margins, growth rates) are expressed as decimals (0.25 = 25%).
  • Periods are always ISO strings ("2023-12-31" annual, "2023-Q3" quarterly).
  • Every model includes `source_provider` and `fetched_at` for audit trails.

These models are the contract between the data layer and the valuation engine.
Changing a field name here requires a corresponding change in the engine.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator


# ── Shared base ────────────────────────────────────────────────────────────────

class FinancialBase(BaseModel):
    """Metadata common to every fetched financial object."""

    ticker: str = Field(..., description="Uppercase exchange ticker symbol")
    period_type: Literal["annual", "quarterly", "ttm"] = "annual"
    period_end_date: date = Field(..., description="Fiscal period end date")
    fiscal_year: int = Field(..., ge=1990, le=2100)
    currency: str = Field(default="USD", max_length=3)
    source_provider: str = Field(..., description="Provider that delivered this data")
    fetched_at: datetime = Field(default_factory=datetime.utcnow)

    model_config = {"frozen": True}   # immutable after creation

    @field_validator("ticker")
    @classmethod
    def normalise_ticker(cls, v: str) -> str:
        return v.upper().strip()


# ── Income Statement ────────────────────────────────────────────────────────────

class IncomeStatement(FinancialBase):
    """
    Standardised income statement.
    All values in the company's reporting currency (millions unless noted).
    """

    # Top line
    revenue: float | None = None
    revenue_growth_yoy: float | None = Field(
        default=None, description="YoY growth as decimal, e.g. 0.12 = 12%"
    )

    # Cost structure
    cost_of_revenue: float | None = None
    gross_profit: float | None = None
    gross_margin: float | None = Field(default=None, ge=-10.0, le=10.0)

    # Operating items
    research_and_development: float | None = None
    selling_general_administrative: float | None = None
    operating_expenses: float | None = None
    operating_income: float | None = None           # EBIT
    operating_margin: float | None = None

    # EBITDA (derived or reported)
    ebitda: float | None = None
    ebitda_margin: float | None = None
    depreciation_amortisation: float | None = None  # from IS or CFS

    # Below the line
    interest_expense: float | None = None
    interest_income: float | None = None
    other_non_operating: float | None = None
    pretax_income: float | None = None
    income_tax_expense: float | None = None
    effective_tax_rate: float | None = Field(default=None, ge=-5.0, le=5.0)

    # Bottom line
    net_income: float | None = None
    net_income_margin: float | None = None
    net_income_common: float | None = None          # after preferred dividends

    # Per-share metrics
    eps_basic: float | None = None
    eps_diluted: float | None = None
    weighted_avg_shares_basic: float | None = None
    weighted_avg_shares_diluted: float | None = None

    # Dividends
    dividends_per_share: float | None = None

    @model_validator(mode="after")
    def derive_margins(self) -> "IncomeStatement":
        """Back-fill margin fields when revenue and profit are available."""
        obj = self.model_copy()  # work on a mutable copy
        if obj.revenue and obj.revenue != 0:
            if obj.gross_profit is not None and obj.gross_margin is None:
                object.__setattr__(obj, "gross_margin", obj.gross_profit / obj.revenue)
            if obj.ebitda is not None and obj.ebitda_margin is None:
                object.__setattr__(obj, "ebitda_margin", obj.ebitda / obj.revenue)
            if obj.net_income is not None and obj.net_income_margin is None:
                object.__setattr__(obj, "net_income_margin", obj.net_income / obj.revenue)
        return obj


# ── Balance Sheet ──────────────────────────────────────────────────────────────

class BalanceSheet(FinancialBase):
    """Standardised balance sheet as of period_end_date."""

    # Current assets
    cash_and_equivalents: float | None = None
    short_term_investments: float | None = None
    accounts_receivable: float | None = None
    inventory: float | None = None
    other_current_assets: float | None = None
    total_current_assets: float | None = None

    # Non-current assets
    property_plant_equipment_net: float | None = None
    goodwill: float | None = None
    intangible_assets: float | None = None
    long_term_investments: float | None = None
    other_non_current_assets: float | None = None
    total_non_current_assets: float | None = None

    total_assets: float | None = None

    # Current liabilities
    accounts_payable: float | None = None
    short_term_debt: float | None = None
    deferred_revenue_current: float | None = None
    other_current_liabilities: float | None = None
    total_current_liabilities: float | None = None

    # Non-current liabilities
    long_term_debt: float | None = None
    deferred_tax_liabilities: float | None = None
    other_non_current_liabilities: float | None = None
    total_non_current_liabilities: float | None = None

    total_liabilities: float | None = None

    # Equity
    common_stock: float | None = None
    retained_earnings: float | None = None
    additional_paid_in_capital: float | None = None
    accumulated_other_comprehensive_income: float | None = None
    total_stockholders_equity: float | None = None

    # Derived — computed by the valuation engine
    net_debt: float | None = None            # total_debt - cash
    net_working_capital: float | None = None # current_assets - current_liabilities

    @model_validator(mode="after")
    def derive_net_items(self) -> "BalanceSheet":
        obj = self.model_copy()
        cash = obj.cash_and_equivalents or 0.0
        st_invest = obj.short_term_investments or 0.0
        st_debt = obj.short_term_debt or 0.0
        lt_debt = obj.long_term_debt or 0.0
        total_debt = st_debt + lt_debt

        if obj.net_debt is None:
            object.__setattr__(obj, "net_debt", total_debt - (cash + st_invest))

        if (obj.total_current_assets is not None
                and obj.total_current_liabilities is not None
                and obj.net_working_capital is None):
            object.__setattr__(
                obj,
                "net_working_capital",
                obj.total_current_assets - obj.total_current_liabilities,
            )
        return obj


# ── Cash Flow Statement ────────────────────────────────────────────────────────

class CashFlowStatement(FinancialBase):
    """Standardised statement of cash flows."""

    # Operating activities
    net_income: float | None = None
    depreciation_amortisation: float | None = None
    stock_based_compensation: float | None = None
    deferred_income_tax: float | None = None
    change_in_working_capital: float | None = None
    accounts_receivable_change: float | None = None
    inventory_change: float | None = None
    accounts_payable_change: float | None = None
    other_operating_activities: float | None = None
    operating_cash_flow: float | None = None        # CFO

    # Investing activities
    capital_expenditures: float | None = None       # CapEx (usually negative)
    acquisitions: float | None = None
    purchases_of_investments: float | None = None
    sales_of_investments: float | None = None
    other_investing_activities: float | None = None
    investing_cash_flow: float | None = None        # CFI

    # Financing activities
    dividends_paid: float | None = None
    share_repurchases: float | None = None
    debt_repayment: float | None = None
    debt_issuance: float | None = None
    other_financing_activities: float | None = None
    financing_cash_flow: float | None = None        # CFF

    # Totals
    net_change_in_cash: float | None = None
    free_cash_flow: float | None = None             # CFO - CapEx

    @model_validator(mode="after")
    def derive_fcf(self) -> "CashFlowStatement":
        obj = self.model_copy()
        if (obj.free_cash_flow is None
                and obj.operating_cash_flow is not None
                and obj.capital_expenditures is not None):
            # CapEx from CFS is typically reported as negative
            fcf = obj.operating_cash_flow + obj.capital_expenditures
            object.__setattr__(obj, "free_cash_flow", fcf)
        return obj


# ── Market Data ────────────────────────────────────────────────────────────────

class MarketData(BaseModel):
    """Real-time / end-of-day market metrics."""

    ticker: str
    as_of: datetime = Field(default_factory=datetime.utcnow)
    source_provider: str
    fetched_at: datetime = Field(default_factory=datetime.utcnow)

    # Price
    current_price: float | None = None
    fifty_two_week_high: float | None = None
    fifty_two_week_low: float | None = None
    price_change_1d: float | None = None
    price_change_pct_1d: float | None = None

    # Capitalisation
    market_cap: float | None = None
    enterprise_value: float | None = None
    shares_outstanding: float | None = None
    shares_float: float | None = None

    # Risk metrics
    beta: float | None = Field(
        default=None,
        description="2-year weekly regression beta vs S&P 500"
    )
    volatility_30d: float | None = None

    # Valuation multiples (trailing)
    pe_ratio_ttm: float | None = None
    ps_ratio_ttm: float | None = None
    pb_ratio: float | None = None
    ev_ebitda_ttm: float | None = None
    ev_revenue_ttm: float | None = None

    # Dividends
    dividend_yield: float | None = None
    dividend_per_share_ttm: float | None = None
    payout_ratio: float | None = None

    # Cost of capital inputs
    risk_free_rate: float | None = Field(
        default=None,
        description="10-year government bond yield at fetch time (decimal)"
    )

    model_config = {"frozen": True}

    @field_validator("ticker")
    @classmethod
    def normalise_ticker(cls, v: str) -> str:
        return v.upper().strip()

    @field_validator("beta")
    @classmethod
    def validate_beta(cls, v: float | None) -> float | None:
        # Reasonable sanity bounds; extreme outliers are flagged in validation layer
        if v is not None and (v < -5.0 or v > 10.0):
            return None   # will trigger a validation warning upstream
        return v


# ── Peer Comparable Multiple ───────────────────────────────────────────────────

class PeerMultiple(BaseModel):
    """Single peer company's trading multiples for the Comps engine."""

    ticker: str
    company_name: str
    sector: str | None = None
    industry: str | None = None

    # Market
    market_cap: float | None = None
    enterprise_value: float | None = None

    # LTM multiples
    ev_ebitda: float | None = None
    ev_revenue: float | None = None
    ev_ebit: float | None = None
    pe_ratio: float | None = None
    ps_ratio: float | None = None
    pb_ratio: float | None = None
    price_fcf: float | None = None

    # Growth
    revenue_growth_1y: float | None = None
    ebitda_margin: float | None = None
    net_margin: float | None = None

    source_provider: str = ""
    fetched_at: datetime = Field(default_factory=datetime.utcnow)

    model_config = {"frozen": True}
