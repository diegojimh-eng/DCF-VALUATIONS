"""
data/models/company.py
----------------------
Company-level metadata models — separate from financial statement data
so they can be cached independently (longer TTL, rarely changes).
"""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field, field_validator


class CompanyProfile(BaseModel):
    """
    Static and semi-static company metadata.
    Cached for 7 days — changes only on ticker changes, acquisitions, etc.
    """

    ticker: str
    cik: str | None = Field(
        default=None,
        description="SEC Central Index Key — used for EDGAR lookups",
    )
    isin: str | None = None
    company_name: str
    exchange: str | None = None
    currency: str = "USD"
    country: str | None = None

    # Classification
    sector: str | None = None
    industry: str | None = None
    gics_sector: str | None = None
    gics_sub_industry: str | None = None

    # Identifiers
    description: str | None = None
    website: str | None = None
    ceo: str | None = None
    employees: int | None = None
    founded: int | None = None    # year

    # Data provenance
    source_provider: str = ""
    fetched_at: datetime = Field(default_factory=datetime.utcnow)

    model_config = {"frozen": True}

    @field_validator("ticker")
    @classmethod
    def normalise_ticker(cls, v: str) -> str:
        return v.upper().strip()


class CompanySearchResult(BaseModel):
    """
    Lightweight result returned by the company autocomplete endpoint.
    Does not include financials — just enough to identify the company.
    """

    ticker: str
    company_name: str
    exchange: str | None = None
    sector: str | None = None
    country: str | None = None
    currency: str | None = None
    source_provider: str = ""

    @field_validator("ticker")
    @classmethod
    def normalise_ticker(cls, v: str) -> str:
        return v.upper().strip()
