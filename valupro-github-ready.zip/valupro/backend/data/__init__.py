"""
data/ — Financial data layer for ValuPro.

Public interface:
    from data import DataRouter, FinancialCache, create_redis_client
    from data.providers import build_http_client, PROVIDER_REGISTRY
"""

from .cache import FinancialCache, create_redis_client
from .router import DataRouter

__all__ = [
    "DataRouter",
    "FinancialCache",
    "create_redis_client",
]
