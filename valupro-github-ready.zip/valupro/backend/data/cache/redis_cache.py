"""
data/cache/redis_cache.py
-------------------------
Typed async Redis cache for all financial data.

Design:
  • All values serialised as JSON (Pydantic models → dict → JSON string)
  • TTL policy driven by config.py (market data = 15m, financials = 24h)
  • Cache keys follow a deterministic hierarchy: {entity_type}:{ticker}:{variant}
  • On Redis unavailability, all operations degrade gracefully (no error, log warning)
  • Namespace prefix allows multiple environments to share one Redis instance

Key format examples:
  company_profile:AAPL
  income_statement:AAPL:annual:5
  market_data:AAPL
  balance_sheet:AAPL:annual:5
  cash_flow:AAPL:annual:5
  peers:AAPL:10
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, TypeVar

import redis.asyncio as aioredis
from redis.asyncio import Redis
from redis.exceptions import ConnectionError as RedisConnectionError
from redis.exceptions import RedisError

from config import get_settings
from logger import get_logger

log = get_logger(__name__)

T = TypeVar("T")


class FinancialCache:
    """
    Typed async cache wrapper over Redis.

    Usage:
        cache = FinancialCache(redis_client)
        await cache.set_market_data("AAPL", market_data_dict)
        data = await cache.get_market_data("AAPL")
    """

    # Key prefix — bump to invalidate all cache entries across deployments
    _NS = "valupro:v1"

    def __init__(self, client: Redis) -> None:
        self._r = client
        self._cfg = get_settings()

    # ── Key builders ───────────────────────────────────────────────────────

    def _key(self, *parts: str) -> str:
        return f"{self._NS}:{':'.join(parts)}"

    def _profile_key(self, ticker: str) -> str:
        return self._key("profile", ticker.upper())

    def _market_key(self, ticker: str) -> str:
        return self._key("market", ticker.upper())

    def _is_key(self, ticker: str, years: int, quarterly: bool) -> str:
        variant = "quarterly" if quarterly else "annual"
        return self._key("is", ticker.upper(), variant, str(years))

    def _bs_key(self, ticker: str, years: int, quarterly: bool) -> str:
        variant = "quarterly" if quarterly else "annual"
        return self._key("bs", ticker.upper(), variant, str(years))

    def _cfs_key(self, ticker: str, years: int, quarterly: bool) -> str:
        variant = "quarterly" if quarterly else "annual"
        return self._key("cfs", ticker.upper(), variant, str(years))

    def _peers_key(self, ticker: str, max_peers: int) -> str:
        return self._key("peers", ticker.upper(), str(max_peers))

    def _bundle_key(self, ticker: str) -> str:
        return self._key("bundle", ticker.upper())

    # ── Low-level get / set / delete ───────────────────────────────────────

    async def _get_json(self, key: str) -> dict | list | None:
        """Fetch a JSON-encoded value. Returns None on miss or Redis error."""
        try:
            raw = await self._r.get(key)
            if raw is None:
                return None
            return json.loads(raw)
        except RedisConnectionError:
            log.warning("cache.redis_unavailable", key=key)
            return None
        except (RedisError, json.JSONDecodeError) as exc:
            log.error("cache.get_error", key=key, error=str(exc))
            return None

    async def _set_json(
        self,
        key: str,
        value: dict | list,
        ttl_seconds: int,
    ) -> None:
        """Store a JSON-encoded value with TTL. Silently fails on Redis error."""
        try:
            payload = json.dumps(value, default=_json_serialiser)
            await self._r.setex(key, ttl_seconds, payload)
        except RedisConnectionError:
            log.warning("cache.redis_unavailable_write", key=key)
        except RedisError as exc:
            log.error("cache.set_error", key=key, error=str(exc))

    async def delete(self, key: str) -> None:
        """Delete a single cache key."""
        try:
            await self._r.delete(key)
        except RedisError as exc:
            log.warning("cache.delete_error", key=key, error=str(exc))

    async def invalidate_ticker(self, ticker: str) -> None:
        """
        Delete ALL cache entries for a given ticker.
        Uses SCAN to avoid blocking Redis with KEYS *.
        """
        pattern = self._key("*", ticker.upper(), "*")
        try:
            cursor = 0
            while True:
                cursor, keys = await self._r.scan(cursor, match=pattern, count=100)
                if keys:
                    await self._r.delete(*keys)
                if cursor == 0:
                    break
            log.info("cache.invalidated", ticker=ticker)
        except RedisError as exc:
            log.error("cache.invalidate_error", ticker=ticker, error=str(exc))

    # ── TTL getters from config ────────────────────────────────────────────

    @property
    def _ttl_market(self) -> int:
        return self._cfg.cache_ttl_market_data

    @property
    def _ttl_financials(self) -> int:
        return self._cfg.cache_ttl_financials

    @property
    def _ttl_profile(self) -> int:
        return self._cfg.cache_ttl_company_profile

    # ── Company profile ────────────────────────────────────────────────────

    async def get_profile(self, ticker: str) -> dict | None:
        return await self._get_json(self._profile_key(ticker))  # type: ignore[return-value]

    async def set_profile(self, ticker: str, data: dict) -> None:
        await self._set_json(self._profile_key(ticker), data, self._ttl_profile)

    # ── Market data ────────────────────────────────────────────────────────

    async def get_market_data(self, ticker: str) -> dict | None:
        return await self._get_json(self._market_key(ticker))  # type: ignore[return-value]

    async def set_market_data(self, ticker: str, data: dict) -> None:
        await self._set_json(self._market_key(ticker), data, self._ttl_market)

    # ── Income statements ──────────────────────────────────────────────────

    async def get_income_statements(
        self, ticker: str, years: int, quarterly: bool
    ) -> list | None:
        return await self._get_json(self._is_key(ticker, years, quarterly))  # type: ignore[return-value]

    async def set_income_statements(
        self, ticker: str, years: int, quarterly: bool, data: list
    ) -> None:
        await self._set_json(
            self._is_key(ticker, years, quarterly), data, self._ttl_financials
        )

    # ── Balance sheets ─────────────────────────────────────────────────────

    async def get_balance_sheets(
        self, ticker: str, years: int, quarterly: bool
    ) -> list | None:
        return await self._get_json(self._bs_key(ticker, years, quarterly))  # type: ignore[return-value]

    async def set_balance_sheets(
        self, ticker: str, years: int, quarterly: bool, data: list
    ) -> None:
        await self._set_json(
            self._bs_key(ticker, years, quarterly), data, self._ttl_financials
        )

    # ── Cash flow statements ───────────────────────────────────────────────

    async def get_cash_flows(
        self, ticker: str, years: int, quarterly: bool
    ) -> list | None:
        return await self._get_json(self._cfs_key(ticker, years, quarterly))  # type: ignore[return-value]

    async def set_cash_flows(
        self, ticker: str, years: int, quarterly: bool, data: list
    ) -> None:
        await self._set_json(
            self._cfs_key(ticker, years, quarterly), data, self._ttl_financials
        )

    # ── Peers ──────────────────────────────────────────────────────────────

    async def get_peers(self, ticker: str, max_peers: int) -> list | None:
        return await self._get_json(self._peers_key(ticker, max_peers))  # type: ignore[return-value]

    async def set_peers(self, ticker: str, max_peers: int, data: list) -> None:
        await self._set_json(
            self._peers_key(ticker, max_peers), data, self._ttl_financials
        )

    # ── Full bundle ────────────────────────────────────────────────────────

    async def get_bundle(self, ticker: str) -> dict | None:
        return await self._get_json(self._bundle_key(ticker))  # type: ignore[return-value]

    async def set_bundle(self, ticker: str, data: dict) -> None:
        # Bundle TTL = min(market TTL, financials TTL) = market TTL
        await self._set_json(self._bundle_key(ticker), data, self._ttl_market)

    # ── Health check ───────────────────────────────────────────────────────

    async def ping(self) -> bool:
        """Return True if Redis is reachable."""
        try:
            return await self._r.ping()
        except RedisError:
            return False


# ── JSON serialiser for Pydantic / datetime objects ───────────────────────────

def _json_serialiser(obj: Any) -> str:  # noqa: ANN401
    """Custom serialiser for types json.dumps doesn't handle natively."""
    if isinstance(obj, datetime):
        return obj.isoformat()
    from datetime import date  # noqa: PLC0415
    if isinstance(obj, date):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj)} is not JSON serialisable")


# ── Factory ────────────────────────────────────────────────────────────────────

async def create_redis_client() -> Redis:
    """
    Create an async Redis client connected to the URL in settings.
    Call at application startup; close at shutdown.
    """
    cfg = get_settings()
    client: Redis = aioredis.from_url(
        cfg.redis_url,
        encoding="utf-8",
        decode_responses=True,
        socket_connect_timeout=3,
        socket_timeout=5,
        retry_on_timeout=True,
        max_connections=20,
    )
    # Test connectivity at startup — non-fatal if Redis is down
    try:
        await client.ping()
        log.info("cache.redis.connected", url=cfg.redis_url)
    except RedisConnectionError:
        log.warning(
            "cache.redis.unavailable",
            url=cfg.redis_url,
            note="Running without cache — all requests will hit providers directly",
        )
    return client
