"""
data/providers/base.py
----------------------
Abstract base class that every financial data provider must implement.

Design philosophy:
  • The DataRouter knows nothing about provider internals.
  • Every provider normalises raw API responses into the same Pydantic models.
  • Providers raise typed ProviderError subclasses — never raw exceptions.
  • All I/O is async; providers share a single httpx.AsyncClient lifecycle.

Adding a new provider:
  1. Create data/providers/my_provider.py
  2. Subclass BaseFinancialProvider
  3. Implement all abstract methods
  4. Register in data/providers/__init__.py
  5. Add to Settings.provider_priority
"""

from __future__ import annotations

import abc
import time
from contextlib import asynccontextmanager
from typing import AsyncIterator

import httpx

from config import get_settings
from data.models import (
    BalanceSheet,
    CashFlowStatement,
    CompanyProfile,
    CompanySearchResult,
    IncomeStatement,
    MarketData,
    PeerMultiple,
)


# ── Provider error hierarchy ───────────────────────────────────────────────────

class ProviderError(Exception):
    """Base class for all provider errors."""

    def __init__(self, provider: str, message: str, status_code: int | None = None) -> None:
        self.provider = provider
        self.status_code = status_code
        super().__init__(f"[{provider}] {message}")


class ProviderAuthError(ProviderError):
    """API key missing, invalid, or quota exceeded."""


class ProviderRateLimitError(ProviderError):
    """Provider responded with 429 Too Many Requests."""

    def __init__(self, provider: str, retry_after_seconds: float | None = None) -> None:
        self.retry_after_seconds = retry_after_seconds
        super().__init__(provider, "Rate limit exceeded", status_code=429)


class ProviderTimeoutError(ProviderError):
    """Provider did not respond within the configured timeout."""


class ProviderDataError(ProviderError):
    """Provider responded but the data was malformed or unexpectedly empty."""


class ProviderUnavailableError(ProviderError):
    """Provider returned 5xx or is otherwise unreachable."""


# ── Timing context manager ─────────────────────────────────────────────────────

class _Timer:
    """Simple wall-clock timer for latency tracking."""

    def __init__(self) -> None:
        self._start: float = 0.0
        self.elapsed_ms: float = 0.0

    def __enter__(self) -> "_Timer":
        self._start = time.perf_counter()
        return self

    def __exit__(self, *_: object) -> None:
        self.elapsed_ms = (time.perf_counter() - self._start) * 1000.0


# ── Abstract provider ──────────────────────────────────────────────────────────

class BaseFinancialProvider(abc.ABC):
    """
    Contract that every financial data provider must satisfy.

    Lifecycle
    ---------
    Providers are instantiated once and reused for the application lifetime.
    The shared httpx.AsyncClient is injected via __init__ so providers do not
    manage their own connection pools.

    Error contract
    --------------
    All methods must raise one of the ProviderError subclasses on failure.
    Never raise raw httpx exceptions or ValueError — always wrap and re-raise.
    """

    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client
        self._cfg = get_settings()

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Machine-readable provider identifier, e.g. 'fmp'."""

    @property
    @abc.abstractmethod
    def supports_realtime(self) -> bool:
        """
        True if this provider serves real-time / intraday price data.
        False for providers that only serve end-of-day or fundamental data.
        """

    # ── Company search / profile ───────────────────────────────────────────

    @abc.abstractmethod
    async def search_companies(
        self,
        query: str,
        limit: int = 10,
    ) -> list[CompanySearchResult]:
        """
        Full-text ticker / name search.

        Args:
            query: Partial ticker or company name.
            limit: Maximum results to return.

        Returns:
            List of lightweight CompanySearchResult, sorted by relevance.

        Raises:
            ProviderError subclass on failure.
        """

    @abc.abstractmethod
    async def get_company_profile(self, ticker: str) -> CompanyProfile:
        """
        Fetch static company metadata.

        Returns:
            CompanyProfile with sector, industry, CIK, description, etc.
        """

    # ── Financial statements ───────────────────────────────────────────────

    @abc.abstractmethod
    async def get_income_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[IncomeStatement]:
        """
        Retrieve annual (or quarterly) income statements.

        Args:
            ticker: Exchange ticker symbol.
            years:  How many periods to fetch (default: 5 years).
            quarterly: If True, return quarterly periods instead.

        Returns:
            List ordered newest-first. Length may be < years if history
            is unavailable.
        """

    @abc.abstractmethod
    async def get_balance_sheets(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[BalanceSheet]:
        """Retrieve annual (or quarterly) balance sheets."""

    @abc.abstractmethod
    async def get_cash_flow_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[CashFlowStatement]:
        """Retrieve annual (or quarterly) cash flow statements."""

    # ── Market data ────────────────────────────────────────────────────────

    @abc.abstractmethod
    async def get_market_data(self, ticker: str) -> MarketData:
        """
        Fetch current market metrics: price, market cap, EV, beta,
        shares outstanding, and LTM multiples.
        """

    # ── Peers ──────────────────────────────────────────────────────────────

    async def get_peer_multiples(
        self,
        ticker: str,
        max_peers: int = 10,
    ) -> list[PeerMultiple]:
        """
        Fetch trading multiples for comparable peers.

        Default implementation returns an empty list — override if the
        provider supports peer screening (FMP does, EDGAR does not).
        """
        return []

    # ── Shared utilities ───────────────────────────────────────────────────

    def _timer(self) -> _Timer:
        return _Timer()

    async def _get(
        self,
        url: str,
        params: dict | None = None,
        timeout: float | None = None,
    ) -> dict:
        """
        Execute a GET request with unified error handling.

        Translates httpx / HTTP errors into typed ProviderError subclasses
        so callers never have to import httpx.
        """
        cfg = self._cfg
        timeout_ = timeout or cfg.http_read_timeout
        try:
            response = await self._client.get(
                url,
                params=params,
                timeout=httpx.Timeout(
                    connect=cfg.http_connect_timeout,
                    read=timeout_,
                    write=5.0,
                    pool=5.0,
                ),
            )
        except httpx.TimeoutException as exc:
            raise ProviderTimeoutError(self.name, f"Timeout fetching {url}") from exc
        except httpx.NetworkError as exc:
            raise ProviderUnavailableError(self.name, f"Network error: {exc}") from exc

        if response.status_code == 401:
            raise ProviderAuthError(self.name, "Invalid or missing API key", status_code=401)
        if response.status_code == 403:
            raise ProviderAuthError(self.name, "Access forbidden", status_code=403)
        if response.status_code == 429:
            retry_after = float(response.headers.get("Retry-After", 60))
            raise ProviderRateLimitError(self.name, retry_after_seconds=retry_after)
        if response.status_code >= 500:
            raise ProviderUnavailableError(
                self.name,
                f"Provider returned {response.status_code}",
                status_code=response.status_code,
            )

        try:
            return response.json()
        except Exception as exc:
            raise ProviderDataError(
                self.name, f"Non-JSON response from {url}: {response.text[:200]}"
            ) from exc

    @staticmethod
    def _safe_float(value: object) -> float | None:
        """Convert any numeric-ish value to float, returning None on failure."""
        if value is None:
            return None
        try:
            f = float(value)  # type: ignore[arg-type]
            return None if (f != f) else f   # NaN check
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _safe_int(value: object) -> int | None:
        """Convert to int, returning None on failure."""
        f = BaseFinancialProvider._safe_float(value)
        return int(f) if f is not None else None


# ── Shared HTTP client factory ─────────────────────────────────────────────────

@asynccontextmanager
async def build_http_client() -> AsyncIterator[httpx.AsyncClient]:
    """
    Application-lifetime httpx.AsyncClient context manager.

    Uses HTTP/2 where the server supports it (FMP does), and configures
    connection pooling appropriate for a single-server deployment.

    Usage (in main.py lifespan):
        async with build_http_client() as client:
            app.state.http_client = client
    """
    cfg = get_settings()
    limits = httpx.Limits(
        max_keepalive_connections=20,
        max_connections=40,
        keepalive_expiry=30.0,
    )
    headers = {
        "User-Agent": f"{cfg.app_name}/0.1 (research; contact@valupro.io)",
        "Accept": "application/json",
        "Accept-Encoding": "gzip, deflate, br",
    }
    async with httpx.AsyncClient(
        http2=True,
        limits=limits,
        headers=headers,
        follow_redirects=True,
    ) as client:
        yield client
