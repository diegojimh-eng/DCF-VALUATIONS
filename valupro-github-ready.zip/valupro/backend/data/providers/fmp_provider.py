"""
data/providers/fmp_provider.py
------------------------------
Financial Modeling Prep (FMP) provider — primary data source.

FMP delivers clean, structured JSON for all financial statements, market data,
and peer screening. Free tier: 250 req/day. Paid: 300 req/min.

API reference: https://financialmodelingprep.com/developer/docs

Endpoints used:
  GET /profile/{ticker}
  GET /income-statement/{ticker}?limit=N&period=annual
  GET /balance-sheet-statement/{ticker}?limit=N&period=annual
  GET /cash-flow-statement/{ticker}?limit=N&period=annual
  GET /quote/{ticker}
  GET /stock-screener?sector=...&country=US&limit=N   (peers)
  GET /search?query=...&limit=N
"""

from __future__ import annotations

import httpx
from datetime import date, datetime

from config import get_settings
from data.models import (
    BalanceSheet,
    CashFlowStatement,
    CompanyProfile,
    CompanySearchResult,
    IncomeStatement,
    MarketData,
    PeerMultiple,
)
from data.providers.base import (
    BaseFinancialProvider,
    ProviderAuthError,
    ProviderDataError,
)
from logger import get_logger

log = get_logger(__name__)


class FMPProvider(BaseFinancialProvider):
    """Financial Modeling Prep data provider."""

    def __init__(self, client: httpx.AsyncClient) -> None:
        super().__init__(client)
        cfg = get_settings()
        self._api_key = cfg.fmp_api_key.get_secret_value()
        self._base = cfg.fmp_base_url

    @property
    def name(self) -> str:
        return "fmp"

    @property
    def supports_realtime(self) -> bool:
        return True

    # ── Internal helpers ───────────────────────────────────────────────────

    def _params(self, extra: dict | None = None) -> dict:
        """Merge api key with any additional query params."""
        p: dict = {"apikey": self._api_key}
        if extra:
            p.update(extra)
        return p

    def _url(self, path: str) -> str:
        return f"{self._base}/{path.lstrip('/')}"

    async def _fmp_get(self, path: str, extra_params: dict | None = None) -> object:
        """GET an FMP endpoint, validating auth on the way."""
        if not self._api_key:
            raise ProviderAuthError(self.name, "FMP API key not configured")
        return await self._get(self._url(path), params=self._params(extra_params))

    @staticmethod
    def _parse_date(raw: str | None) -> date:
        """Parse 'YYYY-MM-DD' string to date, defaulting to today."""
        if not raw:
            return date.today()
        try:
            return date.fromisoformat(raw[:10])
        except (ValueError, TypeError):
            return date.today()

    # ── Company search & profile ───────────────────────────────────────────

    async def search_companies(
        self,
        query: str,
        limit: int = 10,
    ) -> list[CompanySearchResult]:
        raw = await self._fmp_get("search", {"query": query, "limit": limit})
        if not isinstance(raw, list):
            return []
        results = []
        for item in raw:
            results.append(
                CompanySearchResult(
                    ticker=item.get("symbol", ""),
                    company_name=item.get("name", ""),
                    exchange=item.get("stockExchange"),
                    currency=item.get("currency"),
                    source_provider=self.name,
                )
            )
        return results

    async def get_company_profile(self, ticker: str) -> CompanyProfile:
        raw = await self._fmp_get(f"profile/{ticker}")
        if not isinstance(raw, list) or not raw:
            raise ProviderDataError(
                self.name, f"No profile data returned for {ticker}"
            )
        d = raw[0]
        return CompanyProfile(
            ticker=d.get("symbol", ticker),
            company_name=d.get("companyName", ""),
            exchange=d.get("exchangeShortName"),
            currency=d.get("currency", "USD"),
            country=d.get("country"),
            sector=d.get("sector"),
            industry=d.get("industry"),
            description=d.get("description"),
            website=d.get("website"),
            ceo=d.get("ceo"),
            employees=self._safe_int(d.get("fullTimeEmployees")),
            isin=d.get("isin"),
            source_provider=self.name,
        )

    # ── Income Statement ───────────────────────────────────────────────────

    async def get_income_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[IncomeStatement]:
        period = "quarter" if quarterly else "annual"
        raw = await self._fmp_get(
            f"income-statement/{ticker}",
            {"limit": years, "period": period},
        )
        if not isinstance(raw, list):
            raise ProviderDataError(self.name, f"Unexpected IS response for {ticker}")

        statements = []
        for d in raw:
            period_end = self._parse_date(d.get("date"))
            revenue = self._safe_float(d.get("revenue"))
            gross_profit = self._safe_float(d.get("grossProfit"))
            ebitda = self._safe_float(d.get("ebitda"))
            net_income = self._safe_float(d.get("netIncome"))
            da = self._safe_float(d.get("depreciationAndAmortization"))
            operating_income = self._safe_float(d.get("operatingIncome"))

            statements.append(
                IncomeStatement(
                    ticker=ticker,
                    period_type="quarterly" if quarterly else "annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    currency=d.get("reportedCurrency", "USD"),
                    source_provider=self.name,
                    # Revenue
                    revenue=revenue,
                    # Cost & profit
                    cost_of_revenue=self._safe_float(d.get("costOfRevenue")),
                    gross_profit=gross_profit,
                    # Operating
                    research_and_development=self._safe_float(d.get("researchAndDevelopmentExpenses")),
                    selling_general_administrative=self._safe_float(d.get("sellingGeneralAndAdministrativeExpenses")),
                    operating_expenses=self._safe_float(d.get("operatingExpenses")),
                    operating_income=operating_income,
                    ebitda=ebitda,
                    depreciation_amortisation=da,
                    # Below the line
                    interest_expense=self._safe_float(d.get("interestExpense")),
                    interest_income=self._safe_float(d.get("interestIncome")),
                    pretax_income=self._safe_float(d.get("incomeBeforeTax")),
                    income_tax_expense=self._safe_float(d.get("incomeTaxExpense")),
                    # Bottom line
                    net_income=net_income,
                    net_income_common=self._safe_float(d.get("netIncomeCommonShareholders") or d.get("netIncome")),
                    eps_basic=self._safe_float(d.get("epsDiluted")),
                    eps_diluted=self._safe_float(d.get("epsDiluted")),
                    weighted_avg_shares_basic=self._safe_float(d.get("weightedAverageShsOut")),
                    weighted_avg_shares_diluted=self._safe_float(d.get("weightedAverageShsOutDil")),
                    dividends_per_share=self._safe_float(d.get("dividendsPerShareDeclarations")),
                )
            )

        log.debug("fmp.income_statements.fetched", ticker=ticker, count=len(statements))
        return statements

    # ── Balance Sheet ──────────────────────────────────────────────────────

    async def get_balance_sheets(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[BalanceSheet]:
        period = "quarter" if quarterly else "annual"
        raw = await self._fmp_get(
            f"balance-sheet-statement/{ticker}",
            {"limit": years, "period": period},
        )
        if not isinstance(raw, list):
            raise ProviderDataError(self.name, f"Unexpected BS response for {ticker}")

        sheets = []
        for d in raw:
            period_end = self._parse_date(d.get("date"))
            sheets.append(
                BalanceSheet(
                    ticker=ticker,
                    period_type="quarterly" if quarterly else "annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    currency=d.get("reportedCurrency", "USD"),
                    source_provider=self.name,
                    # Current assets
                    cash_and_equivalents=self._safe_float(d.get("cashAndCashEquivalents")),
                    short_term_investments=self._safe_float(d.get("shortTermInvestments")),
                    accounts_receivable=self._safe_float(d.get("netReceivables")),
                    inventory=self._safe_float(d.get("inventory")),
                    other_current_assets=self._safe_float(d.get("otherCurrentAssets")),
                    total_current_assets=self._safe_float(d.get("totalCurrentAssets")),
                    # Non-current assets
                    property_plant_equipment_net=self._safe_float(d.get("propertyPlantEquipmentNet")),
                    goodwill=self._safe_float(d.get("goodwill")),
                    intangible_assets=self._safe_float(d.get("intangibleAssets")),
                    long_term_investments=self._safe_float(d.get("longTermInvestments")),
                    other_non_current_assets=self._safe_float(d.get("otherNonCurrentAssets")),
                    total_non_current_assets=self._safe_float(d.get("totalNonCurrentAssets")),
                    total_assets=self._safe_float(d.get("totalAssets")),
                    # Current liabilities
                    accounts_payable=self._safe_float(d.get("accountPayables")),
                    short_term_debt=self._safe_float(d.get("shortTermDebt")),
                    deferred_revenue_current=self._safe_float(d.get("deferredRevenue")),
                    other_current_liabilities=self._safe_float(d.get("otherCurrentLiabilities")),
                    total_current_liabilities=self._safe_float(d.get("totalCurrentLiabilities")),
                    # Non-current liabilities
                    long_term_debt=self._safe_float(d.get("longTermDebt")),
                    deferred_tax_liabilities=self._safe_float(d.get("deferredTaxLiabilitiesNonCurrent")),
                    other_non_current_liabilities=self._safe_float(d.get("otherNonCurrentLiabilities")),
                    total_non_current_liabilities=self._safe_float(d.get("totalNonCurrentLiabilities")),
                    total_liabilities=self._safe_float(d.get("totalLiabilities")),
                    # Equity
                    common_stock=self._safe_float(d.get("commonStock")),
                    retained_earnings=self._safe_float(d.get("retainedEarnings")),
                    additional_paid_in_capital=self._safe_float(d.get("additionalPaidInCapital")),
                    accumulated_other_comprehensive_income=self._safe_float(d.get("accumulatedOtherComprehensiveIncomeLoss")),
                    total_stockholders_equity=self._safe_float(d.get("totalStockholdersEquity")),
                )
            )

        log.debug("fmp.balance_sheets.fetched", ticker=ticker, count=len(sheets))
        return sheets

    # ── Cash Flow Statement ────────────────────────────────────────────────

    async def get_cash_flow_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[CashFlowStatement]:
        period = "quarter" if quarterly else "annual"
        raw = await self._fmp_get(
            f"cash-flow-statement/{ticker}",
            {"limit": years, "period": period},
        )
        if not isinstance(raw, list):
            raise ProviderDataError(self.name, f"Unexpected CFS response for {ticker}")

        statements = []
        for d in raw:
            period_end = self._parse_date(d.get("date"))
            statements.append(
                CashFlowStatement(
                    ticker=ticker,
                    period_type="quarterly" if quarterly else "annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    currency=d.get("reportedCurrency", "USD"),
                    source_provider=self.name,
                    # Operating
                    net_income=self._safe_float(d.get("netIncome")),
                    depreciation_amortisation=self._safe_float(d.get("depreciationAndAmortization")),
                    stock_based_compensation=self._safe_float(d.get("stockBasedCompensation")),
                    deferred_income_tax=self._safe_float(d.get("deferredIncomeTax")),
                    change_in_working_capital=self._safe_float(d.get("changeInWorkingCapital")),
                    accounts_receivable_change=self._safe_float(d.get("accountsReceivables")),
                    inventory_change=self._safe_float(d.get("inventory")),
                    accounts_payable_change=self._safe_float(d.get("accountsPayables")),
                    other_operating_activities=self._safe_float(d.get("otherWorkingCapital")),
                    operating_cash_flow=self._safe_float(d.get("operatingCashFlow")),
                    # Investing
                    capital_expenditures=self._safe_float(d.get("capitalExpenditure")),
                    acquisitions=self._safe_float(d.get("acquisitionsNet")),
                    purchases_of_investments=self._safe_float(d.get("purchasesOfInvestments")),
                    sales_of_investments=self._safe_float(d.get("salesMaturitiesOfInvestments")),
                    other_investing_activities=self._safe_float(d.get("otherInvestingActivities")),
                    investing_cash_flow=self._safe_float(d.get("investingCashFlow") or d.get("netCashUsedForInvestingActivites")),
                    # Financing
                    dividends_paid=self._safe_float(d.get("dividendsPaid")),
                    share_repurchases=self._safe_float(d.get("commonStockRepurchased")),
                    debt_repayment=self._safe_float(d.get("repaymentOfDebt")),
                    debt_issuance=self._safe_float(d.get("debtRepayment")),
                    other_financing_activities=self._safe_float(d.get("otherFinancingActivities")),
                    financing_cash_flow=self._safe_float(d.get("financingCashFlow") or d.get("netCashUsedProvidedByFinancingActivities")),
                    # Summary
                    net_change_in_cash=self._safe_float(d.get("netChangeInCash")),
                    free_cash_flow=self._safe_float(d.get("freeCashFlow")),
                )
            )

        log.debug("fmp.cash_flows.fetched", ticker=ticker, count=len(statements))
        return statements

    # ── Market Data ────────────────────────────────────────────────────────

    async def get_market_data(self, ticker: str) -> MarketData:
        # FMP /quote returns current price, market cap, beta, EV, PE
        raw = await self._fmp_get(f"quote/{ticker}")
        if not isinstance(raw, list) or not raw:
            raise ProviderDataError(self.name, f"No quote data for {ticker}")
        q = raw[0]

        # EV and shares from /key-metrics (last annual)
        key_raw = await self._fmp_get(f"key-metrics/{ticker}", {"limit": 1})
        km = key_raw[0] if isinstance(key_raw, list) and key_raw else {}

        return MarketData(
            ticker=ticker,
            source_provider=self.name,
            # Price
            current_price=self._safe_float(q.get("price")),
            fifty_two_week_high=self._safe_float(q.get("yearHigh")),
            fifty_two_week_low=self._safe_float(q.get("yearLow")),
            price_change_1d=self._safe_float(q.get("change")),
            price_change_pct_1d=self._safe_float(q.get("changesPercentage")),
            # Capitalisation
            market_cap=self._safe_float(q.get("marketCap")),
            enterprise_value=self._safe_float(km.get("enterpriseValue") or q.get("marketCap")),
            shares_outstanding=self._safe_float(q.get("sharesOutstanding")),
            # Risk
            beta=self._safe_float(q.get("beta")),
            # Multiples
            pe_ratio_ttm=self._safe_float(q.get("pe")),
            ev_ebitda_ttm=self._safe_float(km.get("enterpriseValueOverEBITDA")),
            ev_revenue_ttm=self._safe_float(km.get("evToSales")),
            pb_ratio=self._safe_float(km.get("pbRatio")),
            ps_ratio_ttm=self._safe_float(km.get("priceToSalesRatio")),
            # Dividends
            dividend_yield=self._safe_float(q.get("earningsAnnouncement")),   # approximated
        )

    # ── Peer multiples ─────────────────────────────────────────────────────

    async def get_peer_multiples(
        self,
        ticker: str,
        max_peers: int = 10,
    ) -> list[PeerMultiple]:
        # Step 1: get the subject's profile to know sector
        profile = await self.get_company_profile(ticker)
        if not profile.sector:
            log.warning("fmp.peers.no_sector", ticker=ticker)
            return []

        # Step 2: screen for peers in same sector
        screener_raw = await self._fmp_get(
            "stock-screener",
            {
                "sector": profile.sector,
                "country": profile.country or "US",
                "limit": max_peers + 5,   # fetch a few extra to filter out subject
                "exchange": "NASDAQ,NYSE",
            },
        )
        if not isinstance(screener_raw, list):
            return []

        peers = []
        for item in screener_raw:
            peer_ticker = item.get("symbol", "")
            if peer_ticker.upper() == ticker.upper():
                continue    # exclude the subject itself
            if len(peers) >= max_peers:
                break

            peers.append(
                PeerMultiple(
                    ticker=peer_ticker,
                    company_name=item.get("companyName", ""),
                    sector=item.get("sector"),
                    industry=item.get("industry"),
                    market_cap=self._safe_float(item.get("marketCap")),
                    ev_ebitda=self._safe_float(item.get("enterpriseValueEbitdaRatio")),
                    pe_ratio=self._safe_float(item.get("priceEarningsRatio")),
                    revenue_growth_1y=self._safe_float(item.get("revenueGrowth")),
                    ebitda_margin=self._safe_float(item.get("ebitdaMargin")),
                    source_provider=self.name,
                )
            )

        log.debug("fmp.peers.fetched", ticker=ticker, count=len(peers))
        return peers
