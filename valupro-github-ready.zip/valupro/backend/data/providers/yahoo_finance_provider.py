"""
data/providers/yahoo_finance_provider.py
-----------------------------------------
Yahoo Finance provider using the yfinance library.

No API key required. Used as a tertiary fallback when both FMP and
Alpha Vantage are unavailable or rate-limited.

yfinance wraps Yahoo Finance's private API — it can break without notice
when Yahoo changes its endpoints. This provider wraps all calls in
exception handlers to ensure graceful degradation.

Limitations:
  • Rate limits are unofficial and undocumented (be conservative)
  • yfinance is synchronous; we run it in a thread pool executor
  • EDGAR-grade disclosure data is NOT available here
  • Peer screening not supported
"""

from __future__ import annotations

import asyncio
from datetime import date, datetime
from functools import partial

import httpx
import yfinance as yf

from data.models import (
    BalanceSheet,
    CashFlowStatement,
    CompanyProfile,
    CompanySearchResult,
    IncomeStatement,
    MarketData,
)
from data.providers.base import BaseFinancialProvider, ProviderDataError
from logger import get_logger

log = get_logger(__name__)


class YahooFinanceProvider(BaseFinancialProvider):
    """Yahoo Finance (yfinance) provider — free fallback."""

    def __init__(self, client: httpx.AsyncClient) -> None:
        super().__init__(client)
        self._loop = asyncio.get_event_loop()

    @property
    def name(self) -> str:
        return "yahoo_finance"

    @property
    def supports_realtime(self) -> bool:
        return True   # 15-minute delayed quotes on free tier

    # ── Helper to run blocking yfinance in thread pool ─────────────────────

    async def _run_sync(self, func: partial) -> object:  # type: ignore[type-arg]
        """Execute a blocking yfinance call in the default thread pool."""
        return await self._loop.run_in_executor(None, func)

    def _ticker_obj(self, ticker: str) -> yf.Ticker:
        return yf.Ticker(ticker)

    @staticmethod
    def _to_float(val: object) -> float | None:
        if val is None:
            return None
        try:
            f = float(val)  # type: ignore[arg-type]
            return None if f != f else f   # NaN guard
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _parse_date_from_timestamp(ts: object) -> date:
        """yfinance returns pandas Timestamps as index keys."""
        try:
            return ts.date()  # type: ignore[union-attr]
        except AttributeError:
            try:
                return datetime.utcfromtimestamp(float(ts)).date()  # type: ignore[arg-type]
            except Exception:
                return date.today()

    # ── Company search (limited — yfinance has no search API) ─────────────

    async def search_companies(
        self,
        query: str,
        limit: int = 10,
    ) -> list[CompanySearchResult]:
        """
        yfinance has no search endpoint.
        Return a single result if the query is an exact ticker.
        """
        try:
            t = await self._run_sync(partial(self._ticker_obj, query.upper()))
            info = await self._run_sync(partial(lambda tk: tk.info, t))
            if not info or "symbol" not in info:
                return []
            return [
                CompanySearchResult(
                    ticker=info["symbol"],
                    company_name=info.get("longName", info["symbol"]),
                    exchange=info.get("exchange"),
                    sector=info.get("sector"),
                    currency=info.get("currency"),
                    source_provider=self.name,
                )
            ]
        except Exception as exc:
            log.warning("yahoo.search.failed", query=query, error=str(exc))
            return []

    async def get_company_profile(self, ticker: str) -> CompanyProfile:
        try:
            t = self._ticker_obj(ticker)
            info: dict = await self._run_sync(partial(lambda tk: tk.info, t))  # type: ignore[arg-type]
        except Exception as exc:
            raise ProviderDataError(self.name, f"yfinance info failed: {exc}") from exc

        if not info:
            raise ProviderDataError(self.name, f"No info returned for {ticker}")

        return CompanyProfile(
            ticker=info.get("symbol", ticker),
            company_name=info.get("longName", ticker),
            exchange=info.get("exchange"),
            currency=info.get("currency", "USD"),
            country=info.get("country"),
            sector=info.get("sector"),
            industry=info.get("industry"),
            description=info.get("longBusinessSummary"),
            website=info.get("website"),
            ceo=info.get("companyOfficers", [{}])[0].get("name") if info.get("companyOfficers") else None,
            employees=self._safe_int(info.get("fullTimeEmployees")),
            source_provider=self.name,
        )

    # ── Income Statement ───────────────────────────────────────────────────

    async def get_income_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[IncomeStatement]:
        try:
            t = self._ticker_obj(ticker)
            raw = await self._run_sync(
                partial(lambda tk: tk.quarterly_income_stmt if quarterly else tk.income_stmt, t)
            )
        except Exception as exc:
            raise ProviderDataError(self.name, f"yfinance IS failed: {exc}") from exc

        if raw is None or raw.empty:
            raise ProviderDataError(self.name, f"Empty income statement for {ticker}")

        statements = []
        # yfinance returns columns as period dates (most recent first)
        for col in list(raw.columns)[:years]:
            s = raw[col]
            period_end = self._parse_date_from_timestamp(col)
            revenue = self._to_float(s.get("Total Revenue"))
            gross_profit = self._to_float(s.get("Gross Profit"))
            ebitda = self._to_float(s.get("EBITDA"))
            net_income = self._to_float(s.get("Net Income"))
            da = self._to_float(s.get("Reconciled Depreciation") or s.get("Depreciation And Amortization"))

            statements.append(
                IncomeStatement(
                    ticker=ticker,
                    period_type="quarterly" if quarterly else "annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    source_provider=self.name,
                    revenue=revenue,
                    gross_profit=gross_profit,
                    cost_of_revenue=self._to_float(s.get("Cost Of Revenue")),
                    research_and_development=self._to_float(s.get("Research And Development")),
                    selling_general_administrative=self._to_float(s.get("Selling General And Administration")),
                    operating_income=self._to_float(s.get("Operating Income") or s.get("EBIT")),
                    ebitda=ebitda,
                    depreciation_amortisation=da,
                    interest_expense=self._to_float(s.get("Interest Expense")),
                    pretax_income=self._to_float(s.get("Pretax Income")),
                    income_tax_expense=self._to_float(s.get("Tax Provision")),
                    net_income=net_income,
                    eps_diluted=self._to_float(s.get("Diluted EPS")),
                    weighted_avg_shares_diluted=self._to_float(s.get("Diluted Average Shares")),
                )
            )

        log.debug("yahoo.income_statements.fetched", ticker=ticker, count=len(statements))
        return statements

    # ── Balance Sheet ──────────────────────────────────────────────────────

    async def get_balance_sheets(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[BalanceSheet]:
        try:
            t = self._ticker_obj(ticker)
            raw = await self._run_sync(
                partial(lambda tk: tk.quarterly_balance_sheet if quarterly else tk.balance_sheet, t)
            )
        except Exception as exc:
            raise ProviderDataError(self.name, f"yfinance BS failed: {exc}") from exc

        if raw is None or raw.empty:
            raise ProviderDataError(self.name, f"Empty balance sheet for {ticker}")

        sheets = []
        for col in list(raw.columns)[:years]:
            s = raw[col]
            period_end = self._parse_date_from_timestamp(col)
            sheets.append(
                BalanceSheet(
                    ticker=ticker,
                    period_type="quarterly" if quarterly else "annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    source_provider=self.name,
                    cash_and_equivalents=self._to_float(s.get("Cash And Cash Equivalents") or s.get("Cash Cash Equivalents And Short Term Investments")),
                    accounts_receivable=self._to_float(s.get("Receivables")),
                    inventory=self._to_float(s.get("Inventory")),
                    total_current_assets=self._to_float(s.get("Current Assets")),
                    property_plant_equipment_net=self._to_float(s.get("Net PPE")),
                    goodwill=self._to_float(s.get("Goodwill")),
                    intangible_assets=self._to_float(s.get("Other Intangible Assets")),
                    total_assets=self._to_float(s.get("Total Assets")),
                    accounts_payable=self._to_float(s.get("Payables")),
                    short_term_debt=self._to_float(s.get("Current Debt") or s.get("Short Term Debt")),
                    total_current_liabilities=self._to_float(s.get("Current Liabilities")),
                    long_term_debt=self._to_float(s.get("Long Term Debt")),
                    total_liabilities=self._to_float(s.get("Total Liabilities Net Minority Interest")),
                    retained_earnings=self._to_float(s.get("Retained Earnings")),
                    total_stockholders_equity=self._to_float(s.get("Stockholders Equity") or s.get("Common Stock Equity")),
                )
            )

        log.debug("yahoo.balance_sheets.fetched", ticker=ticker, count=len(sheets))
        return sheets

    # ── Cash Flow Statement ────────────────────────────────────────────────

    async def get_cash_flow_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[CashFlowStatement]:
        try:
            t = self._ticker_obj(ticker)
            raw = await self._run_sync(
                partial(lambda tk: tk.quarterly_cashflow if quarterly else tk.cashflow, t)
            )
        except Exception as exc:
            raise ProviderDataError(self.name, f"yfinance CFS failed: {exc}") from exc

        if raw is None or raw.empty:
            raise ProviderDataError(self.name, f"Empty cash flow for {ticker}")

        statements = []
        for col in list(raw.columns)[:years]:
            s = raw[col]
            period_end = self._parse_date_from_timestamp(col)
            statements.append(
                CashFlowStatement(
                    ticker=ticker,
                    period_type="quarterly" if quarterly else "annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    source_provider=self.name,
                    net_income=self._to_float(s.get("Net Income")),
                    depreciation_amortisation=self._to_float(s.get("Depreciation And Amortization") or s.get("Depreciation Amortization Depletion")),
                    stock_based_compensation=self._to_float(s.get("Stock Based Compensation")),
                    change_in_working_capital=self._to_float(s.get("Change In Working Capital")),
                    operating_cash_flow=self._to_float(s.get("Operating Cash Flow")),
                    capital_expenditures=self._to_float(s.get("Capital Expenditure")),
                    investing_cash_flow=self._to_float(s.get("Investing Cash Flow")),
                    dividends_paid=self._to_float(s.get("Common Stock Dividend Paid") or s.get("Dividends Paid")),
                    share_repurchases=self._to_float(s.get("Repurchase Of Capital Stock") or s.get("Common Stock Issuance")),
                    financing_cash_flow=self._to_float(s.get("Financing Cash Flow")),
                    net_change_in_cash=self._to_float(s.get("Changes In Cash")),
                    free_cash_flow=self._to_float(s.get("Free Cash Flow")),
                )
            )

        log.debug("yahoo.cash_flows.fetched", ticker=ticker, count=len(statements))
        return statements

    # ── Market Data ────────────────────────────────────────────────────────

    async def get_market_data(self, ticker: str) -> MarketData:
        try:
            t = self._ticker_obj(ticker)
            info: dict = await self._run_sync(partial(lambda tk: tk.info, t))  # type: ignore[arg-type]
        except Exception as exc:
            raise ProviderDataError(self.name, f"yfinance market data failed: {exc}") from exc

        if not info:
            raise ProviderDataError(self.name, f"No market data for {ticker}")

        return MarketData(
            ticker=ticker,
            source_provider=self.name,
            current_price=self._to_float(info.get("currentPrice") or info.get("regularMarketPrice")),
            fifty_two_week_high=self._to_float(info.get("fiftyTwoWeekHigh")),
            fifty_two_week_low=self._to_float(info.get("fiftyTwoWeekLow")),
            market_cap=self._to_float(info.get("marketCap")),
            enterprise_value=self._to_float(info.get("enterpriseValue")),
            shares_outstanding=self._to_float(info.get("sharesOutstanding")),
            shares_float=self._to_float(info.get("floatShares")),
            beta=self._to_float(info.get("beta")),
            pe_ratio_ttm=self._to_float(info.get("trailingPE")),
            ps_ratio_ttm=self._to_float(info.get("priceToSalesTrailing12Months")),
            pb_ratio=self._to_float(info.get("priceToBook")),
            ev_ebitda_ttm=self._to_float(info.get("enterpriseToEbitda")),
            ev_revenue_ttm=self._to_float(info.get("enterpriseToRevenue")),
            dividend_yield=self._to_float(info.get("dividendYield")),
            dividend_per_share_ttm=self._to_float(info.get("trailingAnnualDividendRate")),
            payout_ratio=self._to_float(info.get("payoutRatio")),
        )
