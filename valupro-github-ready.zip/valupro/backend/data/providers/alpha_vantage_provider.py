"""
data/providers/alpha_vantage_provider.py
-----------------------------------------
Alpha Vantage provider — secondary fallback.

Free tier: 25 req/day, 5 req/min.
Premium: 75–1200 req/min depending on plan.

API reference: https://www.alphavantage.co/documentation/

Functions used:
  OVERVIEW                    — company profile + key metrics
  INCOME_STATEMENT            — annual/quarterly IS
  BALANCE_SHEET               — annual/quarterly BS
  CASH_FLOW                   — annual/quarterly CFS
  GLOBAL_QUOTE                — real-time price quote
  SYMBOL_SEARCH               — company search

Alpha Vantage returns all numbers as strings — robust parsing is critical.
"""

from __future__ import annotations

from datetime import date, datetime

import httpx

from config import get_settings
from data.models import (
    BalanceSheet,
    CashFlowStatement,
    CompanyProfile,
    CompanySearchResult,
    IncomeStatement,
    MarketData,
)
from data.providers.base import (
    BaseFinancialProvider,
    ProviderAuthError,
    ProviderDataError,
)
from logger import get_logger

log = get_logger(__name__)

_NONE_STRINGS = {"None", "none", "N/A", "n/a", "-", "", "0.0000"}


def _av_float(val: object) -> float | None:
    """Parse Alpha Vantage's string-encoded numbers."""
    if val is None:
        return None
    s = str(val).strip()
    if s in _NONE_STRINGS:
        return None
    try:
        f = float(s)
        return None if f != f else f
    except (ValueError, TypeError):
        return None


def _av_date(raw: str | None) -> date:
    if not raw:
        return date.today()
    try:
        return date.fromisoformat(raw[:10])
    except (ValueError, TypeError):
        return date.today()


class AlphaVantageProvider(BaseFinancialProvider):
    """Alpha Vantage data provider."""

    def __init__(self, client: httpx.AsyncClient) -> None:
        super().__init__(client)
        cfg = get_settings()
        self._api_key = cfg.alpha_vantage_api_key.get_secret_value()
        self._base = cfg.alpha_vantage_base_url

    @property
    def name(self) -> str:
        return "alpha_vantage"

    @property
    def supports_realtime(self) -> bool:
        return True

    def _params(self, function: str, symbol: str | None = None, extra: dict | None = None) -> dict:
        p: dict = {"function": function, "apikey": self._api_key}
        if symbol:
            p["symbol"] = symbol
        if extra:
            p.update(extra)
        return p

    def _check_key(self) -> None:
        if not self._api_key:
            raise ProviderAuthError(self.name, "Alpha Vantage API key not configured")

    async def _av_get(self, function: str, symbol: str | None = None, extra: dict | None = None) -> dict:
        self._check_key()
        raw = await self._get(self._base, params=self._params(function, symbol, extra))
        if not isinstance(raw, dict):
            raise ProviderDataError(self.name, f"Non-dict response for function={function}")
        # AV encodes errors inside the response body
        if "Error Message" in raw:
            raise ProviderDataError(self.name, raw["Error Message"])
        if "Note" in raw:
            # Rate limit note
            raise ProviderDataError(self.name, f"AV rate limit: {raw['Note']}")
        if "Information" in raw:
            raise ProviderDataError(self.name, f"AV info: {raw['Information']}")
        return raw

    # ── Company search & profile ───────────────────────────────────────────

    async def search_companies(
        self,
        query: str,
        limit: int = 10,
    ) -> list[CompanySearchResult]:
        raw = await self._av_get("SYMBOL_SEARCH", extra={"keywords": query})
        matches = raw.get("bestMatches", [])
        return [
            CompanySearchResult(
                ticker=m.get("1. symbol", ""),
                company_name=m.get("2. name", ""),
                exchange=m.get("4. region"),
                currency=m.get("8. currency"),
                source_provider=self.name,
            )
            for m in matches[:limit]
        ]

    async def get_company_profile(self, ticker: str) -> CompanyProfile:
        raw = await self._av_get("OVERVIEW", symbol=ticker)
        if not raw or raw.get("Symbol") is None:
            raise ProviderDataError(self.name, f"No OVERVIEW for {ticker}")

        return CompanyProfile(
            ticker=raw.get("Symbol", ticker),
            company_name=raw.get("Name", ticker),
            exchange=raw.get("Exchange"),
            currency=raw.get("Currency", "USD"),
            country=raw.get("Country"),
            sector=raw.get("Sector"),
            industry=raw.get("Industry"),
            description=raw.get("Description"),
            website=raw.get("OfficialSite"),
            cik=raw.get("CIK"),
            isin=raw.get("ISIN"),
            source_provider=self.name,
        )

    # ── Income Statement ───────────────────────────────────────────────────

    async def get_income_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[IncomeStatement]:
        raw = await self._av_get("INCOME_STATEMENT", symbol=ticker)
        key = "quarterlyReports" if quarterly else "annualReports"
        reports = raw.get(key, [])[:years]

        statements = []
        for r in reports:
            period_end = _av_date(r.get("fiscalDateEnding"))
            revenue = _av_float(r.get("totalRevenue"))
            gross_profit = _av_float(r.get("grossProfit"))
            ebitda = _av_float(r.get("ebitda"))
            net_income = _av_float(r.get("netIncome"))
            da = _av_float(r.get("depreciationAndAmortization"))
            operating_income = _av_float(r.get("operatingIncome") or r.get("ebit"))

            statements.append(
                IncomeStatement(
                    ticker=ticker,
                    period_type="quarterly" if quarterly else "annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    currency=r.get("reportedCurrency", "USD"),
                    source_provider=self.name,
                    revenue=revenue,
                    gross_profit=gross_profit,
                    cost_of_revenue=_av_float(r.get("costOfRevenue")),
                    research_and_development=_av_float(r.get("researchAndDevelopment")),
                    selling_general_administrative=_av_float(r.get("sellingGeneralAndAdministrative")),
                    operating_expenses=_av_float(r.get("operatingExpenses") or r.get("totalOperatingExpense")),
                    operating_income=operating_income,
                    ebitda=ebitda,
                    depreciation_amortisation=da,
                    interest_expense=_av_float(r.get("interestExpense")),
                    pretax_income=_av_float(r.get("incomeBeforeTax")),
                    income_tax_expense=_av_float(r.get("incomeTaxExpense")),
                    net_income=net_income,
                    net_income_common=_av_float(r.get("netIncomeApplicableToCommonShares") or r.get("netIncome")),
                    eps_diluted=_av_float(r.get("dilutedEPS")),
                    weighted_avg_shares_diluted=_av_float(r.get("dilutedAverageShares")),
                )
            )

        log.debug("av.income_statements.fetched", ticker=ticker, count=len(statements))
        return statements

    # ── Balance Sheet ──────────────────────────────────────────────────────

    async def get_balance_sheets(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[BalanceSheet]:
        raw = await self._av_get("BALANCE_SHEET", symbol=ticker)
        key = "quarterlyReports" if quarterly else "annualReports"
        reports = raw.get(key, [])[:years]

        sheets = []
        for r in reports:
            period_end = _av_date(r.get("fiscalDateEnding"))
            sheets.append(
                BalanceSheet(
                    ticker=ticker,
                    period_type="quarterly" if quarterly else "annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    currency=r.get("reportedCurrency", "USD"),
                    source_provider=self.name,
                    cash_and_equivalents=_av_float(r.get("cashAndCashEquivalentsAtCarryingValue")),
                    short_term_investments=_av_float(r.get("shortTermInvestments")),
                    accounts_receivable=_av_float(r.get("currentNetReceivables")),
                    inventory=_av_float(r.get("inventory")),
                    total_current_assets=_av_float(r.get("totalCurrentAssets")),
                    property_plant_equipment_net=_av_float(r.get("propertyPlantEquipmentNet")),
                    goodwill=_av_float(r.get("goodwill")),
                    intangible_assets=_av_float(r.get("intangibleAssets")),
                    long_term_investments=_av_float(r.get("longTermInvestments")),
                    total_assets=_av_float(r.get("totalAssets")),
                    accounts_payable=_av_float(r.get("currentAccountsPayable")),
                    short_term_debt=_av_float(r.get("shortTermDebt") or r.get("currentDebt")),
                    total_current_liabilities=_av_float(r.get("totalCurrentLiabilities")),
                    long_term_debt=_av_float(r.get("longTermDebt")),
                    total_liabilities=_av_float(r.get("totalLiabilities")),
                    retained_earnings=_av_float(r.get("retainedEarnings")),
                    total_stockholders_equity=_av_float(r.get("totalShareholderEquity")),
                )
            )

        log.debug("av.balance_sheets.fetched", ticker=ticker, count=len(sheets))
        return sheets

    # ── Cash Flow Statement ────────────────────────────────────────────────

    async def get_cash_flow_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[CashFlowStatement]:
        raw = await self._av_get("CASH_FLOW", symbol=ticker)
        key = "quarterlyReports" if quarterly else "annualReports"
        reports = raw.get(key, [])[:years]

        statements = []
        for r in reports:
            period_end = _av_date(r.get("fiscalDateEnding"))
            statements.append(
                CashFlowStatement(
                    ticker=ticker,
                    period_type="quarterly" if quarterly else "annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    currency=r.get("reportedCurrency", "USD"),
                    source_provider=self.name,
                    net_income=_av_float(r.get("netIncome")),
                    depreciation_amortisation=_av_float(r.get("depreciationDepletionAndAmortization")),
                    stock_based_compensation=_av_float(r.get("capitalExpenditures")),  # AV label varies
                    change_in_working_capital=_av_float(r.get("changeInOperatingLiabilities")),
                    operating_cash_flow=_av_float(r.get("operatingCashflow")),
                    capital_expenditures=_av_float(r.get("capitalExpenditures")),
                    investing_cash_flow=_av_float(r.get("cashflowFromInvestment")),
                    dividends_paid=_av_float(r.get("dividendPayout") or r.get("dividendPayoutCommonStock")),
                    share_repurchases=_av_float(r.get("paymentsForRepurchaseOfCommonStock")),
                    debt_repayment=_av_float(r.get("proceedsFromRepaymentsOfShortTermDebt")),
                    financing_cash_flow=_av_float(r.get("cashflowFromFinancing")),
                    net_change_in_cash=_av_float(r.get("changeInCashAndCashEquivalents")),
                )
            )

        log.debug("av.cash_flows.fetched", ticker=ticker, count=len(statements))
        return statements

    # ── Market Data ────────────────────────────────────────────────────────

    async def get_market_data(self, ticker: str) -> MarketData:
        # GLOBAL_QUOTE for price; OVERVIEW for beta, EV, market cap, multiples
        quote_raw, overview_raw = await _gather_two(
            self._av_get("GLOBAL_QUOTE", symbol=ticker),
            self._av_get("OVERVIEW", symbol=ticker),
        )

        q = quote_raw.get("Global Quote", {})
        ov = overview_raw

        return MarketData(
            ticker=ticker,
            source_provider=self.name,
            current_price=_av_float(q.get("05. price")),
            fifty_two_week_high=_av_float(q.get("03. high") or ov.get("52WeekHigh")),
            fifty_two_week_low=_av_float(q.get("04. low") or ov.get("52WeekLow")),
            price_change_1d=_av_float(q.get("09. change")),
            price_change_pct_1d=_av_float((q.get("10. change percent") or "0").replace("%", "")),
            market_cap=_av_float(ov.get("MarketCapitalization")),
            shares_outstanding=_av_float(ov.get("SharesOutstanding")),
            beta=_av_float(ov.get("Beta")),
            pe_ratio_ttm=_av_float(ov.get("TrailingPE")),
            pb_ratio=_av_float(ov.get("PriceToBookRatio")),
            ps_ratio_ttm=_av_float(ov.get("PriceToSalesRatioTTM")),
            ev_ebitda_ttm=_av_float(ov.get("EVToEBITDA")),
            ev_revenue_ttm=_av_float(ov.get("EVToRevenue")),
            dividend_yield=_av_float(ov.get("DividendYield")),
            dividend_per_share_ttm=_av_float(ov.get("DividendPerShare")),
        )


# ── Helper for concurrent requests ────────────────────────────────────────────

import asyncio as _asyncio  # noqa: E402 — local import after class definition


async def _gather_two(coro1: object, coro2: object) -> tuple[dict, dict]:
    """Run two coroutines concurrently, returning both results."""
    results = await _asyncio.gather(coro1, coro2, return_exceptions=True)  # type: ignore[arg-type]
    r1 = results[0] if not isinstance(results[0], Exception) else {}
    r2 = results[1] if not isinstance(results[1], Exception) else {}
    return r1, r2  # type: ignore[return-value]
