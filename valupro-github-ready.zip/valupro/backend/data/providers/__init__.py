"""
data/providers/__init__.py
--------------------------
Provider registry and factory functions.

Adding a new provider:
  1. Create data/providers/my_provider.py implementing BaseFinancialProvider
  2. Import the class here
  3. Add it to PROVIDER_REGISTRY
  4. Add its name to Settings.provider_priority
"""

from .alpha_vantage_provider import AlphaVantageProvider
from .base import (
    BaseFinancialProvider,
    ProviderAuthError,
    ProviderDataError,
    ProviderError,
    ProviderRateLimitError,
    ProviderTimeoutError,
    ProviderUnavailableError,
    build_http_client,
)
from .fmp_provider import FMPProvider
from .sec_edgar_provider import SECEDGARProvider
from .yahoo_finance_provider import YahooFinanceProvider

# Maps provider name → class
PROVIDER_REGISTRY: dict[str, type[BaseFinancialProvider]] = {
    "fmp": FMPProvider,
    "alpha_vantage": AlphaVantageProvider,
    "sec_edgar": SECEDGARProvider,
    "yahoo_finance": YahooFinanceProvider,
}

__all__ = [
    "AlphaVantageProvider",
    "BaseFinancialProvider",
    "FMPProvider",
    "PROVIDER_REGISTRY",
    "ProviderAuthError",
    "ProviderDataError",
    "ProviderError",
    "ProviderRateLimitError",
    "ProviderTimeoutError",
    "ProviderUnavailableError",
    "SECEDGARProvider",
    "YahooFinanceProvider",
    "build_http_client",
]
