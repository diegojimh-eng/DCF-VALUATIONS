"""
data/providers/sec_edgar_provider.py
--------------------------------------
SEC EDGAR provider — authoritative regulatory filing data.

No API key required. Public API under SEC fair-use policy.
Rate limit: 10 requests/second per IP (enforced by EDGAR).

API documentation: https://www.sec.gov/developer

Endpoints used:
  https://efts.sec.gov/LATEST/search-index?q="TICKER"&dateRange=custom&...
  https://data.sec.gov/submissions/CIK{cik}.json         — filing index
  https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json  — XBRL facts

XBRL companyfacts is the gold standard for fundamental data because it
maps directly to GAAP taxonomy concepts — no parsing ambiguity.

This provider is primarily useful for:
  • Cross-validating FMP / AV data with the primary source
  • Fetching data for companies not covered by commercial providers
  • Accessing historical data beyond what commercial APIs provide

Limitations:
  • EDGAR only covers US public companies
  • XBRL data quality varies by filing quality
  • No real-time price data
"""

from __future__ import annotations

import asyncio
from datetime import date
from typing import Any

import httpx

from config import get_settings
from data.models import (
    BalanceSheet,
    CashFlowStatement,
    CompanyProfile,
    CompanySearchResult,
    IncomeStatement,
    MarketData,
)
from data.providers.base import (
    BaseFinancialProvider,
    ProviderDataError,
    ProviderUnavailableError,
)
from logger import get_logger

log = get_logger(__name__)


# ── XBRL concept → our field mapping ──────────────────────────────────────────
# US-GAAP concept names that map to our standard fields.
# Lists are ordered by preference (most specific first).

_IS_CONCEPTS: dict[str, list[str]] = {
    "revenue": [
        "Revenues", "RevenueFromContractWithCustomerExcludingAssessedTax",
        "SalesRevenueNet", "SalesRevenueGoodsNet",
    ],
    "gross_profit": ["GrossProfit"],
    "operating_income": ["OperatingIncomeLoss"],
    "ebitda": [],   # not a GAAP concept — derived
    "depreciation_amortisation": [
        "DepreciationDepletionAndAmortization",
        "DepreciationAndAmortization",
    ],
    "interest_expense": ["InterestExpense", "InterestAndDebtExpense"],
    "pretax_income": ["IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest"],
    "income_tax_expense": ["IncomeTaxExpenseBenefit"],
    "net_income": ["NetIncomeLoss"],
    "eps_diluted": ["EarningsPerShareDiluted"],
    "weighted_avg_shares_diluted": ["WeightedAverageNumberOfDilutedSharesOutstanding"],
}

_BS_CONCEPTS: dict[str, list[str]] = {
    "cash_and_equivalents": ["CashAndCashEquivalentsAtCarryingValue"],
    "short_term_investments": ["ShortTermInvestments", "MarketableSecuritiesCurrent"],
    "accounts_receivable": ["AccountsReceivableNetCurrent"],
    "inventory": ["InventoryNet"],
    "total_current_assets": ["AssetsCurrent"],
    "property_plant_equipment_net": ["PropertyPlantAndEquipmentNet"],
    "goodwill": ["Goodwill"],
    "intangible_assets": ["IntangibleAssetsNetExcludingGoodwill"],
    "total_assets": ["Assets"],
    "accounts_payable": ["AccountsPayableCurrent"],
    "short_term_debt": ["ShortTermBorrowings", "DebtCurrent"],
    "total_current_liabilities": ["LiabilitiesCurrent"],
    "long_term_debt": ["LongTermDebtNoncurrent", "LongTermDebt"],
    "total_liabilities": ["Liabilities"],
    "retained_earnings": ["RetainedEarningsAccumulatedDeficit"],
    "total_stockholders_equity": ["StockholdersEquity", "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"],
}

_CFS_CONCEPTS: dict[str, list[str]] = {
    "operating_cash_flow": ["NetCashProvidedByUsedInOperatingActivities"],
    "capital_expenditures": ["PaymentsToAcquirePropertyPlantAndEquipment"],
    "investing_cash_flow": ["NetCashProvidedByUsedInInvestingActivities"],
    "dividends_paid": ["PaymentsOfDividends", "PaymentsOfDividendsCommonStock"],
    "share_repurchases": ["PaymentsForRepurchaseOfCommonStock"],
    "financing_cash_flow": ["NetCashProvidedByUsedInFinancingActivities"],
    "depreciation_amortisation": ["DepreciationDepletionAndAmortization"],
    "net_income": ["NetIncomeLoss"],
}


class SECEDGARProvider(BaseFinancialProvider):
    """SEC EDGAR XBRL companyfacts provider."""

    def __init__(self, client: httpx.AsyncClient) -> None:
        super().__init__(client)
        cfg = get_settings()
        self._base = cfg.sec_edgar_base_url
        self._user_agent = cfg.sec_edgar_user_agent
        # CIK lookup cache (in-memory, refreshed on restart)
        self._cik_cache: dict[str, str] = {}

    @property
    def name(self) -> str:
        return "sec_edgar"

    @property
    def supports_realtime(self) -> bool:
        return False   # EDGAR is filing-based, not real-time

    # ── EDGAR-specific GET (adds required User-Agent) ──────────────────────

    async def _edgar_get(self, url: str) -> dict:
        try:
            response = await self._client.get(
                url,
                headers={"User-Agent": self._user_agent, "Accept": "application/json"},
                timeout=httpx.Timeout(connect=5.0, read=30.0, write=5.0, pool=5.0),
            )
        except httpx.TimeoutException as exc:
            raise ProviderUnavailableError(self.name, f"EDGAR timeout: {url}") from exc

        if response.status_code == 429:
            await asyncio.sleep(1.0)  # brief back-off on EDGAR rate limit
            raise ProviderUnavailableError(self.name, "EDGAR rate limited")
        if response.status_code >= 500:
            raise ProviderUnavailableError(self.name, f"EDGAR {response.status_code}")

        try:
            return response.json()
        except Exception as exc:
            raise ProviderDataError(self.name, f"Non-JSON from EDGAR: {url}") from exc

    # ── CIK resolution ─────────────────────────────────────────────────────

    async def _resolve_cik(self, ticker: str) -> str:
        """
        Resolve ticker to SEC CIK number.
        EDGAR CIKs are zero-padded to 10 digits.
        """
        ticker_upper = ticker.upper()
        if ticker_upper in self._cik_cache:
            return self._cik_cache[ticker_upper]

        # EDGAR provides a ticker→CIK JSON map
        data = await self._edgar_get(
            "https://www.sec.gov/files/company_tickers.json"
        )
        # Response: { "0": {"cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc."}, ... }
        for _idx, entry in data.items():
            if entry.get("ticker", "").upper() == ticker_upper:
                cik = str(entry["cik_str"]).zfill(10)
                self._cik_cache[ticker_upper] = cik
                return cik

        raise ProviderDataError(self.name, f"Cannot resolve CIK for ticker {ticker}")

    # ── XBRL facts loader ──────────────────────────────────────────────────

    async def _get_company_facts(self, ticker: str) -> dict:
        """
        Fetch the full XBRL companyfacts JSON for a company.
        This is a large (~2-10MB) blob that contains all reported GAAP facts.
        """
        cik = await self._resolve_cik(ticker)
        url = f"{self._base}/api/xbrl/companyfacts/CIK{cik}.json"
        facts = await self._edgar_get(url)
        return facts.get("facts", {}).get("us-gaap", {})

    # ── XBRL fact extraction helper ────────────────────────────────────────

    @staticmethod
    def _extract_annual_values(
        gaap_facts: dict,
        concepts: list[str],
        years: int,
    ) -> list[tuple[date, float]]:
        """
        From a list of GAAP concept names (ordered by preference), extract
        annual 10-K filed values for the most recent N fiscal years.

        Returns list of (period_end_date, value) tuples, newest-first.
        """
        for concept in concepts:
            if concept not in gaap_facts:
                continue
            units_block = gaap_facts[concept].get("units", {})
            # Most concepts are in USD; shares are in "shares"
            values_list: list[dict[str, Any]] = (
                units_block.get("USD")
                or units_block.get("shares")
                or []
            )

            # Filter to 10-K annual filings (form = "10-K" or "10-K405")
            annual = [
                v for v in values_list
                if v.get("form") in ("10-K", "10-K405")
                and v.get("end") is not None
                and v.get("val") is not None
            ]
            if not annual:
                continue

            # Sort by end date descending, deduplicate by end date
            seen: set[str] = set()
            deduped: list[tuple[date, float]] = []
            for v in sorted(annual, key=lambda x: x["end"], reverse=True):
                end_str = v["end"]
                if end_str in seen:
                    continue
                seen.add(end_str)
                try:
                    period_end = date.fromisoformat(end_str)
                    deduped.append((period_end, float(v["val"])))
                except (ValueError, TypeError):
                    continue
                if len(deduped) >= years:
                    break

            return deduped

        return []

    # ── Public interface ───────────────────────────────────────────────────

    async def search_companies(
        self,
        query: str,
        limit: int = 10,
    ) -> list[CompanySearchResult]:
        """EDGAR search — limited, returns exact ticker match only."""
        try:
            cik = await self._resolve_cik(query)
            subs = await self._edgar_get(
                f"{self._base}/submissions/CIK{cik}.json"
            )
            return [
                CompanySearchResult(
                    ticker=subs.get("tickers", [query])[0],
                    company_name=subs.get("name", query),
                    exchange=subs.get("exchanges", [None])[0],
                    source_provider=self.name,
                )
            ]
        except ProviderDataError:
            return []

    async def get_company_profile(self, ticker: str) -> CompanyProfile:
        cik = await self._resolve_cik(ticker)
        subs = await self._edgar_get(f"{self._base}/submissions/CIK{cik}.json")

        return CompanyProfile(
            ticker=(subs.get("tickers") or [ticker])[0],
            cik=cik.lstrip("0"),
            company_name=subs.get("name", ticker),
            exchange=(subs.get("exchanges") or [None])[0],
            country="US",   # EDGAR is US only
            source_provider=self.name,
        )

    async def get_income_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[IncomeStatement]:
        if quarterly:
            # XBRL quarterly parsing is complex — defer to other providers
            raise ProviderDataError(
                self.name, "EDGAR quarterly parsing not implemented; use FMP/AV"
            )

        gaap = await self._get_company_facts(ticker)
        statements: list[IncomeStatement] = []

        # Build a dict of field → [(date, value)] pairs
        field_values: dict[str, list[tuple[date, float]]] = {}
        for field, concepts in _IS_CONCEPTS.items():
            vals = self._extract_annual_values(gaap, concepts, years)
            if vals:
                field_values[field] = vals

        # Anchor to revenue dates
        revenue_series = field_values.get("revenue", [])
        if not revenue_series:
            raise ProviderDataError(self.name, f"No revenue XBRL data for {ticker}")

        def get_val(field: str, period_end: date) -> float | None:
            series = field_values.get(field, [])
            for d, v in series:
                if d == period_end:
                    return v
            return None

        for period_end, revenue in revenue_series[:years]:
            statements.append(
                IncomeStatement(
                    ticker=ticker,
                    period_type="annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    source_provider=self.name,
                    revenue=revenue,
                    gross_profit=get_val("gross_profit", period_end),
                    operating_income=get_val("operating_income", period_end),
                    depreciation_amortisation=get_val("depreciation_amortisation", period_end),
                    interest_expense=get_val("interest_expense", period_end),
                    pretax_income=get_val("pretax_income", period_end),
                    income_tax_expense=get_val("income_tax_expense", period_end),
                    net_income=get_val("net_income", period_end),
                    eps_diluted=get_val("eps_diluted", period_end),
                    weighted_avg_shares_diluted=get_val("weighted_avg_shares_diluted", period_end),
                )
            )

        log.debug("edgar.income_statements.fetched", ticker=ticker, count=len(statements))
        return statements

    async def get_balance_sheets(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[BalanceSheet]:
        if quarterly:
            raise ProviderDataError(self.name, "EDGAR quarterly not implemented")

        gaap = await self._get_company_facts(ticker)
        field_values: dict[str, list[tuple[date, float]]] = {}
        for field, concepts in _BS_CONCEPTS.items():
            vals = self._extract_annual_values(gaap, concepts, years)
            if vals:
                field_values[field] = vals

        asset_series = field_values.get("total_assets", [])
        if not asset_series:
            raise ProviderDataError(self.name, f"No total assets XBRL data for {ticker}")

        def get_val(field: str, period_end: date) -> float | None:
            for d, v in field_values.get(field, []):
                if d == period_end:
                    return v
            return None

        sheets = []
        for period_end, total_assets in asset_series[:years]:
            sheets.append(
                BalanceSheet(
                    ticker=ticker,
                    period_type="annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    source_provider=self.name,
                    cash_and_equivalents=get_val("cash_and_equivalents", period_end),
                    short_term_investments=get_val("short_term_investments", period_end),
                    accounts_receivable=get_val("accounts_receivable", period_end),
                    inventory=get_val("inventory", period_end),
                    total_current_assets=get_val("total_current_assets", period_end),
                    property_plant_equipment_net=get_val("property_plant_equipment_net", period_end),
                    goodwill=get_val("goodwill", period_end),
                    intangible_assets=get_val("intangible_assets", period_end),
                    total_assets=total_assets,
                    accounts_payable=get_val("accounts_payable", period_end),
                    short_term_debt=get_val("short_term_debt", period_end),
                    total_current_liabilities=get_val("total_current_liabilities", period_end),
                    long_term_debt=get_val("long_term_debt", period_end),
                    total_liabilities=get_val("total_liabilities", period_end),
                    retained_earnings=get_val("retained_earnings", period_end),
                    total_stockholders_equity=get_val("total_stockholders_equity", period_end),
                )
            )

        log.debug("edgar.balance_sheets.fetched", ticker=ticker, count=len(sheets))
        return sheets

    async def get_cash_flow_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> list[CashFlowStatement]:
        if quarterly:
            raise ProviderDataError(self.name, "EDGAR quarterly not implemented")

        gaap = await self._get_company_facts(ticker)
        field_values: dict[str, list[tuple[date, float]]] = {}
        for field, concepts in _CFS_CONCEPTS.items():
            vals = self._extract_annual_values(gaap, concepts, years)
            if vals:
                field_values[field] = vals

        cfo_series = field_values.get("operating_cash_flow", [])
        if not cfo_series:
            raise ProviderDataError(self.name, f"No CFO XBRL data for {ticker}")

        def get_val(field: str, period_end: date) -> float | None:
            for d, v in field_values.get(field, []):
                if d == period_end:
                    return v
            return None

        statements = []
        for period_end, cfo in cfo_series[:years]:
            statements.append(
                CashFlowStatement(
                    ticker=ticker,
                    period_type="annual",
                    period_end_date=period_end,
                    fiscal_year=period_end.year,
                    source_provider=self.name,
                    net_income=get_val("net_income", period_end),
                    depreciation_amortisation=get_val("depreciation_amortisation", period_end),
                    operating_cash_flow=cfo,
                    capital_expenditures=get_val("capital_expenditures", period_end),
                    investing_cash_flow=get_val("investing_cash_flow", period_end),
                    dividends_paid=get_val("dividends_paid", period_end),
                    share_repurchases=get_val("share_repurchases", period_end),
                    financing_cash_flow=get_val("financing_cash_flow", period_end),
                )
            )

        log.debug("edgar.cash_flows.fetched", ticker=ticker, count=len(statements))
        return statements

    async def get_market_data(self, ticker: str) -> MarketData:
        """EDGAR does not provide market prices — always raises."""
        raise ProviderDataError(
            self.name,
            "EDGAR does not provide real-time market data. Use FMP, AV, or Yahoo Finance.",
        )
