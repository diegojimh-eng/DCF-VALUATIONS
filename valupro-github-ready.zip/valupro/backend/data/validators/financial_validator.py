"""
data/validators/financial_validator.py
---------------------------------------
Business-rule validation for financial data.

Pydantic handles type/schema validation. This module handles financial
semantics — things that are structurally valid JSON but financially
nonsensical (e.g. negative market cap, beta of 50, total assets ≠ assets).

Validation approach:
  • Non-fatal: issues produce warnings, not exceptions
  • The data is still returned even if warnings exist
  • DataResponse.status = "partial" when warnings are present
  • Callers (DataRouter) decide whether to try another provider

Usage:
    validator = FinancialDataValidator()
    warnings = validator.validate_income_statement(statement)
    warnings += validator.validate_market_data(market_data)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Sequence

from data.models import BalanceSheet, CashFlowStatement, IncomeStatement, MarketData
from logger import get_logger

log = get_logger(__name__)


class Severity(str, Enum):
    WARNING = "WARNING"
    ERROR = "ERROR"     # Data unusable for valuation — will trigger provider fallback


@dataclass
class ValidationIssue:
    code: str
    field: str
    message: str
    severity: Severity = Severity.WARNING
    value: float | str | None = None


@dataclass
class ValidationResult:
    issues: list[ValidationIssue] = field(default_factory=list)

    @property
    def has_errors(self) -> bool:
        return any(i.severity == Severity.ERROR for i in self.issues)

    @property
    def has_warnings(self) -> bool:
        return bool(self.issues)

    @property
    def is_clean(self) -> bool:
        return not self.issues

    def warnings_as_strings(self) -> list[str]:
        return [f"[{i.severity}] {i.code}: {i.message}" for i in self.issues]

    def merge(self, other: "ValidationResult") -> "ValidationResult":
        return ValidationResult(issues=self.issues + other.issues)


class FinancialDataValidator:
    """
    Validates financial data objects against business rules.

    All validate_* methods return a ValidationResult — they never raise.
    """

    # ── Income Statement ───────────────────────────────────────────────────

    def validate_income_statement(self, stmt: IncomeStatement) -> ValidationResult:
        issues: list[ValidationIssue] = []

        # Revenue must be present and positive for a going concern
        if stmt.revenue is None:
            issues.append(ValidationIssue(
                code="IS_MISSING_REVENUE",
                field="revenue",
                message="Revenue is None — cannot build forecast",
                severity=Severity.ERROR,
            ))
        elif stmt.revenue <= 0:
            issues.append(ValidationIssue(
                code="IS_NEGATIVE_REVENUE",
                field="revenue",
                message=f"Revenue is non-positive: {stmt.revenue:,.0f}",
                severity=Severity.ERROR,
                value=stmt.revenue,
            ))

        # Gross profit should not exceed revenue
        if stmt.revenue and stmt.gross_profit:
            if stmt.gross_profit > stmt.revenue * 1.05:  # 5% tolerance for rounding
                issues.append(ValidationIssue(
                    code="IS_GROSS_EXCEEDS_REVENUE",
                    field="gross_profit",
                    message=f"Gross profit ({stmt.gross_profit:,.0f}) exceeds revenue ({stmt.revenue:,.0f})",
                    severity=Severity.WARNING,
                ))

        # EBITDA margin sanity bounds
        if stmt.ebitda_margin is not None:
            if stmt.ebitda_margin < -0.5:
                issues.append(ValidationIssue(
                    code="IS_EBITDA_MARGIN_EXTREME_LOW",
                    field="ebitda_margin",
                    message=f"EBITDA margin is {stmt.ebitda_margin:.1%} — extremely low, verify data",
                    severity=Severity.WARNING,
                    value=stmt.ebitda_margin,
                ))
            elif stmt.ebitda_margin > 0.9:
                issues.append(ValidationIssue(
                    code="IS_EBITDA_MARGIN_EXTREME_HIGH",
                    field="ebitda_margin",
                    message=f"EBITDA margin is {stmt.ebitda_margin:.1%} — suspiciously high",
                    severity=Severity.WARNING,
                    value=stmt.ebitda_margin,
                ))

        # Net income check
        if stmt.net_income is None:
            issues.append(ValidationIssue(
                code="IS_MISSING_NET_INCOME",
                field="net_income",
                message="Net income is None",
                severity=Severity.WARNING,
            ))

        # EPS / share count consistency
        if stmt.eps_diluted and stmt.net_income and stmt.weighted_avg_shares_diluted:
            implied_eps = stmt.net_income / stmt.weighted_avg_shares_diluted
            if abs(implied_eps - stmt.eps_diluted) / (abs(stmt.eps_diluted) + 1e-6) > 0.10:
                issues.append(ValidationIssue(
                    code="IS_EPS_INCONSISTENCY",
                    field="eps_diluted",
                    message=(
                        f"Reported EPS ({stmt.eps_diluted:.4f}) differs from "
                        f"implied EPS ({implied_eps:.4f}) by >10%"
                    ),
                    severity=Severity.WARNING,
                ))

        self._log_result("income_statement", stmt.ticker, issues)
        return ValidationResult(issues=issues)

    # ── Balance Sheet ──────────────────────────────────────────────────────

    def validate_balance_sheet(self, bs: BalanceSheet) -> ValidationResult:
        issues: list[ValidationIssue] = []

        # Total assets must be present
        if bs.total_assets is None:
            issues.append(ValidationIssue(
                code="BS_MISSING_TOTAL_ASSETS",
                field="total_assets",
                message="Total assets is None — balance sheet cannot be used",
                severity=Severity.ERROR,
            ))

        # Accounting identity: Assets = Liabilities + Equity
        if (bs.total_assets is not None
                and bs.total_liabilities is not None
                and bs.total_stockholders_equity is not None):
            implied_assets = bs.total_liabilities + bs.total_stockholders_equity
            discrepancy = abs(bs.total_assets - implied_assets)
            # Allow 1% tolerance for rounding in reported figures
            if discrepancy > abs(bs.total_assets) * 0.01:
                issues.append(ValidationIssue(
                    code="BS_ACCOUNTING_IDENTITY_VIOLATION",
                    field="total_assets",
                    message=(
                        f"Assets ({bs.total_assets:,.0f}) ≠ Liabilities + Equity "
                        f"({implied_assets:,.0f}). Discrepancy: {discrepancy:,.0f}"
                    ),
                    severity=Severity.WARNING,
                ))

        # Non-negative current assets
        if bs.total_current_assets is not None and bs.total_current_assets < 0:
            issues.append(ValidationIssue(
                code="BS_NEGATIVE_CURRENT_ASSETS",
                field="total_current_assets",
                message=f"Current assets is negative: {bs.total_current_assets:,.0f}",
                severity=Severity.WARNING,
            ))

        # Leverage sanity: debt/equity > 20x is extreme and likely a data error
        if (bs.long_term_debt is not None
                and bs.total_stockholders_equity is not None
                and bs.total_stockholders_equity > 0):
            de_ratio = bs.long_term_debt / bs.total_stockholders_equity
            if de_ratio > 20.0:
                issues.append(ValidationIssue(
                    code="BS_EXTREME_LEVERAGE",
                    field="long_term_debt",
                    message=f"D/E ratio is {de_ratio:.1f}x — verify capital structure",
                    severity=Severity.WARNING,
                    value=de_ratio,
                ))

        self._log_result("balance_sheet", bs.ticker, issues)
        return ValidationResult(issues=issues)

    # ── Cash Flow Statement ────────────────────────────────────────────────

    def validate_cash_flow_statement(self, cfs: CashFlowStatement) -> ValidationResult:
        issues: list[ValidationIssue] = []

        if cfs.operating_cash_flow is None:
            issues.append(ValidationIssue(
                code="CFS_MISSING_CFO",
                field="operating_cash_flow",
                message="Operating cash flow is None — FCF cannot be computed",
                severity=Severity.ERROR,
            ))

        # CapEx is typically negative in cash flow statements (cash outflow)
        # If reported as positive it may be a sign error from the provider
        if cfs.capital_expenditures is not None and cfs.capital_expenditures > 0:
            issues.append(ValidationIssue(
                code="CFS_CAPEX_POSITIVE",
                field="capital_expenditures",
                message=(
                    f"CapEx is positive ({cfs.capital_expenditures:,.0f}). "
                    "Provider may use sign convention where outflows are positive. "
                    "Verify before computing FCF."
                ),
                severity=Severity.WARNING,
                value=cfs.capital_expenditures,
            ))

        # FCF consistency check when both components are available
        if (cfs.operating_cash_flow is not None
                and cfs.capital_expenditures is not None
                and cfs.free_cash_flow is not None):
            implied_fcf = cfs.operating_cash_flow + cfs.capital_expenditures
            discrepancy = abs(implied_fcf - cfs.free_cash_flow)
            if discrepancy > abs(cfs.free_cash_flow + 1e-6) * 0.05:
                issues.append(ValidationIssue(
                    code="CFS_FCF_INCONSISTENCY",
                    field="free_cash_flow",
                    message=(
                        f"Reported FCF ({cfs.free_cash_flow:,.0f}) differs from "
                        f"implied FCF ({implied_fcf:,.0f}) by more than 5%"
                    ),
                    severity=Severity.WARNING,
                ))

        self._log_result("cash_flow", cfs.ticker, issues)
        return ValidationResult(issues=issues)

    # ── Market Data ────────────────────────────────────────────────────────

    def validate_market_data(self, md: MarketData) -> ValidationResult:
        issues: list[ValidationIssue] = []

        # Price is required
        if md.current_price is None:
            issues.append(ValidationIssue(
                code="MD_MISSING_PRICE",
                field="current_price",
                message="Current price is None",
                severity=Severity.ERROR,
            ))
        elif md.current_price <= 0:
            issues.append(ValidationIssue(
                code="MD_INVALID_PRICE",
                field="current_price",
                message=f"Current price is non-positive: {md.current_price}",
                severity=Severity.ERROR,
                value=md.current_price,
            ))

        # Market cap
        if md.market_cap is None:
            issues.append(ValidationIssue(
                code="MD_MISSING_MARKET_CAP",
                field="market_cap",
                message="Market cap is None",
                severity=Severity.WARNING,
            ))
        elif md.market_cap <= 0:
            issues.append(ValidationIssue(
                code="MD_INVALID_MARKET_CAP",
                field="market_cap",
                message=f"Market cap is non-positive: {md.market_cap:,.0f}",
                severity=Severity.ERROR,
                value=md.market_cap,
            ))

        # Beta sanity bounds (±5 covers virtually all real companies)
        if md.beta is None:
            issues.append(ValidationIssue(
                code="MD_MISSING_BETA",
                field="beta",
                message="Beta is None — WACC cannot be computed from CAPM",
                severity=Severity.WARNING,
            ))
        elif abs(md.beta) > 5.0:
            issues.append(ValidationIssue(
                code="MD_EXTREME_BETA",
                field="beta",
                message=f"Beta is {md.beta:.2f} — outside expected range [-5, 5]",
                severity=Severity.WARNING,
                value=md.beta,
            ))

        # Shares outstanding
        if md.shares_outstanding is None:
            issues.append(ValidationIssue(
                code="MD_MISSING_SHARES",
                field="shares_outstanding",
                message="Shares outstanding is None — equity value per share cannot be computed",
                severity=Severity.ERROR,
            ))
        elif md.shares_outstanding <= 0:
            issues.append(ValidationIssue(
                code="MD_INVALID_SHARES",
                field="shares_outstanding",
                message=f"Shares outstanding is non-positive: {md.shares_outstanding:,.0f}",
                severity=Severity.ERROR,
            ))

        # Price / market cap consistency check
        if (md.current_price and md.market_cap and md.shares_outstanding
                and md.shares_outstanding > 0):
            implied_mc = md.current_price * md.shares_outstanding
            discrepancy_pct = abs(implied_mc - md.market_cap) / md.market_cap
            if discrepancy_pct > 0.05:   # >5% discrepancy
                issues.append(ValidationIssue(
                    code="MD_MARKET_CAP_INCONSISTENCY",
                    field="market_cap",
                    message=(
                        f"Reported market cap ({md.market_cap:,.0f}) differs from "
                        f"implied ({implied_mc:,.0f}) by {discrepancy_pct:.1%}"
                    ),
                    severity=Severity.WARNING,
                ))

        self._log_result("market_data", md.ticker, issues)
        return ValidationResult(issues=issues)

    # ── Cross-statement validation ─────────────────────────────────────────

    def validate_cross_statement(
        self,
        stmt: IncomeStatement,
        bs: BalanceSheet,
        cfs: CashFlowStatement,
    ) -> ValidationResult:
        """
        Validate consistency across the three financial statements.
        Runs after individual statement validation passes.
        """
        issues: list[ValidationIssue] = []

        # Net income should match across IS and CFS
        if stmt.net_income is not None and cfs.net_income is not None:
            discrepancy = abs(stmt.net_income - cfs.net_income)
            tolerance = max(abs(stmt.net_income) * 0.02, 1.0)   # 2% or $1
            if discrepancy > tolerance:
                issues.append(ValidationIssue(
                    code="CROSS_NET_INCOME_MISMATCH",
                    field="net_income",
                    message=(
                        f"Net income mismatch: IS={stmt.net_income:,.0f} "
                        f"vs CFS={cfs.net_income:,.0f}"
                    ),
                    severity=Severity.WARNING,
                ))

        # D&A in CFS should be positive (add-back)
        if (stmt.depreciation_amortisation is not None
                and cfs.depreciation_amortisation is not None
                and cfs.depreciation_amortisation < 0):
            issues.append(ValidationIssue(
                code="CROSS_DA_SIGN_ERROR",
                field="depreciation_amortisation",
                message="D&A in CFS is negative — likely a sign convention issue",
                severity=Severity.WARNING,
            ))

        return ValidationResult(issues=issues)

    # ── Series validation ──────────────────────────────────────────────────

    def validate_income_series(
        self, statements: Sequence[IncomeStatement]
    ) -> ValidationResult:
        """
        Validate a time series of income statements for internal consistency.
        Detects suspicious jumps that suggest data errors rather than real events.
        """
        issues: list[ValidationIssue] = []
        if len(statements) < 2:
            return ValidationResult()

        # Check for implausible revenue jumps (>400% YoY or <-90% YoY)
        for i in range(len(statements) - 1):
            curr = statements[i]    # newer
            prev = statements[i + 1]  # older
            if curr.revenue and prev.revenue and prev.revenue != 0:
                growth = (curr.revenue - prev.revenue) / abs(prev.revenue)
                if growth > 4.0:
                    issues.append(ValidationIssue(
                        code="SERIES_REVENUE_JUMP",
                        field="revenue",
                        message=(
                            f"Revenue grew {growth:.0%} YoY "
                            f"({prev.fiscal_year} → {curr.fiscal_year}) — verify data"
                        ),
                        severity=Severity.WARNING,
                        value=growth,
                    ))
                elif growth < -0.90:
                    issues.append(ValidationIssue(
                        code="SERIES_REVENUE_COLLAPSE",
                        field="revenue",
                        message=(
                            f"Revenue fell {growth:.0%} YoY "
                            f"({prev.fiscal_year} → {curr.fiscal_year}) — verify data"
                        ),
                        severity=Severity.WARNING,
                        value=growth,
                    ))

        return ValidationResult(issues=issues)

    # ── Internal logging helper ────────────────────────────────────────────

    @staticmethod
    def _log_result(
        statement_type: str,
        ticker: str,
        issues: list[ValidationIssue],
    ) -> None:
        errors = [i for i in issues if i.severity == Severity.ERROR]
        warnings = [i for i in issues if i.severity == Severity.WARNING]
        if errors:
            log.warning(
                "validator.errors",
                ticker=ticker,
                statement=statement_type,
                error_codes=[i.code for i in errors],
            )
        elif warnings:
            log.debug(
                "validator.warnings",
                ticker=ticker,
                statement=statement_type,
                warning_codes=[i.code for i in warnings],
            )
