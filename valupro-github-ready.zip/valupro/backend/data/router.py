"""
data/router.py
--------------
DataRouter — the single interface between the application and all
financial data sources.

Responsibilities:
  1. Cache-first: check Redis before hitting any provider
  2. Provider waterfall: try providers in priority order until one succeeds
  3. Validation: run ValidationResult on every fetched object
  4. Retry: tenacity-based exponential back-off on transient errors
  5. Concurrency: fetch all three financial statements in parallel
  6. Provenance: every response carries ProviderMeta for audit trails

Usage:
    router = DataRouter(cache=cache, providers=provider_map)

    # Fetch everything for the valuation engine in one call
    bundle = await router.get_financials_bundle("AAPL")

    # Or fetch individual pieces
    market = await router.get_market_data("AAPL")
    income = await router.get_income_statements("AAPL", years=5)
"""

from __future__ import annotations

import asyncio
import time
from typing import TypeVar

from tenacity import (
    AsyncRetrying,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from config import get_settings
from data.cache import FinancialCache
from data.models import (
    BalanceSheet,
    CashFlowStatement,
    CompanyProfile,
    CompanySearchResult,
    IncomeStatement,
    MarketData,
    PeerMultiple,
)
from data.models.responses import DataError, DataResponse, FinancialsBundle, ProviderMeta
from data.providers import (
    BaseFinancialProvider,
    ProviderAuthError,
    ProviderDataError,
    ProviderError,
    ProviderRateLimitError,
    ProviderTimeoutError,
    ProviderUnavailableError,
)
from data.validators import FinancialDataValidator, ValidationResult
from logger import get_logger

log = get_logger(__name__)
T = TypeVar("T")


# Errors that justify trying the next provider immediately (no retry on same)
_PROVIDER_SKIP_ERRORS = (ProviderAuthError, ProviderDataError)

# Errors that justify a retry on the same provider before moving on
_PROVIDER_RETRY_ERRORS = (ProviderTimeoutError, ProviderUnavailableError, ProviderRateLimitError)


class DataRouter:
    """
    Provider-agnostic router for all financial data.

    Instantiated once at application startup and reused for all requests.
    Thread-safe: all state is per-request (no shared mutable state).
    """

    def __init__(
        self,
        cache: FinancialCache,
        providers: dict[str, BaseFinancialProvider],
    ) -> None:
        self._cache = cache
        self._providers = providers
        self._cfg = get_settings()
        self._validator = FinancialDataValidator()

        # Ordered list of provider names (from config)
        self._priority: list[str] = [
            name for name in self._cfg.provider_priority
            if name in self._providers
        ]
        log.info(
            "data_router.init",
            providers=self._priority,
        )

    # ── Public interface ───────────────────────────────────────────────────

    async def search_companies(
        self, query: str, limit: int = 10
    ) -> list[CompanySearchResult]:
        """Search by ticker or company name. Tries providers in priority order."""
        for name in self._priority:
            provider = self._providers[name]
            try:
                results = await provider.search_companies(query, limit)
                if results:
                    return results
            except ProviderError as exc:
                log.warning("router.search.provider_error", provider=name, error=str(exc))
        return []

    async def get_company_profile(self, ticker: str) -> DataResponse[CompanyProfile]:
        """Fetch company profile with cache-first logic."""
        t0 = time.perf_counter()

        # Cache check
        cached = await self._cache.get_profile(ticker)
        if cached:
            profile = CompanyProfile(**cached)
            return DataResponse.ok(
                data=profile,
                meta=ProviderMeta(
                    provider=cached.get("source_provider", "cache"),
                    cache_hit=True,
                    cache_ttl_seconds=self._cfg.cache_ttl_company_profile,
                    latency_ms=(time.perf_counter() - t0) * 1000,
                ),
            )

        # Provider waterfall
        last_error: str = "No providers available"
        for name in self._priority:
            provider = self._providers[name]
            try:
                profile = await self._with_retry(provider.get_company_profile, ticker)
                await self._cache.set_profile(ticker, profile.model_dump(mode="json"))
                return DataResponse.ok(
                    data=profile,
                    meta=ProviderMeta(
                        provider=name,
                        latency_ms=(time.perf_counter() - t0) * 1000,
                    ),
                )
            except _PROVIDER_SKIP_ERRORS as exc:
                log.warning("router.profile.skip", provider=name, ticker=ticker, error=str(exc))
                last_error = str(exc)
            except ProviderError as exc:
                log.error("router.profile.error", provider=name, ticker=ticker, error=str(exc))
                last_error = str(exc)

        return DataResponse.error(
            meta=ProviderMeta(provider="none", latency_ms=(time.perf_counter() - t0) * 1000),
            errors=[DataError(code="ALL_PROVIDERS_FAILED", message=last_error)],
        )

    async def get_market_data(self, ticker: str) -> DataResponse[MarketData]:
        """Fetch real-time market data (price, beta, EV, shares)."""
        t0 = time.perf_counter()

        # Cache check
        cached = await self._cache.get_market_data(ticker)
        if cached:
            md = MarketData(**cached)
            return DataResponse.ok(
                data=md,
                meta=ProviderMeta(
                    provider=cached.get("source_provider", "cache"),
                    cache_hit=True,
                    cache_ttl_seconds=self._cfg.cache_ttl_market_data,
                    latency_ms=(time.perf_counter() - t0) * 1000,
                ),
            )

        # Provider waterfall — skip EDGAR (no market data)
        real_time_providers = [
            n for n in self._priority
            if self._providers[n].supports_realtime
        ]
        last_error = "No real-time providers available"
        fallback_used = False
        first_provider = True

        for name in real_time_providers:
            provider = self._providers[name]
            try:
                md = await self._with_retry(provider.get_market_data, ticker)

                # Validate
                validation = self._validator.validate_market_data(md)
                if validation.has_errors and not fallback_used:
                    log.warning(
                        "router.market_data.validation_errors",
                        provider=name,
                        ticker=ticker,
                        issues=validation.warnings_as_strings(),
                    )
                    first_provider = False
                    fallback_used = True
                    continue   # try next provider

                await self._cache.set_market_data(ticker, md.model_dump(mode="json"))

                meta = ProviderMeta(
                    provider=name,
                    latency_ms=(time.perf_counter() - t0) * 1000,
                    fallback_used=fallback_used,
                )

                if validation.has_warnings:
                    return DataResponse.partial(
                        data=md,
                        meta=meta,
                        errors=_issues_to_errors(validation, name),
                    )
                return DataResponse.ok(data=md, meta=meta)

            except _PROVIDER_SKIP_ERRORS as exc:
                log.warning("router.market_data.skip", provider=name, ticker=ticker, error=str(exc))
                last_error = str(exc)
                fallback_used = not first_provider
                first_provider = False
            except ProviderError as exc:
                log.error("router.market_data.error", provider=name, ticker=ticker, error=str(exc))
                last_error = str(exc)
                fallback_used = not first_provider
                first_provider = False

        return DataResponse.error(
            meta=ProviderMeta(provider="none", latency_ms=(time.perf_counter() - t0) * 1000),
            errors=[DataError(code="ALL_PROVIDERS_FAILED", message=last_error)],
        )

    async def get_income_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> DataResponse[list[IncomeStatement]]:
        """Fetch income statements with cache-first and provider waterfall."""
        t0 = time.perf_counter()

        cached = await self._cache.get_income_statements(ticker, years, quarterly)
        if cached:
            stmts = [IncomeStatement(**s) for s in cached]
            return DataResponse.ok(
                data=stmts,
                meta=ProviderMeta(provider="cache", cache_hit=True,
                                  latency_ms=(time.perf_counter() - t0) * 1000),
            )

        last_error = ""
        for name in self._priority:
            provider = self._providers[name]
            try:
                stmts = await self._with_retry(
                    provider.get_income_statements, ticker, years, quarterly
                )
                if not stmts:
                    continue

                # Validate each statement + the series
                all_issues: list = []
                for s in stmts:
                    r = self._validator.validate_income_statement(s)
                    all_issues.extend(r.issues)
                series_r = self._validator.validate_income_series(stmts)
                all_issues.extend(series_r.issues)

                await self._cache.set_income_statements(
                    ticker, years, quarterly, [s.model_dump(mode="json") for s in stmts]
                )
                meta = ProviderMeta(provider=name, latency_ms=(time.perf_counter() - t0) * 1000)
                has_errors = any(i.severity.value == "ERROR" for i in all_issues)
                if has_errors:
                    from data.validators import ValidationResult as VR
                    vr = VR(issues=all_issues)
                    return DataResponse.partial(
                        data=stmts, meta=meta, errors=_raw_issues_to_errors(all_issues, name)
                    )
                if all_issues:
                    return DataResponse.partial(
                        data=stmts, meta=meta, errors=_raw_issues_to_errors(all_issues, name)
                    )
                return DataResponse.ok(data=stmts, meta=meta)

            except _PROVIDER_SKIP_ERRORS as exc:
                log.warning("router.income.skip", provider=name, ticker=ticker, error=str(exc))
                last_error = str(exc)
            except ProviderError as exc:
                log.error("router.income.error", provider=name, ticker=ticker, error=str(exc))
                last_error = str(exc)

        return DataResponse.error(
            meta=ProviderMeta(provider="none", latency_ms=(time.perf_counter() - t0) * 1000),
            errors=[DataError(code="ALL_PROVIDERS_FAILED", message=last_error)],
        )

    async def get_balance_sheets(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> DataResponse[list[BalanceSheet]]:
        t0 = time.perf_counter()

        cached = await self._cache.get_balance_sheets(ticker, years, quarterly)
        if cached:
            sheets = [BalanceSheet(**s) for s in cached]
            return DataResponse.ok(
                data=sheets,
                meta=ProviderMeta(provider="cache", cache_hit=True,
                                  latency_ms=(time.perf_counter() - t0) * 1000),
            )

        last_error = ""
        for name in self._priority:
            provider = self._providers[name]
            try:
                sheets = await self._with_retry(
                    provider.get_balance_sheets, ticker, years, quarterly
                )
                if not sheets:
                    continue

                all_issues = []
                for bs in sheets:
                    r = self._validator.validate_balance_sheet(bs)
                    all_issues.extend(r.issues)

                await self._cache.set_balance_sheets(
                    ticker, years, quarterly, [s.model_dump(mode="json") for s in sheets]
                )
                meta = ProviderMeta(provider=name, latency_ms=(time.perf_counter() - t0) * 1000)
                if all_issues:
                    return DataResponse.partial(
                        data=sheets, meta=meta, errors=_raw_issues_to_errors(all_issues, name)
                    )
                return DataResponse.ok(data=sheets, meta=meta)

            except _PROVIDER_SKIP_ERRORS as exc:
                log.warning("router.bs.skip", provider=name, ticker=ticker, error=str(exc))
                last_error = str(exc)
            except ProviderError as exc:
                log.error("router.bs.error", provider=name, ticker=ticker, error=str(exc))
                last_error = str(exc)

        return DataResponse.error(
            meta=ProviderMeta(provider="none", latency_ms=(time.perf_counter() - t0) * 1000),
            errors=[DataError(code="ALL_PROVIDERS_FAILED", message=last_error)],
        )

    async def get_cash_flow_statements(
        self,
        ticker: str,
        years: int = 5,
        quarterly: bool = False,
    ) -> DataResponse[list[CashFlowStatement]]:
        t0 = time.perf_counter()

        cached = await self._cache.get_cash_flows(ticker, years, quarterly)
        if cached:
            stmts = [CashFlowStatement(**s) for s in cached]
            return DataResponse.ok(
                data=stmts,
                meta=ProviderMeta(provider="cache", cache_hit=True,
                                  latency_ms=(time.perf_counter() - t0) * 1000),
            )

        last_error = ""
        for name in self._priority:
            provider = self._providers[name]
            try:
                stmts = await self._with_retry(
                    provider.get_cash_flow_statements, ticker, years, quarterly
                )
                if not stmts:
                    continue

                all_issues = []
                for cfs in stmts:
                    r = self._validator.validate_cash_flow_statement(cfs)
                    all_issues.extend(r.issues)

                await self._cache.set_cash_flows(
                    ticker, years, quarterly, [s.model_dump(mode="json") for s in stmts]
                )
                meta = ProviderMeta(provider=name, latency_ms=(time.perf_counter() - t0) * 1000)
                if all_issues:
                    return DataResponse.partial(
                        data=stmts, meta=meta, errors=_raw_issues_to_errors(all_issues, name)
                    )
                return DataResponse.ok(data=stmts, meta=meta)

            except _PROVIDER_SKIP_ERRORS as exc:
                log.warning("router.cfs.skip", provider=name, ticker=ticker, error=str(exc))
                last_error = str(exc)
            except ProviderError as exc:
                log.error("router.cfs.error", provider=name, ticker=ticker, error=str(exc))
                last_error = str(exc)

        return DataResponse.error(
            meta=ProviderMeta(provider="none", latency_ms=(time.perf_counter() - t0) * 1000),
            errors=[DataError(code="ALL_PROVIDERS_FAILED", message=last_error)],
        )

    async def get_peer_multiples(
        self,
        ticker: str,
        max_peers: int = 10,
    ) -> DataResponse[list[PeerMultiple]]:
        t0 = time.perf_counter()

        cached = await self._cache.get_peers(ticker, max_peers)
        if cached:
            peers = [PeerMultiple(**p) for p in cached]
            return DataResponse.ok(
                data=peers,
                meta=ProviderMeta(provider="cache", cache_hit=True,
                                  latency_ms=(time.perf_counter() - t0) * 1000),
            )

        for name in self._priority:
            provider = self._providers[name]
            try:
                peers = await provider.get_peer_multiples(ticker, max_peers)
                if peers:
                    await self._cache.set_peers(
                        ticker, max_peers, [p.model_dump(mode="json") for p in peers]
                    )
                    return DataResponse.ok(
                        data=peers,
                        meta=ProviderMeta(provider=name,
                                          latency_ms=(time.perf_counter() - t0) * 1000),
                    )
            except ProviderError as exc:
                log.warning("router.peers.skip", provider=name, ticker=ticker, error=str(exc))

        # Peers are non-fatal — return empty list with ok status
        return DataResponse.ok(
            data=[],
            meta=ProviderMeta(provider="none", latency_ms=(time.perf_counter() - t0) * 1000),
        )

    async def get_financials_bundle(
        self,
        ticker: str,
        years: int = 5,
    ) -> FinancialsBundle:
        """
        Fetch everything the valuation engine needs in a single call.
        All three statement types are fetched concurrently.
        Returns a FinancialsBundle — the valuation engine's primary input.
        """
        t0 = time.perf_counter()

        # Check full-bundle cache first
        cached_bundle = await self._cache.get_bundle(ticker)
        if cached_bundle:
            log.info("router.bundle.cache_hit", ticker=ticker)
            return FinancialsBundle(**cached_bundle)

        log.info("router.bundle.fetching", ticker=ticker, years=years)

        # Concurrent fetches — profile + market can run alongside statements
        (
            profile_resp,
            market_resp,
            is_resp,
            bs_resp,
            cfs_resp,
        ) = await asyncio.gather(
            self.get_company_profile(ticker),
            self.get_market_data(ticker),
            self.get_income_statements(ticker, years),
            self.get_balance_sheets(ticker, years),
            self.get_cash_flow_statements(ticker, years),
            return_exceptions=False,
        )

        # Fail-fast on critical data
        if profile_resp.status == "error":
            raise ValueError(f"Cannot fetch company profile for {ticker}: {profile_resp.errors}")
        if market_resp.status == "error":
            raise ValueError(f"Cannot fetch market data for {ticker}: {market_resp.errors}")

        # Collect all validation warnings
        all_warnings: list[str] = []
        for resp in (is_resp, bs_resp, cfs_resp):
            all_warnings.extend(e.message for e in resp.errors)

        # Use whichever provider actually served the market data
        primary_provider = market_resp.meta.provider

        bundle = FinancialsBundle(
            profile=profile_resp.data,
            market_data=market_resp.data,
            income_statements=is_resp.data or [],
            balance_sheets=bs_resp.data or [],
            cash_flow_statements=cfs_resp.data or [],
            meta=ProviderMeta(
                provider=primary_provider,
                latency_ms=(time.perf_counter() - t0) * 1000,
                fallback_used=market_resp.meta.fallback_used,
            ),
            validation_warnings=all_warnings,
        )

        # Cache the bundle (at market data TTL = 15 min)
        await self._cache.set_bundle(ticker, bundle.model_dump(mode="json"))

        log.info(
            "router.bundle.complete",
            ticker=ticker,
            provider=primary_provider,
            income_years=len(bundle.income_statements),
            warnings=len(all_warnings),
            latency_ms=round((time.perf_counter() - t0) * 1000, 1),
        )
        return bundle

    # ── Retry helper ───────────────────────────────────────────────────────

    async def _with_retry(self, fn: object, *args: object, **kwargs: object) -> object:
        """
        Execute a provider method with exponential back-off retry.
        Only retries on transient errors (timeout, 5xx).
        Auth errors and data errors are not retried.
        """
        cfg = self._cfg
        async for attempt in AsyncRetrying(
            retry=retry_if_exception_type(_PROVIDER_RETRY_ERRORS),
            stop=stop_after_attempt(cfg.fmp_max_retries),
            wait=wait_exponential(multiplier=0.5, min=0.5, max=8.0),
            reraise=True,
        ):
            with attempt:
                return await fn(*args, **kwargs)  # type: ignore[operator]


# ── Helpers ────────────────────────────────────────────────────────────────────

def _issues_to_errors(
    validation: ValidationResult, provider: str
) -> list[DataError]:
    return [
        DataError(
            code=i.code,
            message=i.message,
            field=i.field,
            provider=provider,
        )
        for i in validation.issues
    ]


def _raw_issues_to_errors(issues: list, provider: str) -> list[DataError]:
    from data.validators import ValidationIssue
    return [
        DataError(
            code=i.code,
            message=i.message,
            field=i.field,
            provider=provider,
        )
        for i in issues
        if isinstance(i, ValidationIssue)
    ]
