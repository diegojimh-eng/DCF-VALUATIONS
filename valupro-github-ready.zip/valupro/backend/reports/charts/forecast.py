"""
reports/charts/forecast.py
----------------------------
Revenue, EBITDA, and FCFF forecast charts.

Each function accepts a list of ForecastYear-like objects (or dicts with the
same keys) and returns PNG bytes ready for embedding in ReportLab.

Charts:
  1. revenue_chart    — grouped bar: Revenue by scenario + growth rate line
  2. ebitda_chart     — stacked area: EBITDA by scenario + margin line
  3. fcff_chart       — bar chart: FCFF by scenario with PV overlay
"""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.ticker import FuncFormatter

from reports.theme import (
    C, SIZE, clean_spines, add_chart_title,
    fmt_billions, fmt_pct, to_png, label_bar,
)


# ── Shared type ───────────────────────────────────────────────────────────────────

class YearData:
    """
    Lightweight wrapper over ForecastYear or a plain dict.
    Allows the chart functions to work with both.
    """
    def __init__(self, src: object) -> None:
        if isinstance(src, dict):
            self._d = src
        else:
            self._d = src.__dict__ if hasattr(src, "__dict__") else {}
            # Pydantic v2 frozen model
            if not self._d:
                self._d = {k: getattr(src, k) for k in src.model_fields}

    def __getattr__(self, name: str) -> float | int:
        val = self._d.get(name)
        if val is None:
            raise AttributeError(f"No attribute {name!r}")
        return val  # type: ignore[return-value]


def _years(data: list[object]) -> list[YearData]:
    return [YearData(d) for d in data]


# ── 1. Revenue Forecast Chart ────────────────────────────────────────────────────

def revenue_chart(
    bear: list[object],
    base: list[object],
    bull: list[object],
) -> bytes:
    """
    Grouped bar chart showing Revenue for Bear / Base / Bull scenarios.
    Secondary axis: Base case YoY revenue growth rate (%).

    Args:
        bear / base / bull: Lists of ForecastYear objects or equivalent dicts.

    Returns:
        PNG bytes.
    """
    b_data  = _years(bear)
    ba_data = _years(base)
    bu_data = _years(bull)

    years   = [d.fiscal_year for d in ba_data]
    x       = np.arange(len(years))
    width   = 0.26

    revenues_bear = [d.revenue / 1e9 for d in b_data]
    revenues_base = [d.revenue / 1e9 for d in ba_data]
    revenues_bull = [d.revenue / 1e9 for d in bu_data]
    growth_base   = [d.revenue_growth_rate * 100 for d in ba_data]

    fig, ax = plt.subplots(figsize=SIZE["full"])
    ax2 = ax.twinx()

    # Bars
    ax.bar(x - width, revenues_bear, width, color=C["amber"],   alpha=0.75, label="Bear")
    ax.bar(x,          revenues_base, width, color=C["blue"],    alpha=0.85, label="Base")
    ax.bar(x + width,  revenues_bull, width, color=C["emerald"], alpha=0.75, label="Bull")

    # Growth line on secondary axis
    ax2.plot(x, growth_base, color=C["blue_light"], linewidth=1.2,
             linestyle="--", marker="o", markersize=3, label="Base Growth %")
    ax2.set_ylabel("Revenue Growth (%)", color=C["text_muted"], fontsize=7)
    ax2.tick_params(axis="y", colors=C["text_muted"], labelsize=7)
    ax2.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:.1f}%"))
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_color(C["border"])
    ax2.spines["right"].set_linewidth(0.5)

    ax.set_xticks(x)
    ax.set_xticklabels([f"FY{y}" for y in years], rotation=0, fontsize=7)
    ax.yaxis.set_major_formatter(FuncFormatter(fmt_billions))
    ax.set_ylabel("Revenue ($B)", color=C["text_secondary"])
    clean_spines(ax)
    add_chart_title(ax, "Revenue Forecast", "Bear / Base / Bull · 10-Year Projection")

    # Combined legend
    legend_elements = [
        mpatches.Patch(facecolor=C["amber"],   label="Bear", alpha=0.75),
        mpatches.Patch(facecolor=C["blue"],    label="Base", alpha=0.85),
        mpatches.Patch(facecolor=C["emerald"], label="Bull", alpha=0.75),
        plt.Line2D([0], [0], color=C["blue_light"], linestyle="--",
                   linewidth=1.2, label="Base Growth %"),
    ]
    ax.legend(handles=legend_elements, loc="upper left", framealpha=0.8, fontsize=7)
    fig.tight_layout()
    return to_png(fig)


# ── 2. EBITDA Forecast Chart ─────────────────────────────────────────────────────

def ebitda_chart(
    bear: list[object],
    base: list[object],
    bull: list[object],
) -> bytes:
    """
    Filled area chart for EBITDA by scenario + EBITDA margin % line.
    """
    b_data  = _years(bear)
    ba_data = _years(base)
    bu_data = _years(bull)

    years         = [d.fiscal_year for d in ba_data]
    x             = np.arange(len(years))
    ebitda_bear   = [d.ebitda / 1e9 for d in b_data]
    ebitda_base   = [d.ebitda / 1e9 for d in ba_data]
    ebitda_bull   = [d.ebitda / 1e9 for d in bu_data]
    margin_base   = [d.ebitda_margin * 100 for d in ba_data]

    fig, ax = plt.subplots(figsize=SIZE["full"])
    ax2 = ax.twinx()

    # Fill areas
    ax.fill_between(x, ebitda_bear, alpha=0.25, color=C["amber"],   label="Bear")
    ax.fill_between(x, ebitda_base, alpha=0.35, color=C["blue"],    label="Base")
    ax.fill_between(x, ebitda_bull, alpha=0.25, color=C["emerald"], label="Bull")

    # Lines on top
    ax.plot(x, ebitda_bear, color=C["amber"],   linewidth=1.0, linestyle="--")
    ax.plot(x, ebitda_base, color=C["blue"],    linewidth=1.6)
    ax.plot(x, ebitda_bull, color=C["emerald"], linewidth=1.0, linestyle="--")

    # Data labels on base line every other year
    for i, (xi, yi) in enumerate(zip(x, ebitda_base)):
        if i % 2 == 0:
            label_bar(ax, xi, yi + 0.5, f"${yi:.0f}B",
                      color=C["blue_light"], fontsize=6)

    # Margin % on secondary axis
    ax2.plot(x, margin_base, color=C["text_muted"], linewidth=1.0,
             linestyle=":", marker="s", markersize=2.5, label="EBITDA Margin %")
    ax2.set_ylabel("EBITDA Margin (%)", color=C["text_muted"], fontsize=7)
    ax2.tick_params(axis="y", colors=C["text_muted"], labelsize=7)
    ax2.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:.0f}%"))
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_color(C["border"])
    ax2.spines["right"].set_linewidth(0.5)

    ax.set_xticks(x)
    ax.set_xticklabels([f"FY{y}" for y in years], fontsize=7)
    ax.yaxis.set_major_formatter(FuncFormatter(fmt_billions))
    ax.set_ylabel("EBITDA ($B)", color=C["text_secondary"])
    clean_spines(ax)
    add_chart_title(ax, "EBITDA Forecast", "With EBITDA Margin % · 10-Year Projection")

    legend_elements = [
        mpatches.Patch(facecolor=C["amber"],   label="Bear", alpha=0.7),
        mpatches.Patch(facecolor=C["blue"],    label="Base", alpha=0.7),
        mpatches.Patch(facecolor=C["emerald"], label="Bull", alpha=0.7),
        plt.Line2D([0], [0], color=C["text_muted"], linestyle=":", linewidth=1,
                   label="Base EBITDA Margin %"),
    ]
    ax.legend(handles=legend_elements, loc="upper left", framealpha=0.8, fontsize=7)
    fig.tight_layout()
    return to_png(fig)


# ── 3. FCFF Forecast Chart ───────────────────────────────────────────────────────

def fcff_chart(
    bear: list[object],
    base: list[object],
    bull: list[object],
    pv_fcff: list[float] | None = None,
) -> bytes:
    """
    Bar chart for FCFF (Bear / Base / Bull) with optional PV overlay.

    Args:
        pv_fcff: Optional list of discounted FCFF values for the base case.
                 When provided, adds a step-plot showing PV(FCFF).
    """
    b_data  = _years(bear)
    ba_data = _years(base)
    bu_data = _years(bull)

    years       = [d.fiscal_year for d in ba_data]
    x           = np.arange(len(years))
    width       = 0.26
    fcff_bear   = [d.fcff / 1e9 for d in b_data]
    fcff_base   = [d.fcff / 1e9 for d in ba_data]
    fcff_bull   = [d.fcff / 1e9 for d in bu_data]

    fig, ax = plt.subplots(figsize=SIZE["full"])

    ax.bar(x - width, fcff_bear, width, color=C["amber"],   alpha=0.75, label="Bear FCFF")
    ax.bar(x,          fcff_base, width, color=C["blue"],    alpha=0.85, label="Base FCFF")
    ax.bar(x + width,  fcff_bull, width, color=C["emerald"], alpha=0.75, label="Bull FCFF")

    # PV(FCFF) step overlay
    if pv_fcff:
        pv_b = [v / 1e9 for v in pv_fcff]
        ax.step(x, pv_b, where="mid", color=C["blue_light"], linewidth=1.4,
                linestyle="-.", alpha=0.9, label="PV(FCFF) — Base")
        ax.fill_between(x, pv_b, alpha=0.08, color=C["blue"], step="mid")

    # Zero line
    ax.axhline(0, color=C["border"], linewidth=0.7, zorder=0)

    ax.set_xticks(x)
    ax.set_xticklabels([f"FY{y}" for y in years], fontsize=7)
    ax.yaxis.set_major_formatter(FuncFormatter(fmt_billions))
    ax.set_ylabel("FCFF ($B)", color=C["text_secondary"])
    clean_spines(ax)
    add_chart_title(ax, "Free Cash Flow to Firm (FCFF)", "Bear / Base / Bull · FCFF = NOPAT + D&A − CapEx − ΔNWC")
    ax.legend(loc="upper left", framealpha=0.8, fontsize=7)
    fig.tight_layout()
    return to_png(fig)
