"""
reports/charts/waterfall.py
-----------------------------
DCF Waterfall Chart and Enterprise Value Bridge Chart.

DCF Waterfall:
  Shows each year's PV(FCFF) as a step, cumulatively building up to
  Σ PV(FCFF), then adds PV(Terminal Value) to reach Enterprise Value.

Enterprise Value Bridge:
  Classic "bridge" / "waterfall" chart showing:
    Enterprise Value
    → − Net Debt
    → − Minority Interest
    → − Preferred Equity
    → = Equity Value
    → ÷ Shares Outstanding
    → = Fair Value per Share
"""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.ticker import FuncFormatter

from reports.theme import (
    C, SIZE, clean_spines, add_chart_title,
    fmt_billions, fmt_price, to_png, label_bar,
)


# ── 4. DCF Waterfall Chart ───────────────────────────────────────────────────────

def dcf_waterfall_chart(
    dcf_schedule: list[object],
    pv_terminal_value: float,
    enterprise_value: float,
) -> bytes:
    """
    Step-accumulation waterfall: each bar = PV(FCFF_t) added cumulatively,
    final two bars = PV(TV) and total EV.

    Args:
        dcf_schedule:       List of DCFYearResult (or dicts) with pv_fcff + fiscal_year.
        pv_terminal_value:  PV of the terminal value ($).
        enterprise_value:   Total EV = Σ PV(FCFF) + PV(TV) ($).
    """
    # Extract pv_fcff values
    pv_fcff_list: list[float] = []
    year_labels:  list[str]   = []
    for row in dcf_schedule:
        if isinstance(row, dict):
            pv_fcff_list.append(row["pv_fcff"])
            year_labels.append(f"FY{row['fiscal_year']}")
        else:
            pv_fcff_list.append(row.pv_fcff)  # type: ignore[union-attr]
            year_labels.append(f"FY{row.fiscal_year}")  # type: ignore[union-attr]

    # Scale to billions
    pv_b   = [v / 1e9 for v in pv_fcff_list]
    pv_tv  = pv_terminal_value / 1e9
    ev_b   = enterprise_value / 1e9

    # Build waterfall: running total base for each bar
    n          = len(pv_b)
    cumulative = np.cumsum([0.0] + pv_b)

    labels  = year_labels + ["PV(TV)", "EV"]
    heights = pv_b + [pv_tv, 0.0]
    bottoms = list(cumulative[:-1]) + [cumulative[-1], 0.0]
    colors  = (
        [C["blue"]] * n
        + [C["amber"]]           # PV(TV) — highlight differently
        + [C["emerald"]]         # EV total
    )
    alphas = [0.75] * n + [0.90, 1.0]

    fig, ax = plt.subplots(figsize=(7.2, 3.6))

    # Draw bars
    x = np.arange(len(labels))
    for i, (xi, h, bot, col, alp) in enumerate(zip(x, heights, bottoms, colors, alphas)):
        ax.bar(xi, h, bottom=bot, color=col, alpha=alp, width=0.6)

        # Add connector lines between bars (except last two)
        if i < n - 1:
            ax.plot([xi + 0.3, xi + 0.7], [bot + h, bot + h],
                    color=C["border"], linewidth=0.6, zorder=5)

        # Value labels
        if i < n:
            label_text = f"${h:.1f}B"
        else:
            label_text = f"${h:.1f}B" if i == n else f"${ev_b:.1f}B"

        label_bar(ax, xi, bot + h + ev_b * 0.01, label_text,
                  color=C["text_secondary"], fontsize=6)

    # EV total bar (from 0 to ev_b)
    ax.bar(x[-1], ev_b, color=C["emerald"], alpha=1.0, width=0.6)
    label_bar(ax, x[-1], ev_b + ev_b * 0.01, f"${ev_b:.1f}B",
              color=C["emerald"], fontsize=7)

    # Horizontal reference at EV
    ax.axhline(ev_b, color=C["emerald"], linewidth=0.7, linestyle="--", alpha=0.5)

    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=30, ha="right", fontsize=7)
    ax.yaxis.set_major_formatter(FuncFormatter(fmt_billions))
    ax.set_ylabel("Cumulative PV ($B)", color=C["text_secondary"])
    clean_spines(ax)
    add_chart_title(ax, "DCF Waterfall — Present Value Build-Up",
                    "Each bar = discounted FCFF contribution · Final = Enterprise Value")
    fig.tight_layout()
    return to_png(fig)


# ── 5. Enterprise Value Bridge ───────────────────────────────────────────────────

def ev_bridge_chart(
    enterprise_value: float,
    net_debt: float,
    minority_interest: float,
    preferred_equity: float,
    equity_value: float,
    shares_outstanding: float,
    fair_value_per_share: float,
) -> bytes:
    """
    Horizontal waterfall bridge from Enterprise Value to Fair Value per Share.

    EV → − Net Debt → − Minority Int → − Preferred → = Equity Value

    Args:
        All values in full dollars (not billions).
    """
    # Convert to billions for display
    ev_b   = enterprise_value   / 1e9
    nd_b   = net_debt           / 1e9
    mi_b   = minority_interest  / 1e9
    pe_b   = preferred_equity   / 1e9
    eq_b   = equity_value       / 1e9

    steps = [
        ("Enterprise\nValue",   ev_b,   0,          C["blue"],    "positive"),
        ("− Net Debt",          nd_b,   ev_b - nd_b, C["red"],    "negative"),
        ("− Minority\nInt.",    mi_b,   ev_b - nd_b - mi_b, C["red"] if mi_b > 0 else C["slate"], "negative" if mi_b > 0 else "zero"),
        ("− Preferred\nEquity", pe_b,   eq_b,        C["red"] if pe_b > 0 else C["slate"], "negative" if pe_b > 0 else "zero"),
        ("Equity\nValue",       eq_b,   0,           C["emerald"],  "positive"),
    ]

    fig, (ax_top, ax_bot) = plt.subplots(
        2, 1, figsize=SIZE["full_tall"],
        gridspec_kw={"height_ratios": [3, 1], "hspace": 0.4}
    )

    # ── Top: EV bridge ───────────────────────────────────────────────────────
    x = np.arange(len(steps))
    for i, (lbl, val, bottom, color, kind) in enumerate(steps):
        if kind == "positive":
            ax_top.bar(i, val, bottom=bottom, color=color, alpha=0.85, width=0.6)
            ax_top.text(i, bottom + val / 2, f"${val:.1f}B",
                        ha="center", va="center", fontsize=7,
                        color="white", fontweight="semibold")
        elif kind == "negative" and val > 0:
            ax_top.bar(i, -val, bottom=bottom + val, color=color, alpha=0.70, width=0.6)
            ax_top.text(i, bottom + val / 2, f"−${val:.1f}B",
                        ha="center", va="center", fontsize=7,
                        color="white", fontweight="semibold")

        # Connector line (except last)
        if i < len(steps) - 1:
            next_bot = steps[i + 1][2]
            next_top = next_bot + (steps[i + 1][1] if steps[i + 1][3] == "positive" else steps[i + 1][2])
            running  = steps[i][2] + steps[i][1] if kind == "positive" else steps[i][2]
            ax_top.plot([i + 0.3, i + 0.7], [running, running],
                        color=C["border"], linewidth=0.6)

    ax_top.set_xticks(x)
    ax_top.set_xticklabels([s[0] for s in steps], fontsize=7.5)
    ax_top.yaxis.set_major_formatter(FuncFormatter(fmt_billions))
    clean_spines(ax_top)
    add_chart_title(ax_top, "Enterprise Value Bridge",
                    "EV → Equity Value via Capital Structure")
    ax_top.axhline(0, color=C["border"], linewidth=0.5)

    # ── Bottom: share price derivation (text-only mini panel) ───────────────
    ax_bot.axis("off")
    derivation = (
        f"Equity Value: ${eq_b:.2f}B  ÷  "
        f"Shares: {shares_outstanding/1e9:.2f}B  =  "
        f"Fair Value / Share: ${fair_value_per_share:.2f}"
    )
    ax_bot.text(0.5, 0.5, derivation,
                ha="center", va="center", transform=ax_bot.transAxes,
                fontsize=8.5, color=C["emerald"],
                fontfamily="DejaVu Sans Mono",
                bbox=dict(boxstyle="round,pad=0.4", facecolor=C["panel"],
                          edgecolor=C["emerald"], linewidth=0.8))

    fig.tight_layout()
    return to_png(fig)
