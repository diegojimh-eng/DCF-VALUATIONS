"""
reports/charts/valuation_charts.py
-------------------------------------
Sensitivity Heatmap and Football Field Valuation Chart.

Sensitivity Heatmap:
  2-D colour grid: WACC (rows) × Terminal Growth Rate (columns).
  Cell value = Fair Value per Share.
  Colour = diverging green (high) → red (low), base case in blue box.

Football Field:
  Horizontal bar chart showing the implied valuation range from each method:
    DCF Bear / Base / Bull
    Sensitivity (min–max)
    Comps (Q1–median–Q3 per multiple)
  Current market price shown as a vertical dotted line.
"""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors
from matplotlib.ticker import FuncFormatter
from matplotlib.patches import FancyBboxPatch

from reports.theme import (
    C, SIZE, clean_spines, add_chart_title,
    fmt_billions, fmt_price, to_png, label_bar,
)


# ── 6. Sensitivity Heatmap ───────────────────────────────────────────────────────

def sensitivity_heatmap(
    wacc_values: list[float],
    growth_values: list[float],
    fvps_matrix: list[list[float]],
    base_wacc: float,
    base_growth: float,
) -> bytes:
    """
    Annotated WACC × g heatmap showing Fair Value per Share in every cell.

    Args:
        wacc_values:   Row axis — WACC values (ascending, decimal).
        growth_values: Column axis — terminal growth rates (ascending, decimal).
        fvps_matrix:   fvps_matrix[wacc_idx][growth_idx] = FVPS.
        base_wacc:     Base-case WACC (highlighted in blue).
        base_growth:   Base-case growth rate (highlighted in blue).

    Returns:
        PNG bytes.
    """
    data = np.array(fvps_matrix, dtype=float)
    # Zero cells → NaN (invalid WACC−g combinations)
    data[data <= 0] = np.nan

    n_wacc, n_g = data.shape

    # Build diverging colour map: red (low) → white (mid) → green (high)
    cmap = mcolors.LinearSegmentedColormap.from_list(
        "valupro_heat",
        [C["red"], "#3d1f1f", C["panel"], "#0d3b2a", C["emerald"]],
        N=256,
    )

    fig, ax = plt.subplots(figsize=SIZE["heatmap"])

    vmin = np.nanmin(data)
    vmax = np.nanmax(data)
    im = ax.imshow(data, aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax)

    # Axis labels
    ax.set_xticks(range(n_g))
    ax.set_xticklabels([f"{g*100:.1f}%" for g in growth_values], fontsize=7)
    ax.set_yticks(range(n_wacc))
    ax.set_yticklabels([f"{w*100:.1f}%" for w in wacc_values], fontsize=7)
    ax.set_xlabel("Terminal Growth Rate", color=C["text_secondary"], fontsize=8)
    ax.set_ylabel("WACC", color=C["text_secondary"], fontsize=8)

    # Cell annotations
    for wi in range(n_wacc):
        for gi in range(n_g):
            val = data[wi, gi]
            if np.isnan(val):
                continue

            is_base = (
                abs(wacc_values[wi]   - base_wacc)   < 0.0001 and
                abs(growth_values[gi] - base_growth) < 0.0001
            )

            txt_color = "white" if (val - vmin) / (vmax - vmin) < 0.35 else "white"
            weight    = "bold" if is_base else "normal"
            fontsize  = 7.5 if is_base else 6.5

            ax.text(gi, wi, f"${val:.2f}",
                    ha="center", va="center",
                    color=txt_color, fontsize=fontsize, fontweight=weight,
                    fontfamily="DejaVu Sans Mono")

            if is_base:
                # Blue border for base case cell
                rect = plt.Rectangle(
                    (gi - 0.48, wi - 0.48), 0.96, 0.96,
                    linewidth=1.5, edgecolor=C["blue"], facecolor="none", zorder=5,
                )
                ax.add_patch(rect)

    # Colorbar
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.ax.tick_params(labelsize=6, colors=C["text_secondary"])
    cbar.ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"${v:.0f}"))
    cbar.outline.set_edgecolor(C["border"])

    ax.set_facecolor(C["panel"])
    fig.patch.set_facecolor(C["bg"])
    add_chart_title(ax, "Sensitivity Analysis — Fair Value per Share",
                    "WACC × Terminal Growth Rate · Base case in blue border")
    fig.tight_layout()
    return to_png(fig)


# ── 7. Football Field Valuation Chart ────────────────────────────────────────────

def football_field_chart(
    ranges: list[dict],
    current_price: float | None = None,
) -> bytes:
    """
    Horizontal bar "football field" chart showing valuation ranges.

    Args:
        ranges: List of dicts with keys:
                  method (str), low (float), high (float), midpoint (float)
                Items are displayed bottom-to-top (first item at bottom).
        current_price: Market price for the vertical reference line.

    Returns:
        PNG bytes.
    """
    if not ranges:
        fig, ax = plt.subplots(figsize=SIZE["wide_short"])
        ax.text(0.5, 0.5, "No valuation ranges available",
                ha="center", va="center", transform=ax.transAxes,
                color=C["text_muted"])
        return to_png(fig)

    # Sort: longer ranges at bottom (ascending total range)
    sorted_ranges = sorted(ranges, key=lambda r: r["high"] - r["low"])

    labels  = [r["method"]   for r in sorted_ranges]
    lows    = [r["low"]      for r in sorted_ranges]
    highs   = [r["high"]     for r in sorted_ranges]
    mids    = [r.get("midpoint", (r["low"] + r["high"]) / 2) for r in sorted_ranges]

    n = len(labels)
    y = np.arange(n)

    # Global scale
    all_vals  = lows + highs
    if current_price:
        all_vals.append(current_price)
    scale_min = min(all_vals) * 0.93
    scale_max = max(all_vals) * 1.07

    # Colour mapping by method type
    def bar_color(method: str) -> tuple[str, float]:
        m = method.lower()
        if "bear" in m:    return C["amber"],   0.75
        if "bull" in m:    return C["emerald"], 0.75
        if "base" in m:    return C["blue"],    0.85
        if "full" in m:    return C["slate"],   0.55
        if "sens" in m:    return "#7c3aed",    0.60
        if "comp" in m:    return "#0e7490",    0.70
        return C["slate"], 0.60

    fig, ax = plt.subplots(figsize=(7.2, 0.55 * n + 1.4))

    height = 0.55

    for i, (lbl, lo, hi, mid) in enumerate(zip(labels, lows, highs, mids)):
        color, alpha = bar_color(lbl)
        width = hi - lo

        # Bar
        ax.barh(i, width, left=lo, height=height,
                color=color, alpha=alpha, zorder=3)

        # Midpoint tick
        ax.plot([mid, mid], [i - height/2, i + height/2],
                color="white", linewidth=1.0, zorder=4, alpha=0.7)

        # Low / high labels
        ax.text(lo  - (scale_max - scale_min) * 0.005, i,
                f"${lo:.0f}", ha="right", va="center",
                fontsize=6.5, color=C["text_muted"], fontfamily="DejaVu Sans Mono")
        ax.text(hi  + (scale_max - scale_min) * 0.005, i,
                f"${hi:.0f}", ha="left",  va="center",
                fontsize=6.5, color=C["text_muted"], fontfamily="DejaVu Sans Mono")
        ax.text(mid, i, f"${mid:.0f}", ha="center", va="center",
                fontsize=6.5, color="white", fontweight="semibold",
                fontfamily="DejaVu Sans Mono", zorder=5)

    # Current price line
    if current_price:
        ax.axvline(current_price, color=C["blue"], linewidth=1.4,
                   linestyle="--", zorder=6, alpha=0.9)
        ax.text(current_price, n - 0.1,
                f" Current\n ${current_price:.2f}",
                ha="left", va="top", fontsize=6.5,
                color=C["blue"], fontweight="semibold")

    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=7.5)
    ax.set_xlim(scale_min, scale_max)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"${v:.0f}"))
    ax.tick_params(axis="x", labelsize=7)
    clean_spines(ax)
    ax.spines["left"].set_visible(False)
    ax.yaxis.set_tick_params(length=0)

    add_chart_title(ax, "Football Field — Valuation Range Summary",
                    "All methods · Per share · Current price shown as dashed line")
    ax.set_facecolor(C["panel"])
    fig.patch.set_facecolor(C["bg"])
    ax.grid(axis="x", color=C["grid"], linewidth=0.4, alpha=0.8)
    ax.grid(axis="y", visible=False)
    fig.tight_layout()
    return to_png(fig)
