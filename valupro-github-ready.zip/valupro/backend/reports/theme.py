"""
reports/theme.py
-----------------
Design tokens for all Matplotlib-rendered charts in the PDF report.

The palette mirrors the frontend (Navy / Blue / Emerald / Amber / Red) so
charts feel visually continuous with the dashboard.  All charts share:

  • Dark navy background  (#060b18)
  • Hairline grid lines in very dark slate
  • Inter-equivalent fallback (DejaVu Sans — ships with matplotlib)
  • JetBrains Mono-equivalent for tick labels (DejaVu Sans Mono)
  • Fixed figure sizes matched to ReportLab A4 column widths
"""

from __future__ import annotations

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import numpy as np

# ── Palette ─────────────────────────────────────────────────────────────────────

C = {
    # Surfaces
    "bg":          "#060b18",
    "panel":       "#0a1628",
    "border":      "#1e293b",
    "grid":        "#132035",

    # Text
    "text_primary":  "#f1f5f9",
    "text_secondary":"#94a3b8",
    "text_muted":    "#475569",

    # Accent
    "blue":        "#3b82f6",
    "blue_light":  "#60a5fa",
    "blue_dark":   "#1d4ed8",
    "blue_fill":   "#1e3d7a",

    # Semantic
    "emerald":     "#10b981",
    "emerald_fill":"#064e3b",
    "amber":       "#f59e0b",
    "amber_fill":  "#78350f",
    "red":         "#ef4444",
    "red_fill":    "#7f1d1d",
    "slate":       "#475569",
    "slate_light": "#64748b",

    # Scenario
    "bear":        "#f59e0b",
    "bear_fill":   "rgba(245,158,11,0.15)",
    "base":        "#3b82f6",
    "base_fill":   "rgba(59,130,246,0.15)",
    "bull":        "#10b981",
    "bull_fill":   "rgba(16,185,129,0.15)",
}

# ── Chart defaults ───────────────────────────────────────────────────────────────

# Apply dark theme globally
mpl.rcParams.update({
    "figure.facecolor":     C["bg"],
    "axes.facecolor":       C["panel"],
    "axes.edgecolor":       C["border"],
    "axes.labelcolor":      C["text_secondary"],
    "axes.titlecolor":      C["text_primary"],
    "axes.titlesize":       10,
    "axes.titleweight":     "semibold",
    "axes.labelsize":       8,
    "axes.grid":            True,
    "grid.color":           C["grid"],
    "grid.linewidth":       0.5,
    "grid.alpha":           1.0,
    "xtick.color":          C["text_muted"],
    "ytick.color":          C["text_muted"],
    "xtick.labelsize":      7,
    "ytick.labelsize":      7,
    "xtick.labelcolor":     C["text_secondary"],
    "ytick.labelcolor":     C["text_secondary"],
    "legend.facecolor":     C["panel"],
    "legend.edgecolor":     C["border"],
    "legend.labelcolor":    C["text_secondary"],
    "legend.fontsize":      7,
    "legend.framealpha":    0.9,
    "text.color":           C["text_primary"],
    "font.family":          "DejaVu Sans",
    "font.size":            8,
    "lines.linewidth":      1.8,
    "patch.linewidth":      0.5,
    "figure.dpi":           150,
    "savefig.dpi":          150,
    "savefig.facecolor":    C["bg"],
    "savefig.edgecolor":    "none",
    "savefig.bbox":         "tight",
    "savefig.pad_inches":   0.1,
})

# ── Standard figure sizes (inches, for A4 PDF) ───────────────────────────────────

SIZE = {
    "full":       (7.2, 3.2),   # full-width chart
    "full_tall":  (7.2, 4.0),   # full-width, taller
    "half":       (3.5, 2.8),   # half-width (two per row)
    "wide_short": (7.2, 2.2),   # full width, shallow (football field)
    "heatmap":    (5.5, 3.0),   # sensitivity heatmap
}

# ── Shared formatting helpers ────────────────────────────────────────────────────

def fmt_billions(x: float, pos: int = 0) -> str:
    if abs(x) >= 1e12: return f"${x/1e12:.1f}T"
    if abs(x) >= 1e9:  return f"${x/1e9:.1f}B"
    if abs(x) >= 1e6:  return f"${x/1e6:.0f}M"
    return f"${x:.0f}"

def fmt_pct(x: float, pos: int = 0) -> str:
    return f"{x*100:.1f}%"

def fmt_price(x: float, pos: int = 0) -> str:
    return f"${x:.2f}"

def fmt_multiple(x: float, pos: int = 0) -> str:
    return f"{x:.1f}×"

# ── Spine cleanup ─────────────────────────────────────────────────────────────────

def clean_spines(ax: "mpl.axes.Axes") -> None:
    """Remove top/right spines, keep bottom/left as hairlines."""
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(C["border"])
    ax.spines["bottom"].set_color(C["border"])
    ax.spines["left"].set_linewidth(0.5)
    ax.spines["bottom"].set_linewidth(0.5)

# ── Panel title style ─────────────────────────────────────────────────────────────

def add_chart_title(ax: "mpl.axes.Axes", title: str, sub: str = "") -> None:
    """Add a styled title above the axes."""
    ax.set_title(
        title if not sub else f"{title}\n{sub}",
        loc="left",
        color=C["text_primary"],
        fontsize=9,
        fontweight="semibold",
        pad=8,
    )
    if sub:
        # Re-do to give subtitle smaller size
        ax.set_title("", loc="left")
        ax.text(0, 1.06, title, transform=ax.transAxes,
                fontsize=9, fontweight="semibold", color=C["text_primary"])
        ax.text(0, 1.01, sub, transform=ax.transAxes,
                fontsize=7, color=C["text_muted"])

# ── Data label helper ─────────────────────────────────────────────────────────────

def label_bar(ax: "mpl.axes.Axes", x: float, y: float, text: str,
              ha: str = "center", va: str = "bottom",
              color: str = C["text_secondary"], fontsize: int = 6) -> None:
    ax.text(x, y, text, ha=ha, va=va, fontsize=fontsize,
            color=color, fontfamily="DejaVu Sans Mono")

# ── Export to PNG bytes ───────────────────────────────────────────────────────────

def to_png(fig: "mpl.figure.Figure") -> bytes:
    """Render a Figure to PNG bytes for embedding in ReportLab."""
    import io
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight",
                facecolor=C["bg"], edgecolor="none")
    buf.seek(0)
    data = buf.read()
    plt.close(fig)
    return data
