"""
reports/ — Phase 9 Visualizations & PDF Report Generation.

Public API:
    from reports import ValuationReportRenderer, build_report_from_mock
    from reports.charts import (
        revenue_chart, ebitda_chart, fcff_chart,
        dcf_waterfall_chart, ev_bridge_chart,
        sensitivity_heatmap, football_field_chart,
    )
"""

from reports.renderer import ValuationReportRenderer, build_report_from_mock
from reports.charts import (
    revenue_chart,
    ebitda_chart,
    fcff_chart,
    dcf_waterfall_chart,
    ev_bridge_chart,
    sensitivity_heatmap,
    football_field_chart,
)

__all__ = [
    "ValuationReportRenderer",
    "build_report_from_mock",
    "revenue_chart",
    "ebitda_chart",
    "fcff_chart",
    "dcf_waterfall_chart",
    "ev_bridge_chart",
    "sensitivity_heatmap",
    "football_field_chart",
]
