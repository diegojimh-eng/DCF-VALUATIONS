"""
reports/pdf_report.py
----------------------
Professional PDF valuation report generator using ReportLab Platypus.

Report structure:
  Cover Page       — Company name, ticker, date, rating, analyst
  Section 1        — Executive Summary (key metrics table + football field)
  Section 2        — WACC & Cost of Capital
  Section 3        — Revenue & EBITDA Forecasts
  Section 4        — FCFF Projections
  Section 5        — DCF Valuation (waterfall + EV bridge + PV schedule)
  Section 6        — Terminal Value Analysis
  Section 7        — Sensitivity Analysis (heatmap)
  Section 8        — Scenario Analysis (Bear / Base / Bull table)
  Section 9        — Trading Comparables
  Appendix         — Detailed assumptions table

All charts are rendered to PNG via the reports.charts module and embedded
as ReportLab Image flowables.
"""

from __future__ import annotations

import io
import os
from datetime import datetime
from typing import Any

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm, mm
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.platypus import (
    BaseDocTemplate, Frame, PageTemplate, SimpleDocTemplate,
    Paragraph, Spacer, Table, TableStyle,
    Image as RLImage, PageBreak, HRFlowable,
    KeepTogether,
)
from reportlab.platypus.flowables import Flowable

# ── Design tokens (mirroring frontend palette) ────────────────────────────────────

NAVY    = colors.HexColor("#060b18")
PANEL   = colors.HexColor("#0a1628")
BORDER  = colors.HexColor("#1e293b")
BLUE    = colors.HexColor("#3b82f6")
BLUE_L  = colors.HexColor("#60a5fa")
EMERALD = colors.HexColor("#10b981")
AMBER   = colors.HexColor("#f59e0b")
RED     = colors.HexColor("#ef4444")
WHITE   = colors.white
SLATE   = colors.HexColor("#94a3b8")
SLATE_D = colors.HexColor("#475569")
BEAR_C  = AMBER
BASE_C  = BLUE
BULL_C  = EMERALD

# Page dimensions
PAGE_W, PAGE_H = A4
MARGIN_L = MARGIN_R = 1.8 * cm
MARGIN_T = 2.0 * cm
MARGIN_B = 1.8 * cm
CONTENT_W = PAGE_W - MARGIN_L - MARGIN_R


# ── Styles ────────────────────────────────────────────────────────────────────────

_BASE_STYLES = getSampleStyleSheet()

def _style(name: str, **kwargs) -> ParagraphStyle:
    return ParagraphStyle(name, **kwargs)

STYLES = {
    "cover_title": _style("cover_title",
        fontName="Helvetica-Bold", fontSize=28, textColor=WHITE,
        spaceAfter=6, leading=32),
    "cover_sub":   _style("cover_sub",
        fontName="Helvetica", fontSize=13, textColor=SLATE,
        spaceAfter=4, leading=16),
    "cover_meta":  _style("cover_meta",
        fontName="Helvetica", fontSize=9, textColor=SLATE_D,
        spaceAfter=2, leading=11),
    "section":     _style("section",
        fontName="Helvetica-Bold", fontSize=11, textColor=WHITE,
        spaceBefore=14, spaceAfter=6, leading=13,
        borderPad=0),
    "body":        _style("body",
        fontName="Helvetica", fontSize=8, textColor=SLATE,
        leading=11, spaceAfter=3),
    "label":       _style("label",
        fontName="Helvetica-Bold", fontSize=7, textColor=SLATE_D,
        leading=9, spaceAfter=1),
    "data":        _style("data",
        fontName="Courier", fontSize=8, textColor=WHITE,
        leading=10, spaceAfter=1),
    "caption":     _style("caption",
        fontName="Helvetica", fontSize=6.5, textColor=SLATE_D,
        leading=8, spaceAfter=2, alignment=TA_CENTER),
    "warn":        _style("warn",
        fontName="Helvetica", fontSize=7.5, textColor=AMBER,
        leading=10, spaceAfter=2),
    "footer":      _style("footer",
        fontName="Helvetica", fontSize=7, textColor=SLATE_D,
        leading=9, alignment=TA_CENTER),
}

# ── Helper: image from bytes ──────────────────────────────────────────────────────

def _img(png_bytes: bytes, width: float = CONTENT_W) -> RLImage:
    buf = io.BytesIO(png_bytes)
    img = RLImage(buf)
    aspect = img.imageWidth / img.imageHeight
    return RLImage(io.BytesIO(png_bytes), width=width, height=width / aspect)

# ── Helper: coloured section header ──────────────────────────────────────────────

def _section_header(title: str, number: str = "") -> list:
    """Return a list of flowables forming a section header with rule."""
    label = f"{number}. {title}" if number else title
    return [
        Spacer(1, 6 * mm),
        HRFlowable(width=CONTENT_W, thickness=0.5, color=BLUE, spaceAfter=3),
        Paragraph(label, STYLES["section"]),
        Spacer(1, 2 * mm),
    ]

# ── Helper: metric table (2-column key/value) ─────────────────────────────────────

def _metric_table(rows: list[tuple[str, str]], cols: int = 2) -> Table:
    """
    Compact two-column metric table.
    rows = [(label, value), ...]
    """
    # Split into col-groups
    n_rows = -(-len(rows) // cols)  # ceiling division
    padded = rows + [("", "")] * (n_rows * cols - len(rows))

    table_data = []
    for i in range(n_rows):
        row = []
        for c in range(cols):
            lbl, val = padded[i + c * n_rows]
            row += [
                Paragraph(lbl, STYLES["label"]),
                Paragraph(val, STYLES["data"]),
            ]
        table_data.append(row)

    col_widths = [3.2 * cm, 4.0 * cm] * cols
    t = Table(table_data, colWidths=col_widths, repeatRows=0)
    t.setStyle(TableStyle([
        ("BACKGROUND",  (0, 0), (-1, -1), PANEL),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [PANEL, colors.HexColor("#0d1e35")]),
        ("TEXTCOLOR",   (0, 0), (-1, -1), SLATE),
        ("FONTNAME",    (0, 0), (-1, -1), "Helvetica"),
        ("FONTSIZE",    (0, 0), (-1, -1), 8),
        ("TOPPADDING",  (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 3),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING",(0, 0), (-1, -1), 5),
        ("LINEBELOW",   (0, 0), (-1, -1), 0.4, BORDER),
        ("BOX",         (0, 0), (-1, -1), 0.5, BORDER),
    ]))
    return t


def _data_table(
    headers: list[str],
    rows: list[list[str]],
    col_widths: list[float] | None = None,
    highlight_col: int | None = None,
) -> Table:
    """Full data table with dark styling and optional column highlight."""
    header_row = [Paragraph(h, STYLES["label"]) for h in headers]
    data_rows  = [[Paragraph(str(c), STYLES["data"]) for c in row] for row in rows]
    all_data   = [header_row] + data_rows

    if col_widths is None:
        col_widths = [CONTENT_W / len(headers)] * len(headers)

    t = Table(all_data, colWidths=col_widths, repeatRows=1)
    style = [
        # Header
        ("BACKGROUND",    (0, 0), (-1, 0), colors.HexColor("#0f2040")),
        ("TEXTCOLOR",     (0, 0), (-1, 0), BLUE_L),
        ("FONTNAME",      (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, 0), 7.5),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 4),
        ("TOPPADDING",    (0, 0), (-1, 0), 4),
        ("LINEBELOW",     (0, 0), (-1, 0), 0.8, BLUE),
        # Data rows
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [PANEL, colors.HexColor("#0d1e35")]),
        ("FONTSIZE",      (0, 1), (-1, -1), 7.5),
        ("TOPPADDING",    (0, 1), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 3),
        ("LEFTPADDING",   (0, 0), (-1, -1), 6),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 6),
        ("LINEBELOW",     (0, 1), (-1, -1), 0.3, BORDER),
        ("BOX",           (0, 0), (-1, -1), 0.5, BORDER),
        ("ALIGN",         (1, 0), (-1, -1), "RIGHT"),
        ("FONTNAME",      (0, 1), (-1, -1), "Courier"),
    ]
    if highlight_col is not None:
        style += [
            ("BACKGROUND",  (highlight_col, 0), (highlight_col, -1), colors.HexColor("#0f2a4a")),
            ("TEXTCOLOR",   (highlight_col, 1), (highlight_col, -1), BLUE_L),
            ("FONTNAME",    (highlight_col, 1), (highlight_col, -1), "Courier-Bold"),
        ]
    t.setStyle(TableStyle(style))
    return t


# ── Page templates ────────────────────────────────────────────────────────────────

class _CoverBackground(Flowable):
    """Full-page navy cover background with blue accent bar."""
    def __init__(self):
        super().__init__()
        self.width = PAGE_W
        self.height = PAGE_H

    def draw(self):
        c = self.canv
        # Navy background
        c.setFillColor(NAVY)
        c.rect(0, 0, PAGE_W, PAGE_H, fill=1, stroke=0)
        # Top accent bar
        c.setFillColor(BLUE)
        c.rect(0, PAGE_H - 8 * mm, PAGE_W, 8 * mm, fill=1, stroke=0)
        # Bottom accent bar
        c.setFillColor(colors.HexColor("#1d4ed8"))
        c.rect(0, 0, PAGE_W, 4 * mm, fill=1, stroke=0)
        # Left blue gutter
        c.setFillColor(colors.HexColor("#0f2040"))
        c.rect(0, 0, 1.2 * cm, PAGE_H, fill=1, stroke=0)


def _on_later_page(canvas, doc):
    """Footer for all pages after the cover."""
    canvas.saveState()
    # Bottom bar
    canvas.setFillColor(colors.HexColor("#0a1628"))
    canvas.rect(0, 0, PAGE_W, 1.2 * cm, fill=1, stroke=0)
    # Top hairline
    canvas.setStrokeColor(BORDER)
    canvas.setLineWidth(0.4)
    canvas.line(MARGIN_L, PAGE_H - MARGIN_T + 4 * mm, PAGE_W - MARGIN_R, PAGE_H - MARGIN_T + 4 * mm)
    # Header text
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(SLATE_D)
    canvas.drawString(MARGIN_L, PAGE_H - MARGIN_T + 6 * mm, "ValuPro Institutional · CONFIDENTIAL")
    canvas.drawRightString(PAGE_W - MARGIN_R, PAGE_H - MARGIN_T + 6 * mm,
                            f"Generated {datetime.utcnow().strftime('%d %b %Y')}")
    # Page number
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(SLATE_D)
    canvas.drawCentredString(PAGE_W / 2, 6 * mm, f"Page {doc.page}")
    canvas.restoreState()


# ── Main PDF builder ──────────────────────────────────────────────────────────────

class ValuationPDFBuilder:
    """
    Builds the complete institutional PDF valuation report.

    Usage:
        builder = ValuationPDFBuilder()
        pdf_bytes = builder.build(report_data)
    """

    def build(self, data: "ReportData") -> bytes:
        """
        Generate the full PDF and return it as bytes.

        Args:
            data: A ReportData instance with all valuation outputs.

        Returns:
            Raw PDF bytes.
        """
        buf = io.BytesIO()

        doc = SimpleDocTemplate(
            buf,
            pagesize=A4,
            leftMargin=MARGIN_L,
            rightMargin=MARGIN_R,
            topMargin=MARGIN_T,
            bottomMargin=MARGIN_B,
            title=f"ValuPro — {data.ticker} Valuation Report",
            author="ValuPro Institutional",
            subject="Equity Valuation Report",
        )

        story: list = []

        # ── Cover ────────────────────────────────────────────────────────────
        story += self._cover(data)
        story.append(PageBreak())
        story.append(Paragraph("", ParagraphStyle("switch", pageBreakBefore=False)))

        # ── Section 1: Executive Summary ─────────────────────────────────────
        story += self._executive_summary(data)

        # ── Section 2: WACC ──────────────────────────────────────────────────
        story += self._wacc_section(data)

        # ── Section 3: Revenue & EBITDA Forecasts ────────────────────────────
        story += self._forecast_section(data)

        # ── Section 4: DCF Analysis ───────────────────────────────────────────
        story += self._dcf_section(data)

        # ── Section 5: Terminal Value ─────────────────────────────────────────
        story += self._terminal_value_section(data)

        # ── Section 6: Sensitivity Analysis ──────────────────────────────────
        story += self._sensitivity_section(data)

        # ── Section 7: Scenario Analysis ─────────────────────────────────────
        story += self._scenario_section(data)

        # ── Section 8: Trading Comparables ───────────────────────────────────
        if data.comps_result:
            story += self._comps_section(data)

        # ── Appendix: Assumptions ─────────────────────────────────────────────
        story += self._appendix(data)

        def _cover_bg(canvas, doc):
            canvas.saveState()
            canvas.setFillColor(NAVY)
            canvas.rect(0, 0, PAGE_W, PAGE_H, fill=1, stroke=0)
            canvas.setFillColor(BLUE)
            canvas.rect(0, PAGE_H - 8*mm, PAGE_W, 8*mm, fill=1, stroke=0)
            canvas.setFillColor(colors.HexColor("#1d4ed8"))
            canvas.rect(0, 0, PAGE_W, 4*mm, fill=1, stroke=0)
            canvas.restoreState()

        doc.build(story, onFirstPage=_cover_bg, onLaterPages=_on_later_page)

        buf.seek(0)
        return buf.read()

    # ── Cover ─────────────────────────────────────────────────────────────────

    def _cover(self, data: "ReportData") -> list:
        elements: list = []
        # Background (drawn via canvas in the frame)
        # Background drawn via page template canvas, not as a flowable
        elements.append(Spacer(1, 5.5 * cm))

        # Ticker
        elements.append(Paragraph(
            f'<font color="#60a5fa" size="14"><b>{data.ticker}</b></font>',
            STYLES["cover_sub"]
        ))
        # Company name
        elements.append(Paragraph(
            data.company_name or data.ticker,
            STYLES["cover_title"]
        ))
        elements.append(Spacer(1, 0.6 * cm))

        # Rating box
        rating_color = "#10b981" if (data.price_vs_intrinsic or "").startswith("UNDER") \
                       else "#ef4444" if "OVER" in (data.price_vs_intrinsic or "") \
                       else "#f59e0b"
        elements.append(Paragraph(
            f'<font color="{rating_color}" size="16"><b>{data.price_vs_intrinsic or "UNDER REVIEW"}</b></font>',
            STYLES["cover_sub"]
        ))
        elements.append(Spacer(1, 0.4 * cm))

        # Key metrics
        fvps  = data.base_fair_value_per_share
        cur   = data.current_price
        upside = f"+{((fvps/cur - 1)*100):.1f}%" if cur and fvps else "N/A"

        elements.append(Paragraph(
            f"Base Fair Value: <b>${fvps:.2f}</b>  ·  "
            f"Current: <b>${cur:.2f}</b>  ·  "
            f"Upside: <b>{upside}</b>",
            STYLES["cover_meta"]
        ))
        elements.append(Spacer(1, 0.2 * cm))
        elements.append(Paragraph(
            f"WACC: <b>{data.wacc*100:.2f}%</b>  ·  "
            f"Terminal Growth: <b>{data.terminal_growth_rate*100:.2f}%</b>  ·  "
            f"EV: <b>${data.enterprise_value/1e9:.1f}B</b>",
            STYLES["cover_meta"]
        ))
        elements.append(Spacer(1, 1.5 * cm))
        elements.append(HRFlowable(width=CONTENT_W, thickness=0.5, color=BLUE))
        elements.append(Spacer(1, 0.3 * cm))
        elements.append(Paragraph(
            f"ValuPro Institutional Valuation Platform  ·  "
            f"Generated {datetime.utcnow().strftime('%d %B %Y')}  ·  CONFIDENTIAL",
            STYLES["cover_meta"]
        ))
        return elements

    # ── Section 1: Executive Summary ─────────────────────────────────────────

    def _executive_summary(self, data: "ReportData") -> list:
        elements = _section_header("Executive Summary", "1")

        # Key metrics table
        fvps  = data.base_fair_value_per_share
        cur   = data.current_price or 0
        upside = f"+{((fvps/cur - 1)*100):.1f}%" if cur else "N/A"

        metrics = [
            ("Ticker",              data.ticker),
            ("Company",             data.company_name or data.ticker),
            ("Valuation Date",      datetime.utcnow().strftime("%d %b %Y")),
            ("Rating",              data.price_vs_intrinsic or "—"),
            ("Fair Value (Base)",   f"${fvps:.2f}"),
            ("Fair Value (Bear)",   f"${data.bear_fvps:.2f}"),
            ("Fair Value (Bull)",   f"${data.bull_fvps:.2f}"),
            ("Blended Fair Value",  f"${data.blended_fvps:.2f}"),
            ("Current Price",       f"${cur:.2f}"),
            ("Upside to Base",      upside),
            ("Enterprise Value",    f"${data.enterprise_value/1e9:.2f}B"),
            ("Equity Value",        f"${data.equity_value/1e9:.2f}B"),
            ("WACC",                f"{data.wacc*100:.2f}%"),
            ("Ke (CAPM)",           f"{data.ke*100:.2f}%"),
            ("Kd (after-tax)",      f"{data.kd*100:.2f}%"),
            ("Terminal Growth",     f"{data.terminal_growth_rate*100:.2f}%"),
            ("PV(TV) % of EV",      f"{data.pv_tv_pct*100:.1f}%"),
            ("Forecast Horizon",    "10 years"),
        ]
        elements.append(_metric_table(metrics, cols=2))
        elements.append(Spacer(1, 5 * mm))

        # Football field chart
        if data.chart_football_field:
            elements.append(Paragraph("Valuation Range — Football Field", STYLES["label"]))
            elements.append(Spacer(1, 2 * mm))
            elements.append(_img(data.chart_football_field, width=CONTENT_W))
            elements.append(Paragraph(
                "Bear / Base / Bull DCF + Sensitivity + Trading Comparables. "
                "Dashed line = current market price.",
                STYLES["caption"]
            ))

        # Warnings
        if data.warnings:
            elements.append(Spacer(1, 4 * mm))
            for w in data.warnings[:4]:
                elements.append(Paragraph(f"⚠  {w}", STYLES["warn"]))

        return elements

    # ── Section 2: WACC ──────────────────────────────────────────────────────

    def _wacc_section(self, data: "ReportData") -> list:
        elements = _section_header("WACC & Cost of Capital", "2")
        elements.append(Paragraph(
            "WACC is computed via the Capital Asset Pricing Model (CAPM) for the cost of equity "
            "and the interest expense / gross debt ratio for the pre-tax cost of debt.",
            STYLES["body"]
        ))
        elements.append(Spacer(1, 3 * mm))

        wacc_items = [
            ("Beta (levered)",      f"{data.wacc_result.beta_used:.2f}"),
            ("Risk-Free Rate",      f"{data.wacc_result.risk_free_rate*100:.2f}%"),
            ("Equity Risk Premium", f"{data.wacc_result.equity_risk_premium*100:.2f}%"),
            ("Cost of Equity (Ke)", f"{data.ke*100:.2f}%"),
            ("Pre-tax Kd",          f"{data.wacc_result.kd_pretax*100:.2f}%"),
            ("After-tax Kd",        f"{data.kd*100:.2f}%"),
            ("Tax Rate",            f"{data.wacc_result.tax_rate*100:.1f}%"),
            ("Market Cap (E)",      f"${data.wacc_result.market_cap/1e9:.1f}B"),
            ("Gross Debt (D)",      f"${data.wacc_result.gross_debt/1e9:.1f}B"),
            ("E / V (weight)",      f"{data.wacc_result.equity_weight*100:.1f}%"),
            ("D / V (weight)",      f"{data.wacc_result.debt_weight*100:.1f}%"),
            ("WACC",                f"{data.wacc*100:.2f}%"),
        ]
        elements.append(_metric_table(wacc_items, cols=2))

        # Formula display
        elements.append(Spacer(1, 4 * mm))
        formula = (
            f"<font name='Courier' size='8' color='#94a3b8'>"
            f"Ke  = Rf + β × ERP<br/>"
            f"    = {data.wacc_result.risk_free_rate*100:.2f}% + "
            f"{data.wacc_result.beta_used:.2f} × "
            f"{data.wacc_result.equity_risk_premium*100:.2f}% = {data.ke*100:.2f}%<br/><br/>"
            f"WACC = (E/V) × Ke + (D/V) × Kd × (1 − t)<br/>"
            f"     = ({data.wacc_result.equity_weight*100:.1f}%) × {data.ke*100:.2f}% "
            f"+ ({data.wacc_result.debt_weight*100:.1f}%) × {data.kd*100:.2f}%<br/>"
            f"     = {data.wacc*100:.2f}%"
            f"</font>"
        )
        elements.append(Paragraph(formula, STYLES["data"]))
        return elements

    # ── Section 3: Revenue & EBITDA Forecasts ────────────────────────────────

    def _forecast_section(self, data: "ReportData") -> list:
        elements = _section_header("Revenue & EBITDA Forecasts", "3")

        if data.chart_revenue:
            elements.append(Paragraph("Revenue Forecast", STYLES["label"]))
            elements.append(Spacer(1, 2 * mm))
            elements.append(_img(data.chart_revenue, width=CONTENT_W))
            elements.append(Paragraph(
                "Grouped bar chart showing Revenue by scenario. Secondary axis: Base case YoY growth rate.",
                STYLES["caption"]
            ))
            elements.append(Spacer(1, 5 * mm))

        if data.chart_ebitda:
            elements.append(Paragraph("EBITDA Forecast", STYLES["label"]))
            elements.append(Spacer(1, 2 * mm))
            elements.append(_img(data.chart_ebitda, width=CONTENT_W))
            elements.append(Paragraph(
                "Area chart showing EBITDA by scenario. Dotted line: Base case EBITDA margin %.",
                STYLES["caption"]
            ))

        # Forecast table
        if data.forecast_table:
            elements.append(Spacer(1, 5 * mm))
            elements.append(Paragraph("10-Year Revenue & EBITDA Projection (Base Case)", STYLES["label"]))
            elements.append(Spacer(1, 2 * mm))
            headers = ["Year", "Revenue", "Growth", "EBITDA", "Margin", "EBIT"]
            col_w   = [1.5*cm, 2.8*cm, 1.8*cm, 2.8*cm, 1.8*cm, 2.8*cm]
            elements.append(_data_table(headers, data.forecast_table, col_w))

        return elements

    # ── Section 4: DCF Analysis ───────────────────────────────────────────────

    def _dcf_section(self, data: "ReportData") -> list:
        elements = _section_header("DCF Valuation", "4")
        elements.append(Paragraph(
            "Discounted Cash Flow valuation discounting 10 years of projected FCFF "
            "(Free Cash Flow to Firm) at the computed WACC, plus the present value "
            "of the terminal value.",
            STYLES["body"]
        ))
        elements.append(Spacer(1, 3 * mm))

        if data.chart_fcff:
            elements.append(Paragraph("FCFF Projection", STYLES["label"]))
            elements.append(Spacer(1, 2 * mm))
            elements.append(_img(data.chart_fcff, width=CONTENT_W))
            elements.append(Paragraph(
                "FCFF = NOPAT + D&A − CapEx − ΔNWC. Step-line = PV(FCFF) base case.",
                STYLES["caption"]
            ))
            elements.append(Spacer(1, 5 * mm))

        if data.chart_dcf_waterfall:
            elements.append(Paragraph("DCF Waterfall — PV Build-Up", STYLES["label"]))
            elements.append(Spacer(1, 2 * mm))
            elements.append(_img(data.chart_dcf_waterfall, width=CONTENT_W))
            elements.append(Paragraph(
                "Each bar = discounted FCFF in that year. Final bar = total Enterprise Value.",
                STYLES["caption"]
            ))
            elements.append(Spacer(1, 5 * mm))

        if data.chart_ev_bridge:
            elements.append(Paragraph("Enterprise Value Bridge", STYLES["label"]))
            elements.append(Spacer(1, 2 * mm))
            elements.append(_img(data.chart_ev_bridge, width=CONTENT_W))
            elements.append(Paragraph(
                "EV → − Net Debt → − Minority Interest → − Preferred Equity → = Equity Value "
                "→ ÷ Shares Outstanding → = Fair Value per Share.",
                STYLES["caption"]
            ))

        # PV schedule
        if data.dcf_schedule_table:
            elements.append(Spacer(1, 5 * mm))
            elements.append(Paragraph("Present Value Schedule (Base Case)", STYLES["label"]))
            elements.append(Spacer(1, 2 * mm))
            headers = ["Year", "FCFF", "Disc. Factor", "PV(FCFF)"]
            col_w   = [1.8*cm, 4.0*cm, 2.8*cm, 4.0*cm]
            elements.append(_data_table(headers, data.dcf_schedule_table, col_w, highlight_col=3))

        return elements

    # ── Section 5: Terminal Value ─────────────────────────────────────────────

    def _terminal_value_section(self, data: "ReportData") -> list:
        elements = _section_header("Terminal Value Analysis", "5")

        tv = data.terminal_value_result
        tv_items = [
            ("Method",            tv.method_used.replace("_", " ").title()),
            ("Terminal Growth g", f"{tv.terminal_growth_rate*100:.2f}%"),
            ("WACC",              f"{tv.wacc*100:.2f}%"),
            ("WACC − g Spread",   f"{(tv.wacc - tv.terminal_growth_rate)*100:.2f}%"),
            ("FCFF (Year 10)",    f"${tv.fcff_terminal/1e9:.2f}B"),
            ("Terminal Value",    f"${tv.tv_final/1e9:.2f}B"),
            ("PV(Terminal Value)",f"${tv.pv_terminal_value/1e9:.2f}B"),
            ("PV(TV) % of EV",   f"{tv.pv_terminal_value_pct*100:.1f}%"),
        ]
        if tv.tv_gordon_growth:
            tv_items.append(("GGM Terminal Value", f"${tv.tv_gordon_growth/1e9:.2f}B"))
        if tv.tv_exit_multiple:
            tv_items.append(("Exit Multiple TV", f"${tv.tv_exit_multiple/1e9:.2f}B"))

        elements.append(_metric_table(tv_items, cols=2))
        elements.append(Spacer(1, 4 * mm))

        # Gordon Growth formula
        g = tv.terminal_growth_rate
        w = tv.wacc
        formula = (
            f"<font name='Courier' size='8' color='#94a3b8'>"
            f"TV  = FCFF_N × (1 + g) / (WACC − g)<br/>"
            f"    = ${tv.fcff_terminal/1e9:.2f}B × (1 + {g*100:.2f}%) / "
            f"({w*100:.2f}% − {g*100:.2f}%)<br/>"
            f"    = ${tv.tv_final/1e9:.2f}B<br/><br/>"
            f"PV(TV) = TV / (1 + WACC)^10<br/>"
            f"       = ${tv.pv_terminal_value/1e9:.2f}B"
            f"</font>"
        )
        elements.append(Paragraph(formula, STYLES["data"]))
        return elements

    # ── Section 6: Sensitivity ────────────────────────────────────────────────

    def _sensitivity_section(self, data: "ReportData") -> list:
        elements = _section_header("Sensitivity Analysis — WACC × Terminal Growth", "6")
        elements.append(Paragraph(
            "Each cell shows the implied Fair Value per Share at a given WACC / terminal growth "
            "rate combination. All other assumptions (FCFF series, capital structure) are held "
            "at their base-case values. The blue-bordered cell is the base case.",
            STYLES["body"]
        ))
        elements.append(Spacer(1, 3 * mm))

        if data.chart_sensitivity:
            elements.append(_img(data.chart_sensitivity, width=CONTENT_W))
            elements.append(Paragraph(
                "Green = higher implied value (low WACC, high g). "
                "Red = lower implied value (high WACC, low g).",
                STYLES["caption"]
            ))

        # Range summary
        sm = data.sensitivity_matrix
        if sm:
            lo, hi = sm.fvps_range()
            elements.append(Spacer(1, 4 * mm))
            elements.append(Paragraph(
                f"Sensitivity range: ${lo:.2f} — ${hi:.2f} per share  "
                f"({sm.base_wacc*100:.1f}% WACC ± {4*0.5:.1f}%  ×  "
                f"{sm.base_growth_rate*100:.1f}% growth ± {2*0.5:.1f}%)",
                STYLES["body"]
            ))
        return elements

    # ── Section 7: Scenario Analysis ─────────────────────────────────────────

    def _scenario_section(self, data: "ReportData") -> list:
        elements = _section_header("Scenario Analysis — Bear / Base / Bull", "7")
        elements.append(Paragraph(
            f"Three scenarios built from the base-case forecast with defined deltas. "
            f"Probability-weighted blended value: "
            f"25% Bear + 50% Base + 25% Bull.",
            STYLES["body"]
        ))
        elements.append(Spacer(1, 3 * mm))

        sa = data.scenario_analysis
        if sa:
            headers = ["Metric", "Bear", "vs Base", "Base", "Bull", "vs Base"]
            col_w   = [3.2*cm, 2.5*cm, 1.8*cm, 2.5*cm, 2.5*cm, 1.8*cm]

            def _pct(v): return f"+{v*100:.1f}%" if v >= 0 else f"{v*100:.1f}%"
            def _b(v):   return f"${v/1e9:.2f}B"
            def _p(v):   return f"${v:.2f}"

            bear, base, bull = sa.bear, sa.base, sa.bull
            b2b, b2u = sa.bear_vs_base, sa.bull_vs_base

            rows = [
                ["Enterprise Value",   _b(bear.enterprise_value), _pct(b2b.ev_delta_pct),    _b(base.enterprise_value), _b(bull.enterprise_value), _pct(b2u.ev_delta_pct)],
                ["Equity Value",       _b(bear.equity_value),     _pct(b2b.equity_delta_pct),_b(base.equity_value),     _b(bull.equity_value),     _pct(b2u.equity_delta_pct)],
                ["Fair Value / Share", _p(bear.fair_value_per_share), _pct(b2b.fvps_delta_pct), _p(base.fair_value_per_share), _p(bull.fair_value_per_share), _pct(b2u.fvps_delta_pct)],
                ["WACC",               f"{bear.wacc*100:.2f}%", "—", f"{base.wacc*100:.2f}%", f"{bull.wacc*100:.2f}%", "—"],
                ["Terminal Growth",    f"{bear.terminal_growth_rate*100:.2f}%", "—", f"{base.terminal_growth_rate*100:.2f}%", f"{bull.terminal_growth_rate*100:.2f}%", "—"],
                ["Rev Growth Y1",      f"{bear.revenue_growth_y1*100:.1f}%", "—", f"{base.revenue_growth_y1*100:.1f}%", f"{bull.revenue_growth_y1*100:.1f}%", "—"],
                ["EBITDA Margin Avg",  f"{bear.ebitda_margin_avg*100:.1f}%", "—", f"{base.ebitda_margin_avg*100:.1f}%", f"{bull.ebitda_margin_avg*100:.1f}%", "—"],
                ["PV(TV) % EV",        f"{bear.pv_tv_pct*100:.1f}%", "—", f"{base.pv_tv_pct*100:.1f}%", f"{bull.pv_tv_pct*100:.1f}%", "—"],
            ]
            elements.append(_data_table(headers, rows, col_w, highlight_col=3))

            # Blended value
            elements.append(Spacer(1, 4 * mm))
            blended = sa.blended.get("fair_value_per_share", 0) if isinstance(sa.blended, dict) else sa.blended.fair_value_per_share
            elements.append(Paragraph(
                f"<font name='Courier' color='#10b981'><b>"
                f"Blended Fair Value: ${blended:.2f}  "
                f"(Bear: 25% × ${bear.fair_value_per_share:.2f} + "
                f"Base: 50% × ${base.fair_value_per_share:.2f} + "
                f"Bull: 25% × ${bull.fair_value_per_share:.2f})"
                f"</b></font>",
                STYLES["data"]
            ))

        # Tornado
        if sa and sa.tornado:
            elements.append(Spacer(1, 4 * mm))
            elements.append(Paragraph("Tornado Chart — Key Value Drivers", STYLES["label"]))
            elements.append(Spacer(1, 2 * mm))
            t_headers = ["Assumption", "Bear Price", "Bull Price", "Total Range"]
            t_rows = [
                [item.assumption, f"${item.bear_price:.2f}", f"${item.bull_price:.2f}", f"${item.total_range:.2f}"]
                for item in sa.tornado
            ]
            t_cols = [6.5*cm, 2.5*cm, 2.5*cm, 2.5*cm]
            elements.append(_data_table(t_headers, t_rows, t_cols))

        return elements

    # ── Section 8: Trading Comparables ───────────────────────────────────────

    def _comps_section(self, data: "ReportData") -> list:
        elements = _section_header("Trading Comparables", "8")
        cr = data.comps_result
        if cr is None:
            elements.append(Paragraph("No comparables data available.", STYLES["body"]))
            return elements

        elements.append(Paragraph(
            f"Peer set: {cr.n_peers_raw} companies · "
            f"Implied price (EV/EBITDA median): ${cr.implied_price.get('central', 0) or 0:.2f}",
            STYLES["body"]
        ))
        elements.append(Spacer(1, 3 * mm))

        # Summary table
        elements.append(Paragraph("Multiple Statistics", STYLES["label"]))
        elements.append(Spacer(1, 2 * mm))
        sum_headers = ["Multiple", "Q1", "Median", "Mean", "Q3", "n", "Implied (Med)"]
        sum_rows = [
            [
                row["multiple"],
                f"{row['q1']:.1f}×",
                f"{row['median']:.1f}×",
                f"{row['mean']:.1f}×",
                f"{row['q3']:.1f}×",
                str(row["n_peers"]),
                f"${row['implied_price_median']:.2f}",
            ]
            for row in cr.summary_table
        ]
        col_w = [2.8*cm, 1.8*cm, 1.8*cm, 1.8*cm, 1.8*cm, 1.0*cm, 2.5*cm]
        elements.append(_data_table(sum_headers, sum_rows, col_w, highlight_col=2))

        return elements

    # ── Appendix ──────────────────────────────────────────────────────────────

    def _appendix(self, data: "ReportData") -> list:
        elements = [PageBreak()]
        elements += _section_header("Appendix — Key Assumptions", "A")
        elements.append(Paragraph(
            "All monetary values in reporting currency. Rates in decimal (0.09 = 9%).",
            STYLES["body"]
        ))
        elements.append(Spacer(1, 3 * mm))

        assumptions = [
            ("Risk-Free Rate",     f"{data.wacc_result.risk_free_rate*100:.2f}%"),
            ("Equity Risk Premium",f"{data.wacc_result.equity_risk_premium*100:.2f}%"),
            ("Beta",               f"{data.wacc_result.beta_used:.2f}"),
            ("Tax Rate",           f"{data.wacc_result.tax_rate*100:.1f}%"),
            ("Forecast Years",     "10"),
            ("TV Method",          data.terminal_value_result.method_used.replace("_", " ").title()),
            ("Terminal Growth g",  f"{data.terminal_growth_rate*100:.2f}%"),
            ("Mid-Year Convention","No (year-end)"),
            ("Net Debt",           f"${data.net_debt/1e9:.2f}B"),
            ("Shares Outstanding", f"{data.shares_outstanding/1e9:.2f}B"),
            ("Minority Interest",  f"${data.minority_interest/1e9:.2f}B"),
            ("Preferred Equity",   f"$0.00B"),
        ]
        elements.append(_metric_table(assumptions, cols=2))
        elements.append(Spacer(1, 5 * mm))
        elements.append(Paragraph(
            "DISCLAIMER: This report is generated by ValuPro for informational purposes only. "
            "It does not constitute financial advice, a solicitation to buy or sell securities, "
            "or investment recommendations. Valuations are inherently uncertain and subject to "
            "material changes in assumptions. Past performance is not indicative of future results.",
            STYLES["caption"]
        ))
        return elements
