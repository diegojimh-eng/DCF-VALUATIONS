"""
analysis/scenario.py
---------------------
Full Scenario Analysis Engine.

─────────────────────────────────────────────────────────────────────────────
Scenario Framework
─────────────────────────────────────────────────────────────────────────────

Three scenarios reflect different economic and operational outcomes:

  Bear Case — adverse conditions
    • Lower revenue growth (default: base − 3 pp per year)
    • Compressed EBITDA margins (default: base − 2 pp)
    • Higher effective tax rate (default: base + 1 pp)
    → Lower FCFF → Lower EV → Lower FVPS

  Base Case — management's plan
    • No adjustments — the analyst's central estimate

  Bull Case — favourable conditions
    • Higher revenue growth (default: base + 3 pp per year)
    • Expanded EBITDA margins (default: base + 2 pp)
    • Lower effective tax rate (default: base − 1 pp)
    → Higher FCFF → Higher EV → Higher FVPS

─────────────────────────────────────────────────────────────────────────────
Outputs per Scenario
─────────────────────────────────────────────────────────────────────────────

  Enterprise Value    = Σ PV(FCFF_t) + PV(Terminal Value)
  Equity Value        = EV − Net Debt − Minority − Preferred
  Fair Value / Share  = Equity Value / Diluted Shares

─────────────────────────────────────────────────────────────────────────────
Probability-Weighted Blended Value
─────────────────────────────────────────────────────────────────────────────

  Blended FV = weight_bear × Bear_FVPS
             + weight_base × Base_FVPS
             + weight_bull × Bull_FVPS

  Default weights: 25% Bear + 50% Base + 25% Bull

─────────────────────────────────────────────────────────────────────────────
Tornado Chart
─────────────────────────────────────────────────────────────────────────────

  A tornado chart shows which assumption has the largest impact on the
  Base Case share price by running one-at-a-time sensitivity:

    1. Start from base assumptions.
    2. For each key driver (revenue growth, EBITDA margin, WACC, g):
         Bear end = replace driver with its Bear value; compute FVPS.
         Bull end = replace driver with its Bull value; compute FVPS.
    3. Rank bars by (bull_price − bear_price) descending.

  This tells the analyst: "What should I focus on most in my diligence?"
"""

from __future__ import annotations

from dataclasses import dataclass
from statistics import mean as _mean

from analysis.models import (
    ScenarioAnalysis,
    ScenarioDelta,
    ScenarioValuation,
    TornadoItem,
)
from engine.models import ForecastOutput
from engine.pipeline.scenario_engine import ScenarioResults
from valuation.dcf import DCFEngine
from valuation.models import DCFInputs, ValuationOutput, WACCResult
from valuation.wacc import WACCCalculator
from logger import get_logger

log = get_logger(__name__)


@dataclass(frozen=True)
class ScenarioWeights:
    """Probability weights for Bear / Base / Bull blending."""
    bear: float = 0.25
    base: float = 0.50
    bull: float = 0.25

    def __post_init__(self) -> None:
        total = self.bear + self.base + self.bull
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"Scenario weights must sum to 1.0, got {total:.4f}")


class ScenarioAnalyser:
    """
    Runs the full Bear / Base / Bull scenario analysis and assembles
    a ScenarioAnalysis with all comparison metrics and tornado data.

    Stateless — safe to reuse across requests.
    """

    def __init__(
        self,
        weights: ScenarioWeights | None = None,
        build_tornado: bool = True,
    ) -> None:
        self._weights       = weights or ScenarioWeights()
        self._build_tornado = build_tornado
        self._dcf           = DCFEngine()

    def run(
        self,
        ticker: str,
        scenario_results: ScenarioResults,
        bear_output: ValuationOutput,
        base_output: ValuationOutput,
        bull_output: ValuationOutput,
        bear_dcf_inputs: DCFInputs,
        base_dcf_inputs: DCFInputs,
        bull_dcf_inputs: DCFInputs,
        wacc_result: WACCResult,
        current_price: float | None = None,
    ) -> ScenarioAnalysis:
        """
        Build the full scenario analysis from pre-computed DCF outputs.

        Args:
            ticker:             Company ticker.
            scenario_results:   ForecastOutput for each scenario (Phase 3).
            bear/base/bull_output:     ValuationOutput from DCFEngine per scenario.
            bear/base/bull_dcf_inputs: DCFInputs used per scenario.
            wacc_result:        Base WACCResult (holds capital structure).
            current_price:      Current market price for premium/discount analysis.

        Returns:
            ScenarioAnalysis with per-scenario valuations, deltas, blended values,
            and tornado chart data.
        """
        log.info("scenario.analyser.run", ticker=ticker, current_price=current_price)

        # ── Build per-scenario valuations ──────────────────────────────────
        bear_sv = self._to_scenario_valuation("bear", "Bear Case", bear_output,
                                              scenario_results.bear, bear_dcf_inputs)
        base_sv = self._to_scenario_valuation("base", "Base Case", base_output,
                                              scenario_results.base, base_dcf_inputs)
        bull_sv = self._to_scenario_valuation("bull", "Bull Case", bull_output,
                                              scenario_results.bull, bull_dcf_inputs)

        # ── Deltas ─────────────────────────────────────────────────────────
        bear_delta = self._compute_delta(bear_sv, base_sv)
        bull_delta = self._compute_delta(bull_sv, base_sv)

        # ── Blended values ─────────────────────────────────────────────────
        w = self._weights
        blended_fvps = (
            w.bear * bear_sv.fair_value_per_share
            + w.base * base_sv.fair_value_per_share
            + w.bull * bull_sv.fair_value_per_share
        )
        blended_ev = (
            w.bear * bear_sv.enterprise_value
            + w.base * base_sv.enterprise_value
            + w.bull * bull_sv.enterprise_value
        )
        blended_equity = (
            w.bear * bear_sv.equity_value
            + w.base * base_sv.equity_value
            + w.bull * bull_sv.equity_value
        )

        # ── Tornado chart ──────────────────────────────────────────────────
        tornado: list[TornadoItem] = []
        if self._build_tornado:
            tornado = self._build_tornado_chart(
                base_sv=base_sv,
                bear_sv=bear_sv,
                bull_sv=bull_sv,
                base_dcf_inputs=base_dcf_inputs,
                wacc_result=wacc_result,
            )

        log.info(
            "scenario.analyser.complete",
            ticker=ticker,
            bear_fvps=round(bear_sv.fair_value_per_share, 2),
            base_fvps=round(base_sv.fair_value_per_share, 2),
            bull_fvps=round(bull_sv.fair_value_per_share, 2),
            blended_fvps=round(blended_fvps, 2),
        )

        return ScenarioAnalysis(
            ticker=ticker,
            bear=bear_sv,
            base=base_sv,
            bull=bull_sv,
            bear_vs_base=bear_delta,
            bull_vs_base=bull_delta,
            blended_fair_value=blended_fvps,
            blended_enterprise_value=blended_ev,
            blended_equity_value=blended_equity,
            weight_bear=w.bear,
            weight_base=w.base,
            weight_bull=w.bull,
            tornado=tornado,
            current_price=current_price,
        )

    # ── Internal builders ──────────────────────────────────────────────────

    @staticmethod
    def _to_scenario_valuation(
        scenario: str,
        label: str,
        dcf_output: ValuationOutput,
        forecast: ForecastOutput,
        dcf_inputs: DCFInputs,
    ) -> ScenarioValuation:
        """Convert a DCFEngine output into a ScenarioValuation."""
        years = forecast.years
        rev_growth_y1  = years[0].revenue_growth_rate  if years else 0.0
        rev_growth_y10 = years[-1].revenue_growth_rate if years else 0.0
        ebitda_margins = [y.ebitda_margin for y in years]
        ebitda_margin_avg = _mean(ebitda_margins) if ebitda_margins else 0.0
        fcff_y1  = years[0].fcff  if years else 0.0
        fcff_y10 = years[-1].fcff if years else 0.0

        return ScenarioValuation(
            scenario=scenario,  # type: ignore[arg-type]
            label=label,
            enterprise_value=dcf_output.enterprise_value,
            equity_value=dcf_output.equity_value,
            fair_value_per_share=dcf_output.fair_value_per_share,
            sum_pv_fcff=dcf_output.sum_pv_fcff,
            pv_terminal_value=dcf_output.pv_terminal_value,
            pv_tv_pct=dcf_output.pv_tv_pct_of_ev,
            wacc=dcf_output.wacc,
            terminal_growth_rate=dcf_output.terminal_growth_rate,
            revenue_growth_y1=rev_growth_y1,
            revenue_growth_y10=rev_growth_y10,
            ebitda_margin_avg=ebitda_margin_avg,
            fcff_y1=fcff_y1,
            fcff_y10=fcff_y10,
            net_debt=dcf_inputs.net_debt,
            shares_outstanding=dcf_inputs.shares_outstanding,
            warnings=dcf_output.warnings,
        )

    @staticmethod
    def _compute_delta(
        scenario_sv: ScenarioValuation,
        base_sv: ScenarioValuation,
    ) -> ScenarioDelta:
        """Compute deltas between a scenario and the base case."""
        def _pct(val: float, base: float) -> float:
            return (val - base) / base if abs(base) > 0 else 0.0

        return ScenarioDelta(
            ev_delta=scenario_sv.enterprise_value - base_sv.enterprise_value,
            ev_delta_pct=_pct(scenario_sv.enterprise_value, base_sv.enterprise_value),
            equity_delta=scenario_sv.equity_value - base_sv.equity_value,
            equity_delta_pct=_pct(scenario_sv.equity_value, base_sv.equity_value),
            fvps_delta=scenario_sv.fair_value_per_share - base_sv.fair_value_per_share,
            fvps_delta_pct=_pct(scenario_sv.fair_value_per_share, base_sv.fair_value_per_share),
        )

    def _build_tornado_chart(
        self,
        base_sv: ScenarioValuation,
        bear_sv: ScenarioValuation,
        bull_sv: ScenarioValuation,
        base_dcf_inputs: DCFInputs,
        wacc_result: WACCResult,
    ) -> list[TornadoItem]:
        """
        Build tornado chart items showing the impact of each key driver.

        Four drivers are evaluated (one-at-a-time):
          1. Revenue Growth — use Bear/Bull FCFF series as proxies
          2. EBITDA Margin  — proxied through Bear/Bull FCFF series
          3. WACC           — stress-test ± 100 bps from base
          4. Terminal Growth — stress-test ± 50 bps from base g
        """
        base_price = base_sv.fair_value_per_share

        items: list[TornadoItem] = []

        # ── Driver 1: Full scenario impact (revenue + margin combined) ─────
        items.append(TornadoItem(
            assumption="Revenue Growth + EBITDA Margin",
            bear_price=bear_sv.fair_value_per_share,
            bull_price=bull_sv.fair_value_per_share,
            base_price=base_price,
            bear_delta=bear_sv.fair_value_per_share - base_price,
            bull_delta=bull_sv.fair_value_per_share - base_price,
            total_range=bull_sv.fair_value_per_share - bear_sv.fair_value_per_share,
        ))

        # ── Driver 2: WACC ± 100 bps ───────────────────────────────────────
        wacc_bear_price = self._fvps_at_wacc(
            base_dcf_inputs, wacc_result, base_sv.wacc + 0.01
        )
        wacc_bull_price = self._fvps_at_wacc(
            base_dcf_inputs, wacc_result, base_sv.wacc - 0.01
        )
        items.append(TornadoItem(
            assumption="WACC (±100 bps)",
            bear_price=wacc_bear_price,
            bull_price=wacc_bull_price,
            base_price=base_price,
            bear_delta=wacc_bear_price - base_price,
            bull_delta=wacc_bull_price - base_price,
            total_range=abs(wacc_bull_price - wacc_bear_price),
        ))

        # ── Driver 3: Terminal Growth ± 50 bps ────────────────────────────
        g_base = base_sv.terminal_growth_rate
        g_bear_price = self._fvps_at_growth(base_dcf_inputs, wacc_result, g_base - 0.005)
        g_bull_price = self._fvps_at_growth(base_dcf_inputs, wacc_result, g_base + 0.005)
        items.append(TornadoItem(
            assumption="Terminal Growth Rate (±50 bps)",
            bear_price=g_bear_price,
            bull_price=g_bull_price,
            base_price=base_price,
            bear_delta=g_bear_price - base_price,
            bull_delta=g_bull_price - base_price,
            total_range=abs(g_bull_price - g_bear_price),
        ))

        # Sort descending by total_range
        items.sort(key=lambda x: x.total_range, reverse=True)
        return items

    def _fvps_at_wacc(
        self,
        dcf_inputs: DCFInputs,
        base_wacc_result: WACCResult,
        new_wacc: float,
    ) -> float:
        """Compute FVPS with WACC substituted; return 0 on error."""
        if new_wacc <= 0.001:
            return 0.0
        cell_wacc = base_wacc_result.model_copy(update={"wacc": new_wacc})
        cell_dcf  = dcf_inputs.model_copy(update={"wacc": new_wacc})
        try:
            result = self._dcf.compute(cell_dcf, cell_wacc)
            return result.fair_value_per_share
        except ValueError:
            return 0.0

    def _fvps_at_growth(
        self,
        dcf_inputs: DCFInputs,
        base_wacc_result: WACCResult,
        new_g: float,
    ) -> float:
        """Compute FVPS with terminal growth substituted; return 0 on error."""
        cell_tv  = dcf_inputs.terminal_value_inputs.model_copy(
            update={"terminal_growth_rate": new_g}
        )
        cell_dcf = dcf_inputs.model_copy(update={"terminal_value_inputs": cell_tv})
        try:
            result = self._dcf.compute(cell_dcf, base_wacc_result)
            return result.fair_value_per_share
        except ValueError:
            return 0.0
