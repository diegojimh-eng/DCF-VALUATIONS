"""
analysis/ — Phase 7 Sensitivity & Scenario Analysis.

Public API:
    from analysis import AnalysisReportBuilder, ScenarioAnalyser, FullSensitivityEngine
    from analysis.models import AnalysisReport, ScenarioAnalysis, SensitivityMatrix
"""

from analysis.models import (
    AnalysisReport,
    ScenarioAnalysis,
    ScenarioDelta,
    ScenarioValuation,
    SensitivityMatrix,
    SensitivityMatrixCell,
    TornadoItem,
)
from analysis.report import AnalysisReportBuilder
from analysis.scenario import ScenarioAnalyser, ScenarioWeights
from analysis.sensitivity import FullSensitivityEngine

__all__ = [
    "AnalysisReport",
    "AnalysisReportBuilder",
    "FullSensitivityEngine",
    "ScenarioAnalyser",
    "ScenarioAnalysis",
    "ScenarioDelta",
    "ScenarioValuation",
    "ScenarioWeights",
    "SensitivityMatrix",
    "SensitivityMatrixCell",
    "TornadoItem",
]
