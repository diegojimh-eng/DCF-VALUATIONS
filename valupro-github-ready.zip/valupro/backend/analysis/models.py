"""
analysis/models.py
-------------------
All Pydantic output models for Phase 7 Sensitivity & Scenario Analysis.

─────────────────────────────────────────────────────────────────────────────
Module Overview
─────────────────────────────────────────────────────────────────────────────

Sensitivity Analysis extends the Phase 4 grid with two additional matrices
so analysts can read three numbers from the same cell:

  ① Fair Value per Share   (already in Phase 4)
  ② Enterprise Value       (already in Phase 4)
  ③ Equity Value           (NEW — EV − net debt − minority − preferred)

All three matrices use identical axis values (WACC rows × g columns) so they
can be displayed as tabbed heatmaps in the UI.

Scenario Analysis captures the full DCF valuation output for each of the
three scenarios (Bear / Base / Bull) in one typed object, enabling:

  • Side-by-side scenario comparison table
  • Delta attribution (what drives Bear vs Bull?)
  • Tornado chart data (which assumption moves price the most?)
  • Probability-weighted blended intrinsic value

─────────────────────────────────────────────────────────────────────────────
Key design decisions:
  • Immutable (frozen=True) — consistent with the rest of the codebase.
  • No circular imports — this module depends only on pydantic and stdlib.
  • All monetary values in reporting currency, same unit as historical data.
  • Percentages stored as decimals (0.08 = 8%).
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, model_validator


# ══════════════════════════════════════════════════════════════════════════════
# Sensitivity Analysis Models
# ══════════════════════════════════════════════════════════════════════════════

class SensitivityMatrixCell(BaseModel):
    """
    One cell of the WACC × g sensitivity matrix.

    All three valuation outputs are stored in each cell so the UI can switch
    between views without recomputation.
    """
    wacc: float
    terminal_growth_rate: float

    # Three valuation outputs per cell
    enterprise_value: float        = Field(..., description="Implied Enterprise Value")
    equity_value: float            = Field(..., description="Implied Equity Value = EV − net_debt − minority − preferred")
    fair_value_per_share: float    = Field(..., description="Implied Share Price = Equity Value / Shares")

    # Percentage deviation from the base-case cell (for heatmap colouring)
    ev_vs_base_pct: float | None   = Field(default=None, description="(EV − base_EV) / base_EV")
    fvps_vs_base_pct: float | None = Field(default=None, description="(FVPS − base_FVPS) / base_FVPS")

    is_base_case: bool = False

    model_config = {"frozen": True}


class SensitivityMatrix(BaseModel):
    """
    Complete WACC × Terminal Growth Rate sensitivity matrix.

    Extends the Phase 4 SensitivityGrid by storing three valuation outputs
    per cell instead of one, and computing percentage-vs-base deviations.

    Standard sell-side format:
      Rows    = WACC values, ascending (e.g. 7.0% → 11.0% in 50 bps steps)
      Columns = Terminal growth rate, ascending (e.g. 1.5% → 3.5% in 50 bps steps)
      Cells   = (EV, Equity Value, FVPS) at each (WACC, g) combination
    """
    ticker: str
    valuation_date: datetime = Field(default_factory=datetime.utcnow)

    # Axis values
    wacc_values: list[float]    = Field(..., description="WACC axis, ascending")
    growth_values: list[float]  = Field(..., description="Terminal growth axis, ascending")

    # Grid: grid[wacc_idx][growth_idx]
    grid: list[list[SensitivityMatrixCell]]

    # Base-case reference values
    base_wacc: float
    base_growth_rate: float
    base_enterprise_value: float
    base_equity_value: float
    base_fair_value_per_share: float

    # Capital structure used for EV → equity bridge
    net_debt: float = 0.0
    minority_interest: float = 0.0
    preferred_equity: float = 0.0
    shares_outstanding: float

    model_config = {"frozen": True}

    # ── Convenience methods ────────────────────────────────────────────────

    def ev_matrix(self) -> list[list[float]]:
        """2-D list of Enterprise Values for JSON serialisation."""
        return [[cell.enterprise_value for cell in row] for row in self.grid]

    def equity_matrix(self) -> list[list[float]]:
        """2-D list of Equity Values."""
        return [[cell.equity_value for cell in row] for row in self.grid]

    def fvps_matrix(self) -> list[list[float]]:
        """2-D list of Fair Values per Share (the primary output)."""
        return [[cell.fair_value_per_share for cell in row] for row in self.grid]

    def ev_pct_matrix(self) -> list[list[float | None]]:
        """2-D list of EV % deviation from base case (for heatmap colouring)."""
        return [[cell.ev_vs_base_pct for cell in row] for row in self.grid]

    def fvps_range(self) -> tuple[float, float]:
        """(min, max) FVPS across the entire grid, ignoring zero sentinels."""
        vals = [
            cell.fair_value_per_share
            for row in self.grid for cell in row
            if cell.fair_value_per_share > 0
        ]
        return (min(vals), max(vals)) if vals else (0.0, 0.0)

    def ev_range(self) -> tuple[float, float]:
        vals = [
            cell.enterprise_value
            for row in self.grid for cell in row
            if cell.enterprise_value > 0
        ]
        return (min(vals), max(vals)) if vals else (0.0, 0.0)

    def base_case_cell(self) -> SensitivityMatrixCell | None:
        for row in self.grid:
            for cell in row:
                if cell.is_base_case:
                    return cell
        return None

    def to_dict(self) -> dict:
        """Complete serialisable representation for the API response."""
        return {
            "ticker": self.ticker,
            "valuation_date": self.valuation_date.isoformat(),
            "wacc_values": self.wacc_values,
            "growth_values": self.growth_values,
            "base_wacc": self.base_wacc,
            "base_growth_rate": self.base_growth_rate,
            "base_enterprise_value": self.base_enterprise_value,
            "base_equity_value": self.base_equity_value,
            "base_fair_value_per_share": self.base_fair_value_per_share,
            "net_debt": self.net_debt,
            "shares_outstanding": self.shares_outstanding,
            # Three output matrices
            "enterprise_value_matrix": self.ev_matrix(),
            "equity_value_matrix": self.equity_matrix(),
            "fair_value_matrix": self.fvps_matrix(),
            # Percentage deviation matrices (for heatmap colouring)
            "ev_pct_vs_base_matrix": self.ev_pct_matrix(),
            # Ranges
            "fvps_range": list(self.fvps_range()),
            "ev_range": list(self.ev_range()),
        }


# ══════════════════════════════════════════════════════════════════════════════
# Scenario Analysis Models
# ══════════════════════════════════════════════════════════════════════════════

class ScenarioValuation(BaseModel):
    """
    Complete DCF valuation output for one scenario (Bear / Base / Bull).

    Captures EV, Equity Value, and Share Price together with the forecast
    assumptions that drove them, enabling full attribution analysis.
    """
    scenario: Literal["bear", "base", "bull", "custom"]
    label: str   # Display label: "Bear Case", "Base Case", "Bull Case"

    # ── Valuation outputs ─────────────────────────────────────────────────
    enterprise_value: float
    equity_value: float
    fair_value_per_share: float

    # ── DCF components ────────────────────────────────────────────────────
    sum_pv_fcff: float       = Field(..., description="Σ PV(FCFF) for explicit period")
    pv_terminal_value: float = Field(..., description="PV of terminal value")
    pv_tv_pct: float         = Field(..., description="PV(TV) / EV — TV dependence")

    # ── Forecast assumptions that produced this scenario ──────────────────
    wacc: float
    terminal_growth_rate: float
    revenue_growth_y1: float         = Field(..., description="Year 1 revenue growth rate")
    revenue_growth_y10: float        = Field(..., description="Year 10 revenue growth rate")
    ebitda_margin_avg: float         = Field(..., description="Average EBITDA margin across 10 years")
    fcff_y1: float                   = Field(..., description="FCFF in year 1")
    fcff_y10: float                  = Field(..., description="FCFF in year 10 (terminal year)")

    # ── Capital structure ──────────────────────────────────────────────────
    net_debt: float
    shares_outstanding: float

    # ── Warnings from DCF engine ──────────────────────────────────────────
    warnings: list[str] = Field(default_factory=list)

    model_config = {"frozen": True}

    def to_dict(self) -> dict:
        return {
            "scenario": self.scenario,
            "label": self.label,
            "enterprise_value": self.enterprise_value,
            "equity_value": self.equity_value,
            "fair_value_per_share": self.fair_value_per_share,
            "sum_pv_fcff": self.sum_pv_fcff,
            "pv_terminal_value": self.pv_terminal_value,
            "pv_tv_pct": self.pv_tv_pct,
            "wacc": self.wacc,
            "terminal_growth_rate": self.terminal_growth_rate,
            "revenue_growth_y1": self.revenue_growth_y1,
            "revenue_growth_y10": self.revenue_growth_y10,
            "ebitda_margin_avg": self.ebitda_margin_avg,
            "fcff_y1": self.fcff_y1,
            "fcff_y10": self.fcff_y10,
            "net_debt": self.net_debt,
            "shares_outstanding": self.shares_outstanding,
            "warnings": self.warnings,
        }


class ScenarioDelta(BaseModel):
    """
    Difference between one scenario and the base case.
    Used for the delta column in the scenario comparison table.
    """
    ev_delta: float         = Field(..., description="EV − base_EV")
    ev_delta_pct: float     = Field(..., description="(EV − base_EV) / base_EV")
    equity_delta: float
    equity_delta_pct: float
    fvps_delta: float       = Field(..., description="FVPS − base_FVPS")
    fvps_delta_pct: float

    model_config = {"frozen": True}


class TornadoItem(BaseModel):
    """
    One bar in the tornado chart — the impact of a single assumption
    on the Base Case share price.
    """
    assumption: str         = Field(..., description="Human-readable assumption name")
    bear_price: float       = Field(..., description="Share price in the bear case of this assumption")
    bull_price: float       = Field(..., description="Share price in the bull case of this assumption")
    base_price: float       = Field(..., description="Base case share price (same for all bars)")
    bear_delta: float       = Field(..., description="bear_price − base_price")
    bull_delta: float       = Field(..., description="bull_price − base_price")
    total_range: float      = Field(..., description="bull_price − bear_price")

    model_config = {"frozen": True}


class ScenarioAnalysis(BaseModel):
    """
    Complete Bear / Base / Bull scenario analysis output.

    Primary output of ScenarioAnalyser.run().
    """
    ticker: str
    valuation_date: datetime = Field(default_factory=datetime.utcnow)

    # Per-scenario valuations
    bear: ScenarioValuation
    base: ScenarioValuation
    bull: ScenarioValuation

    # Deltas vs base
    bear_vs_base: ScenarioDelta
    bull_vs_base: ScenarioDelta

    # Probability-weighted blended value
    blended_fair_value: float       = Field(..., description="w_bear×bear_FVPS + w_base×base_FVPS + w_bull×bull_FVPS")
    blended_enterprise_value: float
    blended_equity_value: float

    # Weights used
    weight_bear: float = 0.25
    weight_base: float = 0.50
    weight_bull: float = 0.25

    # Tornado chart data (sorted by total_range descending)
    tornado: list[TornadoItem] = Field(default_factory=list)

    # Current market price for premium/discount analysis
    current_price: float | None = None

    model_config = {"frozen": True}

    @property
    def price_vs_base(self) -> str | None:
        if self.current_price is None:
            return None
        ratio = self.current_price / self.base.fair_value_per_share
        if ratio < 0.85:
            return "UNDERVALUED"
        elif ratio > 1.15:
            return "OVERVALUED"
        return "FAIRLY VALUED"

    @property
    def price_vs_blended(self) -> str | None:
        if self.current_price is None:
            return None
        ratio = self.current_price / self.blended_fair_value
        if ratio < 0.85:
            return "UNDERVALUED"
        elif ratio > 1.15:
            return "OVERVALUED"
        return "FAIRLY VALUED"

    def scenario_range(self) -> tuple[float, float]:
        """(bear FVPS, bull FVPS) — the full scenario spread."""
        return (self.bear.fair_value_per_share, self.bull.fair_value_per_share)

    def to_dict(self) -> dict:
        return {
            "ticker": self.ticker,
            "valuation_date": self.valuation_date.isoformat(),
            "bear": self.bear.to_dict(),
            "base": self.base.to_dict(),
            "bull": self.bull.to_dict(),
            "bear_vs_base": self.bear_vs_base.model_dump(),
            "bull_vs_base": self.bull_vs_base.model_dump(),
            "blended": {
                "fair_value_per_share": self.blended_fair_value,
                "enterprise_value": self.blended_enterprise_value,
                "equity_value": self.blended_equity_value,
                "weights": {
                    "bear": self.weight_bear,
                    "base": self.weight_base,
                    "bull": self.weight_bull,
                },
            },
            "scenario_range": list(self.scenario_range()),
            "current_price": self.current_price,
            "price_vs_base": self.price_vs_base,
            "price_vs_blended": self.price_vs_blended,
            "tornado": [t.model_dump() for t in self.tornado],
        }


# ══════════════════════════════════════════════════════════════════════════════
# Combined Report
# ══════════════════════════════════════════════════════════════════════════════

class AnalysisReport(BaseModel):
    """
    Combined Sensitivity + Scenario analysis report.

    This is the primary output of AnalysisReportBuilder and the object
    returned by the /analysis/{ticker} API endpoint.
    """
    ticker: str
    valuation_date: datetime = Field(default_factory=datetime.utcnow)

    sensitivity: SensitivityMatrix
    scenarios: ScenarioAnalysis

    # Investment summary (one-paragraph text, filled by AI memo in Phase 8)
    summary: str | None = None

    # Warnings from both engines
    all_warnings: list[str] = Field(default_factory=list)

    model_config = {"frozen": True}

    def to_dict(self) -> dict:
        return {
            "ticker": self.ticker,
            "valuation_date": self.valuation_date.isoformat(),
            "sensitivity": self.sensitivity.to_dict(),
            "scenarios": self.scenarios.to_dict(),
            "summary": self.summary,
            "warnings": self.all_warnings,
        }
