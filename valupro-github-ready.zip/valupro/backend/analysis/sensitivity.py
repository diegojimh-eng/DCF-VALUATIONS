"""
analysis/sensitivity.py
------------------------
Full Sensitivity Analysis Engine.

Extends the Phase 4 SensitivityAnalyser to compute and store all three
valuation outputs per cell — Enterprise Value, Equity Value, and Share Price.

─────────────────────────────────────────────────────────────────────────────
WACC × Terminal Growth Rate Matrix
─────────────────────────────────────────────────────────────────────────────

For every (WACC_i, g_j) combination:

  1. Re-run DCFEngine with WACC_i, g_j (hold FCFF series fixed)
  2. Compute:
       Enterprise Value  = Σ PV(FCFF_t) + PV(TV_ij)
       Equity Value      = EV − Net Debt − Minority Interest − Preferred
       Fair Value/Share  = max(Equity, 0) / Shares Outstanding

  3. Annotate:
       EV % vs base      = (EV_ij − EV_base) / EV_base
       FVPS % vs base    = (FVPS_ij − FVPS_base) / FVPS_base

Grid dimensions (configurable, defaults match sell-side convention):
  WACC:   base ± 4 steps × 50 bps  → 9 rows   (e.g. 7.0% → 11.0%)
  Growth: base ± 2 steps × 50 bps  → 5 columns (e.g. 1.5% → 3.5%)
  Total:  9 × 5 = 45 cells

─────────────────────────────────────────────────────────────────────────────
Capital Structure Consistency
─────────────────────────────────────────────────────────────────────────────

The equity bridge (EV → Equity Value → Share Price) uses the same net_debt,
minority_interest, preferred_equity, and shares_outstanding for every cell.
Only WACC and g vary — capital structure is held constant.

This is standard sell-side practice: you are stress-testing the discount rate
and growth assumption, not the capital structure.
"""

from __future__ import annotations

from analysis.models import SensitivityMatrix, SensitivityMatrixCell
from valuation.dcf import DCFEngine
from valuation.models import (
    DCFInputs,
    ValuationOutput,
    WACCResult,
)
from logger import get_logger

log = get_logger(__name__)


class FullSensitivityEngine:
    """
    Builds a complete WACC × g sensitivity matrix with EV, Equity, and FVPS.

    Wraps DCFEngine — stateless between calls.
    """

    def __init__(self, mid_year_convention: bool = False) -> None:
        self._dcf = DCFEngine(mid_year_convention=mid_year_convention)

    def compute(
        self,
        ticker: str,
        base_output: ValuationOutput,
        dcf_inputs: DCFInputs,
        wacc_result: WACCResult,
        wacc_steps: int = 4,
        growth_steps: int = 2,
        wacc_step_size: float = 0.005,
        growth_step_size: float = 0.005,
    ) -> SensitivityMatrix:
        """
        Build the WACC × g sensitivity matrix.

        Args:
            ticker:           Company ticker for labelling.
            base_output:      The base-case ValuationOutput (provides WACC, g, EV).
            dcf_inputs:       DCFInputs used for the base case (FCFF series, capital structure).
            wacc_result:      Base WACCResult (used to clone cells with updated WACC).
            wacc_steps:       ± steps around base WACC.
            growth_steps:     ± steps around base g.
            wacc_step_size:   Step size for WACC axis (default 50 bps).
            growth_step_size: Step size for g axis (default 50 bps).

        Returns:
            SensitivityMatrix with three output values in every cell.
        """
        base_wacc = base_output.wacc
        base_g    = base_output.terminal_growth_rate

        # ── Build axis values ──────────────────────────────────────────────
        wacc_values = sorted(
            round(base_wacc + (i - wacc_steps) * wacc_step_size, 6)
            for i in range(2 * wacc_steps + 1)
        )
        growth_values = sorted(
            round(base_g + (j - growth_steps) * growth_step_size, 6)
            for j in range(2 * growth_steps + 1)
        )
        # Remove growth rates that would make GGM undefined (g ≥ WACC − 50 bps)
        growth_values = [g for g in growth_values if g < min(wacc_values) - 0.005]
        if not growth_values:
            growth_values = [base_g]

        log.debug(
            "sensitivity.full.params",
            ticker=ticker,
            wacc_n=len(wacc_values),
            g_n=len(growth_values),
            cells=len(wacc_values) * len(growth_values),
        )

        # ── Base-case reference values ─────────────────────────────────────
        base_ev     = base_output.enterprise_value
        base_equity = base_output.equity_value
        base_fvps   = base_output.fair_value_per_share

        # Capital structure from base case (held constant across grid)
        net_debt        = dcf_inputs.net_debt
        minority        = dcf_inputs.minority_interest
        preferred       = dcf_inputs.preferred_equity
        shares          = dcf_inputs.shares_outstanding

        # ── Build grid ─────────────────────────────────────────────────────
        grid: list[list[SensitivityMatrixCell]] = []

        for w in wacc_values:
            row: list[SensitivityMatrixCell] = []
            for g in growth_values:
                cell = self._compute_cell(
                    dcf_inputs=dcf_inputs,
                    wacc_result=wacc_result,
                    w=w, g=g,
                    base_ev=base_ev,
                    base_fvps=base_fvps,
                    base_wacc=base_wacc,
                    base_g=base_g,
                )
                row.append(cell)
            grid.append(row)

        log.info(
            "sensitivity.full.complete",
            ticker=ticker,
            rows=len(grid),
            cols=len(grid[0]) if grid else 0,
            fvps_range=list(SensitivityMatrix(
                ticker=ticker,
                wacc_values=wacc_values,
                growth_values=growth_values,
                grid=grid,
                base_wacc=base_wacc,
                base_growth_rate=base_g,
                base_enterprise_value=base_ev,
                base_equity_value=base_equity,
                base_fair_value_per_share=base_fvps,
                net_debt=net_debt,
                minority_interest=minority,
                preferred_equity=preferred,
                shares_outstanding=shares,
            ).fvps_range()),
        )

        return SensitivityMatrix(
            ticker=ticker,
            wacc_values=wacc_values,
            growth_values=growth_values,
            grid=grid,
            base_wacc=base_wacc,
            base_growth_rate=base_g,
            base_enterprise_value=base_ev,
            base_equity_value=base_equity,
            base_fair_value_per_share=base_fvps,
            net_debt=net_debt,
            minority_interest=minority,
            preferred_equity=preferred,
            shares_outstanding=shares,
        )

    # ── Cell computation ───────────────────────────────────────────────────

    def _compute_cell(
        self,
        dcf_inputs: DCFInputs,
        wacc_result: WACCResult,
        w: float,
        g: float,
        base_ev: float,
        base_fvps: float,
        base_wacc: float,
        base_g: float,
    ) -> SensitivityMatrixCell:
        """Compute one matrix cell: EV, Equity, FVPS at (w, g)."""
        cell_wacc_result = wacc_result.model_copy(update={"wacc": w})
        cell_tv_inputs   = dcf_inputs.terminal_value_inputs.model_copy(
            update={"terminal_growth_rate": g}
        )
        cell_dcf_inputs = dcf_inputs.model_copy(
            update={"terminal_value_inputs": cell_tv_inputs, "wacc": w}
        )

        is_base = abs(w - base_wacc) < 0.0001 and abs(g - base_g) < 0.0001

        try:
            result: ValuationOutput = self._dcf.compute(cell_dcf_inputs, cell_wacc_result)
            ev     = result.enterprise_value
            equity = result.equity_value
            fvps   = result.fair_value_per_share

            ev_pct   = (ev   - base_ev  ) / base_ev   if base_ev   > 0 else None
            fvps_pct = (fvps - base_fvps) / base_fvps if base_fvps > 0 else None

        except ValueError:
            # WACC − g ≤ 0 → undefined terminal value
            ev = equity = fvps = 0.0
            ev_pct = fvps_pct = None

        return SensitivityMatrixCell(
            wacc=w,
            terminal_growth_rate=g,
            enterprise_value=ev,
            equity_value=equity,
            fair_value_per_share=fvps,
            ev_vs_base_pct=ev_pct,
            fvps_vs_base_pct=fvps_pct,
            is_base_case=is_base,
        )
