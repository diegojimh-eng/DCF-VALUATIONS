"""
analysis/report.py
-------------------
AnalysisReportBuilder — the top-level Phase 7 orchestrator.

Takes the outputs already produced by Phases 3 and 4 and assembles
the complete AnalysisReport without re-running the DCF engine.

Execution order:
  1. Accept pre-computed per-scenario DCF outputs (from ValuationPipeline)
  2. Run FullSensitivityEngine → SensitivityMatrix
  3. Run ScenarioAnalyser → ScenarioAnalysis (with tornado chart)
  4. Combine into AnalysisReport

Usage:
    builder = AnalysisReportBuilder()
    report  = builder.build(
        ticker=ticker,
        bear_output=bear, base_output=base, bull_output=bull,
        bear_dcf_inputs=bear_dcf, base_dcf_inputs=base_dcf, bull_dcf_inputs=bull_dcf,
        wacc_result=wacc_result,
        scenario_results=scenario_results,
        current_price=175.50,
    )

    # Or from a ValuationResult (Phase 4 output):
    report = builder.from_valuation_result(valuation_result, scenario_results)
"""

from __future__ import annotations

import asyncio

from analysis.models import AnalysisReport
from analysis.scenario import ScenarioAnalyser, ScenarioWeights
from analysis.sensitivity import FullSensitivityEngine
from engine.pipeline.scenario_engine import ScenarioResults
from valuation.models import DCFInputs, ValuationOutput, WACCResult
from valuation.pipeline import ValuationResult
from logger import get_logger

log = get_logger(__name__)


class AnalysisReportBuilder:
    """
    Assembles the complete Phase 7 AnalysisReport.

    All computation is deterministic and synchronous.
    run_async() is provided for FastAPI route handlers.
    """

    def __init__(
        self,
        sensitivity_wacc_steps: int = 4,
        sensitivity_growth_steps: int = 2,
        wacc_step_size: float = 0.005,
        growth_step_size: float = 0.005,
        scenario_weights: ScenarioWeights | None = None,
        build_tornado: bool = True,
        mid_year_convention: bool = False,
    ) -> None:
        self._sens = FullSensitivityEngine(mid_year_convention=mid_year_convention)
        self._scen = ScenarioAnalyser(
            weights=scenario_weights,
            build_tornado=build_tornado,
        )
        self._wacc_steps   = sensitivity_wacc_steps
        self._growth_steps = sensitivity_growth_steps
        self._wacc_size    = wacc_step_size
        self._growth_size  = growth_step_size

    def build(
        self,
        ticker: str,
        bear_output: ValuationOutput,
        base_output: ValuationOutput,
        bull_output: ValuationOutput,
        bear_dcf_inputs: DCFInputs,
        base_dcf_inputs: DCFInputs,
        bull_dcf_inputs: DCFInputs,
        wacc_result: WACCResult,
        scenario_results: ScenarioResults,
        current_price: float | None = None,
    ) -> AnalysisReport:
        """
        Build the complete AnalysisReport from pre-computed DCF outputs.

        Args:
            ticker:               Company ticker.
            bear/base/bull_output:     ValuationOutput per scenario.
            bear/base/bull_dcf_inputs: DCFInputs per scenario.
            wacc_result:          WACCResult (capital structure + WACC).
            scenario_results:     ScenarioResults from Phase 3 ForecastPipeline.
            current_price:        Current market price for premium/discount.

        Returns:
            AnalysisReport with both SensitivityMatrix and ScenarioAnalysis.
        """
        log.info("report.build.start", ticker=ticker)

        # ── Sensitivity matrix ─────────────────────────────────────────────
        sensitivity = self._sens.compute(
            ticker=ticker,
            base_output=base_output,
            dcf_inputs=base_dcf_inputs,
            wacc_result=wacc_result,
            wacc_steps=self._wacc_steps,
            growth_steps=self._growth_steps,
            wacc_step_size=self._wacc_size,
            growth_step_size=self._growth_size,
        )

        # ── Scenario analysis ──────────────────────────────────────────────
        scenarios = self._scen.run(
            ticker=ticker,
            scenario_results=scenario_results,
            bear_output=bear_output,
            base_output=base_output,
            bull_output=bull_output,
            bear_dcf_inputs=bear_dcf_inputs,
            base_dcf_inputs=base_dcf_inputs,
            bull_dcf_inputs=bull_dcf_inputs,
            wacc_result=wacc_result,
            current_price=current_price,
        )

        # ── Collect all warnings ───────────────────────────────────────────
        all_warnings: list[str] = []
        for sv in (scenarios.bear, scenarios.base, scenarios.bull):
            all_warnings.extend(sv.warnings)
        # Deduplicate while preserving order
        seen: set[str] = set()
        deduped: list[str] = []
        for w in all_warnings:
            if w not in seen:
                seen.add(w)
                deduped.append(w)

        log.info(
            "report.build.complete",
            ticker=ticker,
            fvps_range=list(sensitivity.fvps_range()),
            blended_fvps=round(scenarios.blended_fair_value, 2),
        )

        return AnalysisReport(
            ticker=ticker,
            sensitivity=sensitivity,
            scenarios=scenarios,
            all_warnings=deduped,
        )

    def from_valuation_result(
        self,
        result: ValuationResult,
        scenario_results: ScenarioResults,
        bear_dcf_inputs: DCFInputs,
        base_dcf_inputs: DCFInputs,
        bull_dcf_inputs: DCFInputs,
        current_price: float | None = None,
    ) -> AnalysisReport:
        """
        Build an AnalysisReport directly from a Phase 4 ValuationResult.

        This is the most convenient API when the ValuationPipeline has already run.

        Args:
            result:             ValuationResult from ValuationPipeline.run().
            scenario_results:   ScenarioResults from ScenarioEngine.run_all().
            bear/base/bull_dcf_inputs: The DCFInputs used per scenario.
            current_price:      Current market price.
        """
        return self.build(
            ticker=result.ticker,
            bear_output=result.bear,
            base_output=result.base,
            bull_output=result.bull,
            bear_dcf_inputs=bear_dcf_inputs,
            base_dcf_inputs=base_dcf_inputs,
            bull_dcf_inputs=bull_dcf_inputs,
            wacc_result=result.wacc_result,
            scenario_results=scenario_results,
            current_price=current_price,
        )

    async def build_async(
        self,
        ticker: str,
        bear_output: ValuationOutput,
        base_output: ValuationOutput,
        bull_output: ValuationOutput,
        bear_dcf_inputs: DCFInputs,
        base_dcf_inputs: DCFInputs,
        bull_dcf_inputs: DCFInputs,
        wacc_result: WACCResult,
        scenario_results: ScenarioResults,
        current_price: float | None = None,
    ) -> AnalysisReport:
        """Async wrapper for FastAPI route handlers."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            self.build,
            ticker,
            bear_output, base_output, bull_output,
            bear_dcf_inputs, base_dcf_inputs, bull_dcf_inputs,
            wacc_result, scenario_results, current_price,
        )
