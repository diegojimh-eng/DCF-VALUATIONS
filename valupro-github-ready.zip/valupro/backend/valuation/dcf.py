"""
valuation/dcf.py
-----------------
Discounted Cash Flow (DCF) engine.

Discounts the explicit FCFF forecast (years 1…N) and the terminal value
back to present, then bridges from Enterprise Value to Fair Value per Share.

─────────────────────────────────────────────────────────────────────────────
Step 1 — Discount explicit FCFFs
─────────────────────────────────────────────────────────────────────────────

  For each forecast year t ∈ {1, …, N}:

    Discount Factor_t = 1 / (1 + WACC)^t

    PV(FCFF_t) = FCFF_t × Discount Factor_t

  Σ PV(FCFF) = sum of all discounted FCFFs

  Mid-year convention (optional):
    Discount Factor_t = 1 / (1 + WACC)^(t − 0.5)
    (Used when cash flows are assumed to arrive throughout the year
     rather than at year-end. Default: year-end.)

─────────────────────────────────────────────────────────────────────────────
Step 2 — Enterprise Value
─────────────────────────────────────────────────────────────────────────────

  Enterprise Value = Σ PV(FCFF_t) + PV(Terminal Value)

─────────────────────────────────────────────────────────────────────────────
Step 3 — Equity Bridge
─────────────────────────────────────────────────────────────────────────────

  Equity Value = EV − Net Debt − Minority Interest − Preferred Equity

  Where:
    Net Debt = Short-term debt + Long-term debt − Cash & Equivalents
               (Positive net debt reduces equity value)

─────────────────────────────────────────────────────────────────────────────
Step 4 — Fair Value per Share
─────────────────────────────────────────────────────────────────────────────

  Fair Value / Share = Equity Value / Diluted Shares Outstanding

─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

from valuation.models import (
    DCFInputs,
    DCFYearResult,
    TerminalValueResult,
    ValuationOutput,
    WACCResult,
)
from valuation.terminal_value import TerminalValueCalculator
from logger import get_logger

log = get_logger(__name__)


class DCFEngine:
    """
    Discounts FCFF series and bridges Enterprise Value to equity per share.

    Instantiate once and reuse — fully stateless between calls.
    """

    def __init__(self, mid_year_convention: bool = False) -> None:
        """
        Args:
            mid_year_convention: If True, use t−0.5 exponent instead of t.
                                 This increases all PVs by ~sqrt(1+WACC).
        """
        self._mid_year = mid_year_convention
        self._tv_calc  = TerminalValueCalculator()

    def compute(
        self,
        inputs: DCFInputs,
        wacc_result: WACCResult,
        ticker: str = "",
        scenario: str = "base",
    ) -> ValuationOutput:
        """
        Execute the complete DCF → EV → Equity Value → Fair Value pipeline.

        Args:
            inputs:      DCFInputs (FCFF series, terminal value params, debt, shares).
            wacc_result: Computed WACCResult from WACCCalculator.
            ticker:      For logging and output labelling.
            scenario:    Scenario label (bear/base/bull).

        Returns:
            ValuationOutput with complete valuation and formula audit trail.
        """
        warnings: list[str] = []
        wacc = wacc_result.wacc
        n = len(inputs.fcff_series)

        # ── Step 1: Discount explicit FCFFs ───────────────────────────────
        dcf_schedule, sum_pv_fcff = self._discount_fcff(
            inputs.fcff_series, inputs.fiscal_years, wacc
        )

        # ── Step 2: Terminal value ─────────────────────────────────────────
        fcff_terminal   = inputs.fcff_series[-1]
        ebitda_terminal = inputs.ebitda_series[-1] if inputs.ebitda_series else None

        tv_result = self._tv_calc.compute(
            inputs=inputs.terminal_value_inputs,
            wacc=wacc,
            fcff_terminal=fcff_terminal,
            ebitda_terminal=ebitda_terminal,
            forecast_years=n,
        )
        pv_tv = tv_result.pv_terminal_value

        # ── Step 3: Enterprise Value ───────────────────────────────────────
        enterprise_value = sum_pv_fcff + pv_tv

        # Patch pv_terminal_value_pct now that EV is known
        pv_tv_pct = (pv_tv / enterprise_value) if enterprise_value > 0 else 0.0
        pv_fcff_pct = 1.0 - pv_tv_pct

        # Rebuild tv_result with correct pct (model is frozen, so create new)
        tv_result = tv_result.model_copy(update={"pv_terminal_value_pct": pv_tv_pct})

        # ── Step 4: Equity bridge ──────────────────────────────────────────
        equity_value = (
            enterprise_value
            - inputs.net_debt
            - inputs.minority_interest
            - inputs.preferred_equity
        )

        if equity_value <= 0:
            warnings.append(
                f"Equity value is non-positive ({equity_value:,.0f}). "
                "Net debt exceeds enterprise value — common in distressed situations."
            )
            equity_value = max(equity_value, 0.0)

        # ── Step 5: Fair Value per Share ───────────────────────────────────
        fair_value_per_share = equity_value / inputs.shares_outstanding

        # ── Warnings ─────────────────────────────────────────────────────
        if pv_tv_pct > 0.80:
            warnings.append(
                f"Terminal value represents {pv_tv_pct:.1%} of EV. "
                "High TV dependence — results are sensitive to growth rate and WACC assumptions."
            )
        if any(f < 0 for f in inputs.fcff_series[:3]):
            warnings.append("Negative FCFF in the early forecast years reduces EV materially.")

        g = inputs.terminal_value_inputs.terminal_growth_rate
        wacc_g_spread = wacc - g
        if wacc_g_spread < 0.01:
            warnings.append(
                f"WACC−g spread is very tight ({wacc_g_spread:.2%}). "
                "Terminal value is highly sensitive — consider stress-testing."
            )

        log.info(
            "dcf.computed",
            ticker=ticker,
            scenario=scenario,
            ev=round(enterprise_value),
            equity_value=round(equity_value),
            fvps=round(fair_value_per_share, 2),
            pv_tv_pct=round(pv_tv_pct, 3),
        )

        return ValuationOutput(
            ticker=ticker,
            scenario=scenario,
            wacc_result=wacc_result,
            terminal_value_result=tv_result,
            dcf_schedule=dcf_schedule,
            sum_pv_fcff=sum_pv_fcff,
            pv_terminal_value=pv_tv,
            enterprise_value=enterprise_value,
            net_debt=inputs.net_debt,
            minority_interest=inputs.minority_interest,
            preferred_equity=inputs.preferred_equity,
            equity_value=equity_value,
            shares_outstanding=inputs.shares_outstanding,
            fair_value_per_share=fair_value_per_share,
            pv_fcff_pct_of_ev=pv_fcff_pct,
            pv_tv_pct_of_ev=pv_tv_pct,
            wacc=wacc,
            terminal_growth_rate=g,
            forecast_years=n,
            warnings=warnings,
        )

    # ── Internal helpers ───────────────────────────────────────────────────

    def _discount_fcff(
        self,
        fcff_series: list[float],
        fiscal_years: list[int],
        wacc: float,
    ) -> tuple[list[DCFYearResult], float]:
        """
        Discount each FCFF to present value.

        Returns:
            (dcf_schedule, sum_pv_fcff)
        """
        schedule: list[DCFYearResult] = []
        total_pv = 0.0

        for i, (fcff, fy) in enumerate(zip(fcff_series, fiscal_years)):
            t = i + 1   # year 1 … N
            exponent = (t - 0.5) if self._mid_year else t
            discount_factor = 1.0 / (1.0 + wacc) ** exponent
            pv_fcff = fcff * discount_factor

            schedule.append(
                DCFYearResult(
                    year_index=t,
                    fiscal_year=fy,
                    fcff=fcff,
                    discount_factor=round(discount_factor, 6),
                    pv_fcff=pv_fcff,
                )
            )
            total_pv += pv_fcff

        return schedule, total_pv
