"""
valuation/terminal_value.py
----------------------------
Terminal Value (TV) calculator.

The terminal value captures the company's value beyond the explicit forecast
horizon (years 1–N). It typically represents 60–80% of total DCF value for
mature companies — a fact that should always be disclosed in the report.

─────────────────────────────────────────────────────────────────────────────
Method 1 — Gordon Growth Model (Perpetuity Growth)
─────────────────────────────────────────────────────────────────────────────

  TV = FCFF_N × (1 + g) / (WACC − g)

  Where:
    FCFF_N  = Free Cash Flow to Firm in the final forecast year (year N)
    g       = Terminal (perpetuity) growth rate. MUST be < WACC.
              Typical range: 1.5% – 3.0% for developed-market companies.
              Should not exceed long-run nominal GDP growth.
    WACC    = Discount rate (already computed)

  Constraint: WACC − g > 0  (otherwise TV is negative or undefined)

─────────────────────────────────────────────────────────────────────────────
Method 2 — Exit Multiple (EV / EBITDA)
─────────────────────────────────────────────────────────────────────────────

  TV = EBITDA_N × Exit_Multiple

  Where:
    EBITDA_N    = EBITDA in the final forecast year
    Exit_Multiple = Analyst-specified EV/EBITDA multiple
                   Typically derived from sector peer medians.

─────────────────────────────────────────────────────────────────────────────
Present Value of Terminal Value
─────────────────────────────────────────────────────────────────────────────

  PV(TV) = TV / (1 + WACC)^N

  Where N = number of explicit forecast years.
"""

from __future__ import annotations

from valuation.models import TerminalValueInputs, TerminalValueResult
from logger import get_logger

log = get_logger(__name__)


class TerminalValueCalculator:
    """
    Computes terminal value using Gordon Growth Model and/or Exit Multiple.

    Stateless — safe to reuse across scenarios.
    """

    def compute(
        self,
        inputs: TerminalValueInputs,
        wacc: float,
        fcff_terminal: float,
        ebitda_terminal: float | None,
        forecast_years: int,
        exit_multiple: float | None = None,
    ) -> TerminalValueResult:
        """
        Compute terminal value and its present value.

        Args:
            inputs:          TerminalValueInputs (method, growth rate, multiple).
            wacc:            WACC from WACCResult.wacc.
            fcff_terminal:   FCFF in year N (final forecast year).
            ebitda_terminal: EBITDA in year N (required for exit multiple method).
            forecast_years:  N — used to discount TV back to present.
            exit_multiple:   Override exit multiple (from inputs or caller).

        Returns:
            TerminalValueResult with both methods computed where possible.

        Raises:
            ValueError if WACC ≤ g (Gordon Growth is undefined).
        """
        g = inputs.terminal_growth_rate
        method = inputs.method

        # Resolve exit multiple: caller override > inputs field > None
        em = exit_multiple or inputs.exit_ebitda_multiple

        # ── Gordon Growth Model ────────────────────────────────────────────
        tv_ggm = self._gordon_growth(fcff_terminal, wacc, g)

        # ── Exit Multiple ──────────────────────────────────────────────────
        tv_exit = self._exit_multiple(ebitda_terminal, em)

        # ── Select / blend terminal value ─────────────────────────────────
        tv_final = self._select_tv(method, tv_ggm, tv_exit)

        # ── Discount TV back to present ────────────────────────────────────
        pv_tv = self._present_value(tv_final, wacc, forecast_years)

        log.info(
            "tv.computed",
            method=method,
            tv_ggm=round(tv_ggm) if tv_ggm else None,
            tv_exit=round(tv_exit) if tv_exit else None,
            tv_final=round(tv_final),
            pv_tv=round(pv_tv),
            g=g,
            wacc=wacc,
            n=forecast_years,
        )

        return TerminalValueResult(
            method_used=method,
            terminal_growth_rate=g,
            wacc=wacc,
            fcff_terminal=fcff_terminal,
            ebitda_terminal=ebitda_terminal,
            tv_gordon_growth=tv_ggm,
            tv_exit_multiple=tv_exit,
            tv_final=tv_final,
            pv_terminal_value=pv_tv,
            pv_terminal_value_pct=0.0,   # filled by pipeline after EV is known
        )

    # ── Method implementations ─────────────────────────────────────────────

    @staticmethod
    def _gordon_growth(fcff_n: float, wacc: float, g: float) -> float:
        """
        TV = FCFF_N × (1 + g) / (WACC − g)

        Raises ValueError when WACC ≤ g (denominator ≤ 0).
        """
        spread = wacc - g
        if spread <= 0.005:   # < 50 bps spread is financially unreasonable
            raise ValueError(
                f"WACC ({wacc:.2%}) must exceed terminal growth rate ({g:.2%}) "
                f"by at least 50 bps. Current spread: {spread:.2%}. "
                f"Lower g or raise WACC."
            )
        return fcff_n * (1.0 + g) / spread

    @staticmethod
    def _exit_multiple(
        ebitda_n: float | None,
        multiple: float | None,
    ) -> float | None:
        """
        TV = EBITDA_N × Exit_Multiple

        Returns None when either input is missing.
        """
        if ebitda_n is None or multiple is None:
            return None
        if ebitda_n <= 0:
            log.warning("tv.exit_multiple.negative_ebitda", ebitda=ebitda_n)
            return None
        return ebitda_n * multiple

    @staticmethod
    def _select_tv(
        method: str,
        tv_ggm: float | None,
        tv_exit: float | None,
    ) -> float:
        """Select or blend terminal values based on method."""
        if method == "gordon_growth":
            if tv_ggm is None:
                raise ValueError("Gordon Growth TV could not be computed.")
            return tv_ggm

        elif method == "exit_multiple":
            if tv_exit is None:
                raise ValueError(
                    "Exit Multiple TV requires both ebitda_terminal and exit_ebitda_multiple."
                )
            return tv_exit

        elif method == "average":
            available = [v for v in (tv_ggm, tv_exit) if v is not None]
            if not available:
                raise ValueError("No terminal value method produced a result.")
            return sum(available) / len(available)

        else:
            raise ValueError(f"Unknown terminal value method: {method!r}")

    @staticmethod
    def _present_value(tv: float, wacc: float, n: int) -> float:
        """
        PV(TV) = TV / (1 + WACC)^N

        N is the number of explicit forecast years.
        """
        discount_factor = (1.0 + wacc) ** n
        return tv / discount_factor
