"""
valuation/terminal/gordon_growth.py
-------------------------------------
Gordon Growth Model (GGM) — standalone, fully self-documented terminal value class.

─────────────────────────────────────────────────────────────────────────────
Gordon Growth Model (Perpetuity Growth Method)
─────────────────────────────────────────────────────────────────────────────

The GGM assumes the company grows its free cash flow at a constant rate g
in perpetuity beyond the explicit forecast horizon.

  Terminal Value = FCFF_N × (1 + g)
                   ──────────────────
                      WACC − g

  Where:
    FCFF_N  = Normalised Free Cash Flow to Firm in the terminal year.
              Using the final projected FCFF directly is the standard approach.
    g       = Perpetuity growth rate (MUST be < WACC).
              Best practice: tie to long-run nominal GDP growth for the
              company's primary market (e.g. 2.0–2.5% for the US).
              Should NEVER exceed the risk-free rate long-term.
    WACC    = Discount rate (from the WACC engine).

─────────────────────────────────────────────────────────────────────────────
Implied Growth Rate (Reverse GGM)
─────────────────────────────────────────────────────────────────────────────

  Given a target terminal value (e.g. from the current market price), the
  implied perpetuity growth rate can be solved analytically:

    g = (TV × WACC - FCFF_N) / (TV + FCFF_N)

  This is useful for market-implied growth rate analysis — you take the
  current enterprise value, back out PV(explicit FCFFs), and the remainder
  is the implied TV. Then solve for g to understand what growth rate the
  market is pricing in.

─────────────────────────────────────────────────────────────────────────────
Constraints & Validation
─────────────────────────────────────────────────────────────────────────────

  Hard constraints (raise ValueError):
    • WACC ≤ g                  → denominator ≤ 0 (TV infinite or negative)
    • WACC − g < MIN_SPREAD     → TV is astronomically sensitive (default 30 bps)

  Soft warnings (attached to result, do not raise):
    • g > risk_free_rate        → growth exceeds the "riskless" benchmark
    • g > long-run GDP estimate → growth exceeds macroeconomic ceiling
    • TV/EV > 80%               → model heavily dependent on terminal assumptions
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from logger import get_logger

log = get_logger(__name__)

# Minimum required spread between WACC and g
_MIN_SPREAD: float = 0.003   # 30 bps — below this, TV is hypersenistive
# Long-run nominal GDP ceiling (US reference)
_GDP_CEILING: float = 0.035  # 3.5% — warn if g exceeds this


@dataclass(frozen=True)
class GGMResult:
    """
    Complete result of a Gordon Growth Model computation.

    Formulas displayed:
      TV = FCFF_N × (1 + g) / (WACC − g)
      PV(TV) = TV / (1 + WACC)^N
    """
    # ── Inputs (echoed for audit) ──────────────────────────────────────────
    fcff_terminal: float
    wacc: float
    terminal_growth_rate: float
    forecast_years: int

    # ── Terminal value ─────────────────────────────────────────────────────
    terminal_value: float
    """TV = FCFF_N × (1 + g) / (WACC − g)"""

    pv_terminal_value: float
    """PV(TV) = TV / (1 + WACC)^N"""

    # ── Sensitivity diagnostics ────────────────────────────────────────────
    wacc_g_spread: float
    """WACC − g. Small spread = high TV sensitivity."""

    tv_to_fcff_multiple: float
    """TV / FCFF_N. Shows terminal value in units of terminal cash flow."""

    # ── Flags & warnings ──────────────────────────────────────────────────
    warnings: list[str] = field(default_factory=list)

    def formula_display(self) -> str:
        """
        Multi-line human-readable formula showing every input and output.
        Suitable for embedding in a PDF report or UI tooltip.
        """
        g    = self.terminal_growth_rate
        wacc = self.wacc
        n    = self.forecast_years
        tv   = self.terminal_value
        pv   = self.pv_terminal_value

        return (
            "Gordon Growth Model (Perpetuity Method)\n"
            "────────────────────────────────────────\n"
            f"  TV = FCFF_N × (1 + g) / (WACC − g)\n\n"
            f"     = {self.fcff_terminal:>20,.0f}  ← FCFF in year {n}\n"
            f"       × (1 + {g:.3%})\n"
            f"       ÷ ({wacc:.3%} − {g:.3%})\n"
            f"       ÷ {self.wacc_g_spread:.3%}   ← WACC−g spread\n"
            f"────────────────────────────────────────\n"
            f"  Terminal Value = {tv:>20,.0f}\n\n"
            f"  PV(TV) = TV / (1 + WACC)^N\n"
            f"         = {tv:>20,.0f}\n"
            f"         ÷ (1 + {wacc:.3%})^{n}\n"
            f"         = {pv:>20,.0f}\n\n"
            f"  TV / FCFF_N = {self.tv_to_fcff_multiple:.1f}×"
        )

    def sensitivity_label(self) -> str:
        """One-line label for sensitivity heatmap cells."""
        return f"{self.pv_terminal_value:,.0f}"


class GordonGrowthModel:
    """
    Gordon Growth Model terminal value calculator.

    Stateless — a single instance can be used across all scenarios
    and all sensitivity grid cells without any shared state.

    Usage:
        ggm = GordonGrowthModel()
        result = ggm.compute(
            fcff_terminal=100_000_000,
            wacc=0.09,
            terminal_growth_rate=0.025,
            forecast_years=10,
        )
        print(result.formula_display())
    """

    def __init__(
        self,
        min_spread: float = _MIN_SPREAD,
        gdp_ceiling: float = _GDP_CEILING,
    ) -> None:
        """
        Args:
            min_spread:    Minimum required WACC−g spread. Below this, raise ValueError.
            gdp_ceiling:   Soft warning threshold for g exceeding long-run GDP.
        """
        self._min_spread  = min_spread
        self._gdp_ceiling = gdp_ceiling

    def compute(
        self,
        fcff_terminal: float,
        wacc: float,
        terminal_growth_rate: float,
        forecast_years: int,
        risk_free_rate: float | None = None,
    ) -> GGMResult:
        """
        Compute the Gordon Growth terminal value.

        Args:
            fcff_terminal:       FCFF in the final explicit forecast year (year N).
                                 Can be negative (distressed scenario) — TV will be negative.
            wacc:                WACC (from WACCCalculator). Must exceed g + min_spread.
            terminal_growth_rate: Perpetuity growth rate g. Typically 1.5% – 3.0%.
            forecast_years:      Number of explicit forecast years N. Used to discount TV.
            risk_free_rate:      Optional. If provided, warns when g > Rf.

        Returns:
            GGMResult with terminal value, PV(TV), and all diagnostics.

        Raises:
            ValueError: When WACC − g < min_spread (formula is undefined or explosive).
        """
        g    = terminal_growth_rate
        spread = wacc - g

        # ── Hard constraint ────────────────────────────────────────────────
        if spread < self._min_spread:
            raise ValueError(
                f"WACC ({wacc:.3%}) must exceed terminal growth rate ({g:.3%}) "
                f"by at least {self._min_spread:.0%}. "
                f"Current spread: {spread:.3%}. "
                f"Reduce g or increase WACC."
            )

        # ── Core formula ───────────────────────────────────────────────────
        #   TV = FCFF_N × (1 + g) / (WACC − g)
        terminal_value = fcff_terminal * (1.0 + g) / spread

        # ── Discount to present ────────────────────────────────────────────
        #   PV(TV) = TV / (1 + WACC)^N
        pv_tv = terminal_value / (1.0 + wacc) ** forecast_years

        # ── Diagnostics ────────────────────────────────────────────────────
        tv_to_fcff = (terminal_value / fcff_terminal) if abs(fcff_terminal) > 0 else 0.0

        # ── Soft warnings ──────────────────────────────────────────────────
        warnings: list[str] = []
        if g > self._gdp_ceiling:
            warnings.append(
                f"Terminal growth rate ({g:.2%}) exceeds long-run nominal GDP "
                f"ceiling ({self._gdp_ceiling:.2%}). "
                f"This implies the company will outgrow the economy in perpetuity — "
                f"unlikely for a mature business."
            )
        if risk_free_rate is not None and g > risk_free_rate:
            warnings.append(
                f"Terminal growth rate ({g:.2%}) exceeds the risk-free rate "
                f"({risk_free_rate:.2%}). "
                f"Perpetuity growth should not exceed the risk-free rate long-term."
            )
        if spread < 0.015:   # < 150 bps spread — soft warning zone
            warnings.append(
                f"WACC−g spread is narrow ({spread:.2%}). "
                f"Terminal value is highly sensitive to assumption changes — "
                f"run a sensitivity analysis."
            )
        if fcff_terminal < 0:
            warnings.append(
                f"FCFF_N is negative ({fcff_terminal:,.0f}). "
                f"Negative terminal cash flow implies a negative terminal value — "
                f"verify this is intentional."
            )

        log.debug(
            "ggm.computed",
            wacc=wacc, g=g, spread=spread,
            fcff_n=fcff_terminal,
            tv=terminal_value, pv_tv=pv_tv,
        )

        return GGMResult(
            fcff_terminal=fcff_terminal,
            wacc=wacc,
            terminal_growth_rate=g,
            forecast_years=forecast_years,
            terminal_value=terminal_value,
            pv_terminal_value=pv_tv,
            wacc_g_spread=spread,
            tv_to_fcff_multiple=tv_to_fcff,
            warnings=warnings,
        )

    def implied_growth_rate(
        self,
        target_terminal_value: float,
        fcff_terminal: float,
        wacc: float,
    ) -> float:
        """
        Reverse GGM — solve for the implied growth rate given a target TV.

        Useful for market-implied growth rate analysis:
          1. Take current enterprise value.
          2. Subtract PV of explicit FCFFs.
          3. Discount back to get the implied terminal value.
          4. Call this method to find the implied g.

        Formula derivation:
          TV = FCFF_N × (1+g) / (WACC−g)
          TV × (WACC−g) = FCFF_N × (1+g)
          TV × WACC − TV × g = FCFF_N + FCFF_N × g
          TV × WACC − FCFF_N = g × (TV + FCFF_N)
          g = (TV × WACC − FCFF_N) / (TV + FCFF_N)

        Args:
            target_terminal_value: The TV you want to imply g from.
            fcff_terminal:         FCFF_N (same as used in the forward computation).
            wacc:                  WACC.

        Returns:
            Implied g (decimal). May be negative for distressed scenarios.

        Raises:
            ValueError if TV + FCFF_N ≈ 0 (degenerate case).
        """
        denominator = target_terminal_value + fcff_terminal
        if abs(denominator) < 1.0:
            raise ValueError(
                "Cannot solve for implied g: TV + FCFF_N is near zero. "
                "This occurs when the terminal value exactly offsets the final FCFF."
            )
        g_implied = (target_terminal_value * wacc - fcff_terminal) / denominator
        log.debug("ggm.implied_g", g=g_implied, tv=target_terminal_value, wacc=wacc)
        return g_implied

    def sensitivity_sweep(
        self,
        fcff_terminal: float,
        wacc: float,
        forecast_years: int,
        g_values: list[float],
    ) -> list[GGMResult]:
        """
        Compute GGM for a list of terminal growth rates.

        Used internally by TVSensitivityAnalyser — can also be called directly
        to get a quick 1-D sweep without building a full grid.

        Args:
            fcff_terminal:  Terminal FCFF.
            wacc:           Fixed WACC.
            forecast_years: N.
            g_values:       List of growth rates to evaluate.

        Returns:
            List of GGMResult (same order as g_values).
            Cells where WACC−g < min_spread are skipped (None inserted).
        """
        results: list[GGMResult] = []
        for g in g_values:
            try:
                results.append(self.compute(fcff_terminal, wacc, g, forecast_years))
            except ValueError:
                # Skip invalid cells — caller handles Nones
                pass
        return results
