"""
valuation/terminal/comparison.py
----------------------------------
Terminal Value Comparison — side-by-side analysis of GGM vs Exit Multiple.

In professional practice, both methods are always computed and compared.
Large divergence between methods signals:
  • Inconsistent assumptions (the multiple implies a different g than the analyst assumed)
  • Market mis-pricing vs. fundamental value
  • A sector where one method is more appropriate than the other

This module provides:
  1. Side-by-side comparison table
  2. Damodaran consistency check (implied multiple from GGM)
  3. Implied growth rate from exit multiple (reverse GGM)
  4. Divergence attribution (is the gap driven by growth or multiple?)
  5. Analyst guidance on which method to weight more heavily
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from valuation.terminal.gordon_growth import GGMResult, GordonGrowthModel
from valuation.terminal.exit_multiple import ExitMetric, ExitMultipleModel, ExitMultipleResult
from logger import get_logger

log = get_logger(__name__)


@dataclass(frozen=True)
class TVComparisonResult:
    """
    Full side-by-side comparison of GGM vs Exit Multiple.

    Contains individual results, divergence metrics, consistency checks,
    and analyst guidance formatted for inclusion in a PDF report.
    """
    # ── Individual method results ──────────────────────────────────────────
    ggm: GGMResult
    exit: ExitMultipleResult

    # ── Divergence metrics ─────────────────────────────────────────────────
    tv_divergence_abs: float
    """Absolute difference: |TV_GGM − TV_Exit|"""

    tv_divergence_pct: float
    """Relative divergence: |TV_GGM − TV_Exit| / max(|TV_GGM|, |TV_Exit|)"""

    pv_tv_divergence_abs: float
    """Absolute difference in PV(TV): |PV(TV_GGM) − PV(TV_Exit)|"""

    pv_tv_divergence_pct: float
    """Relative PV(TV) divergence."""

    # ── Consistency cross-checks ────────────────────────────────────────────
    implied_exit_multiple_from_ggm: float | None
    """
    Exit multiple implied by the GGM terminal value.
    TV_GGM / EBITDA_N — tells you what multiple the GGM is implicitly assuming.
    """

    implied_growth_from_exit: float | None
    """
    Growth rate implied by the exit multiple terminal value (reverse GGM).
    g = (TV_Exit × WACC − FCFF_N) / (TV_Exit + FCFF_N)
    """

    damodaran_check: dict
    """
    Damodaran consistency: does the exit multiple match the GGM assumptions?
    {"implied_multiple": float, "your_multiple": float, "gap_pct": float}
    """

    # ── Guidance ───────────────────────────────────────────────────────────
    recommended_weight_ggm: float
    """Engine-suggested weight for GGM (0.0–1.0)."""

    recommended_weight_exit: float
    """Engine-suggested weight for Exit Multiple (0.0–1.0)."""

    guidance_note: str
    """Plain-English explanation of the recommendation."""

    all_warnings: list[str] = field(default_factory=list)

    def comparison_table(self) -> str:
        """
        Formatted comparison table for the PDF report.

        GGM                                Exit Multiple
        ──────────────────────────────────────────────────
        FCFF_N × (1+g) / (WACC−g)         EBITDA_N × multiple
        {ggm.fcff_terminal:,.0f} × ...      {exit.metric_value:,.0f} × {exit.exit_multiple:.1f}×
        TV = {ggm.terminal_value:,.0f}      TV = {exit.terminal_value:,.0f}
        PV(TV) = {ggm.pv_tv:,.0f}           PV(TV) = {exit.pv_tv:,.0f}
        ...
        Divergence: {tv_divergence_pct:.1%}
        """
        w = 22  # column width
        sep = "─" * (w * 2 + 5)
        lines = [
            f"{'Gordon Growth Model':<{w}}   {'Exit Multiple Method'}",
            sep,
            f"{'Formula:':<{w}}   {'Formula:'}",
            f"{'FCFF_N×(1+g)/(WACC−g)':<{w}}   "
            f"{'EBITDA_N × multiple' if self.exit.metric == ExitMetric.EV_EBITDA else self.exit.metric.value}",
            "",
            f"{'Key input:':<{w}}   {'Key input:'}",
            f"{f'FCFF_N = {self.ggm.fcff_terminal:,.0f}':<{w}}   "
            f"Metric = {self.exit.metric_value:,.0f}",
            f"{f'g = {self.ggm.terminal_growth_rate:.2%}':<{w}}   "
            f"Multiple = {self.exit.exit_multiple:.2f}×",
            f"{f'WACC = {self.ggm.wacc:.2%}':<{w}}   "
            f"WACC = {self.exit.wacc:.2%}",
            "",
            sep,
            f"{f'TV = {self.ggm.terminal_value:>18,.0f}':<{w}}   "
            f"TV = {self.exit.terminal_value:>18,.0f}",
            f"{f'PV(TV) = {self.ggm.pv_terminal_value:>14,.0f}':<{w}}   "
            f"PV(TV) = {self.exit.pv_terminal_value:>14,.0f}",
            sep,
            f"TV Divergence:        {self.tv_divergence_abs:>18,.0f}  ({self.tv_divergence_pct:.1%})",
            f"PV(TV) Divergence:    {self.pv_tv_divergence_abs:>18,.0f}  ({self.pv_tv_divergence_pct:.1%})",
            "",
            "Cross-checks:",
        ]
        if self.implied_exit_multiple_from_ggm is not None:
            lines.append(
                f"  GGM implies EV/EBITDA multiple of {self.implied_exit_multiple_from_ggm:.1f}× "
                f"(analyst used {self.exit.exit_multiple:.1f}×)"
            )
        if self.implied_growth_from_exit is not None:
            lines.append(
                f"  Exit Multiple implies g = {self.implied_growth_from_exit:.2%} "
                f"(analyst used g = {self.ggm.terminal_growth_rate:.2%})"
            )
        lines += [
            "",
            f"Recommendation: GGM {self.recommended_weight_ggm:.0%} / Exit {self.recommended_weight_exit:.0%}",
            f"Rationale: {self.guidance_note}",
        ]
        return "\n".join(lines)


class TVComparison:
    """
    Computes a full side-by-side comparison of GGM and Exit Multiple methods.
    """

    _DIVERGENCE_THRESHOLD_HIGH = 0.30    # >30% divergence → weight toward GGM
    _DIVERGENCE_THRESHOLD_LOW  = 0.10    # <10% → equal weight

    def __init__(self) -> None:
        self._ggm_model  = GordonGrowthModel()
        self._exit_model = ExitMultipleModel()

    def compare(
        self,
        ggm_result: GGMResult,
        exit_result: ExitMultipleResult,
        ebitda_terminal: float | None = None,
        ebitda_margin_terminal: float | None = None,
        tax_rate: float = 0.21,
    ) -> TVComparisonResult:
        """
        Build a full comparison from pre-computed GGM and Exit results.

        Args:
            ggm_result:              Pre-computed GGMResult.
            exit_result:             Pre-computed ExitMultipleResult.
            ebitda_terminal:         Terminal EBITDA (for implied multiple calc).
            ebitda_margin_terminal:  EBITDA / Revenue in terminal year (for Damodaran check).
            tax_rate:                For Damodaran consistency check.

        Returns:
            TVComparisonResult with all divergence metrics and guidance.
        """
        tv_ggm  = ggm_result.terminal_value
        tv_exit = exit_result.terminal_value

        # ── Divergence ─────────────────────────────────────────────────────
        tv_div_abs = abs(tv_ggm - tv_exit)
        max_abs_tv = max(abs(tv_ggm), abs(tv_exit), 1.0)
        tv_div_pct = tv_div_abs / max_abs_tv

        pv_ggm  = ggm_result.pv_terminal_value
        pv_exit = exit_result.pv_terminal_value
        pv_div_abs = abs(pv_ggm - pv_exit)
        max_abs_pv = max(abs(pv_ggm), abs(pv_exit), 1.0)
        pv_div_pct = pv_div_abs / max_abs_pv

        # ── Cross-checks ───────────────────────────────────────────────────
        # 1. Implied EV/EBITDA multiple from GGM TV
        implied_em: float | None = None
        if ebitda_terminal and abs(ebitda_terminal) > 0:
            implied_em = tv_ggm / ebitda_terminal

        # 2. Implied g from exit TV (reverse GGM)
        implied_g: float | None = exit_result.implied_growth_rate

        # 3. Damodaran consistency check
        damodaran = {"implied_multiple": None, "your_multiple": exit_result.exit_multiple,
                     "gap_pct": None, "note": "EBITDA margin not provided — skipping check."}
        if ebitda_margin_terminal and ebitda_margin_terminal > 0:
            damodaran = self._exit_model.damodaran_consistency_check(
                exit_ebitda_multiple=exit_result.exit_multiple,
                wacc=exit_result.wacc,
                terminal_growth_rate=ggm_result.terminal_growth_rate,
                ebitda_margin_terminal=ebitda_margin_terminal,
                tax_rate=tax_rate,
            )

        # ── Guidance ───────────────────────────────────────────────────────
        w_ggm, w_exit, guidance = self._recommend_weights(
            tv_div_pct=tv_div_pct,
            damodaran_consistent=damodaran.get("is_consistent", None),
        )

        # ── Collect warnings ───────────────────────────────────────────────
        all_warnings = list(ggm_result.warnings) + list(exit_result.warnings)
        if tv_div_pct > self._DIVERGENCE_THRESHOLD_HIGH:
            all_warnings.append(
                f"GGM and Exit Multiple diverge by {tv_div_pct:.1%}. "
                f"The two methods tell materially different stories — review assumptions."
            )
        if implied_g is not None and abs(implied_g - ggm_result.terminal_growth_rate) > 0.02:
            all_warnings.append(
                f"The exit multiple implies a perpetuity growth rate of {implied_g:.2%}, "
                f"but the GGM uses {ggm_result.terminal_growth_rate:.2%}. "
                f"Consider reconciling these assumptions."
            )

        log.info(
            "tv_comparison.complete",
            tv_div_pct=round(tv_div_pct, 3),
            w_ggm=w_ggm, w_exit=w_exit,
            implied_em=round(implied_em, 2) if implied_em else None,
            implied_g=round(implied_g, 4) if implied_g else None,
        )

        return TVComparisonResult(
            ggm=ggm_result,
            exit=exit_result,
            tv_divergence_abs=tv_div_abs,
            tv_divergence_pct=tv_div_pct,
            pv_tv_divergence_abs=pv_div_abs,
            pv_tv_divergence_pct=pv_div_pct,
            implied_exit_multiple_from_ggm=implied_em,
            implied_growth_from_exit=implied_g,
            damodaran_check=damodaran,
            recommended_weight_ggm=w_ggm,
            recommended_weight_exit=w_exit,
            guidance_note=guidance,
            all_warnings=all_warnings,
        )

    def _recommend_weights(
        self,
        tv_div_pct: float,
        damodaran_consistent: bool | None,
    ) -> tuple[float, float, str]:
        """
        Heuristic weight recommendation based on divergence and Damodaran check.

        Returns (w_ggm, w_exit, guidance_note).
        """
        if tv_div_pct < self._DIVERGENCE_THRESHOLD_LOW:
            return (0.5, 0.5, "Methods agree — equal-weight blend is appropriate.")

        if damodaran_consistent is False and tv_div_pct > self._DIVERGENCE_THRESHOLD_HIGH:
            return (
                0.6, 0.4,
                "Methods diverge significantly and the exit multiple is internally inconsistent "
                "with the GGM growth assumptions. Recommend weighting GGM more heavily and "
                "reviewing the exit multiple."
            )

        if tv_div_pct > self._DIVERGENCE_THRESHOLD_HIGH:
            return (
                0.5, 0.5,
                f"Methods diverge by {tv_div_pct:.1%}. Consider whether the exit multiple "
                f"reflects current market conditions or a normalised cycle. "
                f"Equal-weight blend used until the analyst reconciles assumptions."
            )

        return (
            0.5, 0.5,
            "Methods show moderate divergence — equal-weight blend used. "
            "Consider adjusting weights based on sector norms."
        )
