"""
valuation/terminal/blender.py
------------------------------
Terminal Value Blender — weighted combination of GGM and Exit Multiple.

─────────────────────────────────────────────────────────────────────────────
Blending Rationale
─────────────────────────────────────────────────────────────────────────────

No single terminal value method is definitively correct. In practice:

  • The GGM anchors to the fundamental cash flow trajectory and is
    theoretically consistent with CAPM-based valuation.
  • The Exit Multiple anchors to what the market is currently paying
    for comparable companies and is more empirically observable.

Blending the two provides a valuation estimate that is:
  ① Grounded in fundamentals (GGM component)
  ② Market-informed (Exit Multiple component)
  ③ Less sensitive to the extreme assumptions of either method alone

─────────────────────────────────────────────────────────────────────────────
Blended Terminal Value Formula
─────────────────────────────────────────────────────────────────────────────

  TV_blended = w_ggm × TV_GGM  +  w_exit × TV_Exit

  Where:
    w_ggm  + w_exit = 1.0
    w_ggm  ∈ [0, 1]
    w_exit ∈ [0, 1]

  Default: 50/50 equal-weight blend.

  User selections:
    "gordon_growth"  → w_ggm=1.0, w_exit=0.0 (GGM only)
    "exit_multiple"  → w_ggm=0.0, w_exit=1.0 (Exit only)
    "average"        → w_ggm=0.5, w_exit=0.5 (equal weight)
    "custom"         → user-specified weights
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from valuation.terminal.gordon_growth import GGMResult, GordonGrowthModel
from valuation.terminal.exit_multiple import ExitMetric, ExitMultipleModel, ExitMultipleResult
from logger import get_logger

log = get_logger(__name__)


class BlendMode(str, Enum):
    """Pre-defined weight configurations."""
    GGM_ONLY     = "gordon_growth"   # 100% GGM
    EXIT_ONLY    = "exit_multiple"   # 100% Exit Multiple
    EQUAL        = "average"         # 50/50
    CUSTOM       = "custom"          # user-defined weights


@dataclass(frozen=True)
class BlendedTVResult:
    """
    Result of blending GGM and Exit Multiple terminal values.

    Includes both individual method results and the blended aggregate,
    fully traceable for audit and PDF report generation.
    """
    # ── Individual results ─────────────────────────────────────────────────
    ggm_result: GGMResult | None
    exit_result: ExitMultipleResult | None

    # ── Blend configuration ────────────────────────────────────────────────
    mode: BlendMode
    weight_ggm: float
    weight_exit: float

    # ── Blended outputs ────────────────────────────────────────────────────
    terminal_value: float
    """Blended TV = w_ggm × TV_GGM + w_exit × TV_Exit"""

    pv_terminal_value: float
    """Blended PV(TV) = w_ggm × PV(TV_GGM) + w_exit × PV(TV_Exit)"""

    # ── Diagnostics ────────────────────────────────────────────────────────
    ggm_share_pct: float
    """Fraction of the blended TV attributable to GGM."""

    exit_share_pct: float
    """Fraction of the blended TV attributable to Exit Multiple."""

    tv_method_divergence_pct: float | None
    """
    |TV_GGM − TV_Exit| / max(|TV_GGM|, |TV_Exit|).
    Large divergence (>25%) signals the methods are telling different stories.
    """

    warnings: list[str] = field(default_factory=list)

    def formula_display(self) -> str:
        """Multi-line formula for PDF report embedding."""
        lines = [
            "Blended Terminal Value\n"
            "────────────────────────────────────────",
            f"  Mode: {self.mode.value}",
            f"  Weight GGM  = {self.weight_ggm:.0%}",
            f"  Weight Exit = {self.weight_exit:.0%}",
            "",
        ]
        if self.ggm_result is not None:
            lines.append(
                f"  TV(GGM)  = {self.ggm_result.terminal_value:>20,.0f}  "
                f"× {self.weight_ggm:.0%} = {self.ggm_result.terminal_value * self.weight_ggm:>20,.0f}"
            )
        if self.exit_result is not None:
            lines.append(
                f"  TV(Exit) = {self.exit_result.terminal_value:>20,.0f}  "
                f"× {self.weight_exit:.0%} = {self.exit_result.terminal_value * self.weight_exit:>20,.0f}"
            )
        lines += [
            "────────────────────────────────────────",
            f"  TV(Blended)  = {self.terminal_value:>20,.0f}",
            f"  PV(TV)       = {self.pv_terminal_value:>20,.0f}",
        ]
        if self.tv_method_divergence_pct is not None:
            lines.append(
                f"\n  Method divergence: {self.tv_method_divergence_pct:.1%} "
                + ("⚠ Large — consider investigating" if self.tv_method_divergence_pct > 0.25 else "✓ Reasonable")
            )
        return "\n".join(lines)


class TVBlender:
    """
    Blends GGM and Exit Multiple terminal values with user-configurable weights.

    Can be used in three ways:
      1. Directly: blend pre-computed GGMResult and ExitMultipleResult.
      2. From inputs: provide raw financial data and let it compute both internally.
      3. Single-method: pass weight=1.0 for one method, 0.0 for the other.
    """

    def __init__(self) -> None:
        self._ggm  = GordonGrowthModel()
        self._exit = ExitMultipleModel()

    def blend(
        self,
        ggm_result: GGMResult | None,
        exit_result: ExitMultipleResult | None,
        mode: BlendMode = BlendMode.EQUAL,
        weight_ggm: float | None = None,
        weight_exit: float | None = None,
    ) -> BlendedTVResult:
        """
        Blend pre-computed GGM and Exit Multiple results.

        Args:
            ggm_result:   GGMResult from GordonGrowthModel.compute(). May be None.
            exit_result:  ExitMultipleResult from ExitMultipleModel.compute(). May be None.
            mode:         Pre-defined weight configuration.
            weight_ggm:   Custom weight for GGM (required when mode=CUSTOM).
            weight_exit:  Custom weight for Exit (required when mode=CUSTOM).

        Returns:
            BlendedTVResult with all individual and blended values.

        Raises:
            ValueError: When mode=CUSTOM and weights not provided or don't sum to 1.
            ValueError: When a required method result is None for the chosen mode.
        """
        w_ggm, w_exit = self._resolve_weights(mode, weight_ggm, weight_exit)
        self._validate_availability(mode, ggm_result, exit_result)

        # ── Weighted blending ──────────────────────────────────────────────
        tv_ggm  = ggm_result.terminal_value    if ggm_result  else 0.0
        tv_exit = exit_result.terminal_value   if exit_result else 0.0
        pv_ggm  = ggm_result.pv_terminal_value if ggm_result  else 0.0
        pv_exit = exit_result.pv_terminal_value if exit_result else 0.0

        blended_tv = w_ggm * tv_ggm + w_exit * tv_exit
        blended_pv = w_ggm * pv_ggm + w_exit * pv_exit

        # ── Diagnostics ────────────────────────────────────────────────────
        ggm_share  = (w_ggm * tv_ggm  / blended_tv) if blended_tv != 0 else w_ggm
        exit_share = (w_exit * tv_exit / blended_tv) if blended_tv != 0 else w_exit

        divergence: float | None = None
        if ggm_result is not None and exit_result is not None:
            max_abs = max(abs(tv_ggm), abs(tv_exit))
            if max_abs > 0:
                divergence = abs(tv_ggm - tv_exit) / max_abs

        # ── Collect warnings ───────────────────────────────────────────────
        warnings: list[str] = []
        if ggm_result:
            warnings.extend(ggm_result.warnings)
        if exit_result:
            warnings.extend(exit_result.warnings)
        if divergence is not None and divergence > 0.25:
            warnings.append(
                f"GGM and Exit Multiple diverge by {divergence:.1%}. "
                f"GGM TV: {tv_ggm:,.0f} vs Exit TV: {tv_exit:,.0f}. "
                f"Investigate which method better reflects the company's fundamentals."
            )

        log.info(
            "tv_blender.computed",
            mode=mode.value,
            w_ggm=w_ggm, w_exit=w_exit,
            tv_ggm=round(tv_ggm) if ggm_result else None,
            tv_exit=round(tv_exit) if exit_result else None,
            blended_tv=round(blended_tv),
            divergence=round(divergence, 3) if divergence is not None else None,
        )

        return BlendedTVResult(
            ggm_result=ggm_result,
            exit_result=exit_result,
            mode=mode,
            weight_ggm=w_ggm,
            weight_exit=w_exit,
            terminal_value=blended_tv,
            pv_terminal_value=blended_pv,
            ggm_share_pct=ggm_share,
            exit_share_pct=exit_share,
            tv_method_divergence_pct=divergence,
            warnings=warnings,
        )

    def compute_and_blend(
        self,
        # GGM inputs
        fcff_terminal: float,
        wacc: float,
        terminal_growth_rate: float,
        forecast_years: int,
        # Exit Multiple inputs (all optional)
        exit_metric: ExitMetric | None = None,
        exit_metric_value: float | None = None,
        exit_multiple: float | None = None,
        # Blend configuration
        mode: BlendMode = BlendMode.EQUAL,
        weight_ggm: float | None = None,
        weight_exit: float | None = None,
        # Optional context
        risk_free_rate: float | None = None,
        peer_range: tuple[float, float] | None = None,
    ) -> BlendedTVResult:
        """
        Compute both methods from raw inputs and blend in one call.

        Convenience wrapper used by the TV Selector.

        If exit inputs are None and mode requires Exit Multiple,
        raises ValueError.
        """
        # ── Compute GGM ────────────────────────────────────────────────────
        ggm_result: GGMResult | None = None
        if mode != BlendMode.EXIT_ONLY:
            ggm_result = self._ggm.compute(
                fcff_terminal=fcff_terminal,
                wacc=wacc,
                terminal_growth_rate=terminal_growth_rate,
                forecast_years=forecast_years,
                risk_free_rate=risk_free_rate,
            )

        # ── Compute Exit Multiple ──────────────────────────────────────────
        exit_result: ExitMultipleResult | None = None
        if mode != BlendMode.GGM_ONLY:
            if exit_metric is None or exit_metric_value is None or exit_multiple is None:
                if mode in (BlendMode.EXIT_ONLY, BlendMode.EQUAL, BlendMode.CUSTOM):
                    raise ValueError(
                        "Exit metric, metric_value, and exit_multiple are required "
                        f"for blend mode '{mode.value}'."
                    )
            else:
                exit_result = self._exit.compute(
                    metric=exit_metric,
                    metric_value=exit_metric_value,
                    exit_multiple=exit_multiple,
                    wacc=wacc,
                    forecast_years=forecast_years,
                    fcff_terminal=fcff_terminal,
                    peer_range=peer_range,
                )

        return self.blend(ggm_result, exit_result, mode, weight_ggm, weight_exit)

    # ── Internal helpers ───────────────────────────────────────────────────

    @staticmethod
    def _resolve_weights(
        mode: BlendMode,
        weight_ggm: float | None,
        weight_exit: float | None,
    ) -> tuple[float, float]:
        """Return (w_ggm, w_exit) for the given mode."""
        if mode == BlendMode.GGM_ONLY:
            return (1.0, 0.0)
        elif mode == BlendMode.EXIT_ONLY:
            return (0.0, 1.0)
        elif mode == BlendMode.EQUAL:
            return (0.5, 0.5)
        elif mode == BlendMode.CUSTOM:
            if weight_ggm is None or weight_exit is None:
                raise ValueError(
                    "weight_ggm and weight_exit must be provided when mode=CUSTOM."
                )
            total = weight_ggm + weight_exit
            if abs(total - 1.0) > 1e-6:
                raise ValueError(
                    f"Weights must sum to 1.0; got {total:.4f}. "
                    f"(w_ggm={weight_ggm}, w_exit={weight_exit})"
                )
            return (weight_ggm, weight_exit)
        else:
            raise ValueError(f"Unknown blend mode: {mode!r}")

    @staticmethod
    def _validate_availability(
        mode: BlendMode,
        ggm_result: GGMResult | None,
        exit_result: ExitMultipleResult | None,
    ) -> None:
        """Ensure the required results are present for the chosen mode."""
        if mode in (BlendMode.GGM_ONLY, BlendMode.EQUAL, BlendMode.CUSTOM):
            if mode == BlendMode.GGM_ONLY and ggm_result is None:
                raise ValueError("GGM result is required for mode='gordon_growth'.")
        if mode in (BlendMode.EXIT_ONLY, BlendMode.EQUAL, BlendMode.CUSTOM):
            if mode == BlendMode.EXIT_ONLY and exit_result is None:
                raise ValueError("Exit result is required for mode='exit_multiple'.")
