"""
valuation/terminal/selector.py
--------------------------------
Terminal Value Selector — user-facing integration layer.

This is the primary interface between the DCF engine (Phase 4) and the
full Phase 5 terminal value engine. It replaces TerminalValueCalculator
with a richer API that:

  ① Accepts a user selection (method, multiples, weights)
  ② Delegates to the appropriate GGM / Exit / Blender modules
  ③ Returns a TVSelectionResult compatible with the DCF engine
  ④ Always computes both methods for comparison, regardless of user selection
  ⑤ Runs all three TV sensitivity grids automatically

The Selector makes it trivial for the API route to expose a single
POST body field "tv_method": "gordon_growth" | "exit_multiple" | "average"
| "custom_weights" that controls everything.

─────────────────────────────────────────────────────────────────────────────
Integration with Phase 4 DCFEngine
─────────────────────────────────────────────────────────────────────────────

The DCF engine (dcf.py) calls TerminalValueCalculator.compute().
TVSelector.select() returns a TVSelectionResult that contains a
TerminalValueResult — the same object type the DCF engine expects —
so zero changes are needed to dcf.py.

Swap:
    # Phase 4 (old):
    tv_calc = TerminalValueCalculator()
    tv_result = tv_calc.compute(inputs, wacc, fcff_n, ebitda_n, N)

    # Phase 5 (new):
    selector = TVSelector()
    selection = selector.select(tv_selection_inputs)
    tv_result = selection.tv_result   # ← same type, drop-in replacement
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from valuation.models import TerminalValueInputs, TerminalValueResult
from valuation.terminal.blender import BlendMode, BlendedTVResult, TVBlender
from valuation.terminal.comparison import TVComparison, TVComparisonResult
from valuation.terminal.exit_multiple import ExitMetric, ExitMultipleResult, ExitMultipleModel
from valuation.terminal.gordon_growth import GGMResult, GordonGrowthModel
from valuation.terminal.tv_sensitivity import TVSensitivityAnalyser, TVSensitivityReport
from logger import get_logger

log = get_logger(__name__)


@dataclass
class TVSelectionInputs:
    """
    All inputs the TV Selector needs to run the full Phase 5 TV engine.

    Designed to be populated directly from the API request body.
    """
    # ── Required ───────────────────────────────────────────────────────────
    fcff_terminal: float
    """FCFF in the final forecast year (from ForecastOutput.years[-1].fcff)."""

    wacc: float
    """WACC from the WACC engine."""

    terminal_growth_rate: float = 0.025
    """Perpetuity growth rate for GGM. Default: 2.5%."""

    forecast_years: int = 10
    """Number of explicit forecast years."""

    # ── Method selection ───────────────────────────────────────────────────
    method: str = "gordon_growth"
    """
    Which TV to use as the primary output.
    Options: 'gordon_growth' | 'exit_multiple' | 'average' | 'custom_weights'
    """

    weight_ggm: float | None = None
    """Weight for GGM when method='custom_weights'. Must sum to 1.0 with weight_exit."""

    weight_exit: float | None = None
    """Weight for Exit Multiple when method='custom_weights'."""

    # ── Exit Multiple inputs ───────────────────────────────────────────────
    exit_metric: ExitMetric = ExitMetric.EV_EBITDA
    """Which financial metric to apply the exit multiple to."""

    exit_metric_value: float | None = None
    """
    Value of the exit metric in the terminal year.
    For EV/EBITDA: EBITDA_N from ForecastOutput.
    For EV/Revenue: Revenue_N.
    Required when method includes exit multiple.
    """

    exit_multiple: float | None = None
    """
    The exit multiple to apply. Required when method includes exit multiple.
    Typical ranges: EV/EBITDA 8×–25×, EV/Revenue 1×–10×, EV/EBIT 10×–30×.
    """

    peer_range: tuple[float, float] | None = None
    """Optional (low, high) peer comps range for validation context."""

    # ── Optional context ───────────────────────────────────────────────────
    risk_free_rate: float | None = None
    """For GGM soft-warning when g > Rf."""

    ebitda_margin_terminal: float | None = None
    """For Damodaran consistency check in TVComparison."""

    tax_rate: float = 0.21
    """For Damodaran consistency check."""

    # ── Sensitivity grid dimensions ────────────────────────────────────────
    run_sensitivity: bool = True
    """Whether to build all three TV sensitivity grids."""

    net_debt: float = 0.0
    shares_outstanding: float | None = None
    """For FVPS calculation in sensitivity grid cells."""

    wacc_steps: int = 4
    wacc_step_size: float = 0.005
    g_steps: int = 2
    g_step_size: float = 0.005
    multiple_steps: int = 3
    multiple_step_size: float = 1.0


@dataclass(frozen=True)
class TVSelectionResult:
    """
    Complete output of TVSelector.select().

    The `tv_result` field is a TerminalValueResult — drop-in replacement
    for the Phase 4 TerminalValueCalculator output.
    """
    # ── Primary result (for DCF engine integration) ────────────────────────
    tv_result: TerminalValueResult
    """
    Drop-in replacement for Phase 4 TerminalValueCalculator.compute() output.
    Pass directly to DCFEngine.compute() as-is.
    """

    # ── Detailed individual results ────────────────────────────────────────
    ggm_result: GGMResult | None
    exit_result: ExitMultipleResult | None
    blended_result: BlendedTVResult

    # ── Comparison & diagnostics ───────────────────────────────────────────
    comparison: TVComparisonResult | None
    """None when only one method is computed."""

    sensitivity: TVSensitivityReport | None
    """None when run_sensitivity=False."""

    # ── Metadata ───────────────────────────────────────────────────────────
    method_selected: str
    all_warnings: list[str] = field(default_factory=list)

    def formula_display(self) -> str:
        """Full formula breakdown for PDF report."""
        lines = []
        if self.ggm_result is not None:
            lines.append(self.ggm_result.formula_display())
        if self.exit_result is not None:
            lines.append("\n" + self.exit_result.formula_display())
        if self.comparison is not None:
            lines.append("\n" + self.comparison.comparison_table())
        return "\n".join(lines)


class TVSelector:
    """
    User-facing terminal value selection and computation engine.

    Always computes both GGM and Exit Multiple (when inputs are available),
    regardless of which method is selected as primary. This ensures the
    comparison, consistency check, and divergence metrics are always available.
    """

    def __init__(self) -> None:
        self._ggm       = GordonGrowthModel()
        self._exit      = ExitMultipleModel()
        self._blender   = TVBlender()
        self._comparison = TVComparison()
        self._sensitivity = TVSensitivityAnalyser()

    def select(self, inputs: TVSelectionInputs, ticker: str = "") -> TVSelectionResult:
        """
        Run the full Phase 5 TV engine and return results.

        Args:
            inputs: TVSelectionInputs with all required and optional fields.
            ticker: For labelling sensitivity grids and logs.

        Returns:
            TVSelectionResult with tv_result, comparison, and sensitivity.
        """
        log.info(
            "tv_selector.start",
            ticker=ticker,
            method=inputs.method,
            g=inputs.terminal_growth_rate,
            wacc=inputs.wacc,
            exit_multiple=inputs.exit_multiple,
        )

        # ── Step 1: Compute GGM (always) ──────────────────────────────────
        ggm_result: GGMResult | None = None
        try:
            ggm_result = self._ggm.compute(
                fcff_terminal=inputs.fcff_terminal,
                wacc=inputs.wacc,
                terminal_growth_rate=inputs.terminal_growth_rate,
                forecast_years=inputs.forecast_years,
                risk_free_rate=inputs.risk_free_rate,
            )
        except ValueError as e:
            if inputs.method == "gordon_growth":
                raise
            log.warning("tv_selector.ggm_failed", error=str(e))

        # ── Step 2: Compute Exit Multiple (when inputs available) ──────────
        exit_result: ExitMultipleResult | None = None
        if inputs.exit_metric_value is not None and inputs.exit_multiple is not None:
            try:
                exit_result = self._exit.compute(
                    metric=inputs.exit_metric,
                    metric_value=inputs.exit_metric_value,
                    exit_multiple=inputs.exit_multiple,
                    wacc=inputs.wacc,
                    forecast_years=inputs.forecast_years,
                    fcff_terminal=inputs.fcff_terminal,
                    peer_range=inputs.peer_range,
                )
            except ValueError as e:
                if inputs.method == "exit_multiple":
                    raise
                log.warning("tv_selector.exit_failed", error=str(e))

        # ── Step 3: Blend according to user selection ──────────────────────
        blend_mode = self._method_to_blend_mode(inputs.method)
        blended = self._blender.blend(
            ggm_result=ggm_result,
            exit_result=exit_result,
            mode=blend_mode,
            weight_ggm=inputs.weight_ggm,
            weight_exit=inputs.weight_exit,
        )

        # ── Step 4: Build TerminalValueResult (DCF engine compatible) ─────
        tv_result = self._to_terminal_value_result(inputs, blended, ggm_result, exit_result)

        # ── Step 5: Comparison (when both methods available) ──────────────
        comparison: TVComparisonResult | None = None
        if ggm_result is not None and exit_result is not None:
            comparison = self._comparison.compare(
                ggm_result=ggm_result,
                exit_result=exit_result,
                ebitda_terminal=inputs.exit_metric_value if inputs.exit_metric == ExitMetric.EV_EBITDA else None,
                ebitda_margin_terminal=inputs.ebitda_margin_terminal,
                tax_rate=inputs.tax_rate,
            )

        # ── Step 6: Sensitivity grids ──────────────────────────────────────
        sensitivity: TVSensitivityReport | None = None
        if inputs.run_sensitivity:
            sensitivity = self._sensitivity.compute_all(
                ticker=ticker,
                fcff_terminal=inputs.fcff_terminal,
                ebitda_terminal=inputs.exit_metric_value,
                wacc=inputs.wacc,
                terminal_growth_rate=inputs.terminal_growth_rate,
                forecast_years=inputs.forecast_years,
                net_debt=inputs.net_debt,
                shares_outstanding=inputs.shares_outstanding,
                exit_metric=inputs.exit_metric,
                exit_multiple=inputs.exit_multiple,
                wacc_steps=inputs.wacc_steps,
                wacc_step_size=inputs.wacc_step_size,
                g_steps=inputs.g_steps,
                g_step_size=inputs.g_step_size,
                multiple_steps=inputs.multiple_steps,
                multiple_step_size=inputs.multiple_step_size,
            )

        # ── Step 7: Collect all warnings ──────────────────────────────────
        all_warnings: list[str] = list(blended.warnings)
        if comparison is not None:
            all_warnings.extend(comparison.all_warnings)
        # Deduplicate while preserving order
        seen: set[str] = set()
        deduped_warnings: list[str] = []
        for w in all_warnings:
            if w not in seen:
                seen.add(w)
                deduped_warnings.append(w)

        log.info(
            "tv_selector.complete",
            ticker=ticker,
            tv_final=round(blended.terminal_value),
            pv_tv=round(blended.pv_terminal_value),
            warnings=len(deduped_warnings),
        )

        return TVSelectionResult(
            tv_result=tv_result,
            ggm_result=ggm_result,
            exit_result=exit_result,
            blended_result=blended,
            comparison=comparison,
            sensitivity=sensitivity,
            method_selected=inputs.method,
            all_warnings=deduped_warnings,
        )

    # ── Internal helpers ───────────────────────────────────────────────────

    @staticmethod
    def _method_to_blend_mode(method: str) -> BlendMode:
        mapping = {
            "gordon_growth":   BlendMode.GGM_ONLY,
            "exit_multiple":   BlendMode.EXIT_ONLY,
            "average":         BlendMode.EQUAL,
            "custom_weights":  BlendMode.CUSTOM,
        }
        if method not in mapping:
            raise ValueError(
                f"Unknown TV method '{method}'. "
                f"Valid options: {list(mapping.keys())}"
            )
        return mapping[method]

    @staticmethod
    def _to_terminal_value_result(
        inputs: TVSelectionInputs,
        blended: BlendedTVResult,
        ggm: GGMResult | None,
        exit_: ExitMultipleResult | None,
    ) -> TerminalValueResult:
        """
        Convert BlendedTVResult → TerminalValueResult (Phase 4 DCF engine format).

        This is the glue between Phase 5 and Phase 4.
        """
        return TerminalValueResult(
            method_used=inputs.method,
            terminal_growth_rate=inputs.terminal_growth_rate,
            wacc=inputs.wacc,
            fcff_terminal=inputs.fcff_terminal,
            ebitda_terminal=inputs.exit_metric_value if exit_ else None,
            tv_gordon_growth=ggm.terminal_value if ggm else None,
            tv_exit_multiple=exit_.terminal_value if exit_ else None,
            tv_final=blended.terminal_value,
            pv_terminal_value=blended.pv_terminal_value,
            pv_terminal_value_pct=0.0,  # filled by DCF pipeline after EV is known
        )
