"""
valuation/terminal/exit_multiple.py
-------------------------------------
Exit Multiple Method — standalone terminal value class.

─────────────────────────────────────────────────────────────────────────────
Exit Multiple Method
─────────────────────────────────────────────────────────────────────────────

Assumes that at the end of the explicit forecast horizon, the company
can be sold (or valued) at a multiple of a financial metric:

  Terminal Value = Financial Metric_N × Exit Multiple

Four metric bases are supported:

  1. EV/EBITDA  (most common — industry standard for most sectors)
       TV = EBITDA_N × EV_EBITDA_multiple

  2. EV/EBIT    (preferred for capital-light businesses; removes D&A distortion)
       TV = EBIT_N × EV_EBIT_multiple

  3. EV/Revenue (used for early-stage / negative EBITDA companies)
       TV = Revenue_N × EV_Revenue_multiple

  4. P/FCF      (used for capital-light software / financial companies)
       TV = FCF_N × Price_FCF_multiple   (applied to equity value, not EV)

─────────────────────────────────────────────────────────────────────────────
Multiple Derivation from Peers
─────────────────────────────────────────────────────────────────────────────

The exit multiple should be consistent with the current trading multiples
of comparable companies (the "comps set"). Typical derivation:

  Exit Multiple = Median(peer EV/EBITDA LTM) × (1 ± discount/premium)

Damodaran Rule: The exit multiple should be internally consistent with the
Gordon Growth Model. An EV/EBITDA multiple can be approximately validated:

  Implied EV/EBITDA ≈ (1 − t) × (1 + g) / [(WACC − g) × EBITDA_margin]

  where:
    t              = effective tax rate
    g              = implied long-term growth rate
    WACC           = discount rate
    EBITDA_margin  = EBITDA / Revenue in terminal year

─────────────────────────────────────────────────────────────────────────────
Present Value of Terminal Value
─────────────────────────────────────────────────────────────────────────────

  PV(TV) = TV / (1 + WACC)^N

  Where N = number of explicit forecast years.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from logger import get_logger

log = get_logger(__name__)


class ExitMetric(str, Enum):
    """Financial metric basis for the exit multiple."""
    EV_EBITDA  = "ev_ebitda"    # Enterprise Value / EBITDA
    EV_EBIT    = "ev_ebit"      # Enterprise Value / EBIT
    EV_REVENUE = "ev_revenue"   # Enterprise Value / Revenue
    PRICE_FCF  = "price_fcf"    # Price / Free Cash Flow (equity-level)


@dataclass(frozen=True)
class ExitMultipleResult:
    """
    Complete result of an Exit Multiple terminal value computation.

    Formulas:
      TV = Metric_N × Exit_Multiple
      PV(TV) = TV / (1 + WACC)^N
    """
    # ── Inputs (echoed for audit) ──────────────────────────────────────────
    metric: ExitMetric
    metric_value: float         # the financial metric in the terminal year
    exit_multiple: float        # the multiple applied
    wacc: float
    forecast_years: int

    # ── Terminal value ─────────────────────────────────────────────────────
    terminal_value: float
    """TV = Metric_N × Exit_Multiple"""

    pv_terminal_value: float
    """PV(TV) = TV / (1 + WACC)^N"""

    # ── Diagnostics ────────────────────────────────────────────────────────
    implied_growth_rate: float | None = None
    """
    Implied perpetuity growth rate from this TV, via reverse GGM.
    Allows cross-checking consistency with the Gordon Growth Model.
    """

    peer_multiple_range: tuple[float, float] | None = None
    """(low, high) range from peer comps — for context only, not used in calculation."""

    warnings: list[str] = field(default_factory=list)

    def formula_display(self) -> str:
        """Multi-line formula for PDF report embedding."""
        metric_label = self.metric.value.upper().replace("_", "/")
        return (
            f"Exit Multiple Method ({metric_label})\n"
            "────────────────────────────────────────\n"
            f"  TV = {metric_label}_N × Exit Multiple\n\n"
            f"     = {self.metric_value:>20,.0f}  ← {metric_label} in year {self.forecast_years}\n"
            f"     × {self.exit_multiple:.2f}×\n"
            f"────────────────────────────────────────\n"
            f"  Terminal Value = {self.terminal_value:>20,.0f}\n\n"
            f"  PV(TV) = TV / (1 + WACC)^N\n"
            f"         = {self.terminal_value:>20,.0f}\n"
            f"         ÷ (1 + {self.wacc:.3%})^{self.forecast_years}\n"
            f"         = {self.pv_terminal_value:>20,.0f}\n"
            + (f"\n  Implied g ≈ {self.implied_growth_rate:.2%}" if self.implied_growth_rate is not None else "")
        )


class ExitMultipleModel:
    """
    Exit Multiple terminal value calculator.

    Supports four metric bases: EV/EBITDA, EV/EBIT, EV/Revenue, Price/FCF.

    Usage:
        model = ExitMultipleModel()
        result = model.compute(
            metric=ExitMetric.EV_EBITDA,
            metric_value=251_000_000_000,   # terminal EBITDA
            exit_multiple=18.0,
            wacc=0.09,
            forecast_years=10,
        )
        print(result.formula_display())
    """

    def compute(
        self,
        metric: ExitMetric,
        metric_value: float,
        exit_multiple: float,
        wacc: float,
        forecast_years: int,
        fcff_terminal: float | None = None,
        peer_range: tuple[float, float] | None = None,
    ) -> ExitMultipleResult:
        """
        Compute Exit Multiple terminal value.

        Args:
            metric:          Which financial metric to apply the multiple to.
            metric_value:    Value of the metric in the terminal year.
            exit_multiple:   The multiple (e.g. 18.0 for 18× EV/EBITDA).
            wacc:            WACC for discounting to present.
            forecast_years:  N — used to discount TV.
            fcff_terminal:   Optional. If provided, computes implied g via reverse GGM.
            peer_range:      Optional (low, high) peer comps range for context.

        Returns:
            ExitMultipleResult with TV, PV(TV), and diagnostics.

        Raises:
            ValueError: When metric_value ≤ 0 (nonsensical for EV/EBITDA or EV/EBIT).
                        When exit_multiple ≤ 0.
        """
        warnings: list[str] = []

        # ── Validation ─────────────────────────────────────────────────────
        if exit_multiple <= 0:
            raise ValueError(
                f"Exit multiple must be positive; got {exit_multiple}."
            )
        if metric_value <= 0:
            if metric in (ExitMetric.EV_EBITDA, ExitMetric.EV_EBIT):
                raise ValueError(
                    f"{metric.value} is {metric_value:,.0f}. "
                    f"Cannot apply a positive EV multiple to a non-positive metric — "
                    f"this implies a negative enterprise value."
                )
            warnings.append(
                f"{metric.value} metric is non-positive ({metric_value:,.0f}). "
                f"Terminal value may be meaningless for the exit multiple method."
            )

        # ── Core formula ───────────────────────────────────────────────────
        #   TV = Metric_N × Exit_Multiple
        terminal_value = metric_value * exit_multiple

        # ── Discount to present ────────────────────────────────────────────
        #   PV(TV) = TV / (1 + WACC)^N
        pv_tv = terminal_value / (1.0 + wacc) ** forecast_years

        # ── Implied growth rate ────────────────────────────────────────────
        implied_g: float | None = None
        if fcff_terminal is not None and abs(terminal_value + fcff_terminal) > 1.0:
            # Reverse GGM: g = (TV × WACC − FCFF_N) / (TV + FCFF_N)
            implied_g = (terminal_value * wacc - fcff_terminal) / (terminal_value + fcff_terminal)

        # ── Peer range validation ──────────────────────────────────────────
        if peer_range is not None:
            lo, hi = peer_range
            if exit_multiple < lo:
                warnings.append(
                    f"Exit multiple ({exit_multiple:.1f}×) is below the peer range "
                    f"({lo:.1f}×–{hi:.1f}×). This produces a conservative terminal value."
                )
            elif exit_multiple > hi:
                warnings.append(
                    f"Exit multiple ({exit_multiple:.1f}×) is above the peer range "
                    f"({lo:.1f}×–{hi:.1f}×). This produces an optimistic terminal value."
                )

        # ── High-multiple warning ──────────────────────────────────────────
        if metric in (ExitMetric.EV_EBITDA, ExitMetric.EV_EBIT) and exit_multiple > 30:
            warnings.append(
                f"Exit multiple of {exit_multiple:.1f}× is very high for "
                f"{metric.value}. Verify this is consistent with sector peers."
            )

        log.debug(
            "exit_multiple.computed",
            metric=metric.value,
            metric_value=metric_value,
            multiple=exit_multiple,
            tv=terminal_value,
            pv_tv=pv_tv,
            implied_g=implied_g,
        )

        return ExitMultipleResult(
            metric=metric,
            metric_value=metric_value,
            exit_multiple=exit_multiple,
            wacc=wacc,
            forecast_years=forecast_years,
            terminal_value=terminal_value,
            pv_terminal_value=pv_tv,
            implied_growth_rate=implied_g,
            peer_multiple_range=peer_range,
            warnings=warnings,
        )

    def damodaran_consistency_check(
        self,
        exit_ebitda_multiple: float,
        wacc: float,
        terminal_growth_rate: float,
        ebitda_margin_terminal: float,
        tax_rate: float,
    ) -> dict:
        """
        Damodaran Internal Consistency Check.

        Validates that the exit EV/EBITDA multiple is internally consistent
        with the implied Gordon Growth Model assumptions.

        Formula (approximate, assuming reinvestment from D&A ≈ CapEx):
          Implied EV/EBITDA ≈ (1 − t) × (1 + g) / [(WACC − g) × EBITDA_margin]

        Args:
            exit_ebitda_multiple:   The multiple you want to validate.
            wacc:                   WACC.
            terminal_growth_rate:   The GGM growth rate to compare against.
            ebitda_margin_terminal: EBITDA / Revenue in the terminal year.
            tax_rate:               Effective tax rate.

        Returns:
            dict with implied_multiple, your_multiple, is_consistent, gap_pct.
        """
        g    = terminal_growth_rate
        spread = wacc - g
        if spread <= 0.003 or ebitda_margin_terminal <= 0:
            return {
                "implied_multiple": None,
                "your_multiple": exit_ebitda_multiple,
                "is_consistent": False,
                "gap_pct": None,
                "note": "Cannot compute — WACC−g spread or EBITDA margin is too small.",
            }

        implied = (1.0 - tax_rate) * (1.0 + g) / (spread * ebitda_margin_terminal)
        gap_pct = (exit_ebitda_multiple - implied) / implied
        is_consistent = abs(gap_pct) < 0.20   # within 20% of implied = "consistent"

        return {
            "implied_multiple": round(implied, 2),
            "your_multiple":    exit_ebitda_multiple,
            "is_consistent":    is_consistent,
            "gap_pct":          round(gap_pct, 4),
            "note": (
                "Consistent" if is_consistent
                else f"Gap of {gap_pct:+.1%} — consider adjusting the multiple or growth rate."
            ),
        }

    def sensitivity_sweep(
        self,
        metric: ExitMetric,
        metric_value: float,
        wacc: float,
        forecast_years: int,
        multiple_values: list[float],
        fcff_terminal: float | None = None,
    ) -> list[ExitMultipleResult]:
        """
        Compute Exit Multiple TV for a list of multiples.

        Used by TVSensitivityAnalyser for the multiple sensitivity dimension.

        Returns results in the same order as multiple_values.
        Skips invalid multiples (≤ 0 or metric_value ≤ 0) silently.
        """
        results: list[ExitMultipleResult] = []
        for m in multiple_values:
            try:
                results.append(
                    self.compute(metric, metric_value, m, wacc, forecast_years, fcff_terminal)
                )
            except ValueError:
                pass
        return results
