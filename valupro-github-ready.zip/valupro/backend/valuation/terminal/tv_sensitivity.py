"""
valuation/terminal/tv_sensitivity.py
--------------------------------------
Terminal Value Sensitivity Analyser — three independent 2-D sensitivity grids.

─────────────────────────────────────────────────────────────────────────────
Grid 1: WACC × Terminal Growth Rate   (Gordon Growth)
─────────────────────────────────────────────────────────────────────────────
  Rows    = WACC values
  Columns = Terminal growth rate (g)
  Cells   = PV(TV_GGM)  and  Implied Fair Value per Share

─────────────────────────────────────────────────────────────────────────────
Grid 2: Exit Multiple × Terminal Growth Rate   (cross-check)
─────────────────────────────────────────────────────────────────────────────
  Rows    = Exit Multiple values
  Columns = WACC values
  Cells   = PV(TV_Exit)  and  Implied Fair Value per Share

─────────────────────────────────────────────────────────────────────────────
Grid 3: WACC × Exit Multiple   (Exit Multiple sensitivity)
─────────────────────────────────────────────────────────────────────────────
  Rows    = WACC values
  Columns = Exit Multiple values
  Cells   = PV(TV_Exit)  and  Implied Fair Value per Share

All grids are annotated with the base-case cell for UI highlighting.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from valuation.terminal.gordon_growth import GordonGrowthModel
from valuation.terminal.exit_multiple import ExitMetric, ExitMultipleModel
from logger import get_logger

log = get_logger(__name__)


# ── Shared cell types ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class TVSensCell:
    """One cell of any TV sensitivity grid."""
    row_value: float    # the value on the row axis (WACC or multiple)
    col_value: float    # the value on the column axis (g or multiple or WACC)
    pv_terminal_value: float
    fair_value_per_share: float | None = None   # None when equity bridge not available
    is_base_case: bool = False


@dataclass(frozen=True)
class TVSensGrid:
    """
    A single 2-D TV sensitivity grid.

    Includes axis labels, the grid matrix, and the base case cell location.
    """
    grid_type: str          # "wacc_vs_g", "multiple_vs_wacc", "wacc_vs_multiple"
    ticker: str

    row_label: str          # e.g. "WACC", "Exit Multiple"
    col_label: str          # e.g. "Terminal Growth Rate", "WACC"

    row_values: list[float]
    col_values: list[float]

    grid: list[list[TVSensCell]]  # grid[row_idx][col_idx]

    base_row_value: float
    base_col_value: float
    base_pv_tv: float

    def to_matrix(self, field: str = "pv_terminal_value") -> list[list[float]]:
        """Return a 2-D list for JSON serialisation."""
        if field == "fair_value_per_share":
            return [[c.fair_value_per_share or 0.0 for c in row] for row in self.grid]
        return [[c.pv_terminal_value for c in row] for row in self.grid]

    def implied_range(self) -> tuple[float, float]:
        vals = [c.pv_terminal_value for row in self.grid for c in row if c.pv_terminal_value > 0]
        return (min(vals), max(vals)) if vals else (0.0, 0.0)

    def base_case_cell(self) -> TVSensCell | None:
        for row in self.grid:
            for cell in row:
                if cell.is_base_case:
                    return cell
        return None


@dataclass(frozen=True)
class TVSensitivityReport:
    """
    Complete TV sensitivity output — all three grids in one object.

    Attached to ValuationOutput for PDF report generation and UI heatmaps.
    """
    ticker: str
    wacc_vs_g: TVSensGrid
    multiple_vs_wacc: TVSensGrid | None    # None when exit multiple not configured
    wacc_vs_multiple: TVSensGrid | None    # None when exit multiple not configured

    def to_dict(self) -> dict:
        """Serialisable representation for the API response."""
        result: dict = {
            "ticker": self.ticker,
            "wacc_vs_g": {
                "grid_type": self.wacc_vs_g.grid_type,
                "row_label": self.wacc_vs_g.row_label,
                "col_label": self.wacc_vs_g.col_label,
                "row_values": self.wacc_vs_g.row_values,
                "col_values": self.wacc_vs_g.col_values,
                "matrix": self.wacc_vs_g.to_matrix(),
                "base_row": self.wacc_vs_g.base_row_value,
                "base_col": self.wacc_vs_g.base_col_value,
                "range": list(self.wacc_vs_g.implied_range()),
            },
        }
        if self.multiple_vs_wacc is not None:
            result["multiple_vs_wacc"] = {
                "grid_type": self.multiple_vs_wacc.grid_type,
                "row_label": self.multiple_vs_wacc.row_label,
                "col_label": self.multiple_vs_wacc.col_label,
                "row_values": self.multiple_vs_wacc.row_values,
                "col_values": self.multiple_vs_wacc.col_values,
                "matrix": self.multiple_vs_wacc.to_matrix(),
                "base_row": self.multiple_vs_wacc.base_row_value,
                "base_col": self.multiple_vs_wacc.base_col_value,
                "range": list(self.multiple_vs_wacc.implied_range()),
            }
        if self.wacc_vs_multiple is not None:
            result["wacc_vs_multiple"] = {
                "grid_type": self.wacc_vs_multiple.grid_type,
                "row_label": self.wacc_vs_multiple.row_label,
                "col_label": self.wacc_vs_multiple.col_label,
                "row_values": self.wacc_vs_multiple.row_values,
                "col_values": self.wacc_vs_multiple.col_values,
                "matrix": self.wacc_vs_multiple.to_matrix(),
                "base_row": self.wacc_vs_multiple.base_row_value,
                "base_col": self.wacc_vs_multiple.base_col_value,
                "range": list(self.wacc_vs_multiple.implied_range()),
            }
        return result


# ── Main analyser ──────────────────────────────────────────────────────────────

class TVSensitivityAnalyser:
    """
    Builds all three TV sensitivity grids for a company.

    Stateless — safe to reuse across requests.
    """

    def __init__(self) -> None:
        self._ggm  = GordonGrowthModel()
        self._exit = ExitMultipleModel()

    def compute_all(
        self,
        ticker: str,
        fcff_terminal: float,
        ebitda_terminal: float | None,
        wacc: float,
        terminal_growth_rate: float,
        forecast_years: int,
        # Equity bridge (needed for FVPS cells)
        net_debt: float = 0.0,
        shares_outstanding: float | None = None,
        # Exit multiple (optional — grids 2 & 3 only built when provided)
        exit_metric: ExitMetric = ExitMetric.EV_EBITDA,
        exit_multiple: float | None = None,
        # Grid dimensions
        wacc_steps: int = 4,
        wacc_step_size: float = 0.005,
        g_steps: int = 2,
        g_step_size: float = 0.005,
        multiple_steps: int = 3,
        multiple_step_size: float = 1.0,
    ) -> TVSensitivityReport:
        """
        Build all TV sensitivity grids.

        Args:
            ticker:              Company ticker for labelling.
            fcff_terminal:       FCFF in terminal year.
            ebitda_terminal:     EBITDA in terminal year (for exit multiple grids).
            wacc:                Base case WACC.
            terminal_growth_rate: Base case g.
            forecast_years:      N (explicit forecast years).
            net_debt:            For FVPS computation in grid cells.
            shares_outstanding:  For FVPS computation. None → FVPS omitted.
            exit_metric:         Metric for Exit Multiple (default EV/EBITDA).
            exit_multiple:       Base case exit multiple. None → grids 2 & 3 skipped.
            wacc_steps:          ± steps around base WACC.
            wacc_step_size:      Step size for WACC axis.
            g_steps:             ± steps around base g.
            g_step_size:         Step size for g axis.
            multiple_steps:      ± steps around base multiple.
            multiple_step_size:  Step size for multiple axis.

        Returns:
            TVSensitivityReport with all three grids.
        """
        # ── Build axis values ──────────────────────────────────────────────
        wacc_values = sorted(
            round(wacc + (i - wacc_steps) * wacc_step_size, 6)
            for i in range(2 * wacc_steps + 1)
        )
        g_values = sorted(
            round(terminal_growth_rate + (j - g_steps) * g_step_size, 6)
            for j in range(2 * g_steps + 1)
        )
        # Filter g values that would violate WACC-g constraint
        min_wacc = min(wacc_values)
        g_values_valid = [g for g in g_values if g < min_wacc - 0.003]
        if not g_values_valid:
            g_values_valid = [terminal_growth_rate]

        # ── Grid 1: WACC × g ──────────────────────────────────────────────
        wacc_vs_g = self._build_wacc_vs_g_grid(
            ticker=ticker,
            fcff_terminal=fcff_terminal,
            forecast_years=forecast_years,
            wacc_values=wacc_values,
            g_values=g_values_valid,
            base_wacc=wacc,
            base_g=terminal_growth_rate,
            net_debt=net_debt,
            shares_outstanding=shares_outstanding,
        )

        # ── Grids 2 & 3: Only when exit multiple is provided ──────────────
        multiple_vs_wacc: TVSensGrid | None = None
        wacc_vs_multiple: TVSensGrid | None = None

        if exit_multiple is not None:
            metric_value = ebitda_terminal or 0.0
            if metric_value > 0:
                multiple_values = sorted(
                    round(exit_multiple + (k - multiple_steps) * multiple_step_size, 3)
                    for k in range(2 * multiple_steps + 1)
                    if exit_multiple + (k - multiple_steps) * multiple_step_size > 0
                )

                multiple_vs_wacc = self._build_multiple_vs_wacc_grid(
                    ticker=ticker,
                    metric=exit_metric,
                    metric_value=metric_value,
                    forecast_years=forecast_years,
                    multiple_values=multiple_values,
                    wacc_values=wacc_values,
                    base_multiple=exit_multiple,
                    base_wacc=wacc,
                    net_debt=net_debt,
                    shares_outstanding=shares_outstanding,
                    fcff_terminal=fcff_terminal,
                )

                wacc_vs_multiple = self._build_wacc_vs_multiple_grid(
                    ticker=ticker,
                    metric=exit_metric,
                    metric_value=metric_value,
                    forecast_years=forecast_years,
                    wacc_values=wacc_values,
                    multiple_values=multiple_values,
                    base_wacc=wacc,
                    base_multiple=exit_multiple,
                    net_debt=net_debt,
                    shares_outstanding=shares_outstanding,
                    fcff_terminal=fcff_terminal,
                )

        log.info(
            "tv_sensitivity.complete",
            ticker=ticker,
            grids_built=1 + (1 if multiple_vs_wacc else 0) + (1 if wacc_vs_multiple else 0),
        )

        return TVSensitivityReport(
            ticker=ticker,
            wacc_vs_g=wacc_vs_g,
            multiple_vs_wacc=multiple_vs_wacc,
            wacc_vs_multiple=wacc_vs_multiple,
        )

    # ── Grid builders ──────────────────────────────────────────────────────

    def _build_wacc_vs_g_grid(
        self,
        ticker: str,
        fcff_terminal: float,
        forecast_years: int,
        wacc_values: list[float],
        g_values: list[float],
        base_wacc: float,
        base_g: float,
        net_debt: float,
        shares_outstanding: float | None,
    ) -> TVSensGrid:
        grid: list[list[TVSensCell]] = []
        for w in wacc_values:
            row: list[TVSensCell] = []
            for g in g_values:
                pv_tv, fvps = self._ggm_cell(
                    fcff_terminal, w, g, forecast_years, net_debt, shares_outstanding
                )
                is_base = abs(w - base_wacc) < 0.0001 and abs(g - base_g) < 0.0001
                row.append(TVSensCell(
                    row_value=w, col_value=g,
                    pv_terminal_value=pv_tv,
                    fair_value_per_share=fvps,
                    is_base_case=is_base,
                ))
            grid.append(row)

        base_pv = next(
            (c.pv_terminal_value for r in grid for c in r if c.is_base_case), 0.0
        )
        return TVSensGrid(
            grid_type="wacc_vs_g", ticker=ticker,
            row_label="WACC", col_label="Terminal Growth Rate",
            row_values=wacc_values, col_values=g_values,
            grid=grid,
            base_row_value=base_wacc, base_col_value=base_g, base_pv_tv=base_pv,
        )

    def _build_multiple_vs_wacc_grid(
        self,
        ticker: str,
        metric: ExitMetric,
        metric_value: float,
        forecast_years: int,
        multiple_values: list[float],
        wacc_values: list[float],
        base_multiple: float,
        base_wacc: float,
        net_debt: float,
        shares_outstanding: float | None,
        fcff_terminal: float | None,
    ) -> TVSensGrid:
        grid: list[list[TVSensCell]] = []
        for m in multiple_values:
            row: list[TVSensCell] = []
            for w in wacc_values:
                pv_tv, fvps = self._exit_cell(
                    metric, metric_value, m, w, forecast_years, net_debt, shares_outstanding,
                    fcff_terminal
                )
                is_base = abs(m - base_multiple) < 0.001 and abs(w - base_wacc) < 0.0001
                row.append(TVSensCell(
                    row_value=m, col_value=w,
                    pv_terminal_value=pv_tv,
                    fair_value_per_share=fvps,
                    is_base_case=is_base,
                ))
            grid.append(row)

        base_pv = next(
            (c.pv_terminal_value for r in grid for c in r if c.is_base_case), 0.0
        )
        return TVSensGrid(
            grid_type="multiple_vs_wacc", ticker=ticker,
            row_label="Exit Multiple", col_label="WACC",
            row_values=multiple_values, col_values=wacc_values,
            grid=grid,
            base_row_value=base_multiple, base_col_value=base_wacc, base_pv_tv=base_pv,
        )

    def _build_wacc_vs_multiple_grid(
        self,
        ticker: str,
        metric: ExitMetric,
        metric_value: float,
        forecast_years: int,
        wacc_values: list[float],
        multiple_values: list[float],
        base_wacc: float,
        base_multiple: float,
        net_debt: float,
        shares_outstanding: float | None,
        fcff_terminal: float | None,
    ) -> TVSensGrid:
        grid: list[list[TVSensCell]] = []
        for w in wacc_values:
            row: list[TVSensCell] = []
            for m in multiple_values:
                pv_tv, fvps = self._exit_cell(
                    metric, metric_value, m, w, forecast_years, net_debt, shares_outstanding,
                    fcff_terminal
                )
                is_base = abs(w - base_wacc) < 0.0001 and abs(m - base_multiple) < 0.001
                row.append(TVSensCell(
                    row_value=w, col_value=m,
                    pv_terminal_value=pv_tv,
                    fair_value_per_share=fvps,
                    is_base_case=is_base,
                ))
            grid.append(row)

        base_pv = next(
            (c.pv_terminal_value for r in grid for c in r if c.is_base_case), 0.0
        )
        return TVSensGrid(
            grid_type="wacc_vs_multiple", ticker=ticker,
            row_label="WACC", col_label="Exit Multiple",
            row_values=wacc_values, col_values=multiple_values,
            grid=grid,
            base_row_value=base_wacc, base_col_value=base_multiple, base_pv_tv=base_pv,
        )

    # ── Cell helpers ───────────────────────────────────────────────────────

    def _ggm_cell(
        self,
        fcff_terminal: float,
        wacc: float,
        g: float,
        forecast_years: int,
        net_debt: float,
        shares: float | None,
    ) -> tuple[float, float | None]:
        """Return (pv_tv, fvps) for one GGM grid cell."""
        try:
            result = self._ggm.compute(fcff_terminal, wacc, g, forecast_years)
            pv_tv = result.pv_terminal_value
            fvps = self._to_fvps(pv_tv, net_debt, shares)
            return pv_tv, fvps
        except ValueError:
            return 0.0, None

    def _exit_cell(
        self,
        metric: ExitMetric,
        metric_value: float,
        exit_multiple: float,
        wacc: float,
        forecast_years: int,
        net_debt: float,
        shares: float | None,
        fcff_terminal: float | None,
    ) -> tuple[float, float | None]:
        """Return (pv_tv, fvps) for one Exit Multiple grid cell."""
        try:
            result = self._exit.compute(
                metric=metric,
                metric_value=metric_value,
                exit_multiple=exit_multiple,
                wacc=wacc,
                forecast_years=forecast_years,
                fcff_terminal=fcff_terminal,
            )
            pv_tv = result.pv_terminal_value
            fvps = self._to_fvps(pv_tv, net_debt, shares)
            return pv_tv, fvps
        except ValueError:
            return 0.0, None

    @staticmethod
    def _to_fvps(pv_tv: float, net_debt: float, shares: float | None) -> float | None:
        """
        Approximate FVPS from PV(TV) alone.

        Note: This is a simplified approximation that ignores PV(explicit FCFFs).
        It is used for the TV-only sensitivity grids where the explicit FCFFs
        are held constant. The full DCF pipeline should be used for the primary
        FVPS output (see Phase 4 sensitivity.py).
        """
        if shares is None or shares <= 0:
            return None
        equity_value = max(0.0, pv_tv - net_debt)
        return equity_value / shares
