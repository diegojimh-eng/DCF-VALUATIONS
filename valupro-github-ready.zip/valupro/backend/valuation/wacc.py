"""
valuation/wacc.py
------------------
Weighted Average Cost of Capital (WACC) calculator.

All formulas are displayed explicitly for audit and PDF report generation.

─────────────────────────────────────────────────────────────────────────────
CAPM — Cost of Equity
─────────────────────────────────────────────────────────────────────────────

  Ke = Rf + β × ERP

  Where:
    Rf   = Risk-free rate (10-year government bond yield)
    β    = Levered equity beta (2-year weekly regression vs S&P 500)
    ERP  = Equity Risk Premium (Damodaran US market default: 5.5%)

  β defaults to 1.0 (market beta) when missing from market data.
  ke_override bypasses CAPM entirely when provided.

─────────────────────────────────────────────────────────────────────────────
Cost of Debt
─────────────────────────────────────────────────────────────────────────────

  Kd (pre-tax)  = Interest Expense (LTM) / Average Gross Debt
  Kd (after-tax) = Kd × (1 − t)

  Fallback priority:
    1. kd_override (analyst-provided)
    2. Interest expense / gross debt (from financial statements)
    3. Default: risk_free_rate + 200 bps credit spread

─────────────────────────────────────────────────────────────────────────────
WACC
─────────────────────────────────────────────────────────────────────────────

  E    = Market capitalisation
  D    = Short-term debt + Long-term debt (book value proxy for market value)
  V    = E + D

  WACC = (E/V) × Ke  +  (D/V) × Kd × (1 − t)

  If wacc_override is provided, it is returned directly.
"""

from __future__ import annotations

from valuation.models import WACCInputs, WACCResult
from logger import get_logger

log = get_logger(__name__)

# Conservative fallback bounds
_MIN_WACC = 0.04    # 4%  — floors unrealistically low WACCs
_MAX_WACC = 0.40    # 40% — caps clearly erroneous inputs
_DEFAULT_BETA = 1.0
_DEFAULT_CREDIT_SPREAD = 0.02   # 200 bps over risk-free


class WACCCalculator:
    """
    Computes WACC from WACCInputs.

    Stateless — safe to call from multiple threads concurrently.
    Every intermediate step is preserved in WACCResult for audit.
    """

    def compute(self, inputs: WACCInputs) -> WACCResult:
        """
        Compute WACC and return a fully documented result.

        Args:
            inputs: WACCInputs with all parameters (manual overrides take priority).

        Returns:
            WACCResult with WACC and every intermediate component.
        """
        # ── WACC override: bypass all computation ──────────────────────────
        if inputs.wacc_override is not None:
            log.info("wacc.override_used", wacc=inputs.wacc_override)
            wacc = max(_MIN_WACC, min(inputs.wacc_override, _MAX_WACC))
            # Return a stub result indicating override was used
            return self._override_result(inputs, wacc)

        # ── Step 1: Resolve beta ────────────────────────────────────────────
        beta_used, used_beta_default = self._resolve_beta(inputs.beta)

        # ── Step 2: Cost of equity (CAPM) ──────────────────────────────────
        ke, used_ke_override = self._compute_ke(
            beta_used, inputs.risk_free_rate, inputs.equity_risk_premium,
            inputs.ke_override,
        )
        log.debug(
            "wacc.ke",
            beta=beta_used, rf=inputs.risk_free_rate,
            erp=inputs.equity_risk_premium, ke=ke,
        )

        # ── Step 3: Cost of debt ────────────────────────────────────────────
        kd_pretax, used_kd_override = self._compute_kd_pretax(
            inputs.interest_expense, inputs.gross_debt,
            inputs.risk_free_rate, inputs.kd_override,
        )
        kd_aftertax = kd_pretax * (1.0 - inputs.tax_rate)
        log.debug("wacc.kd", kd_pretax=kd_pretax, kd_aftertax=kd_aftertax)

        # ── Step 4: Capital structure weights ───────────────────────────────
        total_capital = inputs.market_cap + inputs.gross_debt
        if total_capital <= 0:
            raise ValueError(
                f"Total capital (E + D) must be positive; got {total_capital:,.0f}"
            )
        equity_weight = inputs.market_cap / total_capital
        debt_weight   = inputs.gross_debt  / total_capital

        # ── Step 5: WACC ────────────────────────────────────────────────────
        wacc = (equity_weight * ke) + (debt_weight * kd_aftertax)
        wacc = max(_MIN_WACC, min(wacc, _MAX_WACC))

        log.info(
            "wacc.computed",
            ticker="?",
            wacc=round(wacc, 4),
            ke=round(ke, 4),
            kd_aftertax=round(kd_aftertax, 4),
            equity_weight=round(equity_weight, 3),
            debt_weight=round(debt_weight, 3),
        )

        return WACCResult(
            beta_used=beta_used,
            risk_free_rate=inputs.risk_free_rate,
            equity_risk_premium=inputs.equity_risk_premium,
            tax_rate=inputs.tax_rate,
            ke=ke,
            kd_pretax=kd_pretax,
            kd_aftertax=kd_aftertax,
            market_cap=inputs.market_cap,
            gross_debt=inputs.gross_debt,
            cash_and_equivalents=inputs.cash_and_equivalents,
            net_debt=inputs.net_debt,
            total_capital=total_capital,
            equity_weight=equity_weight,
            debt_weight=debt_weight,
            wacc=wacc,
            used_beta_default=used_beta_default,
            used_kd_override=used_kd_override,
            used_ke_override=used_ke_override,
            used_wacc_override=False,
        )

    # ── Internal helpers ───────────────────────────────────────────────────

    @staticmethod
    def _resolve_beta(beta: float | None) -> tuple[float, bool]:
        """Return (beta, used_default). Defaults to 1.0 when None."""
        if beta is None or beta <= 0:
            return (_DEFAULT_BETA, True)
        # Sanity clip: beta outside [-2, 5] is almost certainly a data error
        beta_clipped = max(-2.0, min(beta, 5.0))
        used_default = beta_clipped != beta
        return (beta_clipped, used_default)

    @staticmethod
    def _compute_ke(
        beta: float,
        rf: float,
        erp: float,
        ke_override: float | None,
    ) -> tuple[float, bool]:
        """
        Return (Ke, used_override).

        CAPM:  Ke = Rf + β × ERP
        """
        if ke_override is not None:
            return (ke_override, True)
        ke = rf + beta * erp
        # Floor at risk-free rate: Ke < Rf is theoretically invalid
        ke = max(rf, min(ke, 0.50))
        return (ke, False)

    @staticmethod
    def _compute_kd_pretax(
        interest_expense: float | None,
        gross_debt: float,
        risk_free_rate: float,
        kd_override: float | None,
    ) -> tuple[float, bool]:
        """
        Return (Kd_pretax, used_override).

        Priority:
          1. kd_override
          2. interest_expense / gross_debt
          3. risk_free_rate + 200 bps (default credit spread)
        """
        if kd_override is not None:
            return (kd_override, True)

        if interest_expense is not None and gross_debt > 0:
            kd = interest_expense / gross_debt
            # Sanity bounds: Kd between Rf/2 and 30%
            kd = max(risk_free_rate * 0.50, min(kd, 0.30))
            return (kd, False)

        # Default: risk-free + 200 bps spread
        kd_default = risk_free_rate + _DEFAULT_CREDIT_SPREAD
        return (kd_default, False)

    @staticmethod
    def _override_result(inputs: WACCInputs, wacc: float) -> WACCResult:
        """Stub WACCResult when wacc_override is used."""
        beta = inputs.beta if inputs.beta is not None else _DEFAULT_BETA
        ke   = inputs.ke_override or (inputs.risk_free_rate + beta * inputs.equity_risk_premium)
        kd   = inputs.kd_override or (inputs.risk_free_rate + _DEFAULT_CREDIT_SPREAD)
        total_capital = inputs.market_cap + inputs.gross_debt or 1.0
        return WACCResult(
            beta_used=beta,
            risk_free_rate=inputs.risk_free_rate,
            equity_risk_premium=inputs.equity_risk_premium,
            tax_rate=inputs.tax_rate,
            ke=ke,
            kd_pretax=kd,
            kd_aftertax=kd * (1.0 - inputs.tax_rate),
            market_cap=inputs.market_cap,
            gross_debt=inputs.gross_debt,
            cash_and_equivalents=inputs.cash_and_equivalents,
            net_debt=inputs.net_debt,
            total_capital=total_capital,
            equity_weight=inputs.market_cap / total_capital,
            debt_weight=inputs.gross_debt / total_capital,
            wacc=wacc,
            used_wacc_override=True,
        )
