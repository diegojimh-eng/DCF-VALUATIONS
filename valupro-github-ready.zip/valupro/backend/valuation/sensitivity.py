"""
valuation/sensitivity.py
-------------------------
Sensitivity Analysis — WACC × Terminal Growth Rate grid.

Standard sell-side format:
  Rows    = WACC values (base WACC ± N steps of `step_size` bps)
  Columns = Terminal growth rate (base g ± M steps)
  Cells   = Implied Fair Value per Share at each (WACC, g) combination

The base case cell (base_wacc × base_g) is flagged for visual highlighting
in the UI heatmap and PDF table.

─────────────────────────────────────────────────────────────────────────────
How it works
─────────────────────────────────────────────────────────────────────────────

For each (wacc_i, g_j) combination:
  1. Re-run the DCF engine with wacc_i and g_j substituted.
  2. All other assumptions (FCFF series, net debt, shares) held constant.
  3. Record the implied Fair Value per Share.

This is fully parameterised — grid dimensions and step sizes are configurable.
Default grid: 9 WACC × 5 growth = 45 valuations (runs in < 1ms).
"""

from __future__ import annotations

import numpy as np

from valuation.dcf import DCFEngine
from valuation.models import (
    DCFInputs,
    SensitivityCell,
    SensitivityGrid,
    TerminalValueInputs,
    ValuationOutput,
    WACCResult,
)
from valuation.terminal_value import TerminalValueCalculator
from logger import get_logger

log = get_logger(__name__)


class SensitivityAnalyser:
    """
    Computes a WACC × terminal growth rate sensitivity grid.

    The grid re-uses the same FCFF series and capital structure for every
    cell — only WACC and terminal growth rate vary.
    """

    def __init__(self) -> None:
        self._dcf    = DCFEngine()
        self._tv_calc = TerminalValueCalculator()

    def compute_grid(
        self,
        base_output: ValuationOutput,
        dcf_inputs: DCFInputs,
        wacc_result: WACCResult,
        wacc_steps: int = 4,          # ± steps from base WACC
        growth_steps: int = 2,        # ± steps from base g
        wacc_step_size: float = 0.005,   # 50 bps per step
        growth_step_size: float = 0.005, # 50 bps per step
    ) -> SensitivityGrid:
        """
        Build the WACC × g sensitivity grid.

        Args:
            base_output:    The base-case ValuationOutput (provides WACC, g, ticker).
            dcf_inputs:     The same DCFInputs used for the base case.
            wacc_result:    Base WACCResult (used for capital structure).
            wacc_steps:     Number of steps above AND below base WACC.
                            Default 4 → 9 rows (base ± 4 × 50 bps).
            growth_steps:   Number of steps above AND below base g.
                            Default 2 → 5 columns (base ± 2 × 50 bps).
            wacc_step_size: Step size for WACC axis.
            growth_step_size: Step size for growth rate axis.

        Returns:
            SensitivityGrid with grid[wacc_idx][growth_idx].
        """
        base_wacc = base_output.wacc
        base_g    = base_output.terminal_growth_rate
        n_fcff    = len(dcf_inputs.fcff_series)

        # Build axis value lists (sorted ascending)
        wacc_values  = sorted(
            round(base_wacc + (i - wacc_steps) * wacc_step_size, 6)
            for i in range(2 * wacc_steps + 1)
        )
        growth_values = sorted(
            round(base_g + (j - growth_steps) * growth_step_size, 6)
            for j in range(2 * growth_steps + 1)
        )

        # Remove any growth rates ≥ WACC (would make Gordon Growth undefined)
        growth_values = [g for g in growth_values if g < min(wacc_values) - 0.005]
        if not growth_values:
            growth_values = [base_g]  # fallback

        log.debug(
            "sensitivity.grid.params",
            wacc_values=wacc_values,
            growth_values=growth_values,
            cells=len(wacc_values) * len(growth_values),
        )

        grid: list[list[SensitivityCell]] = []

        for w in wacc_values:
            row: list[SensitivityCell] = []
            for g in growth_values:
                fvps, ev = self._compute_cell(dcf_inputs, wacc_result, w, g, n_fcff)
                is_base = (
                    abs(w - base_wacc) < 0.0001
                    and abs(g - base_g) < 0.0001
                )
                row.append(SensitivityCell(
                    wacc=w,
                    terminal_growth_rate=g,
                    fair_value_per_share=fvps,
                    enterprise_value=ev,
                    is_base_case=is_base,
                ))
            grid.append(row)

        log.info(
            "sensitivity.grid.complete",
            ticker=base_output.ticker,
            rows=len(grid),
            cols=len(grid[0]) if grid else 0,
        )

        return SensitivityGrid(
            ticker=base_output.ticker,
            wacc_values=wacc_values,
            growth_values=growth_values,
            grid=grid,
            base_wacc=base_wacc,
            base_growth_rate=base_g,
            base_fair_value=base_output.fair_value_per_share,
        )

    # ── Cell computation ───────────────────────────────────────────────────

    def _compute_cell(
        self,
        dcf_inputs: DCFInputs,
        base_wacc_result: WACCResult,
        wacc: float,
        g: float,
        n: int,
    ) -> tuple[float, float]:
        """
        Compute one grid cell: (fair_value_per_share, enterprise_value).

        Re-runs the DCF with the given wacc and g, holding everything else constant.
        """
        # Substitute the sensitivity WACC into a fresh WACCResult
        cell_wacc_result = base_wacc_result.model_copy(update={"wacc": wacc})

        # Substitute the sensitivity growth rate into TerminalValueInputs
        cell_tv_inputs = dcf_inputs.terminal_value_inputs.model_copy(
            update={"terminal_growth_rate": g}
        )
        cell_dcf_inputs = dcf_inputs.model_copy(
            update={"terminal_value_inputs": cell_tv_inputs, "wacc": wacc}
        )

        try:
            result = self._dcf.compute(cell_dcf_inputs, cell_wacc_result)
            return (result.fair_value_per_share, result.enterprise_value)
        except ValueError:
            # WACC − g ≤ 0 for this cell — return sentinel
            return (0.0, 0.0)
