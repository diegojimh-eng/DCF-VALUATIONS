"""
valuation/football_field.py
----------------------------
Football Field valuation summary chart builder.

A football field chart is the standard investment banking visualisation
that displays implied value ranges from multiple methods side-by-side
as horizontal bars. The current market price appears as a vertical line.

Ranges included (in display order):
  1. DCF — Bear case (low end of Bear)
  2. DCF — Base case
  3. DCF — Bull case (high end of Bull)
  4. Sensitivity Grid (min–max range across all 45 cells)

Blended Fair Value:
  Probability-weighted average of Bear/Base/Bull fair values.
  Default weights: 25% Bear + 50% Base + 25% Bull.

  Blended FV = 0.25 × Bear_FV + 0.50 × Base_FV + 0.25 × Bull_FV
"""

from __future__ import annotations

from dataclasses import dataclass

from valuation.models import (
    FootballField,
    SensitivityGrid,
    ValuationOutput,
    ValuationRange,
)
from logger import get_logger

log = get_logger(__name__)


@dataclass(frozen=True)
class FootballFieldWeights:
    """Probability weights for blending scenario fair values."""
    bear: float = 0.25
    base: float = 0.50
    bull: float = 0.25

    def __post_init__(self) -> None:
        total = self.bear + self.base + self.bull
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"Scenario weights must sum to 1.0, got {total:.4f}")


class FootballFieldBuilder:
    """
    Builds a FootballField from scenario valuations and optional sensitivity grid.
    """

    def build(
        self,
        bear: ValuationOutput,
        base: ValuationOutput,
        bull: ValuationOutput,
        current_price: float | None = None,
        sensitivity_grid: SensitivityGrid | None = None,
        weights: FootballFieldWeights | None = None,
    ) -> FootballField:
        """
        Build the football field from three scenario valuations.

        Args:
            bear:             Bear case ValuationOutput.
            base:             Base case ValuationOutput.
            bull:             Bull case ValuationOutput.
            current_price:    Current market price (for the vertical line).
            sensitivity_grid: Optional sensitivity grid for additional range.
            weights:          Probability weights for blended fair value.

        Returns:
            FootballField with all ranges and blended fair value.
        """
        w = weights or FootballFieldWeights()
        ranges: list[ValuationRange] = []

        bear_fvps = bear.fair_value_per_share
        base_fvps = base.fair_value_per_share
        bull_fvps = bull.fair_value_per_share

        # ── Individual scenario bars ───────────────────────────────────────
        ranges.append(self._make_range(
            method="DCF — Bear",
            low=bear_fvps,
            high=base_fvps,
            current_price=current_price,
        ))
        ranges.append(self._make_range(
            method="DCF — Base",
            low=min(bear_fvps, base_fvps),
            high=max(base_fvps, bull_fvps),
            current_price=current_price,
        ))
        ranges.append(self._make_range(
            method="DCF — Bull",
            low=base_fvps,
            high=bull_fvps,
            current_price=current_price,
        ))

        # ── Full Bear-to-Bull range ────────────────────────────────────────
        ranges.append(self._make_range(
            method="DCF — Full Range",
            low=bear_fvps,
            high=bull_fvps,
            current_price=current_price,
        ))

        # ── Sensitivity grid range ─────────────────────────────────────────
        if sensitivity_grid is not None:
            lo, hi = sensitivity_grid.implied_range()
            ranges.append(self._make_range(
                method="Sensitivity (WACC × g)",
                low=lo,
                high=hi,
                current_price=current_price,
            ))

        # ── Blended fair value ─────────────────────────────────────────────
        blended = (
            w.bear * bear_fvps
            + w.base * base_fvps
            + w.bull * bull_fvps
        )

        log.info(
            "football_field.built",
            ticker=base.ticker,
            bear=round(bear_fvps, 2),
            base=round(base_fvps, 2),
            bull=round(bull_fvps, 2),
            blended=round(blended, 2),
            current_price=current_price,
        )

        return FootballField(
            ticker=base.ticker,
            current_price=current_price,
            ranges=ranges,
            blended_fair_value=blended,
            weights={"bear": w.bear, "base": w.base, "bull": w.bull},
        )

    @staticmethod
    def _make_range(
        method: str,
        low: float,
        high: float,
        current_price: float | None,
    ) -> ValuationRange:
        """Ensure low ≤ high and compute midpoint."""
        lo, hi = min(low, high), max(low, high)
        return ValuationRange(
            method=method,
            low=lo,
            high=hi,
            midpoint=(lo + hi) / 2.0,
            current_price=current_price,
        )
