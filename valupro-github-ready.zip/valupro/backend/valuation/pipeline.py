"""
valuation/pipeline.py
----------------------
ValuationPipeline — the single entry point that orchestrates the full
Phase 4 valuation for a company.

Execution order:
  1. Extract capital structure from FinancialsBundle (debt, cash, shares)
  2. Build WACCInputs from market data + extracted BS data
  3. Compute WACC via WACCCalculator
  4. Build DCFInputs for each scenario (Bear/Base/Bull)
  5. Run DCFEngine for each scenario
  6. Compute SensitivityGrid on the base case
  7. Build FootballField from all three scenarios + sensitivity

Usage:
    pipeline = ValuationPipeline()
    result   = pipeline.run(bundle, forecast_results, wacc_inputs, tv_inputs)

    # Or async:
    result   = await pipeline.run_async(bundle, forecast_results, wacc_inputs, tv_inputs)
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass

from data.models.responses import FinancialsBundle
from engine.pipeline.scenario_engine import ScenarioResults
from valuation.dcf import DCFEngine
from valuation.football_field import FootballFieldBuilder, ScenarioWeights
from valuation.models import (
    DCFInputs,
    FootballField,
    SensitivityGrid,
    TerminalValueInputs,
    ValuationOutput,
    WACCInputs,
    WACCResult,
)
from valuation.sensitivity import SensitivityAnalyser
from valuation.wacc import WACCCalculator
from logger import get_logger

log = get_logger(__name__)


@dataclass(frozen=True)
class ValuationResult:
    """Complete output from one ValuationPipeline.run() call."""
    ticker: str

    # Per-scenario DCF outputs
    bear: ValuationOutput
    base: ValuationOutput
    bull: ValuationOutput

    # WACC (base case — same capital structure for all scenarios)
    wacc_result: WACCResult

    # Sensitivity grid (base WACC × terminal growth)
    sensitivity: SensitivityGrid

    # Football field summary
    football_field: FootballField

    @property
    def base_fair_value(self) -> float:
        return self.base.fair_value_per_share

    @property
    def blended_fair_value(self) -> float | None:
        return self.football_field.blended_fair_value

    def to_dict(self) -> dict:
        """Serialisable summary for the API response."""
        return {
            "ticker": self.ticker,
            "fair_value": {
                "bear": self.bear.fair_value_per_share,
                "base": self.base.fair_value_per_share,
                "bull": self.bull.fair_value_per_share,
                "blended": self.blended_fair_value,
            },
            "enterprise_value": {
                "bear": self.bear.enterprise_value,
                "base": self.base.enterprise_value,
                "bull": self.bull.enterprise_value,
            },
            "equity_value": {
                "bear": self.bear.equity_value,
                "base": self.base.equity_value,
                "bull": self.bull.equity_value,
            },
            "wacc": self.wacc_result.wacc,
            "ke": self.wacc_result.ke,
            "kd_aftertax": self.wacc_result.kd_aftertax,
            "terminal_growth_rate": self.base.terminal_growth_rate,
            "pv_tv_pct_base": self.base.pv_tv_pct_of_ev,
            "sensitivity_range": list(self.sensitivity.implied_range()),
            "football_field_ranges": [r.model_dump() for r in self.football_field.ranges],
            "price_vs_intrinsic": self.football_field.price_vs_intrinsic(),
            "wacc_formula": self.wacc_result.formula_display(),
            "dcf_formula_base": self.base.formula_display(),
            "tv_formula": self.base.terminal_value_result.formula_display(),
            "warnings": list({
                w for output in (self.bear, self.base, self.bull)
                for w in output.warnings
            }),
        }


class ValuationPipeline:
    """
    Orchestrates the complete DCF valuation pipeline.

    Designed for single-use per request or reuse across multiple requests.
    """

    def __init__(
        self,
        mid_year_convention: bool = False,
        scenario_weights: ScenarioWeights | None = None,
        run_sensitivity: bool = True,
    ) -> None:
        self._wacc_calc    = WACCCalculator()
        self._dcf          = DCFEngine(mid_year_convention=mid_year_convention)
        self._sensitivity  = SensitivityAnalyser()
        self._ff_builder   = FootballFieldBuilder()
        self._weights      = scenario_weights or FootballFieldWeights()
        self._run_sensitivity = run_sensitivity

    def run(
        self,
        bundle: FinancialsBundle,
        scenario_results: ScenarioResults,
        wacc_inputs: WACCInputs,
        tv_inputs: TerminalValueInputs | None = None,
        sensitivity_wacc_steps: int = 4,
        sensitivity_growth_steps: int = 2,
    ) -> ValuationResult:
        """
        Execute the full DCF valuation.

        Args:
            bundle:           FinancialsBundle from DataRouter (Phase 2).
            scenario_results: ScenarioResults from ScenarioEngine (Phase 3).
            wacc_inputs:      WACCInputs with capital structure and rate assumptions.
            tv_inputs:        TerminalValueInputs. Defaults to Gordon Growth at 2.5%.
            sensitivity_wacc_steps:   ± steps for WACC axis.
            sensitivity_growth_steps: ± steps for growth axis.

        Returns:
            ValuationResult with all three scenarios, sensitivity, and football field.
        """
        ticker = bundle.profile.ticker
        tv_inputs = tv_inputs or TerminalValueInputs()

        log.info(
            "valuation.pipeline.start",
            ticker=ticker,
            wacc_override=wacc_inputs.wacc_override,
            tv_method=tv_inputs.method,
            tv_g=tv_inputs.terminal_growth_rate,
        )

        # ── Step 1: Compute WACC ───────────────────────────────────────────
        wacc_result = self._wacc_calc.compute(wacc_inputs)

        # ── Step 2: Compute DCF for each scenario ─────────────────────────
        bear_dcf_inputs = self._build_dcf_inputs(
            scenario_results.bear, wacc_result, tv_inputs, bundle
        )
        base_dcf_inputs = self._build_dcf_inputs(
            scenario_results.base, wacc_result, tv_inputs, bundle
        )
        bull_dcf_inputs = self._build_dcf_inputs(
            scenario_results.bull, wacc_result, tv_inputs, bundle
        )

        bear_output = self._dcf.compute(bear_dcf_inputs, wacc_result, ticker, "bear")
        base_output = self._dcf.compute(base_dcf_inputs, wacc_result, ticker, "base")
        bull_output = self._dcf.compute(bull_dcf_inputs, wacc_result, ticker, "bull")

        # ── Step 3: Sensitivity grid (base case only) ──────────────────────
        if self._run_sensitivity:
            sensitivity = self._sensitivity.compute_grid(
                base_output=base_output,
                dcf_inputs=base_dcf_inputs,
                wacc_result=wacc_result,
                wacc_steps=sensitivity_wacc_steps,
                growth_steps=sensitivity_growth_steps,
            )
        else:
            sensitivity = self._empty_sensitivity(ticker, base_output)

        # ── Step 4: Football field ─────────────────────────────────────────
        current_price = bundle.market_data.current_price
        football_field = self._ff_builder.build(
            bear=bear_output,
            base=base_output,
            bull=bull_output,
            current_price=current_price,
            sensitivity_grid=sensitivity if self._run_sensitivity else None,
            weights=self._weights,
        )

        log.info(
            "valuation.pipeline.complete",
            ticker=ticker,
            base_fvps=round(base_output.fair_value_per_share, 2),
            blended_fvps=round(football_field.blended_fair_value or 0, 2),
            current_price=current_price,
            wacc=round(wacc_result.wacc, 4),
        )

        return ValuationResult(
            ticker=ticker,
            bear=bear_output,
            base=base_output,
            bull=bull_output,
            wacc_result=wacc_result,
            sensitivity=sensitivity,
            football_field=football_field,
        )

    async def run_async(
        self,
        bundle: FinancialsBundle,
        scenario_results: ScenarioResults,
        wacc_inputs: WACCInputs,
        tv_inputs: TerminalValueInputs | None = None,
    ) -> ValuationResult:
        """Async wrapper for FastAPI route handlers."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, self.run, bundle, scenario_results, wacc_inputs, tv_inputs
        )

    # ── Internal helpers ───────────────────────────────────────────────────

    def _build_dcf_inputs(
        self,
        forecast: object,    # ForecastOutput
        wacc_result: WACCResult,
        tv_inputs: TerminalValueInputs,
        bundle: FinancialsBundle,
    ) -> DCFInputs:
        """
        Construct DCFInputs from a ForecastOutput + FinancialsBundle.

        Capital structure (net_debt, shares) comes from the balance sheet.
        """
        from engine.models import ForecastOutput  # local import to avoid circular
        fo: ForecastOutput = forecast  # type: ignore[assignment]

        # Pull balance sheet bridge items from the most recent BS
        bs = bundle.balance_sheets[0] if bundle.balance_sheets else None
        net_debt = (bs.net_debt or 0.0) if bs else 0.0
        minority_interest = 0.0   # not separately modelled in Phase 2
        preferred_equity  = 0.0

        shares = bundle.market_data.shares_outstanding or 1.0

        return DCFInputs(
            fcff_series=fo.forecast_fcffs,
            ebitda_series=fo.forecast_ebitdas,
            fiscal_years=fo.forecast_fiscal_years,
            wacc=wacc_result.wacc,
            terminal_value_inputs=tv_inputs,
            net_debt=net_debt,
            minority_interest=minority_interest,
            preferred_equity=preferred_equity,
            shares_outstanding=shares,
        )

    @staticmethod
    def _empty_sensitivity(ticker: str, base: ValuationOutput) -> SensitivityGrid:
        """Return a single-cell grid when sensitivity is disabled."""
        from valuation.models import SensitivityCell
        cell = SensitivityCell(
            wacc=base.wacc,
            terminal_growth_rate=base.terminal_growth_rate,
            fair_value_per_share=base.fair_value_per_share,
            enterprise_value=base.enterprise_value,
            is_base_case=True,
        )
        return SensitivityGrid(
            ticker=ticker,
            wacc_values=[base.wacc],
            growth_values=[base.terminal_growth_rate],
            grid=[[cell]],
            base_wacc=base.wacc,
            base_growth_rate=base.terminal_growth_rate,
            base_fair_value=base.fair_value_per_share,
        )
