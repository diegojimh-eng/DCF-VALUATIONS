"""
valuation/ — Phase 4 DCF Valuation Engine.

Public API:
    from valuation import ValuationPipeline, WACCInputs, TerminalValueInputs
    from valuation.models import ValuationOutput, ValuationResult, FootballField

Typical usage:
    wacc_inputs = WACCInputs(
        beta=1.25,
        market_cap=2_750_000_000_000,
        long_term_debt=95_000_000_000,
        interest_expense=3_900_000_000,
        cash_and_equivalents=30_000_000_000,
        risk_free_rate=0.043,
        equity_risk_premium=0.055,
        tax_rate=0.25,
    )
    tv_inputs = TerminalValueInputs(terminal_growth_rate=0.025)

    pipeline = ValuationPipeline()
    result   = pipeline.run(bundle, scenario_results, wacc_inputs, tv_inputs)

    print(result.base.fair_value_per_share)
    print(result.football_field.blended_fair_value)
"""

from valuation.dcf import DCFEngine
from valuation.football_field import FootballFieldBuilder, ScenarioWeights
from valuation.models import (
    DCFInputs,
    DCFYearResult,
    FootballField,
    SensitivityCell,
    SensitivityGrid,
    TerminalValueInputs,
    TerminalValueResult,
    ValuationOutput,
    ValuationRange,
    WACCInputs,
    WACCResult,
)
from valuation.pipeline import ValuationPipeline, ValuationResult
from valuation.sensitivity import SensitivityAnalyser
from valuation.terminal_value import TerminalValueCalculator
from valuation.wacc import WACCCalculator

__all__ = [
    "DCFEngine",
    "DCFInputs",
    "DCFYearResult",
    "FootballField",
    "FootballFieldBuilder",
    "ScenarioWeights",
    "SensitivityAnalyser",
    "SensitivityCell",
    "SensitivityGrid",
    "TerminalValueCalculator",
    "TerminalValueInputs",
    "TerminalValueResult",
    "ValuationOutput",
    "ValuationPipeline",
    "ValuationRange",
    "ValuationResult",
    "WACCCalculator",
    "WACCInputs",
    "WACCResult",
]

# ── Phase 5: Terminal Value Engine ─────────────────────────────────────────
from valuation.terminal import (
    BlendedTVResult,
    BlendMode,
    ExitMetric,
    ExitMultipleModel,
    ExitMultipleResult,
    GGMResult,
    GordonGrowthModel,
    TVBlender,
    TVComparison,
    TVComparisonResult,
    TVSelector,
    TVSelectionInputs,
    TVSelectionResult,
    TVSensCell,
    TVSensGrid,
    TVSensitivityAnalyser,
    TVSensitivityReport,
)
