"""
valuation/models.py
--------------------
All Pydantic input/output models for the Phase 4 DCF valuation engine.

Design principles:
  • Every monetary field uses the same currency unit as the historical data
    (full dollars / euros — NOT millions). The front-end formats for display.
  • All rates are decimals (0.09 = 9%).
  • None means "not provided" — never use 0.0 as a proxy for None.
  • frozen=True on all output models ensures immutability post-creation.

Module map:
  WACCInputs  →  WACCResult          (wacc.py)
  DCFInputs   →  DCFYearResult       (dcf.py)
  DCFInputs + WACCResult →  ValuationOutput  (pipeline.py)
  ValuationOutput  →  SensitivityGrid   (sensitivity.py)
  [ValuationOutput × scenarios]  →  FootballField  (football_field.py)
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, model_validator


# ══════════════════════════════════════════════════════════════════════════════
# ① WACC Inputs & Result
# ══════════════════════════════════════════════════════════════════════════════

class WACCInputs(BaseModel):
    """
    All inputs required to compute WACC via CAPM.

    Formula chain:
      Ke  = Rf + β × ERP                        (CAPM cost of equity)
      Kd  = interest_expense / gross_debt        (pre-tax cost of debt)
      E   = market_cap                           (market value of equity)
      D   = short_term_debt + long_term_debt     (market value of debt, proxied by book)
      V   = E + D
      WACC = (E/V) × Ke + (D/V) × Kd × (1 − t)

    All rates are decimals. None triggers a sensible default in the engine.
    """
    # ── Market data inputs ─────────────────────────────────────────────────
    beta: float | None = Field(
        default=None,
        description="Levered equity beta (2-year weekly vs S&P 500). "
                    "None → default 1.0 (market beta).",
    )
    market_cap: float = Field(
        ..., gt=0,
        description="Market capitalisation (E) in reporting currency.",
    )

    # ── Debt inputs ────────────────────────────────────────────────────────
    short_term_debt: float = Field(default=0.0, ge=0.0)
    long_term_debt: float  = Field(default=0.0, ge=0.0)
    interest_expense: float | None = Field(
        default=None, ge=0.0,
        description="LTM interest expense. Used to derive pre-tax cost of debt. "
                    "None → kd_override or default 5%.",
    )
    cash_and_equivalents: float = Field(
        default=0.0, ge=0.0,
        description="Cash & equivalents used to compute net debt.",
    )

    # ── Macro / model parameters ───────────────────────────────────────────
    risk_free_rate: float = Field(
        default=0.043,
        ge=0.0, le=0.15,
        description="10-year government bond yield (decimal). Default: 4.3% (US 10Y, 2024).",
    )
    equity_risk_premium: float = Field(
        default=0.055,
        ge=0.02, le=0.15,
        description="Equity Risk Premium (ERP) — Damodaran US market default: 5.5%.",
    )
    tax_rate: float = Field(
        default=0.21,
        ge=0.0, le=0.60,
        description="Marginal / effective tax rate for debt tax shield.",
    )

    # ── Manual overrides (take precedence over derived values) ────────────
    ke_override: float | None = Field(
        default=None, ge=0.0, le=0.50,
        description="Override cost of equity (Ke). Bypasses CAPM.",
    )
    kd_override: float | None = Field(
        default=None, ge=0.0, le=0.30,
        description="Override pre-tax cost of debt (Kd). Bypasses interest/debt derivation.",
    )
    wacc_override: float | None = Field(
        default=None, ge=0.0, le=0.50,
        description="Override entire WACC. Bypasses all calculation. Use for sensitivity only.",
    )

    model_config = {"frozen": True}

    @property
    def gross_debt(self) -> float:
        return self.short_term_debt + self.long_term_debt

    @property
    def net_debt(self) -> float:
        return self.gross_debt - self.cash_and_equivalents


class WACCResult(BaseModel):
    """
    Fully auditable WACC computation result — every intermediate step preserved.

    Formula display (shown in UI):
      Ke   = Rf + β × ERP
           = {rf:.2%} + {beta:.2f} × {erp:.2%}
           = {ke:.2%}

      Kd   = Interest Expense / Gross Debt   (or override)
           = {ke:.2%}   (pre-tax)
           = {kd_after_tax:.2%}   (after-tax = Kd × (1−t))

      E    = {market_cap:,.0f}
      D    = {gross_debt:,.0f}
      V    = E + D = {total_capital:,.0f}

      WACC = (E/V) × Ke + (D/V) × Kd × (1 − t)
           = ({equity_weight:.1%}) × {ke:.2%}
           + ({debt_weight:.1%}) × {kd_pretax:.2%} × (1 − {tax_rate:.1%})
           = {wacc:.2%}
    """
    # Inputs echoed back for audit
    beta_used: float
    risk_free_rate: float
    equity_risk_premium: float
    tax_rate: float

    # CAPM components
    ke: float = Field(..., description="Cost of Equity = Rf + β × ERP")

    # Debt components
    kd_pretax: float  = Field(..., description="Pre-tax cost of debt")
    kd_aftertax: float = Field(..., description="After-tax cost of debt = Kd × (1 − t)")

    # Capital structure weights
    market_cap: float
    gross_debt: float
    cash_and_equivalents: float
    net_debt: float
    total_capital: float = Field(..., description="E + D (market value weights)")
    equity_weight: float = Field(..., description="E / V")
    debt_weight: float   = Field(..., description="D / V")

    # Final WACC
    wacc: float = Field(..., description="Weighted Average Cost of Capital")

    # Flags
    used_beta_default: bool = False
    used_kd_override: bool  = False
    used_ke_override: bool  = False
    used_wacc_override: bool = False

    model_config = {"frozen": True}

    def formula_display(self) -> str:
        """Human-readable formula breakdown for the PDF report."""
        return (
            f"Ke  = Rf + β × ERP\n"
            f"    = {self.risk_free_rate:.2%} + {self.beta_used:.2f} × {self.equity_risk_premium:.2%}\n"
            f"    = {self.ke:.2%}\n\n"
            f"Kd  = {self.kd_pretax:.2%} (pre-tax)  →  {self.kd_aftertax:.2%} (after-tax)\n\n"
            f"E   = {self.market_cap:>20,.0f}\n"
            f"D   = {self.gross_debt:>20,.0f}\n"
            f"V   = {self.total_capital:>20,.0f}\n\n"
            f"WACC = ({self.equity_weight:.1%}) × {self.ke:.2%}\n"
            f"     + ({self.debt_weight:.1%}) × {self.kd_pretax:.2%} × (1 − {self.tax_rate:.1%})\n"
            f"     = {self.wacc:.2%}"
        )


# ══════════════════════════════════════════════════════════════════════════════
# ② Terminal Value Inputs & Result
# ══════════════════════════════════════════════════════════════════════════════

class TerminalValueInputs(BaseModel):
    """
    Parameters for Terminal Value computation.

    Two methods supported (choose one or both for cross-check):
      1. Gordon Growth Model (GGM):
            TV = FCFF_N × (1 + g) / (WACC − g)
      2. Exit Multiple (EV/EBITDA):
            TV = EBITDA_N × exit_multiple

    FCFF_N and EBITDA_N are the final forecast year values (year 10).
    """
    method: Literal["gordon_growth", "exit_multiple", "average"] = Field(
        default="gordon_growth",
        description=(
            "'gordon_growth' — perpetuity growth model\n"
            "'exit_multiple' — EV/EBITDA exit multiple\n"
            "'average'       — simple average of both"
        ),
    )
    # Gordon Growth Model
    terminal_growth_rate: float = Field(
        default=0.025,
        ge=-0.02, le=0.06,
        description=(
            "Perpetuity growth rate (g). Must be < WACC.\n"
            "Typically = long-run GDP growth ≈ 2.0–2.5% for US companies."
        ),
    )
    # Exit Multiple
    exit_ebitda_multiple: float | None = Field(
        default=None, ge=1.0, le=50.0,
        description="EV/EBITDA multiple applied to terminal year EBITDA. None → not used.",
    )

    model_config = {"frozen": True}


class TerminalValueResult(BaseModel):
    """
    Terminal value computation result.

    Formula display:
      Gordon Growth:  TV = FCFF_N × (1 + g) / (WACC − g)
      Exit Multiple:  TV = EBITDA_N × exit_multiple
    """
    method_used: str
    terminal_growth_rate: float
    wacc: float

    # Terminal year inputs
    fcff_terminal: float   = Field(..., description="FCFF in the final forecast year (year N)")
    ebitda_terminal: float | None = None

    # Results per method
    tv_gordon_growth: float | None = Field(
        default=None,
        description="TV = FCFF_N × (1+g) / (WACC−g)",
    )
    tv_exit_multiple: float | None = Field(
        default=None,
        description="TV = EBITDA_N × exit_multiple",
    )
    tv_final: float = Field(
        ...,
        description="Terminal value used in the DCF (selected or averaged).",
    )

    # Present value of terminal value
    pv_terminal_value: float = Field(
        ...,
        description="PV of terminal value discounted at WACC over N years.",
    )
    pv_terminal_value_pct: float = Field(
        ...,
        description="PV(TV) as % of total EV — flags dependence on TV.",
    )

    model_config = {"frozen": True}

    def formula_display(self) -> str:
        lines = []
        if self.tv_gordon_growth is not None:
            g  = self.terminal_growth_rate
            lines.append(
                f"Gordon Growth:  TV = FCFF_N × (1+g) / (WACC−g)\n"
                f"              = {self.fcff_terminal:,.0f} × (1+{g:.2%}) / ({self.wacc:.2%}−{g:.2%})\n"
                f"              = {self.tv_gordon_growth:,.0f}"
            )
        if self.tv_exit_multiple is not None and self.ebitda_terminal is not None:
            lines.append(
                f"\nExit Multiple:  TV = EBITDA_N × multiple\n"
                f"              = {self.ebitda_terminal:,.0f} × [multiple]\n"
                f"              = {self.tv_exit_multiple:,.0f}"
            )
        return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# ③ DCF Inputs & Per-Year Results
# ══════════════════════════════════════════════════════════════════════════════

class DCFInputs(BaseModel):
    """
    All inputs required to run the DCF computation.

    These come from:
      - ForecastOutput (FCFF series, EBITDA series)
      - WACCResult (WACC)
      - TerminalValueInputs (g, method)
      - FinancialsBundle (net_debt, shares_outstanding)
    """
    # FCFF series (year 1 … N)
    fcff_series: list[float] = Field(..., min_length=1)
    ebitda_series: list[float] = Field(..., min_length=1)
    fiscal_years: list[int]    = Field(..., min_length=1)

    # WACC (from WACCResult or override)
    wacc: float = Field(..., ge=0.001, le=0.50)

    # Terminal value
    terminal_value_inputs: TerminalValueInputs = Field(
        default_factory=TerminalValueInputs
    )

    # Balance sheet bridge
    net_debt: float = Field(
        default=0.0,
        description="Net Debt = Gross Debt − Cash. Positive = net debtor.",
    )
    minority_interest: float = Field(
        default=0.0, ge=0.0,
        description="Minority interest (deducted from EV to get equity value).",
    )
    preferred_equity: float = Field(
        default=0.0, ge=0.0,
        description="Preferred equity (deducted from EV to get common equity value).",
    )

    # Share count
    shares_outstanding: float = Field(
        ..., gt=0,
        description="Diluted shares outstanding.",
    )

    model_config = {"frozen": True}

    @model_validator(mode="after")
    def validate_series_lengths(self) -> "DCFInputs":
        if len(self.fcff_series) != len(self.fiscal_years):
            raise ValueError("fcff_series and fiscal_years must be the same length")
        if len(self.ebitda_series) != len(self.fiscal_years):
            raise ValueError("ebitda_series and fiscal_years must be the same length")
        return self


class DCFYearResult(BaseModel):
    """One row of the DCF present value schedule."""
    year_index: int
    fiscal_year: int
    fcff: float
    discount_factor: float = Field(
        ...,
        description="1 / (1 + WACC)^t",
    )
    pv_fcff: float = Field(
        ...,
        description="Present value of FCFF in this year = FCFF × discount_factor",
    )

    model_config = {"frozen": True}


# ══════════════════════════════════════════════════════════════════════════════
# ④ Full Valuation Output
# ══════════════════════════════════════════════════════════════════════════════

class ValuationOutput(BaseModel):
    """
    Complete DCF valuation result — the primary output of ValuationPipeline.

    All monetary values in the same currency unit as the historical data.

    Formula chain (displayed in the PDF report):
      Enterprise Value = Σ PV(FCFF_t) + PV(Terminal Value)
      Equity Value     = Enterprise Value − Net Debt − Minority Interest − Preferred Equity
      Fair Value/Share = Equity Value / Shares Outstanding
    """
    ticker: str
    scenario: str
    valuation_date: datetime = Field(default_factory=datetime.utcnow)

    # ── Component results ──────────────────────────────────────────────────
    wacc_result: WACCResult
    terminal_value_result: TerminalValueResult
    dcf_schedule: list[DCFYearResult]

    # ── Discounted cash flows ──────────────────────────────────────────────
    sum_pv_fcff: float = Field(
        ...,
        description="Σ PV(FCFF_t) for years 1…N",
    )
    pv_terminal_value: float

    # ── Enterprise Value bridge ────────────────────────────────────────────
    enterprise_value: float = Field(
        ...,
        description="EV = Σ PV(FCFF) + PV(Terminal Value)",
    )

    # ── Equity bridge ─────────────────────────────────────────────────────
    net_debt: float
    minority_interest: float
    preferred_equity: float
    equity_value: float = Field(
        ...,
        description="Equity Value = EV − Net Debt − Minority Interest − Preferred Equity",
    )

    # ── Per-share ─────────────────────────────────────────────────────────
    shares_outstanding: float
    fair_value_per_share: float = Field(
        ...,
        description="Fair Value / Share = Equity Value / Shares Outstanding",
    )

    # ── Diagnostics ───────────────────────────────────────────────────────
    pv_fcff_pct_of_ev: float = Field(
        ...,
        description="Σ PV(FCFF) / EV — fraction of value from explicit forecast period",
    )
    pv_tv_pct_of_ev: float = Field(
        ...,
        description="PV(TV) / EV — fraction of value from terminal value",
    )
    wacc: float
    terminal_growth_rate: float
    forecast_years: int
    warnings: list[str] = Field(default_factory=list)

    model_config = {"frozen": True}

    def formula_display(self) -> str:
        """Full formula waterfall for the PDF report and UI."""
        return (
            f"DCF Valuation — {self.ticker}\n"
            f"{'─' * 50}\n"
            f"Σ PV(FCFF)          = {self.sum_pv_fcff:>20,.0f}\n"
            f"+ PV(Terminal Value) = {self.pv_terminal_value:>20,.0f}\n"
            f"{'─' * 50}\n"
            f"Enterprise Value    = {self.enterprise_value:>20,.0f}  "
            f"(PV FCFF: {self.pv_fcff_pct_of_ev:.1%}, PV TV: {self.pv_tv_pct_of_ev:.1%})\n"
            f"− Net Debt          = {self.net_debt:>20,.0f}\n"
            f"− Minority Interest = {self.minority_interest:>20,.0f}\n"
            f"− Preferred Equity  = {self.preferred_equity:>20,.0f}\n"
            f"{'─' * 50}\n"
            f"Equity Value        = {self.equity_value:>20,.0f}\n"
            f"÷ Shares Outstanding= {self.shares_outstanding:>20,.0f}\n"
            f"{'─' * 50}\n"
            f"Fair Value / Share  = {self.fair_value_per_share:>20,.2f}\n"
        )


# ══════════════════════════════════════════════════════════════════════════════
# ⑤ Sensitivity Grid
# ══════════════════════════════════════════════════════════════════════════════

class SensitivityCell(BaseModel):
    """One cell of the WACC × terminal growth sensitivity grid."""
    wacc: float
    terminal_growth_rate: float
    fair_value_per_share: float
    enterprise_value: float
    is_base_case: bool = False

    model_config = {"frozen": True}


class SensitivityGrid(BaseModel):
    """
    WACC × Terminal Growth Rate sensitivity grid.

    Standard sell-side format:
      Rows    = WACC values (e.g. 7% … 11% in 50 bps steps → 9 rows)
      Columns = Terminal growth rate (e.g. 1.5% … 3.5% in 50 bps steps → 5 cols)
      Cell    = Implied Fair Value per Share

    The base case cell (base_wacc × base_g) is flagged for highlight in the UI.
    """
    ticker: str
    wacc_values: list[float]              # axis values used (ascending)
    growth_values: list[float]            # axis values used (ascending)
    grid: list[list[SensitivityCell]]     # grid[wacc_idx][growth_idx]
    base_wacc: float
    base_growth_rate: float
    base_fair_value: float

    model_config = {"frozen": True}

    def to_matrix(self) -> list[list[float]]:
        """Return a plain 2D list of fair values for JSON serialisation."""
        return [[cell.fair_value_per_share for cell in row] for row in self.grid]

    def implied_range(self) -> tuple[float, float]:
        """Return (min, max) fair value across the entire grid."""
        all_vals = [cell.fair_value_per_share for row in self.grid for cell in row]
        return (min(all_vals), max(all_vals))


# ══════════════════════════════════════════════════════════════════════════════
# ⑥ Football Field Summary
# ══════════════════════════════════════════════════════════════════════════════

class ValuationRange(BaseModel):
    """A single bar in the football field chart."""
    method: str                     # e.g. "DCF — Bear", "DCF — Bull", "Sensitivity Low"
    low: float                      # low end of implied value range
    high: float                     # high end of implied value range
    midpoint: float                 # (low + high) / 2
    current_price: float | None = None

    model_config = {"frozen": True}


class FootballField(BaseModel):
    """
    Football Field valuation summary — a collection of per-method ranges
    rendered as horizontal bars for quick visual comparison.

    Included ranges (where available):
      • DCF Bear / Base / Bull
      • Sensitivity grid (min–max)
      • Current market price (vertical line)
    """
    ticker: str
    current_price: float | None = None
    ranges: list[ValuationRange]

    # Probability-weighted blended value
    blended_fair_value: float | None = Field(
        default=None,
        description="Weighted average: 25% Bear + 50% Base + 25% Bull",
    )
    weights: dict[str, float] = Field(
        default_factory=lambda: {"bear": 0.25, "base": 0.50, "bull": 0.25}
    )

    model_config = {"frozen": True}

    def price_vs_intrinsic(self) -> str | None:
        """Simple buy/hold/sell framing based on current price vs blended value."""
        if self.current_price is None or self.blended_fair_value is None:
            return None
        ratio = self.current_price / self.blended_fair_value
        if ratio < 0.85:
            return "UNDERVALUED"
        elif ratio > 1.15:
            return "OVERVALUED"
        else:
            return "FAIRLY VALUED"
