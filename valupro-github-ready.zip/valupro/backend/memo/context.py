"""
memo/context.py
----------------
MemoContext — assembles all quantitative inputs from Phases 2–9 into
a single, structured string that is injected into every Claude prompt.

Design principles:
  1. Every number in the memo must trace back to a computed value from the
     valuation engine — no hallucinated figures.
  2. The context string is pre-formatted for readability so Claude can scan
     it as a dense fact sheet, not a raw data dump.
  3. All values are formatted in human-readable units (e.g. "$2.98T" not
     "2982000000000") so Claude quotes them consistently.
  4. The context is deterministic — given the same inputs it always produces
     the same string, making it cacheable and auditable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


def _b(v: float | None) -> str:
    """Format dollar value in billions/trillions."""
    if v is None: return "N/A"
    if abs(v) >= 1e12: return f"${v/1e12:.2f}T"
    if abs(v) >= 1e9:  return f"${v/1e9:.2f}B"
    if abs(v) >= 1e6:  return f"${v/1e6:.1f}M"
    return f"${v:.2f}"

def _p(v: float | None) -> str:
    """Format as share price."""
    return f"${v:.2f}" if v is not None else "N/A"

def _pct(v: float | None, decimals: int = 1) -> str:
    """Format as percentage."""
    return f"{v*100:.{decimals}f}%" if v is not None else "N/A"

def _mult(v: float | None) -> str:
    """Format as multiple."""
    return f"{v:.1f}×" if v is not None else "N/A"


@dataclass
class MemoContext:
    """
    All quantitative inputs the memo generator needs.
    Populated by MemoContextBuilder.from_pipeline_outputs().
    """
    # Company identity
    ticker:       str
    company_name: str
    sector:       str | None = None
    industry:     str | None = None
    exchange:     str | None = None
    description:  str | None = None

    # Market data
    current_price:    float | None = None
    market_cap:       float | None = None
    enterprise_value: float | None = None
    fifty_two_wk_high: float | None = None
    fifty_two_wk_low:  float | None = None
    beta:              float | None = None

    # Valuation outputs
    base_fvps:     float | None = None
    bear_fvps:     float | None = None
    bull_fvps:     float | None = None
    blended_fvps:  float | None = None
    equity_value:  float | None = None
    upside_pct:    float | None = None
    price_vs_intrinsic: str | None = None

    # WACC
    wacc:    float | None = None
    ke:      float | None = None
    kd:      float | None = None
    beta_used: float | None = None
    risk_free_rate: float | None = None
    erp:     float | None = None

    # Terminal value
    terminal_growth_rate: float | None = None
    pv_tv_pct:            float | None = None
    tv_method:            str | None   = None

    # Scenario valuation
    bear_ev:  float | None = None
    base_ev:  float | None = None
    bull_ev:  float | None = None
    bear_wacc: float | None = None
    bull_wacc: float | None = None

    # Forecast (base case, year 1 and year 10)
    rev_y1:     float | None = None
    rev_y10:    float | None = None
    rev_growth_y1:  float | None = None
    rev_growth_y10: float | None = None
    ebitda_y1:  float | None = None
    ebitda_y10: float | None = None
    ebitda_margin_y1:  float | None = None
    ebitda_margin_y10: float | None = None
    fcff_y1:   float | None = None
    fcff_y10:  float | None = None

    # Historical financials (LTM)
    revenue_ltm:  float | None = None
    ebitda_ltm:   float | None = None
    net_income_ltm: float | None = None
    net_debt:       float | None = None
    shares_outstanding: float | None = None

    # Sensitivity range
    sensitivity_low:  float | None = None
    sensitivity_high: float | None = None

    # Comps (primary multiple — EV/EBITDA)
    ev_ebitda_peer_median:  float | None = None
    ev_ebitda_peer_mean:    float | None = None
    comps_implied_median:   float | None = None
    n_peers:                int   | None = None

    # Additional comps multiples
    ev_revenue_median: float | None = None
    pe_median:         float | None = None

    # Warnings from the engine
    engine_warnings: list[str] = field(default_factory=list)

    def build_context_string(self) -> str:
        """
        Produce the complete context string injected into every Claude prompt.

        Format: labelled sections separated by hairline rules.
        All numbers are formatted — Claude never sees raw float values.
        """
        upside = (
            f"{self.upside_pct*100:+.1f}%"
            if self.upside_pct is not None
            else "N/A"
        )
        lines = [
            "═" * 60,
            "VALUPRO QUANTITATIVE CONTEXT",
            "═" * 60,
            "",
            "── COMPANY ──────────────────────────────────────────────",
            f"  Ticker:         {self.ticker}",
            f"  Company:        {self.company_name}",
            f"  Sector:         {self.sector or 'N/A'}",
            f"  Industry:       {self.industry or 'N/A'}",
        ]
        if self.description:
            # Truncate to 300 chars
            desc = self.description[:300].replace("\n", " ").strip()
            lines.append(f"  Description:    {desc}…")

        lines += [
            "",
            "── MARKET DATA ──────────────────────────────────────────",
            f"  Current Price:  {_p(self.current_price)}",
            f"  Market Cap:     {_b(self.market_cap)}",
            f"  Enterprise Value:{_b(self.enterprise_value)}",
            f"  52-Week High:   {_p(self.fifty_two_wk_high)}",
            f"  52-Week Low:    {_p(self.fifty_two_wk_low)}",
            f"  Beta:           {self.beta:.2f}" if self.beta else "  Beta:           N/A",
            "",
            "── DCF VALUATION (BASE CASE) ────────────────────────────",
            f"  Fair Value / Share: {_p(self.base_fvps)}",
            f"  Upside to FV:       {upside}",
            f"  Rating Signal:      {self.price_vs_intrinsic or 'N/A'}",
            f"  Equity Value:       {_b(self.equity_value)}",
            f"  Enterprise Value:   {_b(self.base_ev or self.enterprise_value)}",
            "",
            "── SCENARIOS ────────────────────────────────────────────",
            f"  Bear Case FVPS:  {_p(self.bear_fvps)}",
            f"  Base Case FVPS:  {_p(self.base_fvps)}  ← primary",
            f"  Bull Case FVPS:  {_p(self.bull_fvps)}",
            f"  Blended FVPS:    {_p(self.blended_fvps)}  (25/50/25)",
            f"  Bear EV:         {_b(self.bear_ev)}",
            f"  Base EV:         {_b(self.base_ev)}",
            f"  Bull EV:         {_b(self.bull_ev)}",
            "",
            "── WACC & COST OF CAPITAL ───────────────────────────────",
            f"  WACC:                {_pct(self.wacc, 2)}",
            f"  Ke (CAPM):           {_pct(self.ke, 2)}",
            f"  Kd (after-tax):      {_pct(self.kd, 2)}",
            f"  Risk-Free Rate:      {_pct(self.risk_free_rate, 2)}",
            f"  Equity Risk Premium: {_pct(self.erp, 2)}",
            f"  Beta Used:           {f'{self.beta_used:.2f}' if self.beta_used else 'N/A'}",
            "",
            "── TERMINAL VALUE ───────────────────────────────────────",
            f"  Method:              {self.tv_method or 'Gordon Growth'}",
            f"  Terminal Growth g:   {_pct(self.terminal_growth_rate, 2)}",
            f"  PV(TV) % of EV:      {_pct(self.pv_tv_pct)}",
            "",
            "── SENSITIVITY ──────────────────────────────────────────",
            f"  WACC × g Range:  {_p(self.sensitivity_low)} — {_p(self.sensitivity_high)}",
            "",
            "── 10-YEAR FORECAST (BASE CASE) ─────────────────────────",
            f"  Revenue Y1:           {_b(self.rev_y1)}  ({_pct(self.rev_growth_y1)} growth)",
            f"  Revenue Y10:          {_b(self.rev_y10)} ({_pct(self.rev_growth_y10)} growth)",
            f"  EBITDA Y1:            {_b(self.ebitda_y1)} (margin: {_pct(self.ebitda_margin_y1)})",
            f"  EBITDA Y10:           {_b(self.ebitda_y10)} (margin: {_pct(self.ebitda_margin_y10)})",
            f"  FCFF Y1:              {_b(self.fcff_y1)}",
            f"  FCFF Y10:             {_b(self.fcff_y10)}",
            "",
            "── HISTORICAL (LTM) ─────────────────────────────────────",
            f"  Revenue LTM:          {_b(self.revenue_ltm)}",
            f"  EBITDA LTM:           {_b(self.ebitda_ltm)}",
            f"  Net Income LTM:       {_b(self.net_income_ltm)}",
            f"  Net Debt:             {_b(self.net_debt)}",
            f"  Shares Outstanding:   {f'{self.shares_outstanding/1e9:.2f}B' if self.shares_outstanding else 'N/A'}",
        ]

        if any(v is not None for v in [self.ev_ebitda_peer_median, self.comps_implied_median]):
            lines += [
                "",
                "── TRADING COMPARABLES ──────────────────────────────────",
                f"  EV/EBITDA Peer Median: {_mult(self.ev_ebitda_peer_median)}",
                f"  EV/EBITDA Peer Mean:   {_mult(self.ev_ebitda_peer_mean)}",
                f"  EV/Revenue Median:     {_mult(self.ev_revenue_median)}",
                f"  P/E Median:            {_mult(self.pe_median)}",
                f"  Comps Implied Price:   {_p(self.comps_implied_median)}",
                f"  Number of Peers:       {self.n_peers or 'N/A'}",
            ]

        if self.engine_warnings:
            lines += ["", "── ENGINE WARNINGS ──────────────────────────────────────"]
            for w in self.engine_warnings[:4]:
                lines.append(f"  ⚠  {w}")

        lines += ["", "═" * 60]
        return "\n".join(lines)


class MemoContextBuilder:
    """
    Constructs a MemoContext from the raw outputs of Phases 2–7.
    All fields are extracted defensively — missing data produces N/A, not errors.
    """

    @staticmethod
    def from_pipeline_outputs(
        ticker: str,
        company_name: str = "",
        *,
        # Phase 2 — company profile + market data
        company_profile: Any = None,
        market_data: Any = None,
        income_statement: Any = None,
        balance_sheet: Any = None,
        # Phase 4 — valuation result
        valuation_result: Any = None,
        # Phase 7 — scenario analysis + sensitivity matrix
        scenario_analysis: Any = None,
        sensitivity_matrix: Any = None,
        # Phase 6 — comps
        comps_result: Any = None,
        # Phase 3 — forecast (base year list)
        forecast_base_years: list | None = None,
    ) -> MemoContext:
        """
        Build a MemoContext from all available pipeline outputs.

        Args:
            All arguments are optional — pass whatever phases have run.

        Returns:
            MemoContext with all available fields populated.
        """
        ctx = MemoContext(ticker=ticker.upper(), company_name=company_name or ticker)

        # ── Company profile ───────────────────────────────────────────────
        if company_profile is not None:
            p = company_profile
            ctx.sector    = _safe_get(p, "sector")
            ctx.industry  = _safe_get(p, "industry")
            ctx.exchange  = _safe_get(p, "exchange")
            ctx.description = _safe_get(p, "description")
            if not company_name:
                ctx.company_name = _safe_get(p, "company_name") or ticker

        # ── Market data ───────────────────────────────────────────────────
        if market_data is not None:
            m = market_data
            ctx.current_price     = _safe_get(m, "current_price")
            ctx.market_cap        = _safe_get(m, "market_cap")
            ctx.enterprise_value  = _safe_get(m, "enterprise_value")
            ctx.fifty_two_wk_high = _safe_get(m, "fifty_two_week_high")
            ctx.fifty_two_wk_low  = _safe_get(m, "fifty_two_week_low")
            ctx.beta              = _safe_get(m, "beta")

        # ── Historical financials ─────────────────────────────────────────
        if income_statement is not None:
            i = income_statement
            ctx.revenue_ltm    = _safe_get(i, "revenue")
            ctx.ebitda_ltm     = _safe_get(i, "ebitda")
            ctx.net_income_ltm = _safe_get(i, "net_income")

        if balance_sheet is not None:
            b = balance_sheet
            ctx.net_debt           = _safe_get(b, "net_debt")
            ctx.shares_outstanding = _safe_get(b, "shares_outstanding")

        # ── Valuation result ──────────────────────────────────────────────
        if valuation_result is not None:
            base = _safe_get(valuation_result, "base")
            bear = _safe_get(valuation_result, "bear")
            bull = _safe_get(valuation_result, "bull")

            if base is not None:
                ctx.base_fvps     = _safe_get(base, "fair_value_per_share")
                ctx.base_ev       = _safe_get(base, "enterprise_value")
                ctx.equity_value  = _safe_get(base, "equity_value")
                ctx.wacc          = _safe_get(base, "wacc")
                ctx.terminal_growth_rate = _safe_get(base, "terminal_growth_rate")
                ctx.pv_tv_pct     = _safe_get(base, "pv_tv_pct_of_ev")

                wr = _safe_get(base, "wacc_result")
                if wr:
                    ctx.ke             = _safe_get(wr, "ke")
                    ctx.kd             = _safe_get(wr, "kd_aftertax")
                    ctx.beta_used      = _safe_get(wr, "beta_used")
                    ctx.risk_free_rate = _safe_get(wr, "risk_free_rate")
                    ctx.erp            = _safe_get(wr, "equity_risk_premium")

                tvr = _safe_get(base, "terminal_value_result")
                if tvr:
                    ctx.tv_method = _safe_get(tvr, "method_used")

                ctx.engine_warnings = list(_safe_get(base, "warnings") or [])

            if bear is not None:
                ctx.bear_fvps = _safe_get(bear, "fair_value_per_share")
                ctx.bear_ev   = _safe_get(bear, "enterprise_value")
                ctx.bear_wacc = _safe_get(bear, "wacc")

            if bull is not None:
                ctx.bull_fvps = _safe_get(bull, "fair_value_per_share")
                ctx.bull_ev   = _safe_get(bull, "enterprise_value")
                ctx.bull_wacc = _safe_get(bull, "wacc")

            # Football field for blended + rating
            ff = _safe_get(valuation_result, "football_field")
            if ff:
                ctx.blended_fvps       = _safe_get(ff, "blended_fair_value")
                ctx.price_vs_intrinsic = _safe_get(ff, "price_vs_intrinsic")
                if callable(ctx.price_vs_intrinsic):
                    ctx.price_vs_intrinsic = ctx.price_vs_intrinsic()

            # Upside
            if ctx.current_price and ctx.base_fvps and ctx.current_price > 0:
                ctx.upside_pct = (ctx.base_fvps - ctx.current_price) / ctx.current_price

        # ── Sensitivity ───────────────────────────────────────────────────
        if sensitivity_matrix is not None:
            try:
                lo, hi = sensitivity_matrix.fvps_range()
                ctx.sensitivity_low  = lo
                ctx.sensitivity_high = hi
            except Exception:
                pass

        # ── Scenario analysis ─────────────────────────────────────────────
        if scenario_analysis is not None:
            scen = scenario_analysis
            if _safe_get(scen, "bear"):
                ctx.bear_fvps = ctx.bear_fvps or _safe_get(scen.bear, "fair_value_per_share")
            if _safe_get(scen, "bull"):
                ctx.bull_fvps = ctx.bull_fvps or _safe_get(scen.bull, "fair_value_per_share")

            blended = _safe_get(scen, "blended")
            if blended:
                ctx.blended_fvps = (
                    blended.get("fair_value_per_share")
                    if isinstance(blended, dict)
                    else _safe_get(blended, "fair_value_per_share")
                )

        # ── Forecast ─────────────────────────────────────────────────────
        if forecast_base_years:
            try:
                y1  = forecast_base_years[0]
                y10 = forecast_base_years[-1]
                ctx.rev_y1          = _safe_get(y1,  "revenue")
                ctx.rev_y10         = _safe_get(y10, "revenue")
                ctx.rev_growth_y1   = _safe_get(y1,  "revenue_growth_rate")
                ctx.rev_growth_y10  = _safe_get(y10, "revenue_growth_rate")
                ctx.ebitda_y1       = _safe_get(y1,  "ebitda")
                ctx.ebitda_y10      = _safe_get(y10, "ebitda")
                ctx.ebitda_margin_y1  = _safe_get(y1,  "ebitda_margin")
                ctx.ebitda_margin_y10 = _safe_get(y10, "ebitda_margin")
                ctx.fcff_y1         = _safe_get(y1,  "fcff")
                ctx.fcff_y10        = _safe_get(y10, "fcff")
            except Exception:
                pass

        # ── Comps ─────────────────────────────────────────────────────────
        if comps_result is not None:
            try:
                for row in (comps_result.summary_table or []):
                    if isinstance(row, dict):
                        mult = row.get("multiple", "")
                        if "EBITDA" in mult:
                            ctx.ev_ebitda_peer_median  = row.get("median")
                            ctx.ev_ebitda_peer_mean    = row.get("mean")
                            ctx.comps_implied_median   = row.get("implied_price_median")
                        elif "Revenue" in mult and ctx.ev_revenue_median is None:
                            ctx.ev_revenue_median = row.get("median")
                        elif "P/E" in mult and ctx.pe_median is None:
                            ctx.pe_median = row.get("median")
                ctx.n_peers = comps_result.n_peers_raw
            except Exception:
                pass

        return ctx


def _safe_get(obj: Any, key: str) -> Any:
    """Safely get an attribute from an object or dict."""
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(key)
    return getattr(obj, key, None)
