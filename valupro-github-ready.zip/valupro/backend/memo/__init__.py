"""
memo/ — Phase 10 AI Investment Memo.

Public API:
    from memo import MemoGenerator, MemoContextBuilder, MemoIntegrator
    from memo.models import InvestmentMemo, MemoContext, Rating

Usage:
    ctx = MemoContextBuilder.from_pipeline_outputs(
        ticker="AAPL",
        company_name="Apple Inc.",
        valuation_result=val_result,
        scenario_analysis=analysis.scenarios,
        sensitivity_matrix=analysis.sensitivity,
        forecast_base_years=scenario_results.base.years,
        comps_result=comps_result,
        market_data=bundle.market_data,
        company_profile=bundle.profile,
    )

    generator = MemoGenerator()           # reads ANTHROPIC_API_KEY from env
    memo      = await generator.generate_memo(ctx)
    pdf_bytes = MemoIntegrator.standalone_pdf(memo)
"""

from memo.context   import MemoContext, MemoContextBuilder
from memo.generator import MemoGenerator, MemoGeneratorError
from memo.integrator import MemoIntegrator
from memo.models    import (
    ConvictionLevel,
    InvestmentMemo,
    Rating,
    TokenUsage,
)
from memo.prompts   import SECTION_PROMPTS

__all__ = [
    "ConvictionLevel",
    "InvestmentMemo",
    "MemoContext",
    "MemoContextBuilder",
    "MemoGenerator",
    "MemoGeneratorError",
    "MemoIntegrator",
    "Rating",
    "SECTION_PROMPTS",
    "TokenUsage",
]
