"""
memo/prompts.py
----------------
Prompt templates for all 8 sections of the AI investment memo.

Design principles:
  1. SYSTEM PROMPT sets the persona and hard constraints once.
  2. Each section has a USER PROMPT that references the context block
     and gives explicit structural requirements (word count, format).
  3. Quantitative grounding: every section prompt explicitly instructs
     the model to cite specific numbers from the context block.
  4. No hallucination guard: each prompt warns explicitly against
     inventing facts not present in the context.
  5. Institutional register: sell-side equity research style —
     precise, direct, jargon-appropriate, no hedging clichés.

Section prompts receive the context string as {context} and the
ticker/company as {ticker} / {company}.
"""

from __future__ import annotations

# ── System prompt — set once per conversation ─────────────────────────────────

SYSTEM_PROMPT = """\
You are a senior equity research analyst at a bulge-bracket investment bank
with 15+ years of experience writing institutional investment memos on
large-cap technology and consumer companies.

Your task is to write one section of a professional investment memo
for {company} ({ticker}). The memo will be used by portfolio managers
and institutional investors making multi-million dollar allocation decisions.

HARD CONSTRAINTS:
1. Ground every quantitative claim in the data provided in the CONTEXT BLOCK.
   Quote specific numbers (e.g. "$201.40 base case fair value", "WACC of 9.12%").
2. Never invent financial data, growth rates, or peer comparisons not in the context.
3. Write in institutional sell-side style: precise, direct, no marketing fluff.
4. Avoid clichés: "strong management team", "best-in-class", "robust pipeline".
5. Use active voice. Be specific. Name drivers, not categories.
6. Do not include section headers, preamble, or "In conclusion" closers.
   Output only the body text requested.
7. When the context says N/A for a value, do not speculate — omit it.

The context block below contains all valuation outputs from the quantitative engine.
Treat these as authoritative.
"""

# ── Section prompts ───────────────────────────────────────────────────────────

SECTION_PROMPTS: dict[str, dict[str, str]] = {

    "executive_summary": {
        "label": "Executive Summary",
        "description": "3-paragraph synthesis of the full investment case",
        "prompt": """\
Write a 3-paragraph Executive Summary for {company} ({ticker}).

{context}

Structure exactly as follows:
  Paragraph 1 (80-100 words): What the company does, its market position,
    and the current revenue / EBITDA / market cap profile.
  Paragraph 2 (100-120 words): The core valuation argument — why the stock
    is mispriced. Reference the base case fair value, current price,
    implied upside, WACC, and terminal growth rate specifically.
  Paragraph 3 (80-100 words): Investment recommendation with target price,
    time horizon, and the single most important risk to the thesis.

Write at the level of a Goldman Sachs initiation report. No headers.
""",
    },

    "investment_thesis": {
        "label": "Investment Thesis",
        "description": "3 numbered thesis points with quantitative support",
        "prompt": """\
Write the Investment Thesis section for {company} ({ticker}).

{context}

Format: 3 numbered thesis points, each 80-120 words.
Each point must:
  - Open with a bold declarative headline (max 10 words, use ALL CAPS for the headline)
  - Provide 2-3 sentences of quantitative support referencing specific numbers
  - End with the expected financial impact (e.g. "We model this driving X% revenue CAGR")

Example structure:
  1. HEADLINE THESIS POINT ONE
     Supporting analysis with specific numbers...
     Financial impact statement.

  2. HEADLINE THESIS POINT TWO
     ...

  3. HEADLINE THESIS POINT THREE
     ...

Anchor every point in numbers from the context. No boilerplate.
""",
    },

    "competitive_moat": {
        "label": "Competitive Advantages",
        "description": "Durable competitive moat analysis",
        "prompt": """\
Write the Competitive Advantages section for {company} ({ticker}).

{context}

Identify and analyse 3-4 durable competitive advantages (moats).
For each advantage:
  - Name the moat type (e.g. switching costs, network effects, cost advantage,
    intangible assets, efficient scale, pricing power)
  - Explain the specific mechanism with evidence
  - Quantify the advantage where possible (margin premium, market share, retention rate)

Total length: 250-320 words.
Reference the EBITDA margin profile and how it compares to implied peers from the comps.
Do not use the phrase "best-in-class" or "wide moat" without specific support.
""",
    },

    "growth_drivers": {
        "label": "Growth Drivers",
        "description": "3-5 specific, named growth catalysts with timeline",
        "prompt": """\
Write the Growth Drivers section for {company} ({ticker}).

{context}

Identify 3-5 specific growth drivers. For each:
  - Name the driver precisely (product, geography, category, pricing)
  - State the expected timeline (near-term: 0-12 months, medium-term: 1-3 years)
  - Quantify the revenue or margin impact where the data supports it
  - Reference Year 1 vs Year 10 revenue/FCFF growth from the forecast

Total length: 280-360 words.
Connect drivers to the revenue growth trajectory in the context
(Year 1: {rev_y1_growth}% → Year 10: {rev_y10_growth}%).
""",
    },

    "key_risks": {
        "label": "Key Risks",
        "description": "3-5 material risks with quantified downside",
        "prompt": """\
Write the Key Risks section for {company} ({ticker}).

{context}

Identify 3-5 material risks. For each risk:
  - Name the risk specifically (not categories like "competition" but
    "loss of X market share to Y competitor / platform")
  - Explain the mechanism
  - Quantify the potential impact in dollar terms or as a % of fair value where possible
  - Reference the bear case fair value ({bear_fvps}) as the downside anchor

IMPORTANT: Also note that the terminal value represents {pv_tv_pct}% of enterprise value —
this creates sensitivity to growth assumptions. Discuss WACC sensitivity given
the {sens_range} sensitivity range.

Total length: 280-360 words. Be specific and unsentimental. Name real risks.
""",
    },

    "catalysts": {
        "label": "Catalysts",
        "description": "Near-term events that could close the price/value gap",
        "prompt": """\
Write the Catalysts section for {company} ({ticker}).

{context}

List 4-6 specific catalysts that could cause the stock to re-rate toward
our fair value estimate of {base_fvps} within the next 6-18 months.

For each catalyst:
  - Be specific: name the product launch, earnings event, regulatory decision,
    capital allocation action, or macro shift
  - State the expected timing (Q1 2025, H2 2025, etc.)
  - Estimate the magnitude of re-rating (e.g. "+15% to fair value")

Total length: 200-280 words.
Distinguish between: company-specific catalysts, sector catalysts, and macro catalysts.
""",
    },

    "valuation_discussion": {
        "label": "Valuation Discussion",
        "description": "Quantitative valuation methodology and implied value",
        "prompt": """\
Write the Valuation Discussion section for {company} ({ticker}).

{context}

This section is the quantitative backbone of the memo. Cover all of:

1. DCF Methodology (60-80 words):
   Describe the DCF framework — WACC of {wacc}%, terminal growth of {tgr}%,
   10-year FCFF projection from {fcff_y1} (Year 1) to {fcff_y10} (Year 10).
   Note the PV(TV) / EV ratio of {pv_tv_pct}% and what it implies about risk.

2. Scenario Analysis (80-100 words):
   Bear case {bear_fvps} / Base case {base_fvps} / Bull case {bull_fvps}.
   Discuss the key assumption differences and what drives the spread.

3. Sensitivity (40-60 words):
   WACC × g sensitivity range of {sens_low} to {sens_high}.
   State which assumption drives the most value.

4. Comparable Companies (60-80 words):
   Reference peer EV/EBITDA median of {ev_ebitda_median}× and implied price
   of {comps_implied}. Discuss any premium / discount and why it is justified.

5. Conclusion (30-40 words):
   Derive a price target and state the upside to current price of {current_price}.

Total: 300-380 words. Every number must come from the context above.
""",
    },

    "recommendation": {
        "label": "Recommendation",
        "description": "Investment rating, target price, and conviction",
        "prompt": """\
Write the Recommendation section for {company} ({ticker}).

{context}

Based on all prior analysis, write a concise recommendation (150-200 words):

1. State the rating explicitly: one of BUY / OUTPERFORM / HOLD / UNDERPERFORM / SELL
2. State the 12-month price target (derive from base case {base_fvps} with any
   justified premium or discount)
3. State the implied upside / downside from current price {current_price}
4. State the conviction level: HIGH / MEDIUM / LOW and justify it
5. List 3 key assumptions that must hold for the thesis to play out
6. Name the single biggest risk that would cause a downgrade

Format the opening line exactly as:
"Rating: [RATING] | Target Price: $[XX.XX] | Upside: [XX]% | Conviction: [LEVEL]"

Then write the body. No boilerplate closing statements.
""",
    },
}


def build_user_prompt(
    section_key: str,
    context_string: str,
    ticker: str,
    company: str,
    extra_vars: dict | None = None,
) -> str:
    """
    Build the final user prompt for a given section.

    Args:
        section_key:    Key into SECTION_PROMPTS.
        context_string: Pre-built context block from MemoContext.
        ticker:         Company ticker.
        company:        Company full name.
        extra_vars:     Additional format variables for the prompt template.

    Returns:
        Formatted user prompt string.
    """
    template = SECTION_PROMPTS[section_key]["prompt"]

    # Build substitution dict
    fmt_vars = {
        "ticker":        ticker,
        "company":       company,
        "context":       context_string,
        # Common pre-formatted values (may be None / "N/A")
        "base_fvps":     "N/A",
        "bear_fvps":     "N/A",
        "bull_fvps":     "N/A",
        "wacc":          "N/A",
        "tgr":           "N/A",
        "pv_tv_pct":     "N/A",
        "fcff_y1":       "N/A",
        "fcff_y10":      "N/A",
        "rev_y1_growth": "N/A",
        "rev_y10_growth":"N/A",
        "sens_low":      "N/A",
        "sens_high":     "N/A",
        "sens_range":    "N/A",
        "ev_ebitda_median":"N/A",
        "comps_implied": "N/A",
        "current_price": "N/A",
    }
    if extra_vars:
        fmt_vars.update(extra_vars)

    # Safe format — skip unknown placeholders
    try:
        return template.format_map(fmt_vars)
    except KeyError:
        return template


def build_system_prompt(ticker: str, company: str) -> str:
    """Render the system prompt with company identity."""
    return SYSTEM_PROMPT.format(ticker=ticker, company=company)
