"""
memo/integrator.py
-------------------
MemoIntegrator — inserts the AI-generated investment memo into the
Phase 9 PDF report as a new, self-contained section.

Integration point: the memo section is inserted immediately after the
Executive Summary in the PDF, before the WACC section.

The integrator:
  1. Builds the memo section flowables (prose + recommendation box)
  2. Injects them into the PDF story after the exec summary section
  3. Produces a standalone "AI Memo" PDF when called independently

Usage:
    memo   = await generator.generate_memo(context)
    pdf    = MemoIntegrator.embed_in_pdf(report_data, memo, builder)

    # Or standalone memo-only PDF:
    pdf    = MemoIntegrator.standalone_pdf(memo)
"""

from __future__ import annotations

import io
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm, mm
from reportlab.platypus import (
    HRFlowable,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from memo.models import InvestmentMemo, Rating
from reports.pdf_report import (
    AMBER, BLUE, BLUE_L, BORDER, CONTENT_W, EMERALD,
    MARGIN_B, MARGIN_L, MARGIN_R, MARGIN_T,
    NAVY, PAGE_H, PAGE_W, PANEL, RED, SLATE, SLATE_D, WHITE,
    STYLES,
    _data_table, _metric_table, _on_later_page, _section_header,
)

from logger import get_logger

log = get_logger(__name__)

# ── Additional styles for the memo ────────────────────────────────────────────

def _ms(name: str, **kw) -> ParagraphStyle:
    return ParagraphStyle(name, **kw)

MEMO_STYLES = {
    "thesis_point": _ms("thesis_point",
        fontName="Helvetica", fontSize=8.5, textColor=colors.HexColor("#cbd5e1"),
        leading=13, spaceAfter=6, leftIndent=12),
    "bullet": _ms("bullet",
        fontName="Helvetica", fontSize=8, textColor=SLATE,
        leading=11, spaceAfter=3, leftIndent=18, firstLineIndent=-10),
    "rec_line": _ms("rec_line",
        fontName="Courier-Bold", fontSize=10, textColor=EMERALD,
        leading=14, spaceAfter=6, alignment=TA_CENTER),
    "ai_badge": _ms("ai_badge",
        fontName="Helvetica-Bold", fontSize=7, textColor=BLUE_L,
        leading=9, spaceAfter=4, alignment=TA_CENTER),
}

RATING_COLORS = {
    "STRONG BUY":   EMERALD,
    "BUY":          EMERALD,
    "OUTPERFORM":   colors.HexColor("#34d399"),
    "HOLD":         AMBER,
    "UNDERPERFORM": colors.HexColor("#f87171"),
    "SELL":         RED,
}


class MemoIntegrator:
    """
    Builds PDF flowables for the AI investment memo and integrates them
    into the Phase 9 report or produces a standalone PDF.
    """

    # ── Build memo flowables ───────────────────────────────────────────────────

    @classmethod
    def build_flowables(cls, memo: InvestmentMemo) -> list:
        """
        Build the complete list of ReportLab Platypus flowables for the memo.

        Returns a list ready to splice into any PDF story.
        """
        story: list = []
        story += cls._memo_header(memo)
        story += cls._exec_summary_section(memo)
        story += cls._thesis_section(memo)
        story += cls._moat_section(memo)
        story += cls._growth_section(memo)
        story += cls._risks_section(memo)
        story += cls._catalysts_section(memo)
        story += cls._valuation_section(memo)
        story += cls._recommendation_section(memo)
        story += cls._disclaimer_section(memo)
        return story

    # ── Section builders ───────────────────────────────────────────────────────

    @staticmethod
    def _memo_header(memo: InvestmentMemo) -> list:
        elements: list = []
        elements += _section_header("AI Investment Memo", "§")
        elements.append(Paragraph(
            f"<font color='#60a5fa'><b>ValuPro AI Analyst</b></font>  ·  "
            f"Model: {memo.model_used}  ·  "
            f"Generated: {memo.generated_at.strftime('%d %b %Y %H:%M UTC')}  ·  "
            f"Tokens used: {memo.total_usage.total_tokens:,}",
            MEMO_STYLES["ai_badge"],
        ))
        elements.append(Spacer(1, 4 * mm))

        # Warning box
        elements.append(Paragraph(
            "⚠  AI-GENERATED CONTENT: This memo is produced by an AI language model "
            "using quantitative data from the ValuPro engine. It is for informational "
            "purposes only and does not constitute investment advice. Verify all claims "
            "against the underlying financial model before making investment decisions.",
            STYLES["warn"],
        ))
        elements.append(Spacer(1, 4 * mm))
        return elements

    @staticmethod
    def _prose_section(header: str, number: str, text: str) -> list:
        """Generic section: header + prose paragraphs."""
        elements: list = _section_header(header, number)
        for para in text.strip().split("\n\n"):
            clean = para.strip()
            if clean:
                elements.append(Paragraph(clean, STYLES["body"]))
                elements.append(Spacer(1, 2 * mm))
        return elements

    @classmethod
    def _exec_summary_section(cls, memo: InvestmentMemo) -> list:
        return cls._prose_section(
            "Executive Summary", "A", memo.executive_summary.raw_text
        )

    @classmethod
    def _thesis_section(cls, memo: InvestmentMemo) -> list:
        elements: list = _section_header("Investment Thesis", "B")
        text = memo.investment_thesis.raw_text

        # Try to show numbered points, fall back to prose
        points = memo.investment_thesis.thesis_points
        if points:
            for i, point in enumerate(points, 1):
                # Bold the first line if it's a header
                lines = point.strip().split("\n")
                header = lines[0].strip()
                body   = "\n".join(lines[1:]).strip()
                elements.append(Paragraph(
                    f"<b>{i}. {header}</b>",
                    ParagraphStyle("tp_hdr", fontName="Helvetica-Bold",
                                   fontSize=8.5, textColor=WHITE, leading=12, spaceAfter=2)
                ))
                if body:
                    elements.append(Paragraph(body, MEMO_STYLES["thesis_point"]))
                elements.append(Spacer(1, 3 * mm))
        else:
            for para in text.split("\n\n"):
                if para.strip():
                    elements.append(Paragraph(para.strip(), STYLES["body"]))
                    elements.append(Spacer(1, 2 * mm))
        return elements

    @classmethod
    def _moat_section(cls, memo: InvestmentMemo) -> list:
        return cls._prose_section("Competitive Advantages", "C", memo.competitive_moat.raw_text)

    @classmethod
    def _growth_section(cls, memo: InvestmentMemo) -> list:
        return cls._prose_section("Growth Drivers", "D", memo.growth_drivers.raw_text)

    @classmethod
    def _risks_section(cls, memo: InvestmentMemo) -> list:
        return cls._prose_section("Key Risks", "E", memo.key_risks.raw_text)

    @classmethod
    def _catalysts_section(cls, memo: InvestmentMemo) -> list:
        return cls._prose_section("Catalysts", "F", memo.catalysts.raw_text)

    @classmethod
    def _valuation_section(cls, memo: InvestmentMemo) -> list:
        return cls._prose_section("Valuation Discussion", "G", memo.valuation_discussion.raw_text)

    @classmethod
    def _recommendation_section(cls, memo: InvestmentMemo) -> list:
        elements: list = _section_header("Recommendation", "H")
        rec = memo.recommendation

        # Rating summary box
        rating_color = RATING_COLORS.get(rec.rating.value, AMBER)
        upside_str   = (
            f"{rec.upside_pct*100:+.1f}%"
            if rec.upside_pct is not None else "N/A"
        )

        # Summary table
        summary_rows = [
            (f"<font color='{rating_color.hexval() if hasattr(rating_color, 'hexval') else '#10b981'}'>"
             f"<b>{rec.rating.value}</b></font>", "Rating"),
            (f"${rec.target_price:.2f}", "12-Month Target Price"),
            (f"${rec.current_price:.2f}" if rec.current_price else "N/A", "Current Price"),
            (upside_str, "Implied Upside / Downside"),
            (rec.conviction.value, "Conviction"),
            (rec.time_horizon, "Time Horizon"),
        ]

        # Build two-column display
        table_data = []
        for i in range(0, len(summary_rows), 2):
            row = []
            for val, lbl in summary_rows[i:i+2]:
                row += [
                    Paragraph(lbl, STYLES["label"]),
                    Paragraph(val, STYLES["data"]),
                ]
            if len(row) == 2:
                row += [Paragraph("", STYLES["label"]), Paragraph("", STYLES["data"])]
            table_data.append(row)

        t = Table(table_data, colWidths=[3.0*cm, 4.5*cm, 3.0*cm, 4.5*cm])
        t.setStyle(TableStyle([
            ("BACKGROUND",   (0, 0), (-1, -1), PANEL),
            ("ROWBACKGROUNDS",(0, 0), (-1, -1), [PANEL, colors.HexColor("#0d1e35")]),
            ("TOPPADDING",   (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING",(0, 0), (-1, -1), 4),
            ("LEFTPADDING",  (0, 0), (-1, -1), 6),
            ("LINEBELOW",    (0, 0), (-1, -1), 0.3, BORDER),
            ("BOX",          (0, 0), (-1, -1), 0.5, BORDER),
        ]))
        elements.append(t)
        elements.append(Spacer(1, 5 * mm))

        # Recommendation prose
        for para in rec.raw_text.split("\n\n"):
            clean = para.strip()
            if clean and not clean.startswith("Rating:"):
                elements.append(Paragraph(clean, STYLES["body"]))
                elements.append(Spacer(1, 2 * mm))

        return elements

    @staticmethod
    def _disclaimer_section(memo: InvestmentMemo) -> list:
        return [
            Spacer(1, 6 * mm),
            HRFlowable(width=CONTENT_W, thickness=0.4, color=BORDER),
            Spacer(1, 3 * mm),
            Paragraph(
                f"AI Investment Memo  ·  {memo.ticker}  ·  "
                f"Generated by ValuPro AI using {memo.model_used}  ·  "
                "For informational purposes only  ·  Not investment advice",
                STYLES["caption"],
            ),
        ]

    # ── Standalone PDF ─────────────────────────────────────────────────────────

    @classmethod
    def standalone_pdf(cls, memo: InvestmentMemo) -> bytes:
        """
        Generate a standalone AI memo PDF (without the full valuation report).
        Useful for quick memo-only downloads.
        """
        buf = io.BytesIO()
        doc = SimpleDocTemplate(
            buf,
            pagesize=A4,
            leftMargin=MARGIN_L,
            rightMargin=MARGIN_R,
            topMargin=MARGIN_T,
            bottomMargin=MARGIN_B,
            title=f"ValuPro AI Memo — {memo.ticker}",
            author="ValuPro AI",
        )

        story: list = []

        # Cover
        def _cover(canvas, doc):
            canvas.saveState()
            canvas.setFillColor(NAVY)
            canvas.rect(0, 0, PAGE_W, PAGE_H, fill=1, stroke=0)
            canvas.setFillColor(BLUE)
            canvas.rect(0, PAGE_H - 8*mm, PAGE_W, 8*mm, fill=1, stroke=0)
            canvas.setFillColor(colors.HexColor("#1d4ed8"))
            canvas.rect(0, 0, PAGE_W, 4*mm, fill=1, stroke=0)
            canvas.restoreState()

        story.append(Spacer(1, 5 * cm))
        story.append(Paragraph("AI Investment Memo", STYLES["cover_sub"]))
        story.append(Paragraph(f"{memo.ticker} — {memo.company_name}", STYLES["cover_title"]))
        story.append(Spacer(1, 0.4 * cm))

        rec = memo.recommendation
        rating_color_hex = {
            "STRONG BUY": "#10b981", "BUY": "#10b981", "OUTPERFORM": "#34d399",
            "HOLD": "#f59e0b", "UNDERPERFORM": "#f87171", "SELL": "#ef4444",
        }.get(rec.rating.value, "#f59e0b")

        story.append(Paragraph(
            f'<font color="{rating_color_hex}"><b>{rec.rating.value}</b></font>  ·  '
            f'Target: <b>${rec.target_price:.2f}</b>  ·  '
            f'Conviction: <b>{rec.conviction.value}</b>',
            STYLES["cover_meta"],
        ))
        story.append(Spacer(1, 0.3 * cm))
        story.append(Paragraph(
            f"ValuPro AI  ·  {memo.model_used}  ·  "
            f"{memo.generated_at.strftime('%d %B %Y')}",
            STYLES["cover_meta"],
        ))
        story.append(PageBreak())

        # All memo sections
        story += cls.build_flowables(memo)

        doc.build(story, onFirstPage=_cover, onLaterPages=_on_later_page)
        buf.seek(0)
        return buf.read()

    # ── Embed in existing PDF report data ─────────────────────────────────────

    @classmethod
    def embed_memo_in_report_data(
        cls,
        memo: InvestmentMemo,
        existing_story: list,
    ) -> list:
        """
        Insert memo flowables into an existing PDF story after the
        Executive Summary section.

        Args:
            memo:           Generated InvestmentMemo.
            existing_story: Story list from ValuationPDFBuilder.

        Returns:
            Modified story with memo injected after executive summary.
        """
        memo_flowables = cls.build_flowables(memo)
        # Inject after the first PageBreak (end of exec summary)
        insert_idx = 0
        pb_count   = 0
        for i, elem in enumerate(existing_story):
            if hasattr(elem, "__class__") and elem.__class__.__name__ == "PageBreak":
                pb_count += 1
                if pb_count == 2:   # after exec summary
                    insert_idx = i
                    break

        if insert_idx > 0:
            return (
                existing_story[:insert_idx]
                + [PageBreak()]
                + memo_flowables
                + existing_story[insert_idx:]
            )
        # Fallback: append at end
        return existing_story + [PageBreak()] + memo_flowables
