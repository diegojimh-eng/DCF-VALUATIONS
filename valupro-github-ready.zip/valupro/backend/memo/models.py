"""
memo/models.py
---------------
All Pydantic data models for the Phase 10 AI Investment Memo.

─────────────────────────────────────────────────────────────────────────────
Investment Memo Structure
─────────────────────────────────────────────────────────────────────────────

The memo is structured exactly as a sell-side equity research initiation report:

  1. Executive Summary     — 3-paragraph synthesis of the investment case
  2. Investment Thesis     — 3 numbered thesis points with quantitative support
  3. Competitive Moat      — durable advantages: pricing power, switching costs, network
  4. Growth Drivers        — 3-5 near- and medium-term catalysts for revenue growth
  5. Key Risks             — 3-5 specific, quantified risks that could derail the thesis
  6. Catalysts             — near-term events that could close the price/value gap
  7. Valuation Discussion  — quantitative discussion grounded in the DCF + comps
  8. Recommendation        — explicit rating, target price, and conviction level

─────────────────────────────────────────────────────────────────────────────
Design decisions:
  • All sections store both raw_text (direct model output) and parsed structured
    data where relevant, so the API can serve JSON or the PDF can render prose.
  • Token usage is tracked per section and in aggregate for billing visibility.
  • Frozen Pydantic models for consistency with the rest of the codebase.
  • Rating enum follows standard sell-side convention: Buy/Hold/Sell.
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field


# ── Rating ─────────────────────────────────────────────────────────────────────

class Rating(str, Enum):
    STRONG_BUY   = "STRONG BUY"
    BUY          = "BUY"
    OUTPERFORM   = "OUTPERFORM"
    HOLD         = "HOLD"
    UNDERPERFORM = "UNDERPERFORM"
    SELL         = "SELL"

    @property
    def signal_color(self) -> str:
        """Frontend badge colour for this rating."""
        greens  = {self.STRONG_BUY, self.BUY, self.OUTPERFORM}
        reds    = {self.SELL, self.UNDERPERFORM}
        return "green" if self in greens else "red" if self in reds else "amber"


class ConvictionLevel(str, Enum):
    HIGH   = "HIGH"
    MEDIUM = "MEDIUM"
    LOW    = "LOW"


# ── Token usage ────────────────────────────────────────────────────────────────

class TokenUsage(BaseModel):
    input_tokens:  int = 0
    output_tokens: int = 0

    model_config = {"frozen": True}

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def __add__(self, other: "TokenUsage") -> "TokenUsage":
        return TokenUsage(
            input_tokens  = self.input_tokens  + other.input_tokens,
            output_tokens = self.output_tokens + other.output_tokens,
        )


# ── Individual sections ────────────────────────────────────────────────────────

class MemoSection(BaseModel):
    """Base class for all memo sections — holds the raw prose text."""
    raw_text: str = Field(..., description="Verbatim prose output from the model")
    usage:    TokenUsage = Field(default_factory=TokenUsage)

    model_config = {"frozen": True}


class ExecutiveSummary(MemoSection):
    """
    3-paragraph investment thesis summary.

    Para 1: Company overview + what it does.
    Para 2: Why it is undervalued / overvalued right now.
    Para 3: What the analyst recommends and the key upside / downside.
    """
    paragraphs: list[str] = Field(default_factory=list)


class InvestmentThesis(MemoSection):
    """
    3 numbered thesis points, each backed by quantitative evidence.

    Format: "1. <Header>: <body with specific numbers>"
    """
    thesis_points: list[str] = Field(default_factory=list)


class CompetitiveMoat(MemoSection):
    """
    Analysis of durable competitive advantages.

    Covers: pricing power, switching costs, network effects,
    cost advantages, intangible assets, efficient scale.
    """
    moat_types: list[str] = Field(default_factory=list)


class GrowthDrivers(MemoSection):
    """
    3-5 specific, named growth catalysts with timeline and magnitude.
    """
    drivers: list[str] = Field(default_factory=list)


class KeyRisks(MemoSection):
    """
    3-5 material risks with quantified downside where possible.
    """
    risks: list[str] = Field(default_factory=list)


class Catalysts(MemoSection):
    """
    Near-term events (6-18 months) that could close the price/value gap.
    """
    catalyst_list: list[str] = Field(default_factory=list)


class ValuationDiscussion(MemoSection):
    """
    Quantitative valuation discussion grounded in the DCF and comps.

    Anchors every statement to specific numbers from the valuation engine.
    """
    key_figures: dict[str, str] = Field(default_factory=dict)


class Recommendation(MemoSection):
    """
    Explicit investment recommendation.
    """
    rating:          Rating
    target_price:    float = Field(..., gt=0)
    current_price:   float | None = None
    upside_pct:      float | None = None
    conviction:      ConvictionLevel = ConvictionLevel.MEDIUM
    time_horizon:    str = "12 months"
    key_assumptions: list[str] = Field(default_factory=list)

    model_config = {"frozen": True}


# ── Full memo ──────────────────────────────────────────────────────────────────

class InvestmentMemo(BaseModel):
    """
    Complete AI-generated institutional investment memo.

    All 8 sections are populated sequentially by MemoGenerator.
    The memo is self-contained — it can be serialised to JSON,
    rendered as prose, or embedded in the PDF report.
    """
    # Identity
    ticker:       str
    company_name: str
    analyst:      str    = "ValuPro AI"
    model_used:   str    = "claude-sonnet-4-6"
    generated_at: datetime = Field(default_factory=datetime.utcnow)

    # The 8 sections
    executive_summary:     ExecutiveSummary
    investment_thesis:     InvestmentThesis
    competitive_moat:      CompetitiveMoat
    growth_drivers:        GrowthDrivers
    key_risks:             KeyRisks
    catalysts:             Catalysts
    valuation_discussion:  ValuationDiscussion
    recommendation:        Recommendation

    # Aggregate token usage across all sections
    total_usage: TokenUsage = Field(default_factory=TokenUsage)

    # Warnings / caveats from generation
    warnings: list[str] = Field(default_factory=list)

    model_config = {"frozen": True}

    def to_dict(self) -> dict:
        """Full JSON-serialisable representation."""
        return {
            "ticker":        self.ticker,
            "company_name":  self.company_name,
            "analyst":       self.analyst,
            "model_used":    self.model_used,
            "generated_at":  self.generated_at.isoformat(),
            "sections": {
                "executive_summary":    self._section_dict(self.executive_summary),
                "investment_thesis":    self._section_dict(self.investment_thesis),
                "competitive_moat":     self._section_dict(self.competitive_moat),
                "growth_drivers":       self._section_dict(self.growth_drivers),
                "key_risks":            self._section_dict(self.key_risks),
                "catalysts":            self._section_dict(self.catalysts),
                "valuation_discussion": self._section_dict(self.valuation_discussion),
                "recommendation":       {
                    **self._section_dict(self.recommendation),
                    "rating":        self.recommendation.rating.value,
                    "target_price":  self.recommendation.target_price,
                    "current_price": self.recommendation.current_price,
                    "upside_pct":    self.recommendation.upside_pct,
                    "conviction":    self.recommendation.conviction.value,
                    "time_horizon":  self.recommendation.time_horizon,
                },
            },
            "total_usage": {
                "input_tokens":  self.total_usage.input_tokens,
                "output_tokens": self.total_usage.output_tokens,
                "total_tokens":  self.total_usage.total_tokens,
            },
            "warnings": self.warnings,
        }

    @staticmethod
    def _section_dict(section: MemoSection) -> dict:
        return {
            "text": section.raw_text,
            "usage": {
                "input_tokens":  section.usage.input_tokens,
                "output_tokens": section.usage.output_tokens,
            },
        }

    def full_text(self) -> str:
        """Concatenated plain-text version of all sections."""
        sections = [
            ("EXECUTIVE SUMMARY",     self.executive_summary.raw_text),
            ("INVESTMENT THESIS",      self.investment_thesis.raw_text),
            ("COMPETITIVE ADVANTAGES", self.competitive_moat.raw_text),
            ("GROWTH DRIVERS",         self.growth_drivers.raw_text),
            ("KEY RISKS",              self.key_risks.raw_text),
            ("CATALYSTS",              self.catalysts.raw_text),
            ("VALUATION DISCUSSION",   self.valuation_discussion.raw_text),
            ("RECOMMENDATION",         self.recommendation.raw_text),
        ]
        parts: list[str] = []
        for title, text in sections:
            parts.append(f"{'─' * 60}")
            parts.append(title)
            parts.append(f"{'─' * 60}")
            parts.append(text.strip())
            parts.append("")
        return "\n".join(parts)
