"""
comps/implication.py
---------------------
Implied valuation engine — applies peer multiple statistics to the
subject company's financial metrics to derive implied prices.

─────────────────────────────────────────────────────────────────────────────
Implied Value Formulas
─────────────────────────────────────────────────────────────────────────────

EV-based multiples (EV/Revenue, EV/EBITDA, EV/EBIT):
─────────────────────────────────────────────────────
  Step 1:  Implied EV     = Subject Metric × Peer Statistic
  Step 2:  Implied Equity = Implied EV − Net Debt − Minority Interest − Preferred
  Step 3:  Implied Price  = max(0, Implied Equity) / Shares Outstanding

  Where:
    Subject Metric  = subject company's Revenue / EBITDA / EBIT (LTM)
    Peer Statistic  = median (or mean/Q1/Q3) of the cleaned peer multiples
    Net Debt        = Total Debt − Cash (from most recent balance sheet)

Equity-level multiples (P/E, P/B):
───────────────────────────────────
  P/E:  Implied Price  = EPS_LTM × Peer P/E
        Implied Equity = Implied Price × Shares Outstanding

  P/B:  Implied Price  = BVPS × Peer P/B
        Implied Equity = Implied Price × Shares Outstanding

  Note: No EV bridge for equity multiples — they apply directly to share price.

─────────────────────────────────────────────────────────────────────────────
Applied at Four Statistics
─────────────────────────────────────────────────────────────────────────────

  Each multiple is applied at four peer statistics:
    Median — primary (robust, preferred in sell-side)
    Mean   — secondary (sensitive to remaining variation)
    Q1     — lower bound of peer range (conservative case)
    Q3     — upper bound of peer range (optimistic case)

  The Q1–Q3 range becomes the football field bar for this multiple.
"""

from __future__ import annotations

from comps.models import (
    ImpliedValue,
    MultipleStats,
    MultipleType,
    SubjectMetrics,
)
from logger import get_logger

log = get_logger(__name__)


class ImplicationEngine:
    """
    Computes implied enterprise value, equity value, and share price
    by applying peer multiple statistics to subject company metrics.

    Stateless — safe to reuse across any number of calls.
    """

    def compute_all_statistics(
        self,
        stats: MultipleStats,
        subject: SubjectMetrics,
    ) -> dict[str, ImpliedValue]:
        """
        Compute implied values at all four statistics (median, mean, Q1, Q3).

        Args:
            stats:   MultipleStats from the stats calculator.
            subject: Subject company's financial metrics.

        Returns:
            Dict keyed by statistic name: {"median", "mean", "q1", "q3"}.
            Returns empty dict when subject metric is unavailable.
        """
        metric = subject.get_metric(stats.multiple_type)
        if metric is None:
            log.warning(
                "comps.implication.missing_metric",
                multiple=stats.multiple_type.value,
                ticker=subject.ticker,
            )
            return {}

        stat_values = {
            "median": stats.median,
            "mean":   stats.mean,
            "q1":     stats.q1,
            "q3":     stats.q3,
        }

        results: dict[str, ImpliedValue] = {}
        for stat_name, stat_value in stat_values.items():
            try:
                results[stat_name] = self.compute_one(
                    multiple_type=stats.multiple_type,
                    statistic_used=stat_name,  # type: ignore[arg-type]
                    subject_metric=metric,
                    peer_statistic=stat_value,
                    subject=subject,
                )
            except Exception as e:
                log.warning(
                    "comps.implication.error",
                    multiple=stats.multiple_type.value,
                    stat=stat_name,
                    error=str(e),
                )

        return results

    def compute_one(
        self,
        multiple_type: MultipleType,
        statistic_used: str,
        subject_metric: float,
        peer_statistic: float,
        subject: SubjectMetrics,
    ) -> ImpliedValue:
        """
        Compute implied valuation for one (multiple, statistic) combination.

        Args:
            multiple_type:   Which multiple (EV/EBITDA, P/E, etc.)
            statistic_used:  "median", "mean", "q1", or "q3"
            subject_metric:  The subject company's financial metric (LTM)
            peer_statistic:  The peer multiple statistic to apply
            subject:         SubjectMetrics for capital structure bridge

        Returns:
            ImpliedValue with full formula audit trail.
        """
        mt = multiple_type

        if mt.is_ev_multiple:
            return self._ev_implied(
                mt, statistic_used, subject_metric, peer_statistic, subject
            )
        else:
            return self._equity_implied(
                mt, statistic_used, subject_metric, peer_statistic, subject
            )

    # ── EV multiple implication ────────────────────────────────────────────

    @staticmethod
    def _ev_implied(
        mt: MultipleType,
        stat: str,
        metric: float,
        peer_stat: float,
        subject: SubjectMetrics,
    ) -> ImpliedValue:
        """
        Implied EV = Subject Metric × Peer Statistic
        Implied Equity = Implied EV − Net Debt − Minority − Preferred
        Implied Price = max(0, Equity) / Shares
        """
        implied_ev = metric * peer_stat

        # EV → equity bridge
        implied_equity = (
            implied_ev
            - subject.net_debt
            - subject.minority_interest
            - subject.preferred_equity
        )
        implied_equity = max(implied_equity, 0.0)

        # Equity → price per share
        implied_price = implied_equity / subject.shares_outstanding

        log.debug(
            "comps.implication.ev",
            multiple=mt.value,
            stat=stat,
            metric=metric,
            peer_stat=peer_stat,
            implied_ev=round(implied_ev),
            implied_price=round(implied_price, 2),
        )

        return ImpliedValue(
            multiple_type=mt,
            statistic_used=stat,  # type: ignore[arg-type]
            subject_metric=metric,
            peer_statistic=peer_stat,
            implied_ev=implied_ev,
            implied_equity_value=implied_equity,
            implied_share_price=implied_price,
            net_debt_deducted=subject.net_debt,
            minority_interest_deducted=subject.minority_interest,
            preferred_equity_deducted=subject.preferred_equity,
        )

    @staticmethod
    def _equity_implied(
        mt: MultipleType,
        stat: str,
        metric: float,
        peer_stat: float,
        subject: SubjectMetrics,
    ) -> ImpliedValue:
        """
        P/E: Implied Price = EPS_LTM × Peer P/E
        P/B: Implied Price = BVPS    × Peer P/B
        Implied Equity = Implied Price × Shares
        """
        # For equity multiples, subject_metric IS per-share (EPS or BVPS)
        implied_price  = metric * peer_stat
        implied_price  = max(implied_price, 0.0)
        implied_equity = implied_price * subject.shares_outstanding

        log.debug(
            "comps.implication.equity",
            multiple=mt.value,
            stat=stat,
            metric=metric,
            peer_stat=peer_stat,
            implied_price=round(implied_price, 2),
        )

        return ImpliedValue(
            multiple_type=mt,
            statistic_used=stat,  # type: ignore[arg-type]
            subject_metric=metric,
            peer_statistic=peer_stat,
            implied_ev=None,                    # equity multiples have no EV
            implied_equity_value=implied_equity,
            implied_share_price=implied_price,
            net_debt_deducted=0.0,
            minority_interest_deducted=0.0,
            preferred_equity_deducted=0.0,
        )
