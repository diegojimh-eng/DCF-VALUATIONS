"""
comps/cleaner.py
-----------------
Peer multiple outlier screening and data cleaner.

─────────────────────────────────────────────────────────────────────────────
Why Outlier Screening Matters
─────────────────────────────────────────────────────────────────────────────

Raw peer multiples often contain extreme values that distort mean and
median statistics:

  • A peer with near-zero EBITDA gives an astronomical EV/EBITDA multiple.
  • A loss-making peer gives a negative or nonsensical P/E.
  • A newly-listed peer may have incomplete LTM financials.
  • A distressed peer trades at a temporary discount unrelated to fundamentals.

Standard sell-side practice: screen out multiples outside
  [Q1 − 1.5 × IQR,  Q3 + 1.5 × IQR]

This module implements:
  1. Hard sanity bounds per multiple type (always applied first)
  2. IQR-based Tukey outlier screening (configurable multiplier)
  3. Minimum observation threshold (< MIN_OBS → flagged as unreliable)
  4. Full audit trail: excluded tickers + reason for exclusion

─────────────────────────────────────────────────────────────────────────────
Screening Order
─────────────────────────────────────────────────────────────────────────────

  1. Drop None / NaN values.
  2. Drop values outside hard sanity bounds (e.g. EV/EBITDA < 0 or > 100).
  3. Compute Q1, Q3, IQR on the remaining values.
  4. Drop values outside Tukey fences: Q1 − k×IQR  to  Q3 + k×IQR.
  5. Report clean values + excluded tickers + reasons.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field

from comps.models import MultipleType, PeerData
from logger import get_logger

log = get_logger(__name__)

# ── Default screening parameters ───────────────────────────────────────────────

DEFAULT_IQR_MULTIPLIER = 1.5     # Tukey standard; use 3.0 for less aggressive screening
MIN_CLEAN_OBS = 2                # Minimum observations after screening


@dataclass(frozen=True)
class CleanedSeries:
    """
    Result of outlier screening for one multiple type.

    Preserves both the clean values and the excluded tickers with reasons.
    """
    multiple_type: MultipleType
    clean_values: list[float]
    clean_tickers: list[str]
    excluded: list[tuple[str, float, str]]   # (ticker, value, reason)

    @property
    def is_reliable(self) -> bool:
        return len(self.clean_values) >= MIN_CLEAN_OBS

    @property
    def excluded_tickers(self) -> list[str]:
        return [t for t, _, _ in self.excluded]

    @property
    def excluded_count(self) -> int:
        return len(self.excluded)

    @property
    def raw_count(self) -> int:
        return len(self.clean_values) + self.excluded_count


class PeerCleaner:
    """
    Cleans a list of PeerData for one multiple type by applying
    sanity bounds then IQR-based outlier screening.

    Stateless — can be used concurrently.
    """

    def __init__(
        self,
        iqr_multiplier: float = DEFAULT_IQR_MULTIPLIER,
        min_observations: int = MIN_CLEAN_OBS,
    ) -> None:
        self._k    = iqr_multiplier
        self._min  = min_observations

    def clean(
        self,
        peers: list[PeerData],
        multiple_type: MultipleType,
    ) -> CleanedSeries:
        """
        Screen peers for the given multiple type.

        Args:
            peers:         List of PeerData objects (all candidates).
            multiple_type: Which multiple to screen.

        Returns:
            CleanedSeries with clean values + excluded audit trail.
        """
        lo_bound, hi_bound = multiple_type.typical_range
        excluded: list[tuple[str, float, str]] = []
        candidates: list[tuple[str, float]] = []

        # ── Step 1 & 2: Drop None and hard-bound violations ────────────────
        for peer in peers:
            raw = peer.get_multiple(multiple_type)
            if raw is None:
                excluded.append((peer.ticker, float("nan"), "missing value"))
                continue
            if not _is_finite(raw):
                excluded.append((peer.ticker, raw, "non-finite value"))
                continue
            if raw < lo_bound or raw > hi_bound:
                excluded.append((
                    peer.ticker, raw,
                    f"outside sanity bounds [{lo_bound:.1f}×, {hi_bound:.1f}×]",
                ))
                continue
            candidates.append((peer.ticker, raw))

        if not candidates:
            log.warning(
                "comps.cleaner.no_candidates",
                multiple=multiple_type.value,
                total_peers=len(peers),
            )
            return CleanedSeries(
                multiple_type=multiple_type,
                clean_values=[],
                clean_tickers=[],
                excluded=excluded,
            )

        # ── Step 3 & 4: IQR outlier screening ─────────────────────────────
        values = [v for _, v in candidates]

        if len(values) >= 4:
            q1, q3 = _quartiles(values)
            iqr    = q3 - q1
            lo_fence = q1 - self._k * iqr
            hi_fence = q3 + self._k * iqr

            clean: list[tuple[str, float]] = []
            for ticker, v in candidates:
                if v < lo_fence or v > hi_fence:
                    excluded.append((
                        ticker, v,
                        f"IQR outlier (fence: [{lo_fence:.2f}×, {hi_fence:.2f}×])",
                    ))
                else:
                    clean.append((ticker, v))
        else:
            # Too few observations for IQR screening — keep all candidates
            clean = candidates

        clean_tickers = [t for t, _ in clean]
        clean_values  = [v for _, v in clean]

        log.debug(
            "comps.cleaner.result",
            multiple=multiple_type.value,
            raw=len(peers),
            clean=len(clean_values),
            excluded=len(excluded),
        )

        return CleanedSeries(
            multiple_type=multiple_type,
            clean_values=clean_values,
            clean_tickers=clean_tickers,
            excluded=excluded,
        )

    def clean_all(
        self,
        peers: list[PeerData],
        multiple_types: list[MultipleType] | None = None,
    ) -> dict[MultipleType, CleanedSeries]:
        """
        Clean all five (or specified) multiple types in one call.

        Returns:
            Dict keyed by MultipleType.
        """
        types = multiple_types or list(MultipleType)
        return {mt: self.clean(peers, mt) for mt in types}


# ── Helpers ────────────────────────────────────────────────────────────────────

def _is_finite(v: float) -> bool:
    """Return True when v is a normal finite number (not NaN, not ±Inf)."""
    return v == v and abs(v) != float("inf")


def _quartiles(values: list[float]) -> tuple[float, float]:
    """
    Compute Q1 (25th percentile) and Q3 (75th percentile).

    Uses linear interpolation (same as Excel QUARTILE.INC).
    """
    sorted_vals = sorted(values)
    n = len(sorted_vals)

    def _percentile(p: float) -> float:
        idx = p * (n - 1)
        lo  = int(idx)
        hi  = min(lo + 1, n - 1)
        frac = idx - lo
        return sorted_vals[lo] + frac * (sorted_vals[hi] - sorted_vals[lo])

    return _percentile(0.25), _percentile(0.75)
