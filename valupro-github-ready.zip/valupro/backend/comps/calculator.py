"""
comps/calculator.py
--------------------
Multiple calculator — derives the five valuation multiples from raw
financial statement data when they are not already pre-computed
by the data provider.

─────────────────────────────────────────────────────────────────────────────
Multiple Definitions
─────────────────────────────────────────────────────────────────────────────

  EV / Revenue  = Enterprise Value / LTM Revenue
                  Sector-independent; used for early-stage and negative-EBITDA companies.

  EV / EBITDA   = Enterprise Value / LTM EBITDA
                  The most widely used multiple in sell-side M&A analysis.
                  Removes capital structure, tax, and D&A policy differences.

  EV / EBIT     = Enterprise Value / LTM EBIT (Operating Income)
                  Preferred for capital-intensive sectors where D&A is economically real.
                  Also called EV/Operating Profit or EV/EBIT.

  P / E         = Price per Share / LTM Diluted EPS
                  The most commonly reported equity multiple.
                  Distorted by capital structure and extraordinary items.
                  Meaningless for loss-making companies.

  P / B         = Price per Share / Book Value per Share
                  Book Value per Share = (Total Equity − Preferred) / Shares Outstanding
                  Useful for banks, insurance, and asset-heavy businesses.

─────────────────────────────────────────────────────────────────────────────
Data Sources
─────────────────────────────────────────────────────────────────────────────

  The DataRouter (Phase 2) fetches pre-computed multiples from FMP's
  /key-metrics endpoint. This calculator handles two scenarios:

  ① Pre-computed:  Provider returned the multiple directly → pass through.
  ② Derived:       Provider returned raw financials → compute here.

  Derived computation:
    EV  = Market Cap + Total Debt − Cash & Equivalents
          (FMP /key-metrics also returns EV directly — use it when available.)

    BVPS = (Total Equity − Preferred Stock) / Diluted Shares Outstanding

─────────────────────────────────────────────────────────────────────────────
Sign Conventions
─────────────────────────────────────────────────────────────────────────────

  All denominators must be positive for the multiple to be meaningful.
  When EBITDA, EBIT, or EPS is negative:
    → The multiple is set to None (not computed).
    → The cleaner will exclude it as a sanity-bound violation anyway.
"""

from __future__ import annotations

from comps.models import PeerData, SubjectMetrics
from data.models.financial import BalanceSheet, IncomeStatement, MarketData
from logger import get_logger

log = get_logger(__name__)


class MultipleCalculator:
    """
    Derives valuation multiples from raw financial data.

    All methods are pure functions — no side effects, fully testable.
    """

    # ── Derive PeerData from raw Phase 2 data ──────────────────────────────

    def from_raw_financials(
        self,
        market: MarketData,
        income: IncomeStatement,
        balance: BalanceSheet | None,
        company_name: str = "",
    ) -> PeerData:
        """
        Build a PeerData object by computing all multiples from raw statements.

        Args:
            market:  MarketData object (price, market cap, beta, etc.)
            income:  Most recent annual IncomeStatement.
            balance: Most recent BalanceSheet (needed for P/B; optional).
            company_name: Display name.

        Returns:
            PeerData with all computable multiples populated.
        """
        ticker = market.ticker

        # ── Enterprise Value ───────────────────────────────────────────────
        # Prefer provider-reported EV; fall back to market cap + net debt
        ev = market.enterprise_value
        if ev is None and market.market_cap is not None:
            net_debt = self._compute_net_debt(balance)
            if net_debt is not None:
                ev = max(0.0, market.market_cap + net_debt)

        # ── EV multiples ───────────────────────────────────────────────────
        ev_revenue = self._safe_divide(ev, income.revenue)
        ev_ebitda  = self._safe_divide(ev, income.ebitda)
        ev_ebit    = self._safe_divide(ev, income.operating_income)

        # ── P/E ───────────────────────────────────────────────────────────
        pe = market.pe_ratio_ttm
        if pe is None:
            pe = self._safe_divide(market.current_price, income.eps_diluted)

        # ── P/B ───────────────────────────────────────────────────────────
        pb = market.pb_ratio
        if pb is None and balance is not None and market.shares_outstanding:
            bvps = self._book_value_per_share(balance, market.shares_outstanding)
            pb   = self._safe_divide(market.current_price, bvps)

        log.debug(
            "comps.calculator.peer_computed",
            ticker=ticker,
            ev_ebitda=round(ev_ebitda, 2) if ev_ebitda else None,
            pe=round(pe, 2) if pe else None,
        )

        return PeerData(
            ticker=ticker,
            company_name=company_name or ticker,
            market_cap=market.market_cap,
            enterprise_value=ev,
            current_price=market.current_price,
            ev_revenue=ev_revenue,
            ev_ebitda=ev_ebitda,
            ev_ebit=ev_ebit,
            pe_ratio=pe,
            pb_ratio=pb,
            revenue_ltm=income.revenue,
            ebitda_ltm=income.ebitda,
            ebitda_margin=income.ebitda_margin,
            net_margin=income.net_income_margin,
            source_provider=market.source_provider,
        )

    # ── Derive SubjectMetrics from the subject company's bundle ────────────

    def subject_metrics_from_bundle(
        self,
        ticker: str,
        market: MarketData,
        income: IncomeStatement,
        balance: BalanceSheet | None,
    ) -> SubjectMetrics:
        """
        Build SubjectMetrics for the company being valued.

        Args:
            ticker:  Subject company ticker.
            market:  Current market data.
            income:  Most recent annual income statement.
            balance: Most recent annual balance sheet.

        Returns:
            SubjectMetrics ready to be used in the implied-value calculation.
        """
        # ── Book value per share ───────────────────────────────────────────
        shares = market.shares_outstanding or 1.0
        bvps: float | None = None
        net_debt: float = 0.0
        minority: float = 0.0

        if balance is not None:
            bvps     = self._book_value_per_share(balance, shares)
            net_debt = balance.net_debt or 0.0

        return SubjectMetrics(
            ticker=ticker,
            revenue_ltm=income.revenue,
            ebitda_ltm=income.ebitda,
            ebit_ltm=income.operating_income,
            eps_diluted_ltm=income.eps_diluted,
            book_value_per_share=bvps,
            net_debt=net_debt,
            minority_interest=minority,
            preferred_equity=0.0,
            shares_outstanding=shares,
        )

    # ── Individual multiple helpers (public for testing) ───────────────────

    @staticmethod
    def ev_revenue(ev: float | None, revenue: float | None) -> float | None:
        """EV / Revenue. Returns None when either input is None or Revenue ≤ 0."""
        return MultipleCalculator._safe_divide(ev, revenue)

    @staticmethod
    def ev_ebitda(ev: float | None, ebitda: float | None) -> float | None:
        """EV / EBITDA. Returns None when EBITDA ≤ 0 (loss-making)."""
        if ebitda is not None and ebitda <= 0:
            return None
        return MultipleCalculator._safe_divide(ev, ebitda)

    @staticmethod
    def ev_ebit(ev: float | None, ebit: float | None) -> float | None:
        """EV / EBIT. Returns None when EBIT ≤ 0."""
        if ebit is not None and ebit <= 0:
            return None
        return MultipleCalculator._safe_divide(ev, ebit)

    @staticmethod
    def pe_ratio(price: float | None, eps: float | None) -> float | None:
        """P / E. Returns None when EPS ≤ 0 (loss-making)."""
        if eps is not None and eps <= 0:
            return None
        return MultipleCalculator._safe_divide(price, eps)

    @staticmethod
    def pb_ratio(
        price: float | None,
        total_equity: float | None,
        preferred_stock: float | None,
        shares: float | None,
    ) -> float | None:
        """
        P / B = Price per Share / Book Value per Share.
        BVPS = (Total Equity − Preferred Stock) / Shares Outstanding.
        """
        if total_equity is None or shares is None or shares <= 0:
            return None
        preferred = preferred_stock or 0.0
        bvps = (total_equity - preferred) / shares
        if bvps <= 0:
            return None
        return MultipleCalculator._safe_divide(price, bvps)

    # ── Internal helpers ───────────────────────────────────────────────────

    @staticmethod
    def _safe_divide(numerator: float | None, denominator: float | None) -> float | None:
        """Divide two values; return None when either is None or denominator ≤ 0."""
        if numerator is None or denominator is None:
            return None
        if denominator <= 0:
            return None
        result = numerator / denominator
        if result != result:   # NaN check
            return None
        return result

    @staticmethod
    def _compute_net_debt(balance: BalanceSheet | None) -> float | None:
        if balance is None:
            return None
        return balance.net_debt   # already computed by BalanceSheet model validator

    @staticmethod
    def _book_value_per_share(
        balance: BalanceSheet,
        shares: float,
    ) -> float | None:
        if balance.total_stockholders_equity is None or shares <= 0:
            return None
        bvps = balance.total_stockholders_equity / shares
        return bvps if bvps > 0 else None


# ── Phase 2 → Phase 6 bridge (promoted from api/routes/comps.py) ──────────────

def peer_multiple_to_peer_data(pm: object) -> "PeerData":
    """
    Convert a Phase 2 PeerMultiple (from DataRouter) to a Phase 6 PeerData.

    This bridge is the canonical conversion function — used by the comps route,
    the reports route, and the memo route so the logic lives in exactly one place.
    """
    from comps.models import PeerData as _PD
    return _PD(
        ticker=getattr(pm, "ticker", ""),
        company_name=getattr(pm, "company_name", ""),
        sector=getattr(pm, "sector", None),
        industry=getattr(pm, "industry", None),
        market_cap=getattr(pm, "market_cap", None),
        enterprise_value=getattr(pm, "enterprise_value", None),
        ev_revenue=getattr(pm, "ev_revenue", None),
        ev_ebitda=getattr(pm, "ev_ebitda", None),
        ev_ebit=getattr(pm, "ev_ebit", None),
        pe_ratio=getattr(pm, "pe_ratio", None),
        pb_ratio=getattr(pm, "pb_ratio", None),
        revenue_growth_1y=getattr(pm, "revenue_growth_1y", None),
        ebitda_margin=getattr(pm, "ebitda_margin", None),
        net_margin=getattr(pm, "net_margin", None),
        source_provider=getattr(pm, "source_provider", ""),
    )
