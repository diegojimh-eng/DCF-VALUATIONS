"""
comps/ — Phase 6 Trading Comparables Engine.

Public API:
    from comps import CompsEngine, MultipleCalculator
    from comps.models import CompsResult, PeerData, SubjectMetrics, MultipleType

Typical usage:
    # Build subject metrics from Phase 2 data
    calc    = MultipleCalculator()
    subject = calc.subject_metrics_from_bundle(ticker, market, income, balance)

    # Build peer data (from DataRouter peer_multiples or raw financials)
    peers = [calc.from_raw_financials(m, i, b) for m, i, b in peer_raw]

    # Run the engine
    engine = CompsEngine()
    result = engine.run(subject=subject, peers=peers)

    print(result.summary_table())
    print(result.implied_price_central)
"""

from comps.calculator import MultipleCalculator, peer_multiple_to_peer_data
from comps.cleaner import PeerCleaner, CleanedSeries
from comps.engine import CompsEngine
from comps.implication import ImplicationEngine
from comps.models import (
    CompsMultiple,
    CompsResult,
    ImpliedValue,
    MultipleStats,
    MultipleType,
    PeerData,
    PeerTableRow,
    SubjectMetrics,
)
from comps.stats import MultipleStatsCalculator

__all__ = [
    "CleanedSeries",
    "CompsEngine",
    "CompsMultiple",
    "CompsResult",
    "ImplicationEngine",
    "ImpliedValue",
    "MultipleCalculator",
    "peer_multiple_to_peer_data",
    "MultipleStats",
    "MultipleStatsCalculator",
    "MultipleType",
    "PeerCleaner",
    "PeerData",
    "PeerTableRow",
    "SubjectMetrics",
]
