"""
comps/models.py
---------------
All Pydantic data models for the Trading Comparables (Comps) engine.

─────────────────────────────────────────────────────────────────────────────
Trading Comparables Overview
─────────────────────────────────────────────────────────────────────────────

Comps valuation applies peer-company trading multiples to the subject
company's own financial metrics to derive an implied market value.

Five multiples are computed and aggregated:

  EV / Revenue  — Enterprise Value / Last-Twelve-Months Revenue
  EV / EBITDA   — Enterprise Value / LTM EBITDA         ← most common
  EV / EBIT     — Enterprise Value / LTM EBIT
  P / E         — Price per Share / LTM EPS (diluted)
  P / B         — Price per Share / Book Value per Share

Valuation bridge (for EV-based multiples):
  Implied EV     = Subject Metric × Peer Statistic (median / mean)
  Implied Equity = Implied EV − Net Debt − Minority Interest − Preferred
  Implied Price  = Implied Equity / Shares Outstanding

For equity multiples (P/E, P/B):
  Implied Equity = Subject Metric × Peer Statistic
  Implied Price  = Implied Equity / Shares Outstanding

─────────────────────────────────────────────────────────────────────────────
Module map:
  PeerData          — raw data for one peer company
  CompsMultiple     — a single multiple type's stats (mean, median, quartiles)
  MultipleStats     — descriptive statistics for one series of observations
  CompsResult       — the complete output of one CompsEngine.run()
  ImpliedValue      — one implied-value derivation (EV → equity → share price)
  SubjectMetrics    — the subject company's own financial metrics
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator


# ── Multiple type enum ─────────────────────────────────────────────────────────

class MultipleType(str, Enum):
    """The five supported valuation multiples."""
    EV_REVENUE = "ev_revenue"   # Enterprise Value / Revenue
    EV_EBITDA  = "ev_ebitda"   # Enterprise Value / EBITDA
    EV_EBIT    = "ev_ebit"     # Enterprise Value / EBIT
    PE         = "pe"          # Price / Earnings (diluted EPS)
    PB         = "pb"          # Price / Book Value per Share

    @property
    def is_ev_multiple(self) -> bool:
        """True for EV-based multiples; False for equity-level multiples."""
        return self in (MultipleType.EV_REVENUE, MultipleType.EV_EBITDA, MultipleType.EV_EBIT)

    @property
    def label(self) -> str:
        labels = {
            "ev_revenue": "EV/Revenue",
            "ev_ebitda":  "EV/EBITDA",
            "ev_ebit":    "EV/EBIT",
            "pe":         "P/E",
            "pb":         "P/B",
        }
        return labels[self.value]

    @property
    def typical_range(self) -> tuple[float, float]:
        """Sanity-check bounds: (min, max) for this multiple type."""
        ranges = {
            "ev_revenue": (0.1,  30.0),
            "ev_ebitda":  (2.0,  60.0),
            "ev_ebit":    (3.0,  80.0),
            "pe":         (3.0, 200.0),
            "pb":         (0.1,  50.0),
        }
        return ranges[self.value]


# ── Peer data (input) ──────────────────────────────────────────────────────────

class PeerData(BaseModel):
    """
    Raw LTM financial data for one peer company.

    All monetary values in the same currency / unit as the subject company.
    All ratios are already-computed multiples (not the raw metrics they
    derive from — those are computed by the DataRouter from provider data).
    """
    ticker: str
    company_name: str
    sector: str | None = None
    industry: str | None = None

    # Market-level data
    market_cap: float | None = Field(default=None, gt=0)
    enterprise_value: float | None = Field(default=None, gt=0)
    current_price: float | None = Field(default=None, gt=0)

    # Pre-computed multiples (from provider — typically FMP /key-metrics)
    ev_revenue: float | None = Field(default=None, ge=0.0)
    ev_ebitda: float | None  = Field(default=None, ge=0.0)
    ev_ebit: float | None    = Field(default=None, ge=0.0)
    pe_ratio: float | None   = Field(default=None)   # can be negative
    pb_ratio: float | None   = Field(default=None, ge=0.0)

    # Quality / growth context (not used in valuation math, but for sorting/filtering)
    revenue_growth_1y: float | None = None
    ebitda_margin: float | None = None
    net_margin: float | None = None
    revenue_ltm: float | None = None
    ebitda_ltm: float | None = None

    # Provenance
    source_provider: str = ""
    fetched_at: datetime = Field(default_factory=datetime.utcnow)

    model_config = {"frozen": True}

    @field_validator("ticker")
    @classmethod
    def normalise_ticker(cls, v: str) -> str:
        return v.upper().strip()

    def get_multiple(self, mt: MultipleType) -> float | None:
        """Return the pre-computed multiple for the given MultipleType."""
        return {
            MultipleType.EV_REVENUE: self.ev_revenue,
            MultipleType.EV_EBITDA:  self.ev_ebitda,
            MultipleType.EV_EBIT:    self.ev_ebit,
            MultipleType.PE:         self.pe_ratio,
            MultipleType.PB:         self.pb_ratio,
        }[mt]


# ── Subject company metrics (the company being valued) ────────────────────────

class SubjectMetrics(BaseModel):
    """
    The subject company's LTM financial metrics.
    Used as the denominator in the implied-value calculation:
      Implied EV = Subject Metric × Peer Multiple
    """
    ticker: str

    # LTM metrics (denominators for EV multiples)
    revenue_ltm: float | None = Field(default=None, gt=0)
    ebitda_ltm: float | None  = Field(default=None)
    ebit_ltm: float | None    = Field(default=None)

    # EPS and book value (denominators for equity multiples)
    eps_diluted_ltm: float | None   = Field(default=None)
    book_value_per_share: float | None = Field(default=None)

    # Capital structure (for EV → equity bridge)
    net_debt: float = Field(default=0.0)
    minority_interest: float = Field(default=0.0, ge=0.0)
    preferred_equity: float  = Field(default=0.0, ge=0.0)
    shares_outstanding: float = Field(..., gt=0)

    model_config = {"frozen": True}

    @field_validator("ticker")
    @classmethod
    def normalise_ticker(cls, v: str) -> str:
        return v.upper().strip()

    def get_metric(self, mt: MultipleType) -> float | None:
        """Return the metric that corresponds to this multiple type."""
        return {
            MultipleType.EV_REVENUE: self.revenue_ltm,
            MultipleType.EV_EBITDA:  self.ebitda_ltm,
            MultipleType.EV_EBIT:    self.ebit_ltm,
            MultipleType.PE:         self.eps_diluted_ltm,
            MultipleType.PB:         self.book_value_per_share,
        }[mt]


# ── Descriptive statistics for one multiple series ─────────────────────────────

class MultipleStats(BaseModel):
    """
    Descriptive statistics computed from a series of peer multiples.

    The 'clean_count' is the number of values after outlier screening.
    The raw_count is the original peer count before screening.
    """
    multiple_type: MultipleType

    # Core statistics
    mean: float
    median: float
    min: float
    max: float
    q1: float  = Field(..., description="25th percentile")
    q3: float  = Field(..., description="75th percentile")
    iqr: float = Field(..., description="Interquartile range = Q3 − Q1")

    # Sample information
    raw_count: int   = Field(..., description="Total peers before outlier screening")
    clean_count: int = Field(..., description="Peers used after screening")
    excluded_count: int = Field(0, description="Peers excluded as outliers")

    # Excluded tickers for audit
    excluded_tickers: list[str] = Field(default_factory=list)

    model_config = {"frozen": True}

    def summary(self) -> str:
        """One-line summary for logging / display."""
        return (
            f"{self.multiple_type.label}: "
            f"median={self.median:.2f}× mean={self.mean:.2f}× "
            f"Q1={self.q1:.2f}× Q3={self.q3:.2f}× "
            f"n={self.clean_count}/{self.raw_count}"
        )


# ── Implied value from one multiple ───────────────────────────────────────────

class ImpliedValue(BaseModel):
    """
    Implied valuation derived by applying one peer statistic to the
    subject company's corresponding financial metric.

    Formula chain (EV multiples):
      Implied EV     = Subject Metric × Peer Statistic
      Implied Equity = Implied EV − Net Debt − Minority Interest − Preferred
      Implied Price  = Implied Equity / Shares Outstanding

    Formula chain (equity multiples: P/E, P/B):
      Implied Equity = Subject Metric × Shares Outstanding × Peer Statistic
                     (where Subject Metric is EPS or BVPS)
      OR:
      Implied Price  = Subject Metric × Peer Statistic
                     (EPS or BVPS × multiple → price directly)
    """
    multiple_type: MultipleType
    statistic_used: Literal["mean", "median", "q1", "q3"]

    # Inputs echoed for audit
    subject_metric: float
    peer_statistic: float

    # Outputs
    implied_ev: float | None = Field(
        default=None,
        description="Implied Enterprise Value (EV multiples only)",
    )
    implied_equity_value: float
    implied_share_price: float

    # Bridge deductions (EV → equity; zero for equity multiples)
    net_debt_deducted: float = 0.0
    minority_interest_deducted: float = 0.0
    preferred_equity_deducted: float = 0.0

    model_config = {"frozen": True}

    def formula_display(self) -> str:
        mt = self.multiple_type
        stat = self.statistic_used.capitalize()
        lines = [
            f"{mt.label} Implied Valuation ({stat})",
            "─" * 44,
        ]
        if mt.is_ev_multiple:
            lines += [
                f"  {mt.label} ({stat})  = {self.peer_statistic:>8.2f}×",
                f"  Subject Metric    = {self.subject_metric:>20,.0f}",
                f"  ───────────────────────────────────────",
                f"  Implied EV        = {self.implied_ev:>20,.0f}",
                f"  − Net Debt        = {self.net_debt_deducted:>20,.0f}",
                f"  − Minority Int.   = {self.minority_interest_deducted:>20,.0f}",
                f"  − Preferred       = {self.preferred_equity_deducted:>20,.0f}",
                f"  ───────────────────────────────────────",
                f"  Implied Equity    = {self.implied_equity_value:>20,.0f}",
                f"  Implied Price     = {self.implied_share_price:>20.2f}",
            ]
        else:
            lines += [
                f"  {mt.label} ({stat})  = {self.peer_statistic:>8.2f}×",
                f"  Subject Metric    = {self.subject_metric:>20.4f}",
                f"  ───────────────────────────────────────",
                f"  Implied Price     = {self.implied_share_price:>20.2f}",
                f"  Implied Equity    = {self.implied_equity_value:>20,.0f}",
            ]
        return "\n".join(lines)


# ── Per-multiple result ────────────────────────────────────────────────────────

class CompsMultiple(BaseModel):
    """
    Complete result for one multiple type: statistics + implied values.

    Contains the cleaned peer series, all statistics, and implied values
    derived from both mean and median statistics.
    """
    multiple_type: MultipleType
    stats: MultipleStats

    # Clean peer values (after outlier screening) for audit
    clean_values: list[float]
    clean_tickers: list[str]

    # Implied valuations at different peer statistics
    implied_at_median: ImpliedValue
    implied_at_mean:   ImpliedValue
    implied_at_q1:     ImpliedValue
    implied_at_q3:     ImpliedValue

    # Is this multiple usable? False when fewer than 2 clean observations.
    is_reliable: bool = Field(
        ...,
        description="False when fewer than 2 clean observations — statistics are unreliable.",
    )

    model_config = {"frozen": True}

    @property
    def median_price(self) -> float:
        return self.implied_at_median.implied_share_price

    @property
    def mean_price(self) -> float:
        return self.implied_at_mean.implied_share_price

    @property
    def price_range(self) -> tuple[float, float]:
        """(Q1-implied price, Q3-implied price) — the IQR range of implied values."""
        return (
            self.implied_at_q1.implied_share_price,
            self.implied_at_q3.implied_share_price,
        )


# ── Peer table row (for display) ───────────────────────────────────────────────

class PeerTableRow(BaseModel):
    """One row in the comparable companies table displayed in the PDF report."""
    ticker: str
    company_name: str
    market_cap: float | None = None
    enterprise_value: float | None = None
    ev_revenue: float | None = None
    ev_ebitda: float | None = None
    ev_ebit: float | None = None
    pe_ratio: float | None = None
    pb_ratio: float | None = None
    revenue_growth_1y: float | None = None
    ebitda_margin: float | None = None
    is_excluded: bool = False
    exclusion_reasons: list[str] = Field(default_factory=list)

    model_config = {"frozen": True}


# ── Full comps output ──────────────────────────────────────────────────────────

class CompsResult(BaseModel):
    """
    Complete Trading Comparables analysis output.

    Primary output of CompsEngine.run().
    """
    ticker: str
    valuation_date: datetime = Field(default_factory=datetime.utcnow)

    # Subject metrics used as denominators
    subject: SubjectMetrics

    # Per-multiple results (one entry per MultipleType)
    multiples: dict[str, CompsMultiple] = Field(
        default_factory=dict,
        description="Keyed by MultipleType.value (e.g. 'ev_ebitda')",
    )

    # Peer data (all peers, before screening)
    raw_peers: list[PeerData]

    # Peer table (for PDF report display)
    peer_table: list[PeerTableRow] = Field(default_factory=list)

    # Summary: implied price range across all multiples (median-based)
    implied_price_low: float | None = None    # lowest median-implied price
    implied_price_high: float | None = None   # highest median-implied price
    implied_price_central: float | None = None  # EV/EBITDA median (primary)

    # Warnings
    warnings: list[str] = Field(default_factory=list)

    model_config = {"frozen": True}

    @property
    def reliable_multiples(self) -> list[CompsMultiple]:
        """Only multiples with enough clean observations to be reliable."""
        return [m for m in self.multiples.values() if m.is_reliable]

    def get_multiple(self, mt: MultipleType) -> CompsMultiple | None:
        return self.multiples.get(mt.value)

    def to_football_field_ranges(
        self,
        current_price: float | None = None,
    ) -> list[dict]:
        """
        Convert comps results to football field bar format.
        Returns one dict per reliable multiple, Q1–Q3 range.
        """
        rows = []
        for cm in self.reliable_multiples:
            lo, hi = cm.price_range
            rows.append({
                "method": f"Comps — {cm.multiple_type.label}",
                "low": min(lo, hi),
                "high": max(lo, hi),
                "midpoint": cm.median_price,
                "current_price": current_price,
            })
        return rows

    def summary_table(self) -> list[dict]:
        """Flat summary table for API response and PDF report."""
        rows = []
        for cm in self.multiples.values():
            rows.append({
                "multiple": cm.multiple_type.label,
                "median": cm.stats.median,
                "mean": cm.stats.mean,
                "q1": cm.stats.q1,
                "q3": cm.stats.q3,
                "min": cm.stats.min,
                "max": cm.stats.max,
                "n_peers": cm.stats.clean_count,
                "n_excluded": cm.stats.excluded_count,
                "implied_price_median": cm.implied_at_median.implied_share_price,
                "implied_price_mean":   cm.implied_at_mean.implied_share_price,
                "implied_price_q1":     cm.implied_at_q1.implied_share_price,
                "implied_price_q3":     cm.implied_at_q3.implied_share_price,
                "is_reliable": cm.is_reliable,
            })
        return rows
