"""
comps/engine.py
---------------
CompsEngine — the single entry point for the Trading Comparables engine.

Execution order:
  1. Receive peer data (pre-computed multiples from DataRouter)
  2. Receive subject metrics (from MultipleCalculator or directly)
  3. Screen each multiple type for outliers (PeerCleaner)
  4. Compute descriptive statistics per multiple (MultipleStatsCalculator)
  5. Apply statistics to subject metrics → implied values (ImplicationEngine)
  6. Assemble CompsResult
  7. Extend the football field with comps ranges (FootballFieldExtender)

Usage:
    engine = CompsEngine()

    result = engine.run(
        subject=subject_metrics,
        peers=peer_data_list,
    )
    print(result.summary_table())

    # Or from a FinancialsBundle + DataRouter peer response:
    result = engine.run_from_bundle(bundle, peer_response, data_router)
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass

from comps.cleaner import PeerCleaner
from comps.implication import ImplicationEngine
from comps.models import (
    CompsMultiple,
    CompsResult,
    MultipleType,
    PeerData,
    PeerTableRow,
    SubjectMetrics,
)
from comps.stats import MultipleStatsCalculator
from logger import get_logger

log = get_logger(__name__)

# Minimum reliable peers per multiple to include it in the football field
_MIN_RELIABLE_PEERS = 3


class CompsEngine:
    """
    Trading Comparables valuation engine.

    Stateless — create once and reuse across all requests.
    """

    def __init__(
        self,
        iqr_multiplier: float = 1.5,
        min_reliable_peers: int = _MIN_RELIABLE_PEERS,
        multiple_types: list[MultipleType] | None = None,
    ) -> None:
        """
        Args:
            iqr_multiplier:     Tukey fence multiplier for outlier screening.
                                1.5 = standard (aggressive); 3.0 = conservative.
            min_reliable_peers: Minimum clean peers to mark a multiple as reliable.
            multiple_types:     Subset of multiples to compute. Default: all five.
        """
        self._cleaner    = PeerCleaner(iqr_multiplier=iqr_multiplier)
        self._stats_calc = MultipleStatsCalculator()
        self._implic     = ImplicationEngine()
        self._min_peers  = min_reliable_peers
        self._types      = multiple_types or list(MultipleType)

    def run(
        self,
        subject: SubjectMetrics,
        peers: list[PeerData],
    ) -> CompsResult:
        """
        Execute the full Trading Comparables analysis.

        Args:
            subject: The subject company's LTM financial metrics.
            peers:   List of peer PeerData objects (raw, before screening).

        Returns:
            CompsResult with all multiples, statistics, implied values,
            peer table, and overall implied price range.
        """
        if not peers:
            log.warning("comps.engine.no_peers", ticker=subject.ticker)
            return self._empty_result(subject, peers)

        log.info(
            "comps.engine.run",
            ticker=subject.ticker,
            n_peers=len(peers),
            multiples=[mt.value for mt in self._types],
        )

        warnings: list[str] = []

        # ── Step 1: Clean each multiple type ──────────────────────────────
        cleaned = self._cleaner.clean_all(peers, self._types)

        # ── Step 2: Compute statistics ─────────────────────────────────────
        stats_by_type = self._stats_calc.compute_all(cleaned)

        # ── Step 3: Apply → implied values ────────────────────────────────
        multiples: dict[str, CompsMultiple] = {}

        for mt in self._types:
            if mt not in stats_by_type:
                warnings.append(
                    f"{mt.label}: insufficient data after outlier screening "
                    f"— excluded from analysis."
                )
                continue

            stats   = stats_by_type[mt]
            series  = cleaned[mt]
            impl_all = self._implic.compute_all_statistics(stats, subject)

            if not impl_all:
                warnings.append(
                    f"{mt.label}: subject metric not available — cannot compute implied values."
                )
                continue

            # Need all four statistic implied values
            if not all(k in impl_all for k in ("median", "mean", "q1", "q3")):
                warnings.append(f"{mt.label}: could not compute all statistic variants.")
                continue

            is_reliable = series.is_reliable and series.clean_count >= self._min_peers

            multiples[mt.value] = CompsMultiple(
                multiple_type=mt,
                stats=stats,
                clean_values=series.clean_values,
                clean_tickers=series.clean_tickers,
                implied_at_median=impl_all["median"],
                implied_at_mean=impl_all["mean"],
                implied_at_q1=impl_all["q1"],
                implied_at_q3=impl_all["q3"],
                is_reliable=is_reliable,
            )

            log.debug(
                "comps.engine.multiple_complete",
                multiple=mt.value,
                median=round(stats.median, 2),
                implied_median=round(impl_all["median"].implied_share_price, 2),
                n_clean=stats.clean_count,
            )

        # ── Step 4: Build peer table for report ───────────────────────────
        peer_table = self._build_peer_table(peers, cleaned)

        # ── Step 5: Compute implied price summary ─────────────────────────
        reliable = [cm for cm in multiples.values() if cm.is_reliable]
        implied_prices = [cm.implied_at_median.implied_share_price for cm in reliable]

        implied_low     = min(implied_prices) if implied_prices else None
        implied_high    = max(implied_prices) if implied_prices else None
        implied_central: float | None = None

        # Primary: EV/EBITDA median; fallback to plain median of available
        ev_ebitda_cm = multiples.get(MultipleType.EV_EBITDA.value)
        if ev_ebitda_cm and ev_ebitda_cm.is_reliable:
            implied_central = ev_ebitda_cm.implied_at_median.implied_share_price
        elif implied_prices:
            import statistics as _st
            implied_central = _st.median(implied_prices)

        # ── Step 6: Warnings ──────────────────────────────────────────────
        if len(peers) < 5:
            warnings.append(
                f"Only {len(peers)} peer(s) provided. A typical comps set "
                f"has 5–10 peers. Results may be less representative."
            )
        if len(reliable) == 0:
            warnings.append(
                "No reliable multiples after screening. "
                "Check peer data quality and completeness."
            )

        log.info(
            "comps.engine.complete",
            ticker=subject.ticker,
            multiples_computed=len(multiples),
            reliable=len(reliable),
            implied_central=round(implied_central, 2) if implied_central else None,
        )

        return CompsResult(
            ticker=subject.ticker,
            subject=subject,
            multiples=multiples,
            raw_peers=peers,
            peer_table=peer_table,
            implied_price_low=implied_low,
            implied_price_high=implied_high,
            implied_price_central=implied_central,
            warnings=warnings,
        )

    # ── Helper: build peer table ───────────────────────────────────────────

    def _build_peer_table(
        self,
        peers: list[PeerData],
        cleaned: dict[MultipleType, object],
    ) -> list[PeerTableRow]:
        """
        Build the peer comparison table (one row per peer).
        Marks excluded peers and attaches exclusion reasons.
        """
        from comps.cleaner import CleanedSeries

        # Build exclusion index: ticker → list of reasons
        exclusion_index: dict[str, list[str]] = {}
        for mt, series in cleaned.items():
            if isinstance(series, CleanedSeries):
                for ticker, _value, reason in series.excluded:
                    if ticker not in exclusion_index:
                        exclusion_index[ticker] = []
                    exclusion_index[ticker].append(f"{mt.label}: {reason}")  # type: ignore[union-attr]

        rows: list[PeerTableRow] = []
        for peer in peers:
            reasons = exclusion_index.get(peer.ticker, [])
            rows.append(PeerTableRow(
                ticker=peer.ticker,
                company_name=peer.company_name,
                market_cap=peer.market_cap,
                enterprise_value=peer.enterprise_value,
                ev_revenue=peer.ev_revenue,
                ev_ebitda=peer.ev_ebitda,
                ev_ebit=peer.ev_ebit,
                pe_ratio=peer.pe_ratio,
                pb_ratio=peer.pb_ratio,
                revenue_growth_1y=peer.revenue_growth_1y,
                ebitda_margin=peer.ebitda_margin,
                is_excluded=bool(reasons),
                exclusion_reasons=reasons,
            ))
        return rows

    @staticmethod
    def _empty_result(
        subject: SubjectMetrics,
        peers: list[PeerData],
    ) -> CompsResult:
        return CompsResult(
            ticker=subject.ticker,
            subject=subject,
            multiples={},
            raw_peers=peers,
            peer_table=[],
            warnings=["No peer data available — comps analysis could not be performed."],
        )
