"""
comps/stats.py
--------------
Descriptive statistics for peer multiple series.

Computes all statistics needed for the comps table and implied-value
derivation from a cleaned list of peer multiples.

─────────────────────────────────────────────────────────────────────────────
Statistics Computed
─────────────────────────────────────────────────────────────────────────────

  Mean     — arithmetic average; sensitive to remaining outliers after screening
  Median   — robust central tendency; primary statistic for implied-value
  Q1       — 25th percentile; lower bound of typical peer range
  Q3       — 75th percentile; upper bound of typical peer range
  IQR      — Q3 − Q1; spread of the central 50% of observations
  Min      — minimum value in clean series
  Max      — maximum value in clean series

─────────────────────────────────────────────────────────────────────────────
Which Statistic to Use for Valuation
─────────────────────────────────────────────────────────────────────────────

  Median — primary.  Most robust; used in every sell-side comps table.
           Preferred when the peer set has variation in size or profitability.

  Mean   — secondary. Use when the peer set is highly homogeneous and you
           want to weight all companies equally by multiple, not by rank.

  Q1/Q3  — bound the range for the football field chart.

  A company trading above Q3 of its peers is priced at a premium;
  below Q1 implies a discount. The analyst must judge whether this is
  warranted by growth, quality, or sentiment.
"""

from __future__ import annotations

import statistics as pystats

from comps.cleaner import CleanedSeries, _quartiles
from comps.models import MultipleStats, MultipleType
from logger import get_logger

log = get_logger(__name__)

# Minimum number of clean observations to compute reliable statistics
_MIN_RELIABLE = 2


class MultipleStatsCalculator:
    """
    Computes descriptive statistics from a CleanedSeries.

    Stateless — instantiate once and reuse freely.
    """

    def compute(self, series: CleanedSeries) -> MultipleStats:
        """
        Compute all statistics for one cleaned multiple series.

        Args:
            series: CleanedSeries from PeerCleaner.clean().

        Returns:
            MultipleStats with mean, median, quartiles, min, max, IQR.

        Raises:
            ValueError: When the series has fewer than 1 clean observation
                        (cannot compute any statistic).
        """
        vals = series.clean_values
        n    = len(vals)

        if n == 0:
            raise ValueError(
                f"Cannot compute statistics for {series.multiple_type.value}: "
                f"no clean observations after outlier screening."
            )

        mean    = pystats.mean(vals)
        median  = pystats.median(vals)
        min_val = min(vals)
        max_val = max(vals)

        if n >= 2:
            q1, q3 = _quartiles(vals)
            iqr    = q3 - q1
        else:
            # Single observation — quartiles equal the only value
            q1 = q3 = vals[0]
            iqr = 0.0

        log.debug(
            "comps.stats.computed",
            multiple=series.multiple_type.value,
            n=n,
            mean=round(mean, 3),
            median=round(median, 3),
            q1=round(q1, 3),
            q3=round(q3, 3),
        )

        return MultipleStats(
            multiple_type=series.multiple_type,
            mean=mean,
            median=median,
            min=min_val,
            max=max_val,
            q1=q1,
            q3=q3,
            iqr=iqr,
            raw_count=series.raw_count,
            clean_count=n,
            excluded_count=series.excluded_count,
            excluded_tickers=series.excluded_tickers,
        )

    def compute_all(
        self,
        cleaned: dict[MultipleType, CleanedSeries],
    ) -> dict[MultipleType, MultipleStats]:
        """
        Compute statistics for all multiple types.

        Skips types with no clean observations (logs a warning instead of raising).

        Returns:
            Dict keyed by MultipleType; may be incomplete if some types have no data.
        """
        result: dict[MultipleType, MultipleStats] = {}
        for mt, series in cleaned.items():
            if not series.clean_values:
                log.warning(
                    "comps.stats.skipped",
                    multiple=mt.value,
                    reason="no clean observations",
                )
                continue
            try:
                result[mt] = self.compute(series)
            except ValueError as e:
                log.warning("comps.stats.error", multiple=mt.value, error=str(e))
        return result
