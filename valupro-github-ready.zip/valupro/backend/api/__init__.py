"""api — FastAPI routes and middleware."""
