"""
api/dependencies.py
-------------------
FastAPI dependency functions for injecting shared resources into route handlers.

Usage in a route:
    @router.get("/company/{ticker}")
    async def get_company(
        ticker: str,
        data_router: DataRouter = Depends(get_data_router),
    ):
        ...
"""

from __future__ import annotations

from fastapi import Depends, Request

from data import DataRouter, FinancialCache


def get_data_router(request: Request) -> DataRouter:
    """Inject the singleton DataRouter from app state."""
    return request.app.state.data_router


def get_cache(request: Request) -> FinancialCache:
    """Inject the FinancialCache from app state."""
    return request.app.state.cache
