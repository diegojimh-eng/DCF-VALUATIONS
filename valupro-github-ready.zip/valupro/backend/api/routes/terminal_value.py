"""
api/routes/terminal_value.py
-----------------------------
Phase 5 Terminal Value REST endpoints.

Routes:
  POST /tv/{ticker}/select          — run full TV selection (GGM + Exit + blend + sensitivity)
  POST /tv/{ticker}/compare         — side-by-side GGM vs Exit comparison
  POST /tv/{ticker}/sensitivity     — three TV sensitivity grids
  GET  /tv/{ticker}/damodaran-check — consistency check between multiple and GGM assumptions
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from api.dependencies import get_data_router
from data import DataRouter
from valuation.terminal import (
    BlendMode,
    ExitMetric,
    GordonGrowthModel,
    ExitMultipleModel,
    TVBlender,
    TVComparison,
    TVSelector,
    TVSelectionInputs,
    TVSensitivityAnalyser,
)
from logger import get_logger

router = APIRouter()
log = get_logger(__name__)

# Singletons
_ggm       = GordonGrowthModel()
_exit      = ExitMultipleModel()
_blender   = TVBlender()
_comparison = TVComparison()
_selector  = TVSelector()
_tv_sens   = TVSensitivityAnalyser()


# ── Request models ─────────────────────────────────────────────────────────────

class GGMRequest(BaseModel):
    terminal_growth_rate: float = Field(default=0.025, ge=-0.02, le=0.06)
    forecast_years: int = Field(default=10, ge=1, le=20)
    wacc: float = Field(..., ge=0.03, le=0.40)
    fcff_terminal: float = Field(..., description="FCFF in the terminal year")
    risk_free_rate: float | None = None


class ExitRequest(BaseModel):
    metric: str = Field(default="ev_ebitda",
                        pattern="^(ev_ebitda|ev_ebit|ev_revenue|price_fcf)$")
    metric_value: float = Field(..., gt=0, description="Terminal year metric value")
    exit_multiple: float = Field(..., gt=0, le=50.0)
    wacc: float = Field(..., ge=0.03, le=0.40)
    forecast_years: int = Field(default=10, ge=1, le=20)
    fcff_terminal: float | None = None
    peer_range_low: float | None = None
    peer_range_high: float | None = None


class TVSelectRequest(BaseModel):
    """Single request that drives the full Phase 5 TV engine."""
    method: str = Field(
        default="gordon_growth",
        pattern="^(gordon_growth|exit_multiple|average|custom_weights)$",
    )
    wacc: float = Field(..., ge=0.03, le=0.40)
    fcff_terminal: float = Field(..., description="FCFF in final forecast year")
    terminal_growth_rate: float = Field(default=0.025, ge=-0.02, le=0.06)
    forecast_years: int = Field(default=10, ge=1, le=20)

    # Exit Multiple inputs (required when method includes exit)
    exit_metric: str = Field(default="ev_ebitda",
                             pattern="^(ev_ebitda|ev_ebit|ev_revenue|price_fcf)$")
    exit_metric_value: float | None = None
    exit_multiple: float | None = Field(default=None, ge=0.1, le=100.0)
    peer_range_low: float | None = None
    peer_range_high: float | None = None

    # Custom blend weights
    weight_ggm: float | None = Field(default=None, ge=0.0, le=1.0)
    weight_exit: float | None = Field(default=None, ge=0.0, le=1.0)

    # Context
    risk_free_rate: float | None = None
    ebitda_margin_terminal: float | None = None
    tax_rate: float = Field(default=0.21, ge=0.0, le=0.60)

    # Equity bridge (for FVPS in sensitivity)
    net_debt: float = 0.0
    shares_outstanding: float | None = None

    # Sensitivity grid config
    run_sensitivity: bool = True
    wacc_steps: int = Field(default=4, ge=1, le=8)
    g_steps: int = Field(default=2, ge=1, le=5)
    multiple_steps: int = Field(default=3, ge=1, le=6)


class DamodaranCheckRequest(BaseModel):
    exit_ebitda_multiple: float = Field(..., gt=0)
    wacc: float = Field(..., ge=0.03, le=0.40)
    terminal_growth_rate: float = Field(default=0.025, ge=-0.02, le=0.06)
    ebitda_margin_terminal: float = Field(..., ge=0.0, le=1.0)
    tax_rate: float = Field(default=0.21, ge=0.0, le=0.60)


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.post("/tv/{ticker}/select")
async def select_terminal_value(
    ticker: str,
    req: TVSelectRequest,
) -> dict:
    """
    Run the full Phase 5 terminal value engine.

    Computes GGM and Exit Multiple (both, regardless of selection),
    blends according to `method`, builds all three sensitivity grids,
    and returns a full comparison table.
    """
    ticker = ticker.upper()
    metric_map = {
        "ev_ebitda": ExitMetric.EV_EBITDA,
        "ev_ebit":   ExitMetric.EV_EBIT,
        "ev_revenue": ExitMetric.EV_REVENUE,
        "price_fcf": ExitMetric.PRICE_FCF,
    }

    peer_range = (
        (req.peer_range_low, req.peer_range_high)
        if req.peer_range_low is not None and req.peer_range_high is not None
        else None
    )

    inputs = TVSelectionInputs(
        fcff_terminal=req.fcff_terminal,
        wacc=req.wacc,
        terminal_growth_rate=req.terminal_growth_rate,
        forecast_years=req.forecast_years,
        method=req.method,
        exit_metric=metric_map[req.exit_metric],
        exit_metric_value=req.exit_metric_value,
        exit_multiple=req.exit_multiple,
        weight_ggm=req.weight_ggm,
        weight_exit=req.weight_exit,
        peer_range=peer_range,
        risk_free_rate=req.risk_free_rate,
        ebitda_margin_terminal=req.ebitda_margin_terminal,
        tax_rate=req.tax_rate,
        run_sensitivity=req.run_sensitivity,
        net_debt=req.net_debt,
        shares_outstanding=req.shares_outstanding,
        wacc_steps=req.wacc_steps,
        g_steps=req.g_steps,
        multiple_steps=req.multiple_steps,
    )

    try:
        result = _selector.select(inputs, ticker=ticker)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    response: dict = {
        "ticker": ticker,
        "method_selected": result.method_selected,
        "terminal_value": result.tv_result.tv_final,
        "pv_terminal_value": result.tv_result.pv_terminal_value,
        "tv_result": result.tv_result.model_dump(),
        "warnings": result.all_warnings,
        "formula_display": result.formula_display(),
    }

    if result.ggm_result is not None:
        response["ggm"] = {
            "terminal_value": result.ggm_result.terminal_value,
            "pv_terminal_value": result.ggm_result.pv_terminal_value,
            "wacc_g_spread": result.ggm_result.wacc_g_spread,
            "tv_to_fcff_multiple": result.ggm_result.tv_to_fcff_multiple,
            "formula": result.ggm_result.formula_display(),
        }

    if result.exit_result is not None:
        response["exit"] = {
            "terminal_value": result.exit_result.terminal_value,
            "pv_terminal_value": result.exit_result.pv_terminal_value,
            "implied_growth_rate": result.exit_result.implied_growth_rate,
            "formula": result.exit_result.formula_display(),
        }

    if result.comparison is not None:
        response["comparison"] = {
            "tv_divergence_pct": result.comparison.tv_divergence_pct,
            "pv_tv_divergence_pct": result.comparison.pv_tv_divergence_pct,
            "implied_exit_multiple_from_ggm": result.comparison.implied_exit_multiple_from_ggm,
            "implied_growth_from_exit": result.comparison.implied_growth_from_exit,
            "recommended_weight_ggm": result.comparison.recommended_weight_ggm,
            "recommended_weight_exit": result.comparison.recommended_weight_exit,
            "guidance": result.comparison.guidance_note,
            "damodaran_check": result.comparison.damodaran_check,
            "table": result.comparison.comparison_table(),
        }

    if result.sensitivity is not None:
        response["sensitivity"] = result.sensitivity.to_dict()

    return response


@router.post("/tv/{ticker}/damodaran-check")
async def damodaran_consistency_check(
    ticker: str,
    req: DamodaranCheckRequest,
) -> dict:
    """
    Run the Damodaran internal consistency check on an exit multiple.

    Validates whether the exit EV/EBITDA multiple is consistent with
    the GGM growth assumptions, given the company's EBITDA margin.
    """
    ticker = ticker.upper()
    result = _exit.damodaran_consistency_check(
        exit_ebitda_multiple=req.exit_ebitda_multiple,
        wacc=req.wacc,
        terminal_growth_rate=req.terminal_growth_rate,
        ebitda_margin_terminal=req.ebitda_margin_terminal,
        tax_rate=req.tax_rate,
    )
    return {"ticker": ticker, **result}
