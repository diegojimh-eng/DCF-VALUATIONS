"""api/routes — FastAPI route handlers."""
