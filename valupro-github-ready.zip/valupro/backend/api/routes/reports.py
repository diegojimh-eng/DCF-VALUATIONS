"""
api/routes/reports.py
----------------------
PDF Report REST endpoints.

Routes:
  POST /reports/{ticker}       — generate full PDF report (requires full pipeline)
  GET  /reports/{ticker}/demo  — generate PDF from synthetic demo data (no API keys needed)
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field

from api.dependencies import get_data_router
from data import DataRouter
from logger import get_logger

router = APIRouter()
log = get_logger(__name__)


# ── Request models ─────────────────────────────────────────────────────────────

class ReportRequest(BaseModel):
    """Optional overrides passed to the full report pipeline."""
    # Forecast
    revenue_growth_rate: float | None = None
    ebitda_margin: float | None = None
    # WACC
    risk_free_rate: float = Field(default=0.043, ge=0.0, le=0.15)
    equity_risk_premium: float = Field(default=0.055, ge=0.02, le=0.15)
    wacc_override: float | None = Field(default=None, ge=0.0, le=0.50)
    # Terminal value
    terminal_growth_rate: float = Field(default=0.025, ge=-0.02, le=0.06)
    tv_method: str = Field(
        default="gordon_growth",
        pattern="^(gordon_growth|exit_multiple|average)$",
    )
    exit_ebitda_multiple: float | None = Field(default=None, ge=1.0, le=50.0)
    # Scenario deltas
    bear_revenue_delta: float = -0.03
    bull_revenue_delta: float = +0.03
    # Report options
    company_name: str = ""
    include_comps: bool = True


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.post("/reports/{ticker}")
async def generate_report(
    ticker: str,
    req: ReportRequest,
    historical_years: int = Query(default=5, ge=2, le=10),
    data_router: DataRouter = Depends(get_data_router),
) -> Response:
    """
    Generate a full institutional PDF valuation report.

    Runs the complete Phase 2–7 pipeline and renders a professional PDF
    with all 7 Matplotlib charts and all data tables.

    Returns:
        PDF file as application/pdf.
    """
    ticker = ticker.upper()
    log.info("reports.route.start", ticker=ticker)

    try:
        # ── Import pipeline components ─────────────────────────────────────
        from engine import (
            CapExAssumptions, DAAssumptions, ForecastAssumptions,
            ForecastPipeline, MarginAssumptions, NWCAssumptions,
            RevenueAssumptions, ScenarioDeltas, ScenarioEngine, ScenarioType,
        )
        from valuation import ValuationPipeline, WACCInputs
        from valuation.models import TerminalValueInputs
        from analysis import AnalysisReportBuilder
        from analysis.scenario import ScenarioWeights
        from comps.calculator import MultipleCalculator
        from comps.engine import CompsEngine
        from reports import ValuationReportRenderer

        # ── Phase 2: Fetch data ────────────────────────────────────────────
        try:
            bundle = await data_router.get_financials_bundle(ticker, years=historical_years)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc))

        market = bundle.market_data
        bs     = bundle.balance_sheets[0]    if bundle.balance_sheets    else None
        is_    = bundle.income_statements[0] if bundle.income_statements else None

        # ── Phase 3: Forecast ─────────────────────────────────────────────
        fp = ForecastPipeline()
        base_assumptions = ForecastAssumptions(
            ticker=ticker,
            scenario=ScenarioType.BASE,
            forecast_years=10,
            revenue=RevenueAssumptions(constant_growth_rate=req.revenue_growth_rate),
            margins=MarginAssumptions(ebitda_margin=req.ebitda_margin),
            da=DAAssumptions(),
            capex=CapExAssumptions(),
            nwc=NWCAssumptions(),
        )
        deltas = ScenarioDeltas(
            bear_revenue_growth_delta=req.bear_revenue_delta,
            bull_revenue_growth_delta=req.bull_revenue_delta,
        )
        scenario_engine   = ScenarioEngine(fp, deltas)
        scenario_results  = await scenario_engine.run_all_async(bundle, base_assumptions)

        # ── Phase 4: WACC + DCF ───────────────────────────────────────────
        wacc_inputs = WACCInputs(
            beta=market.beta,
            market_cap=market.market_cap or 0.0,
            short_term_debt=(bs.short_term_debt or 0.0) if bs else 0.0,
            long_term_debt=(bs.long_term_debt or 0.0) if bs else 0.0,
            interest_expense=abs(is_.interest_expense or 0.0) if is_ else None,
            cash_and_equivalents=(bs.cash_and_equivalents or 0.0) if bs else 0.0,
            risk_free_rate=req.risk_free_rate,
            equity_risk_premium=req.equity_risk_premium,
            tax_rate=(is_.effective_tax_rate or 0.21) if is_ else 0.21,
            wacc_override=req.wacc_override,
        )
        tv_inputs = TerminalValueInputs(
            method=req.tv_method,
            terminal_growth_rate=req.terminal_growth_rate,
            exit_ebitda_multiple=req.exit_ebitda_multiple,
        )
        val_pipeline   = ValuationPipeline()
        val_result     = await val_pipeline.run_async(bundle, scenario_results, wacc_inputs, tv_inputs)

        # ── Phase 7: Sensitivity + Scenario ───────────────────────────────
        from valuation.wacc import WACCCalculator
        wacc_result = WACCCalculator().compute(wacc_inputs)

        def _build_dcf(fo):
            return val_pipeline._build_dcf_inputs(fo, wacc_result, tv_inputs, bundle)

        bear_dcf = _build_dcf(scenario_results.bear)
        base_dcf = _build_dcf(scenario_results.base)
        bull_dcf = _build_dcf(scenario_results.bull)

        builder = AnalysisReportBuilder(
            scenario_weights=ScenarioWeights(),
            build_tornado=True,
        )
        analysis_report = await builder.build_async(
            ticker=ticker,
            bear_output=val_result.bear,
            base_output=val_result.base,
            bull_output=val_result.bull,
            bear_dcf_inputs=bear_dcf,
            base_dcf_inputs=base_dcf,
            bull_dcf_inputs=bull_dcf,
            wacc_result=wacc_result,
            scenario_results=scenario_results,
            current_price=market.current_price,
        )

        # ── Phase 6: Comps (optional) ─────────────────────────────────────
        comps_result = None
        if req.include_comps:
            try:
                peer_response = await data_router.get_peer_multiples(ticker, max_peers=10)
                if peer_response.data:
                    from comps.calculator import peer_multiple_to_peer_data
                    from comps.calculator import MultipleCalculator
                    calc     = MultipleCalculator()
                    subject  = calc.subject_metrics_from_bundle(
                        ticker, market, is_, bs
                    )
                    peers    = [peer_multiple_to_peer_data(pm) for pm in peer_response.data]
                    comps_result = CompsEngine().run(subject=subject, peers=peers)
            except Exception as exc:
                log.warning("reports.comps.skipped", error=str(exc))

        # ── Phase 9: Render PDF ────────────────────────────────────────────
        renderer = ValuationReportRenderer()
        pdf_bytes = renderer.render(
            ticker=ticker,
            valuation_result=val_result,
            scenario_results=scenario_results,
            scenario_analysis=analysis_report.scenarios,
            sensitivity_matrix=analysis_report.sensitivity,
            comps_result=comps_result,
            company_name=req.company_name or (bundle.profile.company_name if bundle.profile else ticker),
            current_price=market.current_price,
        )

        log.info("reports.route.complete", ticker=ticker, pdf_kb=len(pdf_bytes)//1024)

        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f'attachment; filename="valupro_{ticker}_valuation.pdf"',
                "Content-Length": str(len(pdf_bytes)),
            },
        )

    except HTTPException:
        raise
    except Exception as exc:
        log.error("reports.route.error", ticker=ticker, error=str(exc), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Report generation failed: {exc}")


@router.get("/reports/{ticker}/demo")
async def generate_demo_report(ticker: str = "AAPL") -> Response:
    """
    Generate a demo PDF report using synthetic AAPL-scale data.
    No API keys or database connection required.
    Useful for testing the PDF rendering pipeline in isolation.
    """
    ticker = ticker.upper()
    log.info("reports.demo.start", ticker=ticker)

    try:
        from reports.renderer import build_report_from_mock
        pdf_bytes = build_report_from_mock(ticker=ticker)

        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f'attachment; filename="valupro_{ticker}_demo_report.pdf"',
                "Content-Length": str(len(pdf_bytes)),
            },
        )
    except Exception as exc:
        log.error("reports.demo.error", ticker=ticker, error=str(exc), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Demo report failed: {exc}")
