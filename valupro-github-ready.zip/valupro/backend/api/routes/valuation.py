"""
api/routes/valuation.py
------------------------
DCF Valuation REST endpoints.

Routes:
  POST /valuation/{ticker}           — full DCF (Bear/Base/Bull + sensitivity + football field)
  POST /valuation/{ticker}/wacc      — compute WACC only
  GET  /valuation/{ticker}/sensitivity — sensitivity grid for an existing valuation
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from api.dependencies import get_data_router
from data import DataRouter
from engine import (
    CapExAssumptions,
    DAAssumptions,
    ForecastAssumptions,
    ForecastPipeline,
    MarginAssumptions,
    NWCAssumptions,
    RevenueAssumptions,
    ScenarioDeltas,
    ScenarioEngine,
    ScenarioType,
    TrendMethod,
)
from valuation import (
    ValuationPipeline,
    WACCCalculator,
    WACCInputs,
)
from valuation.models import TerminalValueInputs
from logger import get_logger

router = APIRouter()
log = get_logger(__name__)

# Singletons (created once per process)
_forecast_pipeline = ForecastPipeline()
_scenario_engine   = ScenarioEngine(_forecast_pipeline)
_valuation_pipeline = ValuationPipeline()
_wacc_calculator    = WACCCalculator()


# ── Request models ─────────────────────────────────────────────────────────────

class WACCRequest(BaseModel):
    """Manual WACC inputs. Any field left None → derived from financial data."""
    beta: float | None = Field(default=None, description="Equity beta (None → use market data)")
    risk_free_rate: float = Field(default=0.043, ge=0.0, le=0.15,
                                  description="10Y government bond yield")
    equity_risk_premium: float = Field(default=0.055, ge=0.02, le=0.15,
                                       description="ERP (Damodaran default: 5.5%)")
    tax_rate: float | None = Field(default=None, ge=0.0, le=0.60,
                                   description="Marginal tax rate (None → historical effective)")
    kd_override: float | None = Field(default=None, ge=0.0, le=0.30,
                                      description="Override pre-tax cost of debt")
    ke_override: float | None = Field(default=None, ge=0.0, le=0.50,
                                      description="Override cost of equity (bypasses CAPM)")
    wacc_override: float | None = Field(default=None, ge=0.0, le=0.50,
                                        description="Override entire WACC (bypasses all calculation)")


class TerminalValueRequest(BaseModel):
    method: str = Field(default="gordon_growth",
                        pattern="^(gordon_growth|exit_multiple|average)$")
    terminal_growth_rate: float = Field(default=0.025, ge=-0.02, le=0.06)
    exit_ebitda_multiple: float | None = Field(default=None, ge=1.0, le=50.0)


class ForecastRequest(BaseModel):
    """Forecast assumption overrides (all optional — defaults to trend-based)."""
    revenue_constant_growth_rate: float | None = None
    revenue_near_term_growth: float | None = None
    revenue_long_term_growth: float | None = None
    ebitda_margin: float | None = None
    effective_tax_rate: float | None = None
    da_as_pct_revenue: float | None = None
    capex_as_pct_revenue: float | None = None
    nwc_as_pct_revenue: float | None = None
    historical_years_for_trend: int = Field(default=5, ge=2, le=10)


class ValuationRequest(BaseModel):
    """Combined request for a full DCF valuation run."""
    forecast: ForecastRequest = Field(default_factory=ForecastRequest)
    wacc: WACCRequest = Field(default_factory=WACCRequest)
    terminal_value: TerminalValueRequest = Field(default_factory=TerminalValueRequest)
    # Scenario deltas (defaults to ±3% revenue growth, ±2% EBITDA margin, ±1% tax)
    bear_revenue_growth_delta: float = -0.03
    bear_ebitda_margin_delta:  float = -0.02
    bull_revenue_growth_delta: float = +0.03
    bull_ebitda_margin_delta:  float = +0.02
    # Sensitivity grid dimensions
    sensitivity_wacc_steps:   int = Field(default=4, ge=1, le=8)
    sensitivity_growth_steps: int = Field(default=2, ge=1, le=5)


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.post("/valuation/{ticker}")
async def run_valuation(
    ticker: str,
    req: ValuationRequest,
    historical_years: int = Query(default=5, ge=2, le=10),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """
    Run a full DCF valuation for a company.

    Fetches financial data → runs Bear/Base/Bull forecasts → computes WACC →
    discounts FCFFs → computes EV/Equity Value/Fair Value →
    builds sensitivity grid + football field.
    """
    ticker = ticker.upper()

    # ── Fetch financial bundle ─────────────────────────────────────────────
    try:
        bundle = await data_router.get_financials_bundle(ticker, years=historical_years)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    # ── Build forecast assumptions ─────────────────────────────────────────
    fc = req.forecast
    base_assumptions = ForecastAssumptions(
        ticker=ticker,
        scenario=ScenarioType.BASE,
        forecast_years=10,
        historical_years_for_trend=fc.historical_years_for_trend,
        revenue=RevenueAssumptions(
            constant_growth_rate=fc.revenue_constant_growth_rate,
            near_term_growth=fc.revenue_near_term_growth,
            long_term_growth=fc.revenue_long_term_growth,
        ),
        margins=MarginAssumptions(
            ebitda_margin=fc.ebitda_margin,
            effective_tax_rate=fc.effective_tax_rate,
        ),
        da=DAAssumptions(da_as_pct_revenue=fc.da_as_pct_revenue),
        capex=CapExAssumptions(capex_as_pct_revenue=fc.capex_as_pct_revenue),
        nwc=NWCAssumptions(nwc_as_pct_revenue=fc.nwc_as_pct_revenue),
    )

    # ── Run Bear/Base/Bull forecasts ───────────────────────────────────────
    deltas = ScenarioDeltas(
        bear_revenue_growth_delta=req.bear_revenue_growth_delta,
        bear_ebitda_margin_delta=req.bear_ebitda_margin_delta,
        bull_revenue_growth_delta=req.bull_revenue_growth_delta,
        bull_ebitda_margin_delta=req.bull_ebitda_margin_delta,
    )
    scenario_engine = ScenarioEngine(_forecast_pipeline, deltas)
    try:
        scenario_results = await scenario_engine.run_all_async(bundle, base_assumptions)
    except Exception as exc:
        log.error("valuation.forecast.error", ticker=ticker, error=str(exc))
        raise HTTPException(status_code=500, detail=f"Forecast failed: {exc}")

    # ── Build WACC inputs ─────────────────────────────────────────────────
    market = bundle.market_data
    bs = bundle.balance_sheets[0] if bundle.balance_sheets else None
    is_ = bundle.income_statements[0] if bundle.income_statements else None

    w = req.wacc
    wacc_inputs = WACCInputs(
        beta=w.beta if w.beta is not None else market.beta,
        market_cap=market.market_cap or 0.0,
        short_term_debt=(bs.short_term_debt or 0.0) if bs else 0.0,
        long_term_debt=(bs.long_term_debt or 0.0) if bs else 0.0,
        interest_expense=abs(is_.interest_expense or 0.0) if is_ else None,
        cash_and_equivalents=(bs.cash_and_equivalents or 0.0) if bs else 0.0,
        risk_free_rate=w.risk_free_rate,
        equity_risk_premium=w.equity_risk_premium,
        tax_rate=w.tax_rate or (is_.effective_tax_rate or 0.21) if is_ else 0.21,
        ke_override=w.ke_override,
        kd_override=w.kd_override,
        wacc_override=w.wacc_override,
    )

    # ── Build TV inputs ────────────────────────────────────────────────────
    tv = req.terminal_value
    tv_inputs = TerminalValueInputs(
        method=tv.method,
        terminal_growth_rate=tv.terminal_growth_rate,
        exit_ebitda_multiple=tv.exit_ebitda_multiple,
    )

    # ── Run valuation pipeline ─────────────────────────────────────────────
    try:
        result = await _valuation_pipeline.run_async(
            bundle=bundle,
            scenario_results=scenario_results,
            wacc_inputs=wacc_inputs,
            tv_inputs=tv_inputs,
        )
    except Exception as exc:
        log.error("valuation.dcf.error", ticker=ticker, error=str(exc))
        raise HTTPException(status_code=500, detail=f"DCF failed: {exc}")

    return result.to_dict()


@router.post("/valuation/{ticker}/wacc")
async def compute_wacc(
    ticker: str,
    req: WACCRequest,
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """
    Compute WACC only — without running a full forecast.
    Useful for the WACC builder panel in the UI.
    """
    ticker = ticker.upper()
    try:
        bundle = await data_router.get_financials_bundle(ticker, years=2)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    market = bundle.market_data
    bs = bundle.balance_sheets[0] if bundle.balance_sheets else None
    is_ = bundle.income_statements[0] if bundle.income_statements else None

    wacc_inputs = WACCInputs(
        beta=req.beta if req.beta is not None else market.beta,
        market_cap=market.market_cap or 0.0,
        short_term_debt=(bs.short_term_debt or 0.0) if bs else 0.0,
        long_term_debt=(bs.long_term_debt or 0.0) if bs else 0.0,
        interest_expense=abs(is_.interest_expense or 0.0) if is_ else None,
        cash_and_equivalents=(bs.cash_and_equivalents or 0.0) if bs else 0.0,
        risk_free_rate=req.risk_free_rate,
        equity_risk_premium=req.equity_risk_premium,
        tax_rate=req.tax_rate or 0.21,
        ke_override=req.ke_override,
        kd_override=req.kd_override,
        wacc_override=req.wacc_override,
    )

    wacc_result = _wacc_calculator.compute(wacc_inputs)
    return {
        "ticker": ticker,
        "wacc": wacc_result.wacc,
        "ke": wacc_result.ke,
        "kd_pretax": wacc_result.kd_pretax,
        "kd_aftertax": wacc_result.kd_aftertax,
        "equity_weight": wacc_result.equity_weight,
        "debt_weight": wacc_result.debt_weight,
        "beta_used": wacc_result.beta_used,
        "formula": wacc_result.formula_display(),
        "flags": {
            "used_beta_default": wacc_result.used_beta_default,
            "used_kd_override": wacc_result.used_kd_override,
            "used_ke_override": wacc_result.used_ke_override,
            "used_wacc_override": wacc_result.used_wacc_override,
        },
    }
