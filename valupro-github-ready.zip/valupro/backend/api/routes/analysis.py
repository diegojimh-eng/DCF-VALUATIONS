"""
api/routes/analysis.py
-----------------------
Phase 7 Sensitivity & Scenario Analysis REST endpoints.

Routes:
  POST /analysis/{ticker}            — full analysis (sensitivity + scenarios)
  POST /analysis/{ticker}/sensitivity — sensitivity matrix only
  POST /analysis/{ticker}/scenarios   — scenario comparison only

All endpoints build on top of the Phase 2–4 pipeline:
  1. Fetch FinancialsBundle (Phase 2)
  2. Run forecast scenarios (Phase 3)
  3. Compute WACC + DCF per scenario (Phase 4)
  4. Run AnalysisReportBuilder (Phase 7)
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from analysis import AnalysisReportBuilder
from analysis.scenario import ScenarioWeights
from api.dependencies import get_data_router
from data import DataRouter
from engine import (
    CapExAssumptions,
    DAAssumptions,
    ForecastAssumptions,
    ForecastPipeline,
    MarginAssumptions,
    NWCAssumptions,
    RevenueAssumptions,
    ScenarioDeltas,
    ScenarioEngine,
    ScenarioType,
)
from valuation import ValuationPipeline, WACCInputs
from valuation.models import TerminalValueInputs
from logger import get_logger

router = APIRouter()
log    = get_logger(__name__)

# Singletons
_forecast_pipeline  = ForecastPipeline()
_valuation_pipeline = ValuationPipeline()


# ── Request models ─────────────────────────────────────────────────────────────

class ForecastOverrides(BaseModel):
    """Optional overrides for forecast assumptions (all default to trend-based)."""
    revenue_constant_growth_rate: float | None = None
    revenue_near_term_growth: float | None = None
    revenue_long_term_growth: float | None = None
    ebitda_margin: float | None = None
    effective_tax_rate: float | None = None
    da_as_pct_revenue: float | None = None
    capex_as_pct_revenue: float | None = None
    nwc_as_pct_revenue: float | None = None
    historical_years_for_trend: int = Field(default=5, ge=2, le=10)


class WACCOverrides(BaseModel):
    """Optional overrides for WACC assumptions."""
    beta: float | None = None
    risk_free_rate: float = Field(default=0.043, ge=0.0, le=0.15)
    equity_risk_premium: float = Field(default=0.055, ge=0.02, le=0.15)
    tax_rate: float | None = None
    kd_override: float | None = Field(default=None, ge=0.0, le=0.30)
    ke_override: float | None = Field(default=None, ge=0.0, le=0.50)
    wacc_override: float | None = Field(default=None, ge=0.0, le=0.50)


class TVOverrides(BaseModel):
    """Optional overrides for terminal value assumptions."""
    method: str = Field(default="gordon_growth",
                        pattern="^(gordon_growth|exit_multiple|average)$")
    terminal_growth_rate: float = Field(default=0.025, ge=-0.02, le=0.06)
    exit_ebitda_multiple: float | None = Field(default=None, ge=1.0, le=50.0)


class ScenarioDeltaOverrides(BaseModel):
    """Override the default Bear / Bull deltas."""
    bear_revenue_growth_delta: float = -0.03
    bear_ebitda_margin_delta: float  = -0.02
    bear_tax_rate_delta: float       = +0.01
    bull_revenue_growth_delta: float = +0.03
    bull_ebitda_margin_delta: float  = +0.02
    bull_tax_rate_delta: float       = -0.01


class SensitivityConfig(BaseModel):
    """WACC × g grid dimensions."""
    wacc_steps: int     = Field(default=4, ge=1, le=8)
    growth_steps: int   = Field(default=2, ge=1, le=5)
    wacc_step_size: float   = Field(default=0.005, ge=0.001, le=0.02)
    growth_step_size: float = Field(default=0.005, ge=0.001, le=0.02)


class ScenarioWeightConfig(BaseModel):
    """Probability weights for blending Bear / Base / Bull."""
    bear: float = Field(default=0.25, ge=0.0, le=1.0)
    base: float = Field(default=0.50, ge=0.0, le=1.0)
    bull: float = Field(default=0.25, ge=0.0, le=1.0)


class AnalysisRequest(BaseModel):
    """Combined request for the full analysis endpoint."""
    forecast: ForecastOverrides = Field(default_factory=ForecastOverrides)
    wacc: WACCOverrides = Field(default_factory=WACCOverrides)
    terminal_value: TVOverrides = Field(default_factory=TVOverrides)
    scenario_deltas: ScenarioDeltaOverrides = Field(default_factory=ScenarioDeltaOverrides)
    sensitivity: SensitivityConfig = Field(default_factory=SensitivityConfig)
    weights: ScenarioWeightConfig = Field(default_factory=ScenarioWeightConfig)
    build_tornado: bool = True


# ── Pipeline helper ────────────────────────────────────────────────────────────

async def _run_full_pipeline(
    ticker: str,
    req: AnalysisRequest,
    data_router: DataRouter,
    historical_years: int,
) -> tuple:
    """
    Run Phases 2-4 and return all intermediate objects needed for Phase 7.

    Returns:
        (bundle, scenario_results, wacc_result,
         bear_out, base_out, bull_out,
         bear_dcf, base_dcf, bull_dcf,
         valuation_result)
    """
    # ── Phase 2: Fetch data ────────────────────────────────────────────────
    try:
        bundle = await data_router.get_financials_bundle(ticker, years=historical_years)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    # ── Phase 3: Forecast ─────────────────────────────────────────────────
    fc = req.forecast
    base_assumptions = ForecastAssumptions(
        ticker=ticker,
        scenario=ScenarioType.BASE,
        forecast_years=10,
        historical_years_for_trend=fc.historical_years_for_trend,
        revenue=RevenueAssumptions(
            constant_growth_rate=fc.revenue_constant_growth_rate,
            near_term_growth=fc.revenue_near_term_growth,
            long_term_growth=fc.revenue_long_term_growth,
        ),
        margins=MarginAssumptions(
            ebitda_margin=fc.ebitda_margin,
            effective_tax_rate=fc.effective_tax_rate,
        ),
        da=DAAssumptions(da_as_pct_revenue=fc.da_as_pct_revenue),
        capex=CapExAssumptions(capex_as_pct_revenue=fc.capex_as_pct_revenue),
        nwc=NWCAssumptions(nwc_as_pct_revenue=fc.nwc_as_pct_revenue),
    )
    sd = req.scenario_deltas
    deltas = ScenarioDeltas(
        bear_revenue_growth_delta=sd.bear_revenue_growth_delta,
        bear_ebitda_margin_delta=sd.bear_ebitda_margin_delta,
        bear_tax_rate_delta=sd.bear_tax_rate_delta,
        bull_revenue_growth_delta=sd.bull_revenue_growth_delta,
        bull_ebitda_margin_delta=sd.bull_ebitda_margin_delta,
        bull_tax_rate_delta=sd.bull_tax_rate_delta,
    )
    scenario_engine = ScenarioEngine(_forecast_pipeline, deltas)
    try:
        scenario_results = await scenario_engine.run_all_async(bundle, base_assumptions)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Forecast failed: {exc}")

    # ── Phase 4: WACC + DCF ───────────────────────────────────────────────
    market = bundle.market_data
    bs     = bundle.balance_sheets[0]     if bundle.balance_sheets     else None
    is_    = bundle.income_statements[0]  if bundle.income_statements  else None

    w = req.wacc
    wacc_inputs = WACCInputs(
        beta=w.beta if w.beta is not None else market.beta,
        market_cap=market.market_cap or 0.0,
        short_term_debt=(bs.short_term_debt or 0.0) if bs else 0.0,
        long_term_debt=(bs.long_term_debt or 0.0)   if bs else 0.0,
        interest_expense=abs(is_.interest_expense or 0.0) if is_ else None,
        cash_and_equivalents=(bs.cash_and_equivalents or 0.0) if bs else 0.0,
        risk_free_rate=w.risk_free_rate,
        equity_risk_premium=w.equity_risk_premium,
        tax_rate=w.tax_rate or (is_.effective_tax_rate if is_ else None) or 0.21,
        ke_override=w.ke_override,
        kd_override=w.kd_override,
        wacc_override=w.wacc_override,
    )
    tv = req.terminal_value
    tv_inputs = TerminalValueInputs(
        method=tv.method,
        terminal_growth_rate=tv.terminal_growth_rate,
        exit_ebitda_multiple=tv.exit_ebitda_multiple,
    )
    s = req.sensitivity
    try:
        val_result = await _valuation_pipeline.run_async(
            bundle=bundle,
            scenario_results=scenario_results,
            wacc_inputs=wacc_inputs,
            tv_inputs=tv_inputs,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Valuation failed: {exc}")

    # Reconstruct per-scenario DCFInputs from pipeline internals
    from valuation.wacc import WACCCalculator
    wacc_result = WACCCalculator().compute(wacc_inputs)

    def _build_dcf_inputs(forecast_out: object) -> object:
        return _valuation_pipeline._build_dcf_inputs(  # type: ignore[attr-defined]
            forecast_out, wacc_result, tv_inputs, bundle
        )

    bear_dcf = _build_dcf_inputs(scenario_results.bear)
    base_dcf = _build_dcf_inputs(scenario_results.base)
    bull_dcf = _build_dcf_inputs(scenario_results.bull)

    return (
        bundle, scenario_results, wacc_result,
        val_result.bear, val_result.base, val_result.bull,
        bear_dcf, base_dcf, bull_dcf,
        val_result,
    )


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.post("/analysis/{ticker}")
async def run_full_analysis(
    ticker: str,
    req: AnalysisRequest,
    historical_years: int = Query(default=5, ge=2, le=10),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """
    Run the full Phase 7 analysis: sensitivity matrix + scenario analysis.

    Returns a complete AnalysisReport as JSON.
    """
    ticker = ticker.upper()

    (
        bundle, scenario_results, wacc_result,
        bear_out, base_out, bull_out,
        bear_dcf, base_dcf, bull_dcf,
        val_result,
    ) = await _run_full_pipeline(ticker, req, data_router, historical_years)

    w = req.weights
    try:
        weights = ScenarioWeights(bear=w.bear, base=w.base, bull=w.bull)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    s = req.sensitivity
    builder = AnalysisReportBuilder(
        sensitivity_wacc_steps=s.wacc_steps,
        sensitivity_growth_steps=s.growth_steps,
        wacc_step_size=s.wacc_step_size,
        growth_step_size=s.growth_step_size,
        scenario_weights=weights,
        build_tornado=req.build_tornado,
    )

    try:
        report = await builder.build_async(
            ticker=ticker,
            bear_output=bear_out, base_output=base_out, bull_output=bull_out,
            bear_dcf_inputs=bear_dcf, base_dcf_inputs=base_dcf, bull_dcf_inputs=bull_dcf,
            wacc_result=wacc_result,
            scenario_results=scenario_results,
            current_price=bundle.market_data.current_price,
        )
    except Exception as exc:
        log.error("analysis.route.error", ticker=ticker, error=str(exc), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Analysis failed: {exc}")

    return report.to_dict()


@router.post("/analysis/{ticker}/sensitivity")
async def run_sensitivity_only(
    ticker: str,
    req: AnalysisRequest,
    historical_years: int = Query(default=5, ge=2, le=10),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """Return only the WACC × g sensitivity matrix."""
    ticker = ticker.upper()
    (_, _, wacc_result, _, base_out, _, _, base_dcf, _, _) = \
        await _run_full_pipeline(ticker, req, data_router, historical_years)

    s = req.sensitivity
    from analysis.sensitivity import FullSensitivityEngine
    engine = FullSensitivityEngine()
    matrix = engine.compute(
        ticker=ticker,
        base_output=base_out,
        dcf_inputs=base_dcf,
        wacc_result=wacc_result,
        wacc_steps=s.wacc_steps,
        growth_steps=s.growth_steps,
        wacc_step_size=s.wacc_step_size,
        growth_step_size=s.growth_step_size,
    )
    return matrix.to_dict()


@router.post("/analysis/{ticker}/scenarios")
async def run_scenarios_only(
    ticker: str,
    req: AnalysisRequest,
    historical_years: int = Query(default=5, ge=2, le=10),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """Return only the Bear / Base / Bull scenario comparison."""
    ticker = ticker.upper()
    (
        bundle, scenario_results, wacc_result,
        bear_out, base_out, bull_out,
        bear_dcf, base_dcf, bull_dcf, _,
    ) = await _run_full_pipeline(ticker, req, data_router, historical_years)

    w = req.weights
    weights = ScenarioWeights(bear=w.bear, base=w.base, bull=w.bull)
    analyser = ScenarioAnalyser(weights=weights, build_tornado=req.build_tornado)

    from analysis.scenario import ScenarioAnalyser  # re-import for type
    result = analyser.run(
        ticker=ticker,
        scenario_results=scenario_results,
        bear_output=bear_out, base_output=base_out, bull_output=bull_out,
        bear_dcf_inputs=bear_dcf, base_dcf_inputs=base_dcf, bull_dcf_inputs=bull_dcf,
        wacc_result=wacc_result,
        current_price=bundle.market_data.current_price,
    )
    return result.to_dict()
