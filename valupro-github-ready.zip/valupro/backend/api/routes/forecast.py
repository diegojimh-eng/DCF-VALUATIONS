"""
api/routes/forecast.py
-----------------------
Forecasting engine REST endpoints.

Routes:
  POST /forecast/{ticker}           — run base case forecast
  POST /forecast/{ticker}/scenarios — run Bear/Base/Bull simultaneously
  GET  /forecast/{ticker}/assumptions — return trend-derived assumptions preview
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from api.dependencies import get_data_router
from data import DataRouter
from engine import (
    CapExAssumptions,
    DAAssumptions,
    ForecastAssumptions,
    ForecastPipeline,
    MarginAssumptions,
    NWCAssumptions,
    RevenueAssumptions,
    ScenarioDeltas,
    ScenarioEngine,
    ScenarioType,
    TrendMethod,
)
from logger import get_logger

router = APIRouter()
log = get_logger(__name__)

# ── Shared pipeline singleton (created once per process) ───────────────────────
# In production this would be in app.state via lifespan; kept simple here.
_pipeline = ForecastPipeline()
_scenario_engine = ScenarioEngine(_pipeline)


# ── Request / response models ──────────────────────────────────────────────────

class ForecastRequest(BaseModel):
    """
    Analyst inputs for a forecast run.
    Every field is optional — omit to use trend-derived value.
    """
    scenario: ScenarioType = ScenarioType.BASE
    forecast_years: int = Field(default=10, ge=1, le=20)

    # Revenue
    revenue_constant_growth_rate: float | None = Field(
        default=None,
        description="Single growth rate for all years. e.g. 0.08 = 8%",
    )
    revenue_near_term_growth: float | None = None
    revenue_long_term_growth: float | None = None
    revenue_growth_rates: list[float] | None = Field(
        default=None,
        description="Explicit list of 10 annual growth rates.",
        min_length=10,
        max_length=10,
    )
    revenue_trend_method: TrendMethod = TrendMethod.CAGR

    # EBITDA margin
    ebitda_margin: float | None = Field(
        default=None, description="Target EBITDA/Revenue. e.g. 0.28 = 28%"
    )
    ebitda_margin_by_year: list[float] | None = Field(
        default=None, min_length=10, max_length=10,
    )

    # Tax rate
    effective_tax_rate: float | None = Field(
        default=None, ge=0.0, le=0.6,
    )

    # D&A
    da_as_pct_revenue: float | None = Field(
        default=None, ge=0.0, le=0.5,
    )

    # CapEx
    capex_as_pct_revenue: float | None = Field(
        default=None, ge=0.0, le=0.5,
    )
    maintenance_capex_pct: float | None = None
    growth_capex_pct: float | None = None

    # NWC
    nwc_as_pct_revenue: float | None = None
    accounts_receivable_days: float | None = None
    inventory_days: float | None = None
    accounts_payable_days: float | None = None

    # Historical years to use for trend fitting
    historical_years_for_trend: int = Field(default=5, ge=2, le=10)


class ScenarioForecastRequest(ForecastRequest):
    """Extends ForecastRequest with custom scenario delta overrides."""
    bear_revenue_growth_delta: float = -0.03
    bear_ebitda_margin_delta: float  = -0.02
    bear_tax_rate_delta: float       = +0.01
    bull_revenue_growth_delta: float = +0.03
    bull_ebitda_margin_delta: float  = +0.02
    bull_tax_rate_delta: float       = -0.01


def _build_assumptions(
    ticker: str,
    req: ForecastRequest,
) -> ForecastAssumptions:
    """Convert a ForecastRequest into a validated ForecastAssumptions object."""
    return ForecastAssumptions(
        ticker=ticker,
        scenario=req.scenario,
        forecast_years=req.forecast_years,
        historical_years_for_trend=req.historical_years_for_trend,
        revenue=RevenueAssumptions(
            growth_rates=req.revenue_growth_rates,
            constant_growth_rate=req.revenue_constant_growth_rate,
            near_term_growth=req.revenue_near_term_growth,
            long_term_growth=req.revenue_long_term_growth,
            trend_method=req.revenue_trend_method,
        ),
        margins=MarginAssumptions(
            ebitda_margin=req.ebitda_margin,
            ebitda_margin_by_year=req.ebitda_margin_by_year,
            effective_tax_rate=req.effective_tax_rate,
        ),
        da=DAAssumptions(
            da_as_pct_revenue=req.da_as_pct_revenue,
        ),
        capex=CapExAssumptions(
            capex_as_pct_revenue=req.capex_as_pct_revenue,
            maintenance_capex_pct=req.maintenance_capex_pct,
            growth_capex_pct=req.growth_capex_pct,
        ),
        nwc=NWCAssumptions(
            nwc_as_pct_revenue=req.nwc_as_pct_revenue,
            accounts_receivable_days=req.accounts_receivable_days,
            inventory_days=req.inventory_days,
            accounts_payable_days=req.accounts_payable_days,
        ),
    )


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.post("/forecast/{ticker}")
async def run_forecast(
    ticker: str,
    req: ForecastRequest,
    years: int = Query(default=5, ge=2, le=10, description="Years of historical data to fetch"),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """
    Run a single-scenario 10-year forecast for a company.

    Fetches financial data automatically from the Phase 2 data layer.
    Optionally accepts manual assumption overrides in the request body.
    """
    ticker = ticker.upper()

    # Fetch financial bundle from Phase 2 data layer
    try:
        bundle = await data_router.get_financials_bundle(ticker, years=years)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    assumptions = _build_assumptions(ticker, req)

    try:
        output = await _pipeline.run_async(bundle, assumptions)
    except Exception as exc:
        log.error("forecast.run.error", ticker=ticker, error=str(exc), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Forecast failed: {exc}")

    return {
        "ticker": output.ticker,
        "scenario": output.scenario.value,
        "generated_at": output.generated_at.isoformat(),
        "history": output.history.model_dump(),
        "resolved_assumptions": output.resolved.model_dump(),
        "years": output.to_table(),
        "warnings": output.warnings,
    }


@router.post("/forecast/{ticker}/scenarios")
async def run_scenarios(
    ticker: str,
    req: ScenarioForecastRequest,
    years: int = Query(default=5, ge=2, le=10),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """
    Run Bear, Base, and Bull forecasts simultaneously.

    Returns all three scenarios in a single response for the football field
    chart and scenario comparison table.
    """
    ticker = ticker.upper()

    try:
        bundle = await data_router.get_financials_bundle(ticker, years=years)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    # Ensure base scenario
    base_req = req.model_copy(update={"scenario": ScenarioType.BASE})
    base_assumptions = _build_assumptions(ticker, base_req)

    deltas = ScenarioDeltas(
        bear_revenue_growth_delta=req.bear_revenue_growth_delta,
        bear_ebitda_margin_delta=req.bear_ebitda_margin_delta,
        bear_tax_rate_delta=req.bear_tax_rate_delta,
        bull_revenue_growth_delta=req.bull_revenue_growth_delta,
        bull_ebitda_margin_delta=req.bull_ebitda_margin_delta,
        bull_tax_rate_delta=req.bull_tax_rate_delta,
    )
    engine = ScenarioEngine(_pipeline, deltas)

    try:
        results = await engine.run_all_async(bundle, base_assumptions)
    except Exception as exc:
        log.error("forecast.scenarios.error", ticker=ticker, error=str(exc), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Scenario run failed: {exc}")

    return {
        "ticker": ticker,
        "fiscal_years": results.base.forecast_fiscal_years,
        "bear": {
            "years": results.bear.to_table(),
            "warnings": results.bear.warnings,
            "fcff": results.bear.forecast_fcffs,
            "revenue": results.bear.forecast_revenues,
            "ebitda": results.bear.forecast_ebitdas,
        },
        "base": {
            "years": results.base.to_table(),
            "warnings": results.base.warnings,
            "fcff": results.base.forecast_fcffs,
            "revenue": results.base.forecast_revenues,
            "ebitda": results.base.forecast_ebitdas,
        },
        "bull": {
            "years": results.bull.to_table(),
            "warnings": results.bull.warnings,
            "fcff": results.bull.forecast_fcffs,
            "revenue": results.bull.forecast_revenues,
            "ebitda": results.bull.forecast_ebitdas,
        },
        "revenue_summary": results.revenue_summary(),
        "fcff_summary": results.fcff_summary(),
    }


@router.get("/forecast/{ticker}/assumptions/preview")
async def preview_assumptions(
    ticker: str,
    historical_years: int = Query(default=5, ge=2, le=10),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """
    Preview trend-derived assumption values for a company without running a forecast.
    Useful for the UI's assumptions panel to show analysts what the engine would use.
    """
    ticker = ticker.upper()

    try:
        bundle = await data_router.get_financials_bundle(ticker, years=historical_years)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    from engine.assumptions import TrendAnalyser
    from engine.pipeline.historical_extractor import HistoricalExtractor

    extractor = HistoricalExtractor()
    analyser = TrendAnalyser(max_years=historical_years)
    series = extractor.extract(bundle)

    rev_item     = analyser.revenue_growth_rate(series.revenue)
    ebitda_item  = analyser.ebitda_margin(series.ebitda, series.revenue)
    tax_item     = analyser.effective_tax_rate(series.tax_expense, series.pretax_income)
    da_item      = analyser.da_as_pct_revenue(series.da_cfs, series.revenue)
    capex_item   = analyser.capex_as_pct_revenue(series.capex, series.revenue)
    nwc_item     = analyser.nwc_as_pct_revenue(series.nwc, series.revenue)

    return {
        "ticker": ticker,
        "historical_years": len(series.fiscal_years),
        "trend_assumptions": {
            "revenue_growth_rate": rev_item.model_dump(),
            "ebitda_margin": ebitda_item.model_dump(),
            "effective_tax_rate": tax_item.model_dump(),
            "da_pct_revenue": da_item.model_dump(),
            "capex_pct_revenue": capex_item.model_dump(),
            "nwc_pct_revenue": nwc_item.model_dump(),
        },
    }
