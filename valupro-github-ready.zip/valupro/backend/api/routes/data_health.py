"""
api/routes/data_health.py
-------------------------
Health check endpoint for the data layer.

Returns status of:
  • Redis cache connectivity
  • Each configured provider (key present, basic reachability)

Used by load balancers, monitoring, and CI/CD readiness probes.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request

from api.dependencies import get_cache, get_data_router
from config import get_settings
from data import DataRouter, FinancialCache
from logger import get_logger

router = APIRouter()
log = get_logger(__name__)


@router.get("/health/data")
async def data_health(
    request: Request,
    cache: FinancialCache = Depends(get_cache),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """
    Data layer health check.

    Returns:
        {
            "status": "ok" | "degraded" | "down",
            "cache": { "connected": bool },
            "providers": { "fmp": { "configured": bool }, ... }
        }
    """
    cfg = get_settings()

    # Cache ping
    cache_ok = await cache.ping()

    # Provider status (key configured — not a live API call)
    providers: dict[str, dict] = {}
    for name in cfg.provider_priority:
        provider_info: dict = {"available": True}
        if name == "fmp":
            provider_info["configured"] = cfg.fmp_key_configured()
        elif name == "alpha_vantage":
            provider_info["configured"] = cfg.alpha_vantage_key_configured()
        elif name == "sec_edgar":
            provider_info["configured"] = True   # no key needed
            provider_info["note"] = "Public API, no key required"
        elif name == "yahoo_finance":
            provider_info["configured"] = True   # no key needed
        providers[name] = provider_info

    any_provider_ok = any(p.get("configured", False) for p in providers.values())
    overall = "ok" if (cache_ok and any_provider_ok) else (
        "degraded" if any_provider_ok else "down"
    )

    return {
        "status": overall,
        "cache": {"connected": cache_ok},
        "providers": providers,
        "priority_order": cfg.provider_priority,
    }


@router.get("/health/live")
async def liveness() -> dict:
    """Simple liveness probe — returns 200 if the process is running."""
    return {"status": "ok"}


@router.get("/health/ready")
async def readiness(
    cache: FinancialCache = Depends(get_cache),
) -> dict:
    """
    Readiness probe — returns 200 only when the app can serve requests.
    Used by k8s / Railway to gate traffic.
    """
    cache_ok = await cache.ping()
    return {"status": "ok" if cache_ok else "not_ready", "cache": cache_ok}
