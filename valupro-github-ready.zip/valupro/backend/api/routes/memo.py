"""
api/routes/memo.py
-------------------
Phase 10 AI Investment Memo REST endpoints.

Routes:
  POST /memo/{ticker}             — generate full memo JSON (all 8 sections)
  POST /memo/{ticker}/stream      — Server-Sent Events: section-by-section streaming
  POST /memo/{ticker}/pdf         — generate full valuation PDF with AI memo embedded
  GET  /memo/{ticker}/demo        — demo memo JSON from mock AAPL data (no API key needed)

All generation routes:
  1. Run Phases 2-7 pipeline (or accept pre-computed data)
  2. Build MemoContext from pipeline outputs
  3. Call MemoGenerator → InvestmentMemo
  4. Return memo or embed in PDF

Authentication:
  ANTHROPIC_API_KEY must be set in the environment.
  The API key is never exposed in responses.
"""

from __future__ import annotations

import json
import os
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel, Field

from api.dependencies import get_data_router
from data import DataRouter
from memo import (
    MemoContext,
    MemoContextBuilder,
    MemoGenerator,
    MemoGeneratorError,
    MemoIntegrator,
)
from memo.models import ConvictionLevel, Rating

from logger import get_logger

router = APIRouter()
log    = get_logger(__name__)


# ── Request models ─────────────────────────────────────────────────────────────

class MemoRequest(BaseModel):
    """Request body for memo generation."""
    # WACC overrides
    risk_free_rate:      float = Field(default=0.043, ge=0.0, le=0.15)
    equity_risk_premium: float = Field(default=0.055, ge=0.02, le=0.15)
    wacc_override:       float | None = None
    # Terminal value
    terminal_growth_rate: float = Field(default=0.025, ge=-0.02, le=0.06)
    tv_method:            str   = "gordon_growth"
    # Scenario deltas
    bear_revenue_delta: float = -0.03
    bull_revenue_delta: float = +0.03
    # Memo generation
    model:      str   = "claude-sonnet-4-6"
    max_tokens: int   = Field(default=1200, ge=200, le=4096)
    temperature: float = Field(default=0.3, ge=0.0, le=1.0)
    include_comps: bool = True
    # API key (optional — falls back to env var)
    anthropic_api_key: str | None = None


# ── Helper: run full pipeline and build MemoContext ────────────────────────────

async def _build_context(
    ticker: str,
    req: MemoRequest,
    data_router: DataRouter,
    historical_years: int = 5,
) -> MemoContext:
    """Run Phases 2-7 and assemble a MemoContext."""
    ticker = ticker.upper()

    # ── Phase 2: Fetch data ────────────────────────────────────────────────
    try:
        bundle = await data_router.get_financials_bundle(ticker, years=historical_years)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    market = bundle.market_data
    bs     = bundle.balance_sheets[0]    if bundle.balance_sheets    else None
    is_    = bundle.income_statements[0] if bundle.income_statements else None

    # ── Phase 3: Forecast ─────────────────────────────────────────────────
    from engine import (
        CapExAssumptions, DAAssumptions, ForecastAssumptions,
        ForecastPipeline, MarginAssumptions, NWCAssumptions,
        RevenueAssumptions, ScenarioDeltas, ScenarioEngine, ScenarioType,
    )
    fp = ForecastPipeline()
    base_assumptions = ForecastAssumptions(
        ticker=ticker,
        scenario=ScenarioType.BASE,
        forecast_years=10,
        revenue=RevenueAssumptions(),
        margins=MarginAssumptions(),
        da=DAAssumptions(),
        capex=CapExAssumptions(),
        nwc=NWCAssumptions(),
    )
    deltas = ScenarioDeltas(
        bear_revenue_growth_delta=req.bear_revenue_delta,
        bull_revenue_growth_delta=req.bull_revenue_delta,
    )
    scen_engine      = ScenarioEngine(fp, deltas)
    scenario_results = await scen_engine.run_all_async(bundle, base_assumptions)

    # ── Phase 4: WACC + DCF ───────────────────────────────────────────────
    from valuation import ValuationPipeline, WACCInputs
    from valuation.models import TerminalValueInputs

    wacc_inputs = WACCInputs(
        beta=market.beta,
        market_cap=market.market_cap or 0.0,
        short_term_debt=(bs.short_term_debt or 0.0) if bs else 0.0,
        long_term_debt=(bs.long_term_debt or 0.0)   if bs else 0.0,
        interest_expense=abs(is_.interest_expense or 0.0) if is_ else None,
        cash_and_equivalents=(bs.cash_and_equivalents or 0.0) if bs else 0.0,
        risk_free_rate=req.risk_free_rate,
        equity_risk_premium=req.equity_risk_premium,
        tax_rate=(is_.effective_tax_rate or 0.21) if is_ else 0.21,
        wacc_override=req.wacc_override,
    )
    tv_inputs = TerminalValueInputs(
        method=req.tv_method,
        terminal_growth_rate=req.terminal_growth_rate,
    )
    val_pipeline  = ValuationPipeline()
    val_result    = await val_pipeline.run_async(bundle, scenario_results, wacc_inputs, tv_inputs)

    # ── Phase 7: Sensitivity + Scenario ───────────────────────────────────
    from analysis import AnalysisReportBuilder
    from analysis.scenario import ScenarioWeights
    from valuation.wacc import WACCCalculator

    wacc_result = WACCCalculator().compute(wacc_inputs)

    def _dcf(fo):
        return val_pipeline._build_dcf_inputs(fo, wacc_result, tv_inputs, bundle)

    builder = AnalysisReportBuilder(scenario_weights=ScenarioWeights(), build_tornado=False)
    analysis_report = await builder.build_async(
        ticker=ticker,
        bear_output=val_result.bear, base_output=val_result.base, bull_output=val_result.bull,
        bear_dcf_inputs=_dcf(scenario_results.bear),
        base_dcf_inputs=_dcf(scenario_results.base),
        bull_dcf_inputs=_dcf(scenario_results.bull),
        wacc_result=wacc_result,
        scenario_results=scenario_results,
        current_price=market.current_price,
    )

    # ── Phase 6: Comps (optional) ─────────────────────────────────────────
    comps_result = None
    if req.include_comps:
        try:
            from comps.calculator import MultipleCalculator
            from comps.engine import CompsEngine
            from comps.calculator import peer_multiple_to_peer_data

            calc = MultipleCalculator()
            subject = calc.subject_metrics_from_bundle(ticker, market, is_, bs)
            peer_response = await data_router.get_peer_multiples(ticker, max_peers=10)
            if peer_response.data:
                peers = [peer_multiple_to_peer_data(pm) for pm in peer_response.data]
                comps_result = CompsEngine().run(subject=subject, peers=peers)
        except Exception as exc:
            log.warning("memo.route.comps_skipped", error=str(exc))

    # ── Build MemoContext ─────────────────────────────────────────────────
    company_name = (
        getattr(bundle.profile, "company_name", None)
        if bundle.profile else ticker
    ) or ticker

    ctx = MemoContextBuilder.from_pipeline_outputs(
        ticker=ticker,
        company_name=company_name,
        company_profile=bundle.profile,
        market_data=market,
        income_statement=is_,
        balance_sheet=bs,
        valuation_result=val_result,
        scenario_analysis=analysis_report.scenarios,
        sensitivity_matrix=analysis_report.sensitivity,
        comps_result=comps_result,
        forecast_base_years=scenario_results.base.years,
    )

    return ctx


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.post("/memo/{ticker}")
async def generate_memo(
    ticker: str,
    req: MemoRequest,
    historical_years: int = Query(default=5, ge=2, le=10),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """
    Generate a complete 8-section AI investment memo as JSON.

    Runs the full Phases 2-7 pipeline, builds quantitative context,
    then calls Claude claude-sonnet-4-6 for each section sequentially.

    Returns all sections with token usage statistics.
    """
    ticker = ticker.upper()
    log.info("memo.route.start", ticker=ticker)

    api_key = req.anthropic_api_key or os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise HTTPException(
            status_code=400,
            detail="ANTHROPIC_API_KEY is not configured. Set it in your environment.",
        )

    try:
        ctx = await _build_context(ticker, req, data_router, historical_years)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Pipeline failed: {exc}")

    try:
        generator = MemoGenerator(
            api_key=api_key,
            model=req.model,
            max_tokens=req.max_tokens,
            temperature=req.temperature,
        )
        memo = await generator.generate_memo(ctx)
    except MemoGeneratorError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        log.error("memo.route.error", ticker=ticker, error=str(exc), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Memo generation failed: {exc}")

    log.info(
        "memo.route.complete",
        ticker=ticker,
        tokens=memo.total_usage.total_tokens,
        rating=memo.recommendation.rating.value,
    )
    return memo.to_dict()


@router.post("/memo/{ticker}/stream")
async def stream_memo(
    ticker: str,
    req: MemoRequest,
    historical_years: int = Query(default=5, ge=2, le=10),
    data_router: DataRouter = Depends(get_data_router),
) -> StreamingResponse:
    """
    Stream memo generation as Server-Sent Events (SSE).

    Each section is yielded as it completes:
        data: {"section": "executive_summary", "text": "..."}

    The final event is:
        data: {"done": true, "rating": "BUY", "target_price": 201.40}
    """
    ticker = ticker.upper()
    api_key = req.anthropic_api_key or os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise HTTPException(status_code=400, detail="ANTHROPIC_API_KEY not configured.")

    try:
        ctx = await _build_context(ticker, req, data_router, historical_years)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Pipeline failed: {exc}")

    async def _sse_generator():
        try:
            generator = MemoGenerator(
                api_key=api_key,
                model=req.model,
                max_tokens=req.max_tokens,
                temperature=req.temperature,
            )
            async for section_key, text in generator.stream_memo(ctx):
                from memo.prompts import SECTION_PROMPTS
                label = SECTION_PROMPTS.get(section_key, {}).get("label", section_key)
                payload = json.dumps({
                    "section": section_key,
                    "label":   label,
                    "text":    text,
                })
                yield f"data: {payload}\n\n"

            # Done event
            yield f"data: {json.dumps({'done': True})}\n\n"

        except MemoGeneratorError as exc:
            yield f"data: {json.dumps({'error': str(exc)})}\n\n"
        except Exception as exc:
            yield f"data: {json.dumps({'error': f'Generation failed: {exc}'})}\n\n"

    return StreamingResponse(
        _sse_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/memo/{ticker}/pdf")
async def generate_memo_pdf(
    ticker: str,
    req: MemoRequest,
    historical_years: int = Query(default=5, ge=2, le=10),
    data_router: DataRouter = Depends(get_data_router),
) -> Response:
    """
    Generate a standalone AI Investment Memo PDF.

    This is the memo only (not the full valuation report).
    For the full integrated report use POST /reports/{ticker}.
    """
    ticker = ticker.upper()
    api_key = req.anthropic_api_key or os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise HTTPException(status_code=400, detail="ANTHROPIC_API_KEY not configured.")

    try:
        ctx = await _build_context(ticker, req, data_router, historical_years)
        generator = MemoGenerator(api_key=api_key, model=req.model)
        memo      = await generator.generate_memo(ctx)
        pdf_bytes = MemoIntegrator.standalone_pdf(memo)
    except MemoGeneratorError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        log.error("memo.pdf.error", ticker=ticker, error=str(exc), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Memo PDF failed: {exc}")

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="valupro_{ticker}_ai_memo.pdf"',
            "Content-Length": str(len(pdf_bytes)),
        },
    )


@router.get("/memo/{ticker}/demo")
async def demo_memo(ticker: str = "AAPL") -> dict:
    """
    Return a demo InvestmentMemo JSON built from static mock data.
    No API key required. Useful for frontend development and testing.
    """
    ticker = ticker.upper()
    from memo.models import (
        Catalysts, CompetitiveMoat, ExecutiveSummary,
        GrowthDrivers, InvestmentMemo, InvestmentThesis,
        KeyRisks, Recommendation, TokenUsage, ValuationDiscussion,
    )

    def _mock_section(text: str, cls, **kwargs):
        return cls(raw_text=text, usage=TokenUsage(input_tokens=850, output_tokens=280), **kwargs)

    demo_memo = InvestmentMemo(
        ticker=ticker,
        company_name=f"{ticker} Inc. (Demo)",
        model_used="claude-sonnet-4-6",
        generated_at=datetime.utcnow(),
        executive_summary=_mock_section(
            f"{ticker} is a global technology leader with a $2.75T market cap, "
            f"generating $383B in LTM revenue and $126B in EBITDA at a 33% margin. "
            f"\n\nOur DCF model yields a base case fair value of $201.40 per share, "
            f"representing 14.8% upside to the current price of $175.50. Using a 9.12% "
            f"WACC and 2.50% terminal growth rate, we arrive at a $2.98T enterprise value. "
            f"The terminal value represents 71.8% of EV — high, but consistent with "
            f"the company's cash flow durability and brand permanence. "
            f"\n\nWe initiate with a BUY rating and $201 price target. The primary risk "
            f"is multiple compression in a rising rate environment, which could pressure "
            f"the stock toward our $158 bear case fair value.",
            ExecutiveSummary,
            paragraphs=[
                f"{ticker} is a global technology leader with $383B LTM revenue.",
                "Our DCF yields $201.40 base case fair value, 14.8% upside.",
                "BUY rating, $201 target. Key risk: multiple compression.",
            ],
        ),
        investment_thesis=_mock_section(
            f"1. ECOSYSTEM LOCK-IN DRIVES RECURRING REVENUE\n"
            f"   With 2B+ active devices and 800M+ paid subscriptions, {ticker}'s "
            f"hardware-software-services flywheel creates switching costs that sustain "
            f"above-market margins. Services revenue at 74% gross margin dilutes the "
            f"mix toward higher-quality recurring income, supporting EV/EBITDA expansion.\n\n"
            f"2. SERVICES SEGMENT RE-RATING POTENTIAL\n"
            f"   Services growing at 15% YoY with 74% gross margins vs 36% for Products. "
            f"As Services reaches 30%+ of revenue, we see 3-5 turn EV/EBITDA re-rating "
            f"potential from the current 22.4× to 25-27×.\n\n"
            f"3. CAPITAL ALLOCATION EXCELLENCE\n"
            f"   $110B+ annual buyback authorisation — the largest in S&P 500 history — "
            f"reduces share count by ~3% annually, creating mechanical EPS accretion "
            f"that we model driving $8.50+ EPS by FY2026.",
            InvestmentThesis,
            thesis_points=[
                "ECOSYSTEM LOCK-IN DRIVES RECURRING REVENUE",
                "SERVICES SEGMENT RE-RATING POTENTIAL",
                "CAPITAL ALLOCATION EXCELLENCE",
            ],
        ),
        competitive_moat=_mock_section(
            f"Switching Costs: The {ticker} ecosystem — iPhone, Mac, iPad, Watch, AirPods, "
            f"iCloud — creates compounding lock-in. A user invested in 3+ Apple devices "
            f"faces $2,000-5,000 in hardware replacement costs plus data migration friction "
            f"to switch platforms. This structural moat sustains 85%+ retention rates.\n\n"
            f"Brand Premium: {ticker} commands a 15-25% ASP premium vs Android flagship "
            f"competitors across every category. This pricing power is structural — "
            f"it has persisted through 4 economic cycles.\n\n"
            f"Vertical Integration: Custom silicon (A17 Pro, M3) delivers 2-3 generation "
            f"performance advantages over Qualcomm-dependent competitors, while reducing "
            f"chip costs by ~$50-80 per device — a margin tailwind of ~100-150 bps.",
            CompetitiveMoat,
        ),
        growth_drivers=_mock_section(
            f"1. Services Monetisation (Near-term, 0-12 months): App Store, advertising, "
            f"and Apple One subscriptions growing at 15% YoY. "
            f"Each 1pp of Services mix shift adds ~40 bps to blended gross margin.\n\n"
            f"2. India Market Expansion (Medium-term, 1-3 years): iPhone penetration in "
            f"India at <5% vs 55% in the US. Manufacturing localisation reduces tariff "
            f"exposure and unlocks price-sensitive segments.\n\n"
            f"3. AI Feature Differentiation (Medium-term, 1-2 years): On-device AI "
            f"powered by Apple Intelligence and Neural Engine creates upgrade cycle "
            f"catalyst. We model 8-10% iPhone unit uplift over 2 years.",
            GrowthDrivers,
        ),
        key_risks=_mock_section(
            f"1. Terminal Value Concentration (HIGH): PV(TV) at 71.8% of EV means a 50 bps "
            f"WACC increase reduces fair value by ~8% — from $201 to ~$185. This is the "
            f"single largest model risk.\n\n"
            f"2. China Revenue Exposure (MEDIUM): ~19% of revenue from Greater China. "
            f"Escalating US-China trade restrictions or consumer boycotts could remove "
            f"$15-20B in annual revenue, pressuring the bear case to $140-150.\n\n"
            f"3. Regulatory / Antitrust (MEDIUM): EU Digital Markets Act forces App Store "
            f"sideloading, potentially reducing Services gross profit by $2-4B/year "
            f"(~2-4% of equity value).",
            KeyRisks,
        ),
        catalysts=_mock_section(
            f"1. Q3 FY2025 Earnings (July 2025): Services acceleration above 15% consensus "
            f"growth would validate our re-rating thesis. +8-12% re-rating potential.\n\n"
            f"2. India iPhone Sales Data (Ongoing): Monthly AIIA shipment data showing "
            f">5M units/quarter confirms our India thesis. +5% catalyst.\n\n"
            f"3. Apple Intelligence Launch (September 2025): Full rollout with AI features "
            f"driving upgrade super-cycle. Historical super-cycles added 15-20% to the stock.",
            Catalysts,
        ),
        valuation_discussion=_mock_section(
            f"DCF Methodology: Our 10-year DCF uses a 9.12% WACC (Ke 11.19%, Kd 3.06%) "
            f"and 2.50% terminal growth rate. FCFF grows from $107B (FY2024E) to $194B "
            f"(FY2033E), a 7.9% CAGR driven by Services mix shift. Σ PV(FCFF) = $812B; "
            f"PV(TV) = $2,170B (71.8% of EV). Enterprise Value = $2,982B.\n\n"
            f"Bear/Base/Bull Scenarios: Bear $158 (WACC 10%, g 2%), "
            f"Base $201 (WACC 9.12%, g 2.5%), Bull $250 (WACC 8.5%, g 3%).\n\n"
            f"Comps: Peers trade at 22.5× EV/EBITDA median. At that multiple, "
            f"implied price is $202 — consistent with our DCF.",
            ValuationDiscussion,
        ),
        recommendation=_mock_section(
            f"Rating: BUY | Target Price: $201.00 | Upside: +14.5% | Conviction: HIGH\n\n"
            f"We initiate {ticker} with a BUY rating and $201 12-month price target based "
            f"on our base case DCF. The stock offers asymmetric risk/reward: $201 upside "
            f"in base (+14.5%), $250 in bull (+42%), vs $158 in bear (-10%).\n\n"
            f"Key assumptions: (1) Services growing 12-15% annually; "
            f"(2) WACC stable at 9.1% (30Y treasury <5%); "
            f"(3) China revenue stable or growing. "
            f"Downgrade trigger: China revenue falls >10% YoY for 2+ consecutive quarters.",
            Recommendation,
            rating=Rating.BUY,
            target_price=201.00,
            current_price=175.50,
            upside_pct=0.145,
            conviction=ConvictionLevel.HIGH,
        ),
        total_usage=TokenUsage(input_tokens=6800, output_tokens=2240),
        warnings=["This is a demo memo generated from static mock data, not a real API call."],
    )

    return demo_memo.to_dict()
