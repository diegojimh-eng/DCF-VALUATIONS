"""
api/routes/comps.py
--------------------
Trading Comparables REST endpoints.

Routes:
  POST /comps/{ticker}              — full comps analysis with auto-fetched peers
  POST /comps/{ticker}/custom       — comps with analyst-provided peer multiples
  GET  /comps/{ticker}/peers        — fetch and score peer set (no valuation)

Design:
  The /comps/{ticker} endpoint:
    1. Fetches the subject company's FinancialsBundle (Phase 2)
    2. Fetches peer multiples via DataRouter.get_peer_multiples()
    3. Converts PeerMultiple → PeerData (Phase 2 → Phase 6 type bridge)
    4. Builds SubjectMetrics from the bundle
    5. Runs CompsEngine.run()
    6. Returns the full CompsResult as JSON
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from api.dependencies import get_data_router
from comps.calculator import MultipleCalculator, peer_multiple_to_peer_data
from comps.engine import CompsEngine
from comps.models import MultipleType, PeerData, SubjectMetrics
from data import DataRouter
from data.models.financial import PeerMultiple
from logger import get_logger

router = APIRouter()
log = get_logger(__name__)

# Singletons
_engine     = CompsEngine()
_calculator = MultipleCalculator()


# PeerMultiple → PeerData bridge lives in comps.calculator


# ── Request models ─────────────────────────────────────────────────────────────

class CustomPeerRequest(BaseModel):
    """One analyst-provided peer with manually entered multiples."""
    ticker: str
    company_name: str
    ev_revenue: float | None = Field(default=None, ge=0)
    ev_ebitda: float | None  = Field(default=None, ge=0)
    ev_ebit: float | None    = Field(default=None, ge=0)
    pe_ratio: float | None   = None
    pb_ratio: float | None   = Field(default=None, ge=0)
    sector: str | None = None
    industry: str | None = None


class SubjectOverrideRequest(BaseModel):
    """Optional overrides for the subject company's financial metrics."""
    revenue_ltm: float | None = Field(default=None, gt=0)
    ebitda_ltm: float | None  = None
    ebit_ltm: float | None    = None
    eps_diluted_ltm: float | None = None
    book_value_per_share: float | None = None
    net_debt: float | None = None
    shares_outstanding: float | None = Field(default=None, gt=0)


class CustomCompsRequest(BaseModel):
    """Request body for the custom comps endpoint."""
    peers: list[CustomPeerRequest] = Field(..., min_length=1, max_length=30)
    subject_overrides: SubjectOverrideRequest | None = None
    iqr_multiplier: float = Field(default=1.5, ge=0.5, le=5.0)


class CompsRequest(BaseModel):
    """Request body for the auto-peer comps endpoint."""
    max_peers: int = Field(default=10, ge=3, le=25)
    iqr_multiplier: float = Field(default=1.5, ge=0.5, le=5.0)
    subject_overrides: SubjectOverrideRequest | None = None


# ── Helpers ────────────────────────────────────────────────────────────────────

async def _fetch_bundle_and_subject(
    ticker: str,
    data_router: DataRouter,
    subject_overrides: SubjectOverrideRequest | None,
    historical_years: int = 3,
) -> tuple[object, SubjectMetrics]:
    """Fetch bundle and build SubjectMetrics, applying any analyst overrides."""
    try:
        bundle = await data_router.get_financials_bundle(ticker, years=historical_years)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    income  = bundle.income_statements[0]  if bundle.income_statements  else None
    balance = bundle.balance_sheets[0]     if bundle.balance_sheets      else None
    market  = bundle.market_data

    if income is None:
        raise HTTPException(status_code=422, detail=f"No income statement data for {ticker}")

    subject = _calculator.subject_metrics_from_bundle(
        ticker=ticker,
        market=market,
        income=income,
        balance=balance,
    )

    # Apply any analyst overrides
    if subject_overrides is not None:
        overrides: dict = {}
        if subject_overrides.revenue_ltm is not None:
            overrides["revenue_ltm"] = subject_overrides.revenue_ltm
        if subject_overrides.ebitda_ltm is not None:
            overrides["ebitda_ltm"] = subject_overrides.ebitda_ltm
        if subject_overrides.ebit_ltm is not None:
            overrides["ebit_ltm"] = subject_overrides.ebit_ltm
        if subject_overrides.eps_diluted_ltm is not None:
            overrides["eps_diluted_ltm"] = subject_overrides.eps_diluted_ltm
        if subject_overrides.book_value_per_share is not None:
            overrides["book_value_per_share"] = subject_overrides.book_value_per_share
        if subject_overrides.net_debt is not None:
            overrides["net_debt"] = subject_overrides.net_debt
        if subject_overrides.shares_outstanding is not None:
            overrides["shares_outstanding"] = subject_overrides.shares_outstanding
        if overrides:
            subject = subject.model_copy(update=overrides)

    return bundle, subject


def _result_to_response(result: object, ticker: str, current_price: float | None) -> dict:
    """Serialise a CompsResult into the API response dict."""
    from comps.models import CompsResult
    r: CompsResult = result  # type: ignore[assignment]
    return {
        "ticker": ticker,
        "valuation_date": r.valuation_date.isoformat(),
        "current_price": current_price,
        "n_peers_raw": len(r.raw_peers),
        "implied_price": {
            "central": r.implied_price_central,
            "low":     r.implied_price_low,
            "high":    r.implied_price_high,
        },
        "summary_table": r.summary_table(),
        "multiples": {
            mt_key: {
                "stats": {
                    "median":     cm.stats.median,
                    "mean":       cm.stats.mean,
                    "q1":         cm.stats.q1,
                    "q3":         cm.stats.q3,
                    "min":        cm.stats.min,
                    "max":        cm.stats.max,
                    "iqr":        cm.stats.iqr,
                    "n_clean":    cm.stats.clean_count,
                    "n_excluded": cm.stats.excluded_count,
                    "excluded_tickers": cm.stats.excluded_tickers,
                },
                "implied": {
                    "at_median": {
                        "ev":    cm.implied_at_median.implied_ev,
                        "equity": cm.implied_at_median.implied_equity_value,
                        "price":  cm.implied_at_median.implied_share_price,
                        "formula": cm.implied_at_median.formula_display(),
                    },
                    "at_mean": {
                        "ev":    cm.implied_at_mean.implied_ev,
                        "equity": cm.implied_at_mean.implied_equity_value,
                        "price":  cm.implied_at_mean.implied_share_price,
                    },
                    "at_q1": {
                        "price": cm.implied_at_q1.implied_share_price,
                    },
                    "at_q3": {
                        "price": cm.implied_at_q3.implied_share_price,
                    },
                },
                "is_reliable": cm.is_reliable,
                "clean_tickers": cm.clean_tickers,
                "price_range": list(cm.price_range),
            }
            for mt_key, cm in r.multiples.items()
        },
        "peer_table": [
            {
                "ticker":            row.ticker,
                "company_name":      row.company_name,
                "market_cap":        row.market_cap,
                "enterprise_value":  row.enterprise_value,
                "ev_revenue":        row.ev_revenue,
                "ev_ebitda":         row.ev_ebitda,
                "ev_ebit":           row.ev_ebit,
                "pe_ratio":          row.pe_ratio,
                "pb_ratio":          row.pb_ratio,
                "revenue_growth_1y": row.revenue_growth_1y,
                "ebitda_margin":     row.ebitda_margin,
                "is_excluded":       row.is_excluded,
                "exclusion_reasons": row.exclusion_reasons,
            }
            for row in r.peer_table
        ],
        "football_field_ranges": r.to_football_field_ranges(current_price),
        "warnings": r.warnings,
    }


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.post("/comps/{ticker}")
async def run_comps(
    ticker: str,
    req: CompsRequest,
    historical_years: int = Query(default=3, ge=1, le=5),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """
    Run a full Trading Comparables analysis for a company.

    Automatically fetches peer multiples from the data layer (FMP screener),
    then runs the full comps engine: cleaning → statistics → implied values.
    """
    ticker = ticker.upper()

    # ── Fetch bundle + build subject metrics ──────────────────────────────
    bundle, subject = await _fetch_bundle_and_subject(
        ticker, data_router, req.subject_overrides, historical_years
    )

    # ── Fetch peer multiples via DataRouter ───────────────────────────────
    peer_response = await data_router.get_peer_multiples(ticker, max_peers=req.max_peers)
    if peer_response.status == "error" or not peer_response.data:
        log.warning("comps.route.no_peers", ticker=ticker)
        peers: list[PeerData] = []
    else:
        peers = [peer_multiple_to_peer_data(pm) for pm in peer_response.data]

    # ── Run engine ────────────────────────────────────────────────────────
    engine = CompsEngine(iqr_multiplier=req.iqr_multiplier)
    try:
        result = engine.run(subject=subject, peers=peers)
    except Exception as exc:
        log.error("comps.route.error", ticker=ticker, error=str(exc), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Comps analysis failed: {exc}")

    current_price = bundle.market_data.current_price
    return _result_to_response(result, ticker, current_price)


@router.post("/comps/{ticker}/custom")
async def run_comps_custom(
    ticker: str,
    req: CustomCompsRequest,
    historical_years: int = Query(default=3, ge=1, le=5),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """
    Run comps with analyst-provided peer multiples.

    Useful when the analyst wants to handpick a specific peer set
    rather than using the automatically screened comparables.
    """
    ticker = ticker.upper()

    bundle, subject = await _fetch_bundle_and_subject(
        ticker, data_router, req.subject_overrides, historical_years
    )

    peers = [
        PeerData(
            ticker=p.ticker.upper(),
            company_name=p.company_name,
            sector=p.sector,
            industry=p.industry,
            ev_revenue=p.ev_revenue,
            ev_ebitda=p.ev_ebitda,
            ev_ebit=p.ev_ebit,
            pe_ratio=p.pe_ratio,
            pb_ratio=p.pb_ratio,
        )
        for p in req.peers
    ]

    engine = CompsEngine(iqr_multiplier=req.iqr_multiplier)
    try:
        result = engine.run(subject=subject, peers=peers)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Comps analysis failed: {exc}")

    current_price = bundle.market_data.current_price
    return _result_to_response(result, ticker, current_price)
