"""
api/routes/company.py
---------------------
Financial data endpoints for the company data layer.

Routes:
  GET /company/search?q={query}                    — ticker/name search
  GET /company/{ticker}/profile                    — company metadata
  GET /company/{ticker}/market-data                — price, beta, EV, shares
  GET /company/{ticker}/income-statements          — income statement history
  GET /company/{ticker}/balance-sheets             — balance sheet history
  GET /company/{ticker}/cash-flows                 — cash flow history
  GET /company/{ticker}/peers                      — comparable companies
  GET /company/{ticker}/bundle                     — all financials in one call
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from api.dependencies import get_data_router
from data import DataRouter
from data.models.responses import DataResponse, FinancialsBundle

router = APIRouter()


@router.get("/company/search")
async def search_companies(
    q: str = Query(..., min_length=1, max_length=100, description="Ticker or company name"),
    limit: int = Query(default=10, ge=1, le=50),
    data_router: DataRouter = Depends(get_data_router),
) -> list[dict]:
    """Search for companies by ticker symbol or name."""
    results = await data_router.search_companies(q, limit)
    return [r.model_dump() for r in results]


@router.get("/company/{ticker}/profile")
async def get_company_profile(
    ticker: str,
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """Fetch company metadata: sector, industry, description, employees."""
    response = await data_router.get_company_profile(ticker.upper())
    return response.model_dump()


@router.get("/company/{ticker}/market-data")
async def get_market_data(
    ticker: str,
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """Fetch real-time market data: price, market cap, EV, beta, multiples."""
    response = await data_router.get_market_data(ticker.upper())
    return response.model_dump()


@router.get("/company/{ticker}/income-statements")
async def get_income_statements(
    ticker: str,
    years: int = Query(default=5, ge=1, le=10),
    quarterly: bool = Query(default=False),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """Fetch income statement history (annual or quarterly)."""
    response = await data_router.get_income_statements(
        ticker.upper(), years=years, quarterly=quarterly
    )
    return response.model_dump()


@router.get("/company/{ticker}/balance-sheets")
async def get_balance_sheets(
    ticker: str,
    years: int = Query(default=5, ge=1, le=10),
    quarterly: bool = Query(default=False),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """Fetch balance sheet history."""
    response = await data_router.get_balance_sheets(
        ticker.upper(), years=years, quarterly=quarterly
    )
    return response.model_dump()


@router.get("/company/{ticker}/cash-flows")
async def get_cash_flows(
    ticker: str,
    years: int = Query(default=5, ge=1, le=10),
    quarterly: bool = Query(default=False),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """Fetch cash flow statement history."""
    response = await data_router.get_cash_flow_statements(
        ticker.upper(), years=years, quarterly=quarterly
    )
    return response.model_dump()


@router.get("/company/{ticker}/peers")
async def get_peers(
    ticker: str,
    max_peers: int = Query(default=10, ge=1, le=25),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """Fetch peer comparable companies with trading multiples."""
    response = await data_router.get_peer_multiples(ticker.upper(), max_peers=max_peers)
    return response.model_dump()


@router.get("/company/{ticker}/bundle")
async def get_financials_bundle(
    ticker: str,
    years: int = Query(default=5, ge=1, le=10),
    data_router: DataRouter = Depends(get_data_router),
) -> dict:
    """
    Fetch complete financial data bundle for a company.
    This is the primary endpoint for the valuation engine —
    returns profile, market data, and all three financial statements
    in a single response.
    """
    bundle = await data_router.get_financials_bundle(ticker.upper(), years=years)
    return bundle.model_dump()
