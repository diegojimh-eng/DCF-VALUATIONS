"""
logger.py
---------
Structured logging — structlog when available, stdlib fallback otherwise.

Usage:
    from logger import get_logger, setup_logging
    log = get_logger(__name__)
    log.info("data.fetch.start", ticker="AAPL", provider="fmp")
"""
from __future__ import annotations

import logging
import sys
from typing import Any

# ── Try structlog; fall back to stdlib ────────────────────────────────────────
try:
    import structlog  # type: ignore[import]

    def setup_logging(development: bool = True) -> None:
        shared_processors = [
            structlog.contextvars.merge_contextvars,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
        ]
        if development:
            processors = shared_processors + [
                structlog.dev.ConsoleRenderer(colors=True),
            ]
        else:
            processors = shared_processors + [
                structlog.processors.dict_tracebacks,
                structlog.processors.JSONRenderer(),
            ]

        structlog.configure(
            processors=processors,
            wrapper_class=structlog.make_filtering_bound_logger(logging.DEBUG),
            context_class=dict,
            logger_factory=structlog.PrintLoggerFactory(),
            cache_logger_on_first_use=True,
        )
        logging.basicConfig(
            format="%(message)s",
            stream=sys.stdout,
            level=logging.DEBUG,
        )

    def get_logger(name: str) -> Any:
        return structlog.get_logger(name)

    _USING_STRUCTLOG = True

except ImportError:
    # stdlib fallback — identical call signature so callers need no changes

    def setup_logging(development: bool = True) -> None:  # type: ignore[misc]
        level = logging.DEBUG if development else logging.INFO
        logging.basicConfig(
            format="%(asctime)s %(levelname)-8s %(name)s  %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
            stream=sys.stdout,
            level=level,
        )

    class _StdlibLogger:
        """
        Thin wrapper over logging.Logger that accepts keyword-argument
        extra context the same way structlog does.
        """
        def __init__(self, name: str) -> None:
            self._log = logging.getLogger(name)

        def _fmt(self, event: str, **kw: Any) -> str:
            if kw:
                pairs = " ".join(f"{k}={v!r}" for k, v in kw.items())
                return f"{event}  {pairs}"
            return event

        def debug(self, event: str, **kw: Any) -> None:
            self._log.debug(self._fmt(event, **kw))

        def info(self, event: str, **kw: Any) -> None:
            self._log.info(self._fmt(event, **kw))

        def warning(self, event: str, **kw: Any) -> None:
            self._log.warning(self._fmt(event, **kw))

        warn = warning

        def error(self, event: str, exc_info: bool = False, **kw: Any) -> None:
            self._log.error(self._fmt(event, **kw), exc_info=exc_info)

        def critical(self, event: str, **kw: Any) -> None:
            self._log.critical(self._fmt(event, **kw))

    def get_logger(name: str) -> "_StdlibLogger":  # type: ignore[misc]
        return _StdlibLogger(name)

    _USING_STRUCTLOG = False
