"""
tests/valuation/terminal/test_gordon_growth.py
-----------------------------------------------
Comprehensive tests for GordonGrowthModel.
"""

from __future__ import annotations

import pytest
from valuation.terminal.gordon_growth import GordonGrowthModel, GGMResult

WACC  = 0.09
G     = 0.025
FCFF  = 193_931_000_000   # terminal year FCFF (AAPL-scale)
N     = 10


@pytest.fixture
def ggm() -> GordonGrowthModel:
    return GordonGrowthModel()


# ══════════════════════════════════════════════════════════════════════════════
# Core formula
# ══════════════════════════════════════════════════════════════════════════════

class TestGGMFormula:

    def test_terminal_value_formula_exact(self, ggm: GordonGrowthModel) -> None:
        """TV = FCFF_N × (1+g) / (WACC−g)."""
        result = ggm.compute(FCFF, WACC, G, N)
        expected = FCFF * (1.0 + G) / (WACC - G)
        assert result.terminal_value == pytest.approx(expected, rel=1e-9)

    def test_pv_tv_formula_exact(self, ggm: GordonGrowthModel) -> None:
        """PV(TV) = TV / (1 + WACC)^N."""
        result = ggm.compute(FCFF, WACC, G, N)
        expected_pv = result.terminal_value / (1.0 + WACC) ** N
        assert result.pv_terminal_value == pytest.approx(expected_pv, rel=1e-9)

    def test_wacc_g_spread_recorded(self, ggm: GordonGrowthModel) -> None:
        result = ggm.compute(FCFF, WACC, G, N)
        assert result.wacc_g_spread == pytest.approx(WACC - G, rel=1e-9)

    def test_tv_to_fcff_multiple_correct(self, ggm: GordonGrowthModel) -> None:
        result = ggm.compute(FCFF, WACC, G, N)
        expected = result.terminal_value / FCFF
        assert result.tv_to_fcff_multiple == pytest.approx(expected, rel=1e-6)

    def test_higher_g_gives_higher_tv(self, ggm: GordonGrowthModel) -> None:
        r_low  = ggm.compute(FCFF, WACC, 0.020, N)
        r_high = ggm.compute(FCFF, WACC, 0.030, N)
        assert r_high.terminal_value > r_low.terminal_value

    def test_higher_wacc_gives_lower_tv(self, ggm: GordonGrowthModel) -> None:
        r_low  = ggm.compute(FCFF, 0.08, G, N)
        r_high = ggm.compute(FCFF, 0.12, G, N)
        assert r_low.terminal_value > r_high.terminal_value

    def test_higher_n_gives_lower_pv_tv(self, ggm: GordonGrowthModel) -> None:
        r5  = ggm.compute(FCFF, WACC, G, forecast_years=5)
        r10 = ggm.compute(FCFF, WACC, G, forecast_years=10)
        assert r5.pv_terminal_value > r10.pv_terminal_value

    def test_negative_fcff_gives_negative_tv(self, ggm: GordonGrowthModel) -> None:
        result = ggm.compute(-FCFF, WACC, G, N)
        assert result.terminal_value < 0

    def test_zero_growth_still_computes(self, ggm: GordonGrowthModel) -> None:
        """g=0 is valid: TV = FCFF_N / WACC."""
        result = ggm.compute(FCFF, WACC, 0.0, N)
        expected = FCFF / WACC
        assert result.terminal_value == pytest.approx(expected, rel=1e-6)

    def test_negative_growth_still_computes(self, ggm: GordonGrowthModel) -> None:
        """g<0 (shrinking terminal) is valid and gives lower TV."""
        result_zero = ggm.compute(FCFF, WACC, 0.0, N)
        result_neg  = ggm.compute(FCFF, WACC, -0.01, N)
        assert result_neg.terminal_value < result_zero.terminal_value


# ══════════════════════════════════════════════════════════════════════════════
# Constraints (must raise)
# ══════════════════════════════════════════════════════════════════════════════

class TestGGMConstraints:

    def test_wacc_equals_g_raises(self, ggm: GordonGrowthModel) -> None:
        with pytest.raises(ValueError, match="must exceed"):
            ggm.compute(FCFF, wacc=0.05, terminal_growth_rate=0.05, forecast_years=N)

    def test_wacc_below_min_spread_raises(self, ggm: GordonGrowthModel) -> None:
        """WACC − g = 20 bps < min_spread (30 bps)."""
        with pytest.raises(ValueError):
            ggm.compute(FCFF, wacc=0.05, terminal_growth_rate=0.048, forecast_years=N)

    def test_g_exceeds_wacc_raises(self, ggm: GordonGrowthModel) -> None:
        with pytest.raises(ValueError):
            ggm.compute(FCFF, wacc=0.05, terminal_growth_rate=0.06, forecast_years=N)

    def test_custom_min_spread_respected(self) -> None:
        """Custom min_spread=1% means a 50 bps spread is now invalid."""
        strict_ggm = GordonGrowthModel(min_spread=0.01)
        with pytest.raises(ValueError):
            strict_ggm.compute(FCFF, wacc=0.05, terminal_growth_rate=0.046, forecast_years=N)


# ══════════════════════════════════════════════════════════════════════════════
# Soft warnings
# ══════════════════════════════════════════════════════════════════════════════

class TestGGMWarnings:

    def test_no_warnings_for_normal_inputs(self, ggm: GordonGrowthModel) -> None:
        result = ggm.compute(FCFF, WACC, G, N)
        assert result.warnings == []

    def test_warns_when_g_exceeds_gdp_ceiling(self, ggm: GordonGrowthModel) -> None:
        result = ggm.compute(FCFF, WACC, terminal_growth_rate=0.04, forecast_years=N)
        assert any("nominal GDP" in w for w in result.warnings)

    def test_warns_when_g_exceeds_risk_free_rate(self, ggm: GordonGrowthModel) -> None:
        result = ggm.compute(
            FCFF, WACC, terminal_growth_rate=G, forecast_years=N, risk_free_rate=0.02
        )
        assert any("risk-free rate" in w for w in result.warnings)

    def test_warns_on_narrow_spread(self, ggm: GordonGrowthModel) -> None:
        """Spread of 100 bps → narrow spread warning."""
        result = ggm.compute(FCFF, wacc=0.05, terminal_growth_rate=0.04, forecast_years=N)
        assert any("narrow" in w.lower() or "sensitive" in w.lower() for w in result.warnings)

    def test_warns_on_negative_fcff(self, ggm: GordonGrowthModel) -> None:
        result = ggm.compute(-FCFF, WACC, G, N)
        assert any("negative" in w.lower() for w in result.warnings)

    def test_risk_free_rate_none_no_rf_warning(self, ggm: GordonGrowthModel) -> None:
        result = ggm.compute(FCFF, WACC, G, N, risk_free_rate=None)
        assert not any("risk-free" in w for w in result.warnings)


# ══════════════════════════════════════════════════════════════════════════════
# Implied growth rate (reverse GGM)
# ══════════════════════════════════════════════════════════════════════════════

class TestImpliedGrowthRate:

    def test_round_trip_consistency(self, ggm: GordonGrowthModel) -> None:
        """Compute TV from g, then reverse to recover g."""
        result = ggm.compute(FCFF, WACC, G, N)
        tv     = result.terminal_value
        g_back = ggm.implied_growth_rate(tv, FCFF, WACC)
        assert g_back == pytest.approx(G, rel=1e-6)

    def test_higher_tv_implies_higher_g(self, ggm: GordonGrowthModel) -> None:
        g_low  = ggm.implied_growth_rate(1_000_000_000_000, FCFF, WACC)
        g_high = ggm.implied_growth_rate(3_000_000_000_000, FCFF, WACC)
        assert g_high > g_low

    def test_negative_tv_gives_implied_negative_g(self, ggm: GordonGrowthModel) -> None:
        g = ggm.implied_growth_rate(-500_000_000_000, FCFF, WACC)
        assert g < 0

    def test_degenerate_case_raises(self, ggm: GordonGrowthModel) -> None:
        """TV + FCFF_N ≈ 0 → undefined."""
        with pytest.raises(ValueError):
            ggm.implied_growth_rate(-FCFF, FCFF, WACC)


# ══════════════════════════════════════════════════════════════════════════════
# Sensitivity sweep
# ══════════════════════════════════════════════════════════════════════════════

class TestSensitivitySweep:

    def test_sweep_returns_results_for_valid_g(self, ggm: GordonGrowthModel) -> None:
        g_values = [0.01, 0.02, 0.025, 0.03]
        results = ggm.sensitivity_sweep(FCFF, WACC, N, g_values)
        assert len(results) == 4

    def test_invalid_g_skipped(self, ggm: GordonGrowthModel) -> None:
        """g ≥ WACC cells are skipped (no error)."""
        g_values = [0.02, 0.09, 0.10]   # last two invalid
        results = ggm.sensitivity_sweep(FCFF, WACC, N, g_values)
        assert len(results) == 1   # only 0.02 is valid with spread ≥ 30 bps

    def test_sweep_monotonically_increasing_tv(self, ggm: GordonGrowthModel) -> None:
        g_values = [0.01, 0.02, 0.03, 0.04]
        results = ggm.sensitivity_sweep(FCFF, WACC, N, g_values)
        tvs = [r.terminal_value for r in results]
        assert tvs == sorted(tvs)

    def test_formula_display_contains_key_terms(self, ggm: GordonGrowthModel) -> None:
        result = ggm.compute(FCFF, WACC, G, N)
        display = result.formula_display()
        assert "FCFF" in display
        assert "WACC" in display
        assert "TV" in display
        assert "PV" in display
