"""
tests/valuation/terminal/test_exit_multiple.py
-----------------------------------------------
Tests for ExitMultipleModel — all metric types, constraints, Damodaran check.
"""

from __future__ import annotations

import pytest
from valuation.terminal.exit_multiple import ExitMetric, ExitMultipleModel, ExitMultipleResult

WACC    = 0.09
EBITDA  = 251_512_000_000   # terminal year EBITDA (AAPL-scale)
EBIT    = EBITDA * 0.90     # approximate (90% of EBITDA after D&A)
REVENUE = EBITDA / 0.30     # approximate (30% EBITDA margin)
FCF     = 193_931_000_000   # terminal year FCF
FCFF    = 193_931_000_000
N       = 10
EM      = 18.0              # typical tech EV/EBITDA multiple


@pytest.fixture
def model() -> ExitMultipleModel:
    return ExitMultipleModel()


# ══════════════════════════════════════════════════════════════════════════════
# EV/EBITDA (most common)
# ══════════════════════════════════════════════════════════════════════════════

class TestEVEBITDA:

    def test_formula_exact(self, model: ExitMultipleModel) -> None:
        """TV = EBITDA_N × multiple."""
        result = model.compute(ExitMetric.EV_EBITDA, EBITDA, EM, WACC, N)
        assert result.terminal_value == pytest.approx(EBITDA * EM, rel=1e-9)

    def test_pv_tv_formula_exact(self, model: ExitMultipleModel) -> None:
        """PV(TV) = TV / (1 + WACC)^N."""
        result = model.compute(ExitMetric.EV_EBITDA, EBITDA, EM, WACC, N)
        expected_pv = result.terminal_value / (1.0 + WACC) ** N
        assert result.pv_terminal_value == pytest.approx(expected_pv, rel=1e-9)

    def test_higher_multiple_gives_higher_tv(self, model: ExitMultipleModel) -> None:
        r_low  = model.compute(ExitMetric.EV_EBITDA, EBITDA, 15.0, WACC, N)
        r_high = model.compute(ExitMetric.EV_EBITDA, EBITDA, 22.0, WACC, N)
        assert r_high.terminal_value > r_low.terminal_value

    def test_higher_ebitda_gives_higher_tv(self, model: ExitMultipleModel) -> None:
        r_low  = model.compute(ExitMetric.EV_EBITDA, EBITDA * 0.5, EM, WACC, N)
        r_high = model.compute(ExitMetric.EV_EBITDA, EBITDA,       EM, WACC, N)
        assert r_high.terminal_value > r_low.terminal_value

    def test_negative_ebitda_raises(self, model: ExitMultipleModel) -> None:
        with pytest.raises(ValueError, match="non-positive"):
            model.compute(ExitMetric.EV_EBITDA, -EBITDA, EM, WACC, N)

    def test_zero_multiple_raises(self, model: ExitMultipleModel) -> None:
        with pytest.raises(ValueError, match="positive"):
            model.compute(ExitMetric.EV_EBITDA, EBITDA, 0.0, WACC, N)


# ══════════════════════════════════════════════════════════════════════════════
# EV/EBIT
# ══════════════════════════════════════════════════════════════════════════════

class TestEVEBIT:

    def test_ev_ebit_formula(self, model: ExitMultipleModel) -> None:
        result = model.compute(ExitMetric.EV_EBIT, EBIT, 20.0, WACC, N)
        assert result.terminal_value == pytest.approx(EBIT * 20.0, rel=1e-9)

    def test_ebit_metric_stored(self, model: ExitMultipleModel) -> None:
        result = model.compute(ExitMetric.EV_EBIT, EBIT, 20.0, WACC, N)
        assert result.metric == ExitMetric.EV_EBIT
        assert result.metric_value == pytest.approx(EBIT)


# ══════════════════════════════════════════════════════════════════════════════
# EV/Revenue
# ══════════════════════════════════════════════════════════════════════════════

class TestEVRevenue:

    def test_ev_revenue_formula(self, model: ExitMultipleModel) -> None:
        result = model.compute(ExitMetric.EV_REVENUE, REVENUE, 7.0, WACC, N)
        assert result.terminal_value == pytest.approx(REVENUE * 7.0, rel=1e-9)

    def test_ev_revenue_no_raise_on_zero_if_method_allows(
        self, model: ExitMultipleModel
    ) -> None:
        """EV/Revenue with zero revenue — warns, doesn't raise."""
        result = model.compute(ExitMetric.EV_REVENUE, 0.0, 7.0, WACC, N)
        assert result.terminal_value == pytest.approx(0.0)
        assert any(w for w in result.warnings)


# ══════════════════════════════════════════════════════════════════════════════
# P/FCF
# ══════════════════════════════════════════════════════════════════════════════

class TestPriceFCF:

    def test_price_fcf_formula(self, model: ExitMultipleModel) -> None:
        result = model.compute(ExitMetric.PRICE_FCF, FCF, 25.0, WACC, N)
        assert result.terminal_value == pytest.approx(FCF * 25.0, rel=1e-9)


# ══════════════════════════════════════════════════════════════════════════════
# Implied growth rate
# ══════════════════════════════════════════════════════════════════════════════

class TestImpliedGrowthRate:

    def test_implied_g_computed_when_fcff_provided(
        self, model: ExitMultipleModel
    ) -> None:
        result = model.compute(
            ExitMetric.EV_EBITDA, EBITDA, EM, WACC, N, fcff_terminal=FCFF
        )
        assert result.implied_growth_rate is not None

    def test_implied_g_reverse_formula(self, model: ExitMultipleModel) -> None:
        """g = (TV × WACC − FCFF_N) / (TV + FCFF_N)."""
        result = model.compute(
            ExitMetric.EV_EBITDA, EBITDA, EM, WACC, N, fcff_terminal=FCFF
        )
        tv = result.terminal_value
        expected_g = (tv * WACC - FCFF) / (tv + FCFF)
        assert result.implied_growth_rate == pytest.approx(expected_g, rel=1e-6)

    def test_no_implied_g_without_fcff(self, model: ExitMultipleModel) -> None:
        result = model.compute(ExitMetric.EV_EBITDA, EBITDA, EM, WACC, N)
        assert result.implied_growth_rate is None


# ══════════════════════════════════════════════════════════════════════════════
# Peer range validation
# ══════════════════════════════════════════════════════════════════════════════

class TestPeerRange:

    def test_multiple_within_peer_range_no_warning(
        self, model: ExitMultipleModel
    ) -> None:
        result = model.compute(
            ExitMetric.EV_EBITDA, EBITDA, 18.0, WACC, N, peer_range=(15.0, 22.0)
        )
        peer_warnings = [w for w in result.warnings if "peer range" in w.lower()]
        assert len(peer_warnings) == 0

    def test_multiple_below_peer_range_warns(self, model: ExitMultipleModel) -> None:
        result = model.compute(
            ExitMetric.EV_EBITDA, EBITDA, 10.0, WACC, N, peer_range=(15.0, 22.0)
        )
        assert any("below" in w for w in result.warnings)

    def test_multiple_above_peer_range_warns(self, model: ExitMultipleModel) -> None:
        result = model.compute(
            ExitMetric.EV_EBITDA, EBITDA, 30.0, WACC, N, peer_range=(15.0, 22.0)
        )
        assert any("above" in w for w in result.warnings)


# ══════════════════════════════════════════════════════════════════════════════
# Damodaran consistency check
# ══════════════════════════════════════════════════════════════════════════════

class TestDamodaranCheck:

    def test_check_returns_dict(self, model: ExitMultipleModel) -> None:
        result = model.damodaran_consistency_check(
            exit_ebitda_multiple=18.0,
            wacc=WACC,
            terminal_growth_rate=0.025,
            ebitda_margin_terminal=0.30,
            tax_rate=0.25,
        )
        assert "implied_multiple" in result
        assert "your_multiple" in result
        assert "is_consistent" in result
        assert "gap_pct" in result

    def test_check_formula_approximate(self, model: ExitMultipleModel) -> None:
        """Implied ≈ (1−t) × (1+g) / [(WACC−g) × EBITDA_margin]."""
        g     = 0.025
        spread = WACC - g
        t     = 0.25
        margin = 0.30
        expected_implied = (1.0 - t) * (1.0 + g) / (spread * margin)
        result = model.damodaran_consistency_check(
            exit_ebitda_multiple=expected_implied,   # using the exact implied value
            wacc=WACC,
            terminal_growth_rate=g,
            ebitda_margin_terminal=margin,
            tax_rate=t,
        )
        assert result["gap_pct"] == pytest.approx(0.0, abs=0.001)
        assert result["is_consistent"] is True

    def test_zero_spread_returns_inconsistent(self, model: ExitMultipleModel) -> None:
        result = model.damodaran_consistency_check(
            exit_ebitda_multiple=18.0,
            wacc=0.025,
            terminal_growth_rate=0.025,  # spread = 0
            ebitda_margin_terminal=0.30,
            tax_rate=0.25,
        )
        assert result["implied_multiple"] is None
        assert result["is_consistent"] is False

    def test_high_multiple_flags_inconsistency(self, model: ExitMultipleModel) -> None:
        result = model.damodaran_consistency_check(
            exit_ebitda_multiple=50.0,   # extremely high
            wacc=WACC,
            terminal_growth_rate=0.025,
            ebitda_margin_terminal=0.30,
            tax_rate=0.25,
        )
        assert result["is_consistent"] is False

    def test_high_ebitda_multiple_warns(self, model: ExitMultipleModel) -> None:
        result = model.compute(ExitMetric.EV_EBITDA, EBITDA, 35.0, WACC, N)
        assert any("high" in w.lower() for w in result.warnings)


# ══════════════════════════════════════════════════════════════════════════════
# Sensitivity sweep
# ══════════════════════════════════════════════════════════════════════════════

class TestSensitivitySweep:

    def test_sweep_correct_count(self, model: ExitMultipleModel) -> None:
        multiples = [14.0, 16.0, 18.0, 20.0, 22.0]
        results = model.sensitivity_sweep(ExitMetric.EV_EBITDA, EBITDA, WACC, N, multiples)
        assert len(results) == 5

    def test_sweep_monotonic_tv(self, model: ExitMultipleModel) -> None:
        multiples = [14.0, 16.0, 18.0, 20.0]
        results = model.sensitivity_sweep(ExitMetric.EV_EBITDA, EBITDA, WACC, N, multiples)
        tvs = [r.terminal_value for r in results]
        assert tvs == sorted(tvs)

    def test_formula_display_includes_metric(self, model: ExitMultipleModel) -> None:
        result = model.compute(ExitMetric.EV_EBITDA, EBITDA, EM, WACC, N)
        display = result.formula_display()
        assert "EV/EBITDA" in display
        assert "Exit Multiple" in display
