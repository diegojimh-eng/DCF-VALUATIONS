"""
tests/valuation/terminal/test_blender_sensitivity_selector.py
--------------------------------------------------------------
Tests for TVBlender, TVSensitivityAnalyser, TVComparison, and TVSelector.
"""

from __future__ import annotations

import pytest

from valuation.terminal.blender import BlendMode, BlendedTVResult, TVBlender
from valuation.terminal.comparison import TVComparison, TVComparisonResult
from valuation.terminal.exit_multiple import ExitMetric, ExitMultipleModel
from valuation.terminal.gordon_growth import GordonGrowthModel
from valuation.terminal.selector import TVSelectionInputs, TVSelector
from valuation.terminal.tv_sensitivity import TVSensitivityAnalyser

WACC   = 0.09
G      = 0.025
FCFF   = 193_931_000_000
EBITDA = 251_512_000_000
N      = 10
EM     = 18.0


@pytest.fixture
def ggm_result():
    return GordonGrowthModel().compute(FCFF, WACC, G, N)


@pytest.fixture
def exit_result():
    return ExitMultipleModel().compute(ExitMetric.EV_EBITDA, EBITDA, EM, WACC, N, FCFF)


@pytest.fixture
def blender() -> TVBlender:
    return TVBlender()


# ══════════════════════════════════════════════════════════════════════════════
# TVBlender
# ══════════════════════════════════════════════════════════════════════════════

class TestTVBlender:

    def test_ggm_only_mode(self, blender: TVBlender, ggm_result, exit_result) -> None:
        result = blender.blend(ggm_result, exit_result, BlendMode.GGM_ONLY)
        assert result.terminal_value == pytest.approx(ggm_result.terminal_value, rel=1e-6)
        assert result.weight_ggm == pytest.approx(1.0)
        assert result.weight_exit == pytest.approx(0.0)

    def test_exit_only_mode(self, blender: TVBlender, ggm_result, exit_result) -> None:
        result = blender.blend(ggm_result, exit_result, BlendMode.EXIT_ONLY)
        assert result.terminal_value == pytest.approx(exit_result.terminal_value, rel=1e-6)
        assert result.weight_exit == pytest.approx(1.0)

    def test_equal_mode_is_arithmetic_mean(
        self, blender: TVBlender, ggm_result, exit_result
    ) -> None:
        result = blender.blend(ggm_result, exit_result, BlendMode.EQUAL)
        expected = (ggm_result.terminal_value + exit_result.terminal_value) / 2.0
        assert result.terminal_value == pytest.approx(expected, rel=1e-6)
        assert result.weight_ggm == pytest.approx(0.5)
        assert result.weight_exit == pytest.approx(0.5)

    def test_custom_weights_weighted_correctly(
        self, blender: TVBlender, ggm_result, exit_result
    ) -> None:
        result = blender.blend(
            ggm_result, exit_result, BlendMode.CUSTOM, weight_ggm=0.7, weight_exit=0.3
        )
        expected = 0.7 * ggm_result.terminal_value + 0.3 * exit_result.terminal_value
        assert result.terminal_value == pytest.approx(expected, rel=1e-6)

    def test_custom_weights_must_sum_to_one(
        self, blender: TVBlender, ggm_result, exit_result
    ) -> None:
        with pytest.raises(ValueError, match="sum to 1.0"):
            blender.blend(
                ggm_result, exit_result, BlendMode.CUSTOM, weight_ggm=0.7, weight_exit=0.5
            )

    def test_custom_mode_requires_weights(
        self, blender: TVBlender, ggm_result, exit_result
    ) -> None:
        with pytest.raises(ValueError, match="must be provided"):
            blender.blend(ggm_result, exit_result, BlendMode.CUSTOM)

    def test_pv_blended_is_weighted_sum_of_pvs(
        self, blender: TVBlender, ggm_result, exit_result
    ) -> None:
        result = blender.blend(ggm_result, exit_result, BlendMode.EQUAL)
        expected_pv = 0.5 * ggm_result.pv_terminal_value + 0.5 * exit_result.pv_terminal_value
        assert result.pv_terminal_value == pytest.approx(expected_pv, rel=1e-6)

    def test_divergence_computed_when_both_present(
        self, blender: TVBlender, ggm_result, exit_result
    ) -> None:
        result = blender.blend(ggm_result, exit_result, BlendMode.EQUAL)
        assert result.tv_method_divergence_pct is not None

    def test_divergence_none_when_one_method_only(
        self, blender: TVBlender, ggm_result
    ) -> None:
        result = blender.blend(ggm_result, None, BlendMode.GGM_ONLY)
        assert result.tv_method_divergence_pct is None

    def test_large_divergence_warns(self, blender: TVBlender) -> None:
        """When GGM and Exit differ by >25%, blender should warn."""
        # Force very different TVs
        ggm = GordonGrowthModel().compute(FCFF, WACC, G, N)
        # Exit at a tiny multiple to force large divergence
        exit_ = ExitMultipleModel().compute(ExitMetric.EV_EBITDA, EBITDA, 1.0, WACC, N)
        result = blender.blend(ggm, exit_, BlendMode.EQUAL)
        if result.tv_method_divergence_pct and result.tv_method_divergence_pct > 0.25:
            assert any("diverge" in w.lower() for w in result.warnings)

    def test_formula_display_contains_mode(
        self, blender: TVBlender, ggm_result, exit_result
    ) -> None:
        result = blender.blend(ggm_result, exit_result, BlendMode.EQUAL)
        display = result.formula_display()
        assert "Blended Terminal Value" in display
        assert "Weight" in display

    def test_compute_and_blend_ggm_only(self, blender: TVBlender) -> None:
        result = blender.compute_and_blend(
            fcff_terminal=FCFF, wacc=WACC,
            terminal_growth_rate=G, forecast_years=N,
            mode=BlendMode.GGM_ONLY,
        )
        assert result.weight_ggm == pytest.approx(1.0)
        assert result.terminal_value > 0

    def test_compute_and_blend_missing_exit_raises(self, blender: TVBlender) -> None:
        with pytest.raises(ValueError, match="required"):
            blender.compute_and_blend(
                fcff_terminal=FCFF, wacc=WACC,
                terminal_growth_rate=G, forecast_years=N,
                mode=BlendMode.EXIT_ONLY,
                # no exit inputs provided
            )


# ══════════════════════════════════════════════════════════════════════════════
# TVSensitivityAnalyser
# ══════════════════════════════════════════════════════════════════════════════

class TestTVSensitivityAnalyser:

    @pytest.fixture
    def analyser(self) -> TVSensitivityAnalyser:
        return TVSensitivityAnalyser()

    def test_wacc_vs_g_grid_built(self, analyser: TVSensitivityAnalyser) -> None:
        report = analyser.compute_all(
            ticker="AAPL", fcff_terminal=FCFF, ebitda_terminal=EBITDA,
            wacc=WACC, terminal_growth_rate=G, forecast_years=N,
            wacc_steps=2, g_steps=1,
        )
        grid = report.wacc_vs_g
        assert grid.grid_type == "wacc_vs_g"
        assert len(grid.grid) == 5        # 2 steps each side + base = 5

    def test_exit_grids_built_when_multiple_provided(
        self, analyser: TVSensitivityAnalyser
    ) -> None:
        report = analyser.compute_all(
            ticker="AAPL", fcff_terminal=FCFF, ebitda_terminal=EBITDA,
            wacc=WACC, terminal_growth_rate=G, forecast_years=N,
            exit_multiple=EM, wacc_steps=2, g_steps=1, multiple_steps=2,
        )
        assert report.multiple_vs_wacc is not None
        assert report.wacc_vs_multiple is not None

    def test_no_exit_grids_without_multiple(
        self, analyser: TVSensitivityAnalyser
    ) -> None:
        report = analyser.compute_all(
            ticker="AAPL", fcff_terminal=FCFF, ebitda_terminal=EBITDA,
            wacc=WACC, terminal_growth_rate=G, forecast_years=N,
            exit_multiple=None,
        )
        assert report.multiple_vs_wacc is None
        assert report.wacc_vs_multiple is None

    def test_wacc_vs_g_base_cell_flagged(self, analyser: TVSensitivityAnalyser) -> None:
        report = analyser.compute_all(
            ticker="AAPL", fcff_terminal=FCFF, ebitda_terminal=EBITDA,
            wacc=WACC, terminal_growth_rate=G, forecast_years=N,
            wacc_steps=2, g_steps=1,
        )
        base_cells = [c for row in report.wacc_vs_g.grid for c in row if c.is_base_case]
        assert len(base_cells) == 1

    def test_higher_wacc_lower_pv_tv_in_grid(self, analyser: TVSensitivityAnalyser) -> None:
        report = analyser.compute_all(
            ticker="AAPL", fcff_terminal=FCFF, ebitda_terminal=EBITDA,
            wacc=WACC, terminal_growth_rate=G, forecast_years=N,
            wacc_steps=3, g_steps=1,
        )
        grid = report.wacc_vs_g
        col_idx = 0  # fix growth, vary WACC
        pvs = [row[col_idx].pv_terminal_value for row in grid.grid if row[col_idx].pv_terminal_value > 0]
        assert pvs == sorted(pvs, reverse=True)   # descending as WACC increases

    def test_to_dict_has_wacc_vs_g_key(self, analyser: TVSensitivityAnalyser) -> None:
        report = analyser.compute_all(
            ticker="AAPL", fcff_terminal=FCFF, ebitda_terminal=EBITDA,
            wacc=WACC, terminal_growth_rate=G, forecast_years=N,
        )
        d = report.to_dict()
        assert "wacc_vs_g" in d


# ══════════════════════════════════════════════════════════════════════════════
# TVComparison
# ══════════════════════════════════════════════════════════════════════════════

class TestTVComparison:

    @pytest.fixture
    def comparison(self) -> TVComparison:
        return TVComparison()

    def test_comparison_builds_result(
        self, comparison: TVComparison, ggm_result, exit_result
    ) -> None:
        result = comparison.compare(ggm_result, exit_result)
        assert isinstance(result, TVComparisonResult)

    def test_divergence_is_non_negative(
        self, comparison: TVComparison, ggm_result, exit_result
    ) -> None:
        result = comparison.compare(ggm_result, exit_result)
        assert result.tv_divergence_pct >= 0
        assert result.pv_tv_divergence_pct >= 0

    def test_implied_exit_multiple_computed_when_ebitda_provided(
        self, comparison: TVComparison, ggm_result, exit_result
    ) -> None:
        result = comparison.compare(ggm_result, exit_result, ebitda_terminal=EBITDA)
        assert result.implied_exit_multiple_from_ggm is not None
        expected = ggm_result.terminal_value / EBITDA
        assert result.implied_exit_multiple_from_ggm == pytest.approx(expected, rel=1e-6)

    def test_implied_growth_from_exit_present(
        self, comparison: TVComparison, ggm_result, exit_result
    ) -> None:
        # exit_result was computed with fcff_terminal provided
        result = comparison.compare(ggm_result, exit_result)
        assert result.implied_growth_from_exit is not None

    def test_weights_sum_to_one(
        self, comparison: TVComparison, ggm_result, exit_result
    ) -> None:
        result = comparison.compare(ggm_result, exit_result)
        assert (result.recommended_weight_ggm + result.recommended_weight_exit
                == pytest.approx(1.0, rel=1e-6))

    def test_comparison_table_contains_both_methods(
        self, comparison: TVComparison, ggm_result, exit_result
    ) -> None:
        result = comparison.compare(ggm_result, exit_result)
        table = result.comparison_table()
        assert "Gordon Growth" in table
        assert "Exit Multiple" in table
        assert "Divergence" in table

    def test_large_divergence_warns(
        self, comparison: TVComparison
    ) -> None:
        ggm = GordonGrowthModel().compute(FCFF, WACC, G, N)
        exit_ = ExitMultipleModel().compute(ExitMetric.EV_EBITDA, EBITDA, 1.0, WACC, N)
        result = comparison.compare(ggm, exit_)
        if result.tv_divergence_pct > 0.30:
            assert any("diverge" in w.lower() for w in result.all_warnings)


# ══════════════════════════════════════════════════════════════════════════════
# TVSelector (integration)
# ══════════════════════════════════════════════════════════════════════════════

class TestTVSelector:

    @pytest.fixture
    def selector(self) -> TVSelector:
        return TVSelector()

    def _base_inputs(self, method: str = "gordon_growth") -> TVSelectionInputs:
        return TVSelectionInputs(
            fcff_terminal=FCFF,
            wacc=WACC,
            terminal_growth_rate=G,
            forecast_years=N,
            method=method,
            exit_metric=ExitMetric.EV_EBITDA,
            exit_metric_value=EBITDA,
            exit_multiple=EM,
            run_sensitivity=False,   # speed up tests
        )

    def test_gordon_growth_selection(self, selector: TVSelector) -> None:
        result = selector.select(self._base_inputs("gordon_growth"))
        assert result.tv_result.tv_final == pytest.approx(
            FCFF * (1 + G) / (WACC - G), rel=1e-4
        )

    def test_exit_multiple_selection(self, selector: TVSelector) -> None:
        result = selector.select(self._base_inputs("exit_multiple"))
        assert result.tv_result.tv_final == pytest.approx(EBITDA * EM, rel=1e-4)

    def test_average_selection(self, selector: TVSelector) -> None:
        result = selector.select(self._base_inputs("average"))
        ggm_tv  = FCFF * (1 + G) / (WACC - G)
        exit_tv = EBITDA * EM
        expected = (ggm_tv + exit_tv) / 2.0
        assert result.tv_result.tv_final == pytest.approx(expected, rel=1e-4)

    def test_tv_result_is_terminal_value_result_type(self, selector: TVSelector) -> None:
        from valuation.models import TerminalValueResult
        result = selector.select(self._base_inputs())
        assert isinstance(result.tv_result, TerminalValueResult)

    def test_comparison_built_when_both_methods_available(
        self, selector: TVSelector
    ) -> None:
        result = selector.select(self._base_inputs("average"))
        assert result.comparison is not None

    def test_comparison_none_when_only_ggm(self, selector: TVSelector) -> None:
        inputs = TVSelectionInputs(
            fcff_terminal=FCFF, wacc=WACC, terminal_growth_rate=G,
            forecast_years=N, method="gordon_growth",
            exit_metric_value=None, exit_multiple=None,
            run_sensitivity=False,
        )
        result = selector.select(inputs)
        assert result.comparison is None

    def test_sensitivity_report_built_when_enabled(self, selector: TVSelector) -> None:
        inputs = TVSelectionInputs(
            fcff_terminal=FCFF, wacc=WACC, terminal_growth_rate=G,
            forecast_years=N, method="gordon_growth",
            exit_metric_value=EBITDA, exit_multiple=EM,
            run_sensitivity=True,
            wacc_steps=2, g_steps=1,
        )
        result = selector.select(inputs, ticker="AAPL")
        assert result.sensitivity is not None
        assert result.sensitivity.wacc_vs_g is not None

    def test_sensitivity_none_when_disabled(self, selector: TVSelector) -> None:
        result = selector.select(self._base_inputs())
        assert result.sensitivity is None

    def test_invalid_method_raises(self, selector: TVSelector) -> None:
        inputs = self._base_inputs("not_a_method")
        with pytest.raises(ValueError, match="Unknown TV method"):
            selector.select(inputs)

    def test_custom_weights_method(self, selector: TVSelector) -> None:
        inputs = TVSelectionInputs(
            fcff_terminal=FCFF, wacc=WACC, terminal_growth_rate=G,
            forecast_years=N, method="custom_weights",
            exit_metric_value=EBITDA, exit_multiple=EM,
            weight_ggm=0.7, weight_exit=0.3,
            run_sensitivity=False,
        )
        result = selector.select(inputs)
        ggm_tv  = FCFF * (1 + G) / (WACC - G)
        exit_tv = EBITDA * EM
        expected = 0.7 * ggm_tv + 0.3 * exit_tv
        assert result.tv_result.tv_final == pytest.approx(expected, rel=1e-4)

    def test_method_selected_recorded(self, selector: TVSelector) -> None:
        result = selector.select(self._base_inputs("gordon_growth"))
        assert result.method_selected == "gordon_growth"

    def test_ggm_result_present(self, selector: TVSelector) -> None:
        result = selector.select(self._base_inputs("gordon_growth"))
        assert result.ggm_result is not None

    def test_exit_result_present_when_inputs_provided(
        self, selector: TVSelector
    ) -> None:
        result = selector.select(self._base_inputs("average"))
        assert result.exit_result is not None

    def test_formula_display_contains_both_methods(self, selector: TVSelector) -> None:
        result = selector.select(self._base_inputs("average"))
        display = result.formula_display()
        assert "Gordon" in display
        assert "Exit" in display
