"""
tests/valuation/test_wacc.py
-----------------------------
Comprehensive tests for WACCCalculator — covers CAPM formula correctness,
cost of debt derivation, capital structure weights, and all override paths.
"""

from __future__ import annotations

import pytest

from valuation.models import WACCInputs, WACCResult
from valuation.wacc import WACCCalculator
from tests.valuation.conftest import (
    BETA, CASH, ERP, INTEREST_EXPENSE, LONG_TERM_DEBT,
    MARKET_CAP, RISK_FREE_RATE, SHORT_TERM_DEBT, TAX_RATE,
)


@pytest.fixture
def calc() -> WACCCalculator:
    return WACCCalculator()


# ══════════════════════════════════════════════════════════════════════════════
# CAPM — Cost of Equity
# ══════════════════════════════════════════════════════════════════════════════

class TestCostOfEquity:

    def test_capm_formula_exact(self, calc: WACCCalculator, wacc_inputs: WACCInputs) -> None:
        """Ke = Rf + β × ERP."""
        result = calc.compute(wacc_inputs)
        expected_ke = RISK_FREE_RATE + BETA * ERP
        assert result.ke == pytest.approx(expected_ke, rel=1e-6)

    def test_capm_beta_one_equals_rf_plus_erp(self, calc: WACCCalculator) -> None:
        """When β = 1.0, Ke = Rf + ERP (market return)."""
        inputs = WACCInputs(
            beta=1.0,
            market_cap=MARKET_CAP,
            risk_free_rate=0.04,
            equity_risk_premium=0.055,
        )
        result = calc.compute(inputs)
        assert result.ke == pytest.approx(0.04 + 0.055, rel=1e-6)

    def test_beta_none_defaults_to_one(self, calc: WACCCalculator) -> None:
        """Missing beta defaults to 1.0 (market beta)."""
        inputs = WACCInputs(
            beta=None,
            market_cap=MARKET_CAP,
            risk_free_rate=0.04,
            equity_risk_premium=0.055,
        )
        result = calc.compute(inputs)
        assert result.beta_used == pytest.approx(1.0)
        assert result.used_beta_default is True

    def test_ke_override_bypasses_capm(self, calc: WACCCalculator) -> None:
        """ke_override skips CAPM entirely."""
        inputs = WACCInputs(
            beta=2.5,   # would give high Ke without override
            market_cap=MARKET_CAP,
            risk_free_rate=RISK_FREE_RATE,
            equity_risk_premium=ERP,
            ke_override=0.10,
        )
        result = calc.compute(inputs)
        assert result.ke == pytest.approx(0.10)
        assert result.used_ke_override is True

    def test_ke_floored_at_risk_free_rate(self, calc: WACCCalculator) -> None:
        """Ke is never lower than Rf (negative beta scenario)."""
        inputs = WACCInputs(
            beta=-1.0,   # negative beta → CAPM would give Ke < Rf
            market_cap=MARKET_CAP,
            risk_free_rate=0.04,
            equity_risk_premium=0.055,
        )
        result = calc.compute(inputs)
        assert result.ke >= 0.04   # floored at Rf

    def test_high_beta_clipped_at_five(self, calc: WACCCalculator) -> None:
        """Beta > 5 is clipped to 5 (data error protection)."""
        inputs = WACCInputs(beta=8.0, market_cap=MARKET_CAP)
        result = calc.compute(inputs)
        assert result.beta_used <= 5.0


# ══════════════════════════════════════════════════════════════════════════════
# Cost of Debt
# ══════════════════════════════════════════════════════════════════════════════

class TestCostOfDebt:

    def test_kd_derived_from_interest_and_debt(
        self, calc: WACCCalculator, wacc_inputs: WACCInputs
    ) -> None:
        """Kd_pretax = Interest / Gross Debt."""
        result = calc.compute(wacc_inputs)
        gross_debt = SHORT_TERM_DEBT + LONG_TERM_DEBT
        expected_kd = INTEREST_EXPENSE / gross_debt
        assert result.kd_pretax == pytest.approx(expected_kd, rel=0.01)

    def test_kd_aftertax_applies_tax_shield(
        self, calc: WACCCalculator, wacc_inputs: WACCInputs
    ) -> None:
        """Kd_aftertax = Kd × (1 − t)."""
        result = calc.compute(wacc_inputs)
        assert result.kd_aftertax == pytest.approx(result.kd_pretax * (1.0 - TAX_RATE), rel=1e-6)

    def test_kd_override_bypasses_derivation(self, calc: WACCCalculator) -> None:
        """kd_override replaces the interest/debt calculation."""
        inputs = WACCInputs(
            market_cap=MARKET_CAP,
            interest_expense=INTEREST_EXPENSE,
            long_term_debt=LONG_TERM_DEBT,
            kd_override=0.06,
        )
        result = calc.compute(inputs)
        assert result.kd_pretax == pytest.approx(0.06)
        assert result.used_kd_override is True

    def test_kd_defaults_when_no_debt(self, calc: WACCCalculator) -> None:
        """Zero debt → kd defaults to Rf + credit spread."""
        inputs = WACCInputs(
            beta=1.0,
            market_cap=MARKET_CAP,
            long_term_debt=0.0,
            short_term_debt=0.0,
            interest_expense=None,
            risk_free_rate=0.04,
        )
        result = calc.compute(inputs)
        # Default = Rf + 200 bps
        assert result.kd_pretax == pytest.approx(0.04 + 0.02, rel=0.01)

    def test_kd_no_interest_uses_default(self, calc: WACCCalculator) -> None:
        """Missing interest_expense falls through to default credit spread."""
        inputs = WACCInputs(
            beta=1.0,
            market_cap=MARKET_CAP,
            long_term_debt=50_000_000_000,
            interest_expense=None,
            risk_free_rate=0.043,
        )
        result = calc.compute(inputs)
        assert result.kd_pretax == pytest.approx(0.043 + 0.02, rel=0.01)


# ══════════════════════════════════════════════════════════════════════════════
# Capital Structure Weights
# ══════════════════════════════════════════════════════════════════════════════

class TestCapitalStructureWeights:

    def test_weights_sum_to_one(self, calc: WACCCalculator, wacc_inputs: WACCInputs) -> None:
        result = calc.compute(wacc_inputs)
        assert result.equity_weight + result.debt_weight == pytest.approx(1.0, rel=1e-6)

    def test_all_equity_weight_is_one(self, calc: WACCCalculator) -> None:
        inputs = WACCInputs(
            beta=1.0,
            market_cap=MARKET_CAP,
            long_term_debt=0.0,
            short_term_debt=0.0,
        )
        result = calc.compute(inputs)
        assert result.equity_weight == pytest.approx(1.0, rel=1e-6)
        assert result.debt_weight == pytest.approx(0.0, abs=1e-9)

    def test_total_capital_is_e_plus_d(
        self, calc: WACCCalculator, wacc_inputs: WACCInputs
    ) -> None:
        result = calc.compute(wacc_inputs)
        expected = MARKET_CAP + SHORT_TERM_DEBT + LONG_TERM_DEBT
        assert result.total_capital == pytest.approx(expected)

    def test_net_debt_is_gross_debt_minus_cash(
        self, calc: WACCCalculator, wacc_inputs: WACCInputs
    ) -> None:
        result = calc.compute(wacc_inputs)
        expected_net_debt = (SHORT_TERM_DEBT + LONG_TERM_DEBT) - CASH
        assert result.net_debt == pytest.approx(expected_net_debt)


# ══════════════════════════════════════════════════════════════════════════════
# WACC Formula
# ══════════════════════════════════════════════════════════════════════════════

class TestWACCFormula:

    def test_wacc_is_weighted_sum_of_ke_and_kd(
        self, calc: WACCCalculator, wacc_inputs: WACCInputs
    ) -> None:
        """WACC = (E/V) × Ke + (D/V) × Kd_aftertax."""
        result = calc.compute(wacc_inputs)
        expected_wacc = (
            result.equity_weight * result.ke
            + result.debt_weight * result.kd_aftertax
        )
        assert result.wacc == pytest.approx(expected_wacc, rel=1e-4)

    def test_wacc_for_all_equity_firm_equals_ke(self, calc: WACCCalculator) -> None:
        inputs = WACCInputs(
            beta=1.25,
            market_cap=MARKET_CAP,
            long_term_debt=0.0,
            short_term_debt=0.0,
            risk_free_rate=0.043,
            equity_risk_premium=0.055,
        )
        result = calc.compute(inputs)
        assert result.wacc == pytest.approx(result.ke, rel=1e-4)

    def test_wacc_override_returns_exact_value(self, calc: WACCCalculator) -> None:
        inputs = WACCInputs(market_cap=MARKET_CAP, wacc_override=0.09)
        result = calc.compute(inputs)
        assert result.wacc == pytest.approx(0.09)
        assert result.used_wacc_override is True

    def test_wacc_clamped_to_minimum(self, calc: WACCCalculator) -> None:
        """WACC is never below 4% regardless of inputs."""
        inputs = WACCInputs(
            beta=0.01,
            market_cap=MARKET_CAP,
            risk_free_rate=0.001,
            equity_risk_premium=0.001,
        )
        result = calc.compute(inputs)
        assert result.wacc >= 0.04

    def test_wacc_for_typical_tech_company(self, calc: WACCCalculator) -> None:
        """Spot-check: AAPL-like parameters should yield ~8–11% WACC."""
        result = calc.compute(WACCInputs(
            beta=1.25,
            market_cap=MARKET_CAP,
            long_term_debt=LONG_TERM_DEBT,
            short_term_debt=SHORT_TERM_DEBT,
            interest_expense=INTEREST_EXPENSE,
            cash_and_equivalents=CASH,
            risk_free_rate=0.043,
            equity_risk_premium=0.055,
            tax_rate=0.25,
        ))
        assert 0.07 < result.wacc < 0.12

    def test_formula_display_contains_key_values(
        self, calc: WACCCalculator, wacc_inputs: WACCInputs
    ) -> None:
        result = calc.compute(wacc_inputs)
        formula = result.formula_display()
        assert "Ke" in formula
        assert "WACC" in formula
        assert "%" in formula


# ══════════════════════════════════════════════════════════════════════════════
# Edge Cases
# ══════════════════════════════════════════════════════════════════════════════

class TestWACCEdgeCases:

    def test_zero_market_cap_raises(self, calc: WACCCalculator) -> None:
        with pytest.raises((ValueError, Exception)):
            calc.compute(WACCInputs(market_cap=0.0))

    def test_very_high_leverage_still_computes(self, calc: WACCCalculator) -> None:
        """Highly leveraged firm (D >> E) should still produce a valid WACC."""
        inputs = WACCInputs(
            beta=2.0,
            market_cap=1_000_000_000,        # $1B equity
            long_term_debt=50_000_000_000,   # $50B debt — 50x leverage
            interest_expense=2_000_000_000,
        )
        result = calc.compute(inputs)
        assert 0.04 <= result.wacc <= 0.40
        assert result.debt_weight > result.equity_weight
