"""
tests/valuation/test_sensitivity.py
-------------------------------------
Tests for SensitivityAnalyser and FootballFieldBuilder.
"""

from __future__ import annotations

import pytest

from valuation.dcf import DCFEngine
from valuation.football_field import FootballFieldBuilder, ScenarioWeights
from valuation.models import (
    DCFInputs,
    TerminalValueInputs,
    ValuationOutput,
    WACCInputs,
)
from valuation.sensitivity import SensitivityAnalyser
from valuation.wacc import WACCCalculator
from tests.valuation.conftest import (
    CASH, ERP, INTEREST_EXPENSE, LONG_TERM_DEBT,
    MARKET_CAP, RISK_FREE_RATE, SHORT_TERM_DEBT, TAX_RATE,
)


@pytest.fixture
def wacc_calc() -> WACCCalculator:
    return WACCCalculator()


@pytest.fixture
def dcf_engine() -> DCFEngine:
    return DCFEngine()


@pytest.fixture
def wacc_result(wacc_inputs: WACCInputs, wacc_calc: WACCCalculator):
    return wacc_calc.compute(wacc_inputs)


@pytest.fixture
def base_output(
    dcf_engine: DCFEngine,
    dcf_inputs: DCFInputs,
    wacc_result,
) -> ValuationOutput:
    return dcf_engine.compute(dcf_inputs, wacc_result, ticker="AAPL", scenario="base")


@pytest.fixture
def analyser() -> SensitivityAnalyser:
    return SensitivityAnalyser()


# ══════════════════════════════════════════════════════════════════════════════
# Sensitivity Grid Structure
# ══════════════════════════════════════════════════════════════════════════════

class TestSensitivityGridStructure:

    def test_grid_has_correct_row_count(
        self,
        analyser: SensitivityAnalyser,
        base_output: ValuationOutput,
        dcf_inputs: DCFInputs,
        wacc_result,
    ) -> None:
        """wacc_steps=4 → 9 WACC values (4 below, base, 4 above)."""
        grid = analyser.compute_grid(
            base_output, dcf_inputs, wacc_result, wacc_steps=4, growth_steps=2
        )
        assert len(grid.grid) == 9

    def test_grid_has_correct_column_count(
        self,
        analyser: SensitivityAnalyser,
        base_output: ValuationOutput,
        dcf_inputs: DCFInputs,
        wacc_result,
    ) -> None:
        """growth_steps=2 → up to 5 growth values (2 below, base, 2 above)."""
        grid = analyser.compute_grid(
            base_output, dcf_inputs, wacc_result, wacc_steps=4, growth_steps=2
        )
        # Some growth values might be filtered (g must be < WACC - 50bps)
        # so columns ≤ 5
        assert all(len(row) >= 1 for row in grid.grid)

    def test_base_case_cell_is_flagged(
        self,
        analyser: SensitivityAnalyser,
        base_output: ValuationOutput,
        dcf_inputs: DCFInputs,
        wacc_result,
    ) -> None:
        grid = analyser.compute_grid(
            base_output, dcf_inputs, wacc_result, wacc_steps=2, growth_steps=1
        )
        base_cells = [
            cell
            for row in grid.grid
            for cell in row
            if cell.is_base_case
        ]
        assert len(base_cells) == 1

    def test_base_cell_fair_value_close_to_base_output(
        self,
        analyser: SensitivityAnalyser,
        base_output: ValuationOutput,
        dcf_inputs: DCFInputs,
        wacc_result,
    ) -> None:
        grid = analyser.compute_grid(
            base_output, dcf_inputs, wacc_result, wacc_steps=2, growth_steps=1
        )
        base_cells = [c for row in grid.grid for c in row if c.is_base_case]
        if base_cells:
            assert base_cells[0].fair_value_per_share == pytest.approx(
                base_output.fair_value_per_share, rel=0.02
            )


# ══════════════════════════════════════════════════════════════════════════════
# Sensitivity Grid Monotonicity
# ══════════════════════════════════════════════════════════════════════════════

class TestSensitivityMonotonicity:

    @pytest.fixture
    def grid(
        self,
        analyser: SensitivityAnalyser,
        base_output: ValuationOutput,
        dcf_inputs: DCFInputs,
        wacc_result,
    ):
        return analyser.compute_grid(
            base_output, dcf_inputs, wacc_result, wacc_steps=3, growth_steps=2
        )

    def test_higher_wacc_gives_lower_fvps(self, grid) -> None:
        """For each column, increasing WACC should decrease FVPS."""
        n_cols = len(grid.grid[0])
        for col_idx in range(n_cols):
            fvps = [row[col_idx].fair_value_per_share for row in grid.grid]
            # Filter out sentinel zeros
            fvps_nonzero = [f for f in fvps if f > 0]
            for i in range(1, len(fvps_nonzero)):
                assert fvps_nonzero[i] <= fvps_nonzero[i - 1] + 0.01  # allow tiny rounding

    def test_higher_growth_gives_higher_fvps(self, grid) -> None:
        """For each row, increasing g should increase FVPS."""
        for row in grid.grid:
            fvps = [cell.fair_value_per_share for cell in row if cell.fair_value_per_share > 0]
            for i in range(1, len(fvps)):
                assert fvps[i] >= fvps[i - 1] - 0.01  # allow tiny rounding

    def test_implied_range_min_less_than_max(self, grid) -> None:
        lo, hi = grid.implied_range()
        assert lo < hi

    def test_to_matrix_dimensions(self, grid) -> None:
        matrix = grid.to_matrix()
        assert len(matrix) == len(grid.grid)
        assert all(len(row) == len(grid.grid[0]) for row in matrix)


# ══════════════════════════════════════════════════════════════════════════════
# Football Field
# ══════════════════════════════════════════════════════════════════════════════

def _make_valuation(fvps: float, ev: float, base: ValuationOutput) -> ValuationOutput:
    """Clone base valuation with different fair value and EV."""
    return base.model_copy(update={
        "fair_value_per_share": fvps,
        "equity_value": fvps * base.shares_outstanding,
        "enterprise_value": ev,
    })


class TestFootballField:

    @pytest.fixture
    def builder(self) -> FootballFieldBuilder:
        return FootballFieldBuilder()

    @pytest.fixture
    def three_outputs(self, base_output: ValuationOutput):
        bear = _make_valuation(120.0, base_output.enterprise_value * 0.85, base_output)
        base = _make_valuation(160.0, base_output.enterprise_value,          base_output)
        bull = _make_valuation(200.0, base_output.enterprise_value * 1.15,  base_output)
        return bear, base, bull

    def test_builds_four_ranges_without_sensitivity(
        self, builder: FootballFieldBuilder, three_outputs
    ) -> None:
        bear, base, bull = three_outputs
        ff = builder.build(bear, base, bull, current_price=175.0)
        # Bear, Base, Bull, Full Range = 4 ranges (no sensitivity)
        assert len(ff.ranges) == 4

    def test_adds_sensitivity_range_when_provided(
        self,
        builder: FootballFieldBuilder,
        three_outputs,
        base_output: ValuationOutput,
        dcf_inputs: DCFInputs,
        wacc_result,
    ) -> None:
        bear, base, bull = three_outputs
        grid = SensitivityAnalyser().compute_grid(
            base_output, dcf_inputs, wacc_result, wacc_steps=2, growth_steps=1
        )
        ff = builder.build(bear, base, bull, sensitivity_grid=grid)
        assert len(ff.ranges) == 5

    def test_blended_fair_value_with_equal_weights(
        self, builder: FootballFieldBuilder, three_outputs
    ) -> None:
        bear, base, bull = three_outputs
        weights = ScenarioWeights(bear=1/3, base=1/3, bull=1/3)
        ff = builder.build(bear, base, bull, weights=weights)
        expected = (120.0 + 160.0 + 200.0) / 3.0
        assert ff.blended_fair_value == pytest.approx(expected, rel=1e-4)

    def test_default_weights_25_50_25(
        self, builder: FootballFieldBuilder, three_outputs
    ) -> None:
        bear, base, bull = three_outputs
        ff = builder.build(bear, base, bull)
        expected = 0.25 * 120.0 + 0.50 * 160.0 + 0.25 * 200.0
        assert ff.blended_fair_value == pytest.approx(expected, rel=1e-4)

    def test_range_low_le_high(
        self, builder: FootballFieldBuilder, three_outputs
    ) -> None:
        bear, base, bull = three_outputs
        ff = builder.build(bear, base, bull, current_price=175.0)
        for r in ff.ranges:
            assert r.low <= r.high

    def test_midpoint_is_average_of_low_and_high(
        self, builder: FootballFieldBuilder, three_outputs
    ) -> None:
        bear, base, bull = three_outputs
        ff = builder.build(bear, base, bull)
        for r in ff.ranges:
            assert r.midpoint == pytest.approx((r.low + r.high) / 2.0, rel=1e-6)

    def test_price_vs_intrinsic_undervalued(
        self, builder: FootballFieldBuilder, three_outputs
    ) -> None:
        bear, base, bull = three_outputs
        # Current price well below blended value
        ff = builder.build(bear, base, bull, current_price=100.0)
        assert ff.price_vs_intrinsic() == "UNDERVALUED"

    def test_price_vs_intrinsic_overvalued(
        self, builder: FootballFieldBuilder, three_outputs
    ) -> None:
        bear, base, bull = three_outputs
        ff = builder.build(bear, base, bull, current_price=250.0)
        assert ff.price_vs_intrinsic() == "OVERVALUED"

    def test_price_vs_intrinsic_fairly_valued(
        self, builder: FootballFieldBuilder, three_outputs
    ) -> None:
        bear, base, bull = three_outputs
        blended = 0.25 * 120.0 + 0.50 * 160.0 + 0.25 * 200.0  # = 160
        ff = builder.build(bear, base, bull, current_price=blended)
        assert ff.price_vs_intrinsic() == "FAIRLY VALUED"

    def test_scenario_weights_must_sum_to_one(self) -> None:
        with pytest.raises(ValueError, match="sum to 1"):
            ScenarioWeights(bear=0.40, base=0.40, bull=0.40)
