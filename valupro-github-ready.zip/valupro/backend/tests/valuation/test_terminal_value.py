"""
tests/valuation/test_terminal_value.py
---------------------------------------
Tests for TerminalValueCalculator — Gordon Growth Model, Exit Multiple,
blending, and constraint enforcement.
"""

from __future__ import annotations

import pytest

from valuation.models import TerminalValueInputs
from valuation.terminal_value import TerminalValueCalculator
from tests.valuation.conftest import FCFF_SERIES, EBITDA_SERIES


@pytest.fixture
def calc() -> TerminalValueCalculator:
    return TerminalValueCalculator()


FCFF_N   = FCFF_SERIES[-1]    # final year FCFF
EBITDA_N = EBITDA_SERIES[-1]  # final year EBITDA
WACC     = 0.09
G        = 0.025
N        = 10


# ══════════════════════════════════════════════════════════════════════════════
# Gordon Growth Model
# ══════════════════════════════════════════════════════════════════════════════

class TestGordonGrowthModel:

    def test_formula_exact(self, calc: TerminalValueCalculator) -> None:
        """TV = FCFF_N × (1+g) / (WACC−g)."""
        inputs = TerminalValueInputs(method="gordon_growth", terminal_growth_rate=G)
        result = calc.compute(inputs, WACC, FCFF_N, EBITDA_N, N)
        expected = FCFF_N * (1.0 + G) / (WACC - G)
        assert result.tv_gordon_growth == pytest.approx(expected, rel=1e-6)

    def test_tv_final_equals_ggm_when_gordon_growth_method(
        self, calc: TerminalValueCalculator
    ) -> None:
        inputs = TerminalValueInputs(method="gordon_growth", terminal_growth_rate=G)
        result = calc.compute(inputs, WACC, FCFF_N, EBITDA_N, N)
        assert result.tv_final == pytest.approx(result.tv_gordon_growth, rel=1e-6)

    def test_higher_growth_rate_increases_tv(self, calc: TerminalValueCalculator) -> None:
        low_g  = TerminalValueInputs(method="gordon_growth", terminal_growth_rate=0.02)
        high_g = TerminalValueInputs(method="gordon_growth", terminal_growth_rate=0.03)
        result_low  = calc.compute(low_g,  WACC, FCFF_N, EBITDA_N, N)
        result_high = calc.compute(high_g, WACC, FCFF_N, EBITDA_N, N)
        assert result_high.tv_final > result_low.tv_final

    def test_wacc_close_to_g_raises(self, calc: TerminalValueCalculator) -> None:
        """WACC − g < 50 bps → ValueError (TV would be astronomical)."""
        inputs = TerminalValueInputs(method="gordon_growth", terminal_growth_rate=0.089)
        with pytest.raises(ValueError, match="must exceed"):
            calc.compute(inputs, wacc=0.09, fcff_terminal=FCFF_N,
                         ebitda_terminal=EBITDA_N, forecast_years=N)

    def test_wacc_equals_g_raises(self, calc: TerminalValueCalculator) -> None:
        inputs = TerminalValueInputs(method="gordon_growth", terminal_growth_rate=0.09)
        with pytest.raises(ValueError):
            calc.compute(inputs, wacc=0.09, fcff_terminal=FCFF_N,
                         ebitda_terminal=EBITDA_N, forecast_years=N)

    def test_negative_fcff_terminal_gives_negative_tv(
        self, calc: TerminalValueCalculator
    ) -> None:
        inputs = TerminalValueInputs(method="gordon_growth", terminal_growth_rate=G)
        result = calc.compute(inputs, WACC, fcff_terminal=-10_000_000_000,
                              ebitda_terminal=EBITDA_N, forecast_years=N)
        assert result.tv_gordon_growth < 0


# ══════════════════════════════════════════════════════════════════════════════
# Exit Multiple
# ══════════════════════════════════════════════════════════════════════════════

class TestExitMultiple:

    def test_formula_exact(self, calc: TerminalValueCalculator) -> None:
        """TV = EBITDA_N × multiple."""
        inputs = TerminalValueInputs(
            method="exit_multiple",
            terminal_growth_rate=G,
            exit_ebitda_multiple=18.0,
        )
        result = calc.compute(inputs, WACC, FCFF_N, EBITDA_N, N)
        assert result.tv_exit_multiple == pytest.approx(EBITDA_N * 18.0, rel=1e-6)
        assert result.tv_final == pytest.approx(EBITDA_N * 18.0, rel=1e-6)

    def test_no_multiple_returns_none(self, calc: TerminalValueCalculator) -> None:
        inputs = TerminalValueInputs(method="exit_multiple", terminal_growth_rate=G)
        with pytest.raises(ValueError, match="requires both"):
            calc.compute(inputs, WACC, FCFF_N, EBITDA_N, N)

    def test_zero_ebitda_returns_none(self, calc: TerminalValueCalculator) -> None:
        inputs = TerminalValueInputs(
            method="exit_multiple", terminal_growth_rate=G, exit_ebitda_multiple=18.0
        )
        with pytest.raises(ValueError):
            calc.compute(inputs, WACC, FCFF_N, ebitda_terminal=-1.0, forecast_years=N)

    def test_higher_multiple_increases_tv(self, calc: TerminalValueCalculator) -> None:
        inputs_15 = TerminalValueInputs(method="exit_multiple", terminal_growth_rate=G,
                                        exit_ebitda_multiple=15.0)
        inputs_20 = TerminalValueInputs(method="exit_multiple", terminal_growth_rate=G,
                                        exit_ebitda_multiple=20.0)
        result_15 = calc.compute(inputs_15, WACC, FCFF_N, EBITDA_N, N)
        result_20 = calc.compute(inputs_20, WACC, FCFF_N, EBITDA_N, N)
        assert result_20.tv_final > result_15.tv_final


# ══════════════════════════════════════════════════════════════════════════════
# Average Method
# ══════════════════════════════════════════════════════════════════════════════

class TestAverageMethod:

    def test_average_of_ggm_and_exit(self, calc: TerminalValueCalculator) -> None:
        inputs = TerminalValueInputs(
            method="average",
            terminal_growth_rate=G,
            exit_ebitda_multiple=18.0,
        )
        result = calc.compute(inputs, WACC, FCFF_N, EBITDA_N, N)
        ggm  = result.tv_gordon_growth
        exit = result.tv_exit_multiple
        assert ggm is not None and exit is not None
        expected_avg = (ggm + exit) / 2.0
        assert result.tv_final == pytest.approx(expected_avg, rel=1e-6)

    def test_average_between_ggm_and_exit_bounds(
        self, calc: TerminalValueCalculator
    ) -> None:
        inputs = TerminalValueInputs(
            method="average",
            terminal_growth_rate=G,
            exit_ebitda_multiple=18.0,
        )
        result = calc.compute(inputs, WACC, FCFF_N, EBITDA_N, N)
        assert min(result.tv_gordon_growth, result.tv_exit_multiple) <= result.tv_final <= max(result.tv_gordon_growth, result.tv_exit_multiple)  # type: ignore[arg-type]


# ══════════════════════════════════════════════════════════════════════════════
# Present Value of Terminal Value
# ══════════════════════════════════════════════════════════════════════════════

class TestPresentValueOfTV:

    def test_pv_tv_formula(self, calc: TerminalValueCalculator) -> None:
        """PV(TV) = TV / (1 + WACC)^N."""
        inputs = TerminalValueInputs(method="gordon_growth", terminal_growth_rate=G)
        result = calc.compute(inputs, WACC, FCFF_N, EBITDA_N, N)
        tv = result.tv_final
        expected_pv = tv / (1.0 + WACC) ** N
        assert result.pv_terminal_value == pytest.approx(expected_pv, rel=1e-6)

    def test_longer_forecast_gives_lower_pv_tv(self, calc: TerminalValueCalculator) -> None:
        """More years of discounting → lower PV(TV)."""
        inputs = TerminalValueInputs(method="gordon_growth", terminal_growth_rate=G)
        result_5  = calc.compute(inputs, WACC, FCFF_N, EBITDA_N, forecast_years=5)
        result_10 = calc.compute(inputs, WACC, FCFF_N, EBITDA_N, forecast_years=10)
        assert result_5.pv_terminal_value > result_10.pv_terminal_value

    def test_higher_wacc_gives_lower_pv_tv(self, calc: TerminalValueCalculator) -> None:
        inputs = TerminalValueInputs(method="gordon_growth", terminal_growth_rate=G)
        result_low  = calc.compute(inputs, 0.08, FCFF_N, EBITDA_N, N)
        result_high = calc.compute(inputs, 0.12, FCFF_N, EBITDA_N, N)
        assert result_low.pv_terminal_value > result_high.pv_terminal_value

    def test_formula_display_contains_growth_and_wacc(
        self, calc: TerminalValueCalculator
    ) -> None:
        inputs = TerminalValueInputs(method="gordon_growth", terminal_growth_rate=G)
        result = calc.compute(inputs, WACC, FCFF_N, EBITDA_N, N)
        display = result.formula_display()
        assert "Gordon" in display
