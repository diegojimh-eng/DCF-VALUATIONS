"""
tests/valuation/conftest.py
----------------------------
Shared fixtures for all DCF valuation tests.
Uses realistic AAPL FY2023-scale numbers throughout.
"""

from __future__ import annotations

import pytest

from valuation.models import (
    DCFInputs,
    TerminalValueInputs,
    WACCInputs,
)

# ── Realistic AAPL-scale constants ─────────────────────────────────────────────
MARKET_CAP          = 2_750_000_000_000   # $2.75T
LONG_TERM_DEBT      =    95_000_000_000   # $95B
SHORT_TERM_DEBT     =     9_800_000_000   # $9.8B
INTEREST_EXPENSE    =     3_900_000_000   # $3.9B LTM
CASH                =    30_000_000_000   # $30B
SHARES_OUTSTANDING  =    15_671_000_000   # 15.67B diluted shares
BETA                = 1.25
RISK_FREE_RATE      = 0.043    # 4.3%
ERP                 = 0.055    # 5.5%
TAX_RATE            = 0.25     # 25%
BASE_REVENUE        = 383_285_000_000

# 10-year FCFF series (AAPL-scale, growing ~8% from ~$100B base)
FCFF_SERIES = [
     99_000_000_000,
    106_920_000_000,
    115_474_000_000,
    124_711_000_000,
    134_688_000_000,
    145_463_000_000,
    157_100_000_000,
    169_668_000_000,
    181_244_000_000,
    193_931_000_000,
]

# Corresponding EBITDA series (growing ~8%)
EBITDA_SERIES = [
    125_820_000_000,
    135_885_000_000,
    146_756_000_000,
    158_496_000_000,
    171_176_000_000,
    184_870_000_000,
    199_659_000_000,
    215_632_000_000,
    232_882_000_000,
    251_512_000_000,
]

FISCAL_YEARS = list(range(2024, 2034))   # 2024–2033
NET_DEBT = LONG_TERM_DEBT + SHORT_TERM_DEBT - CASH   # ~$74.8B


@pytest.fixture
def wacc_inputs() -> WACCInputs:
    return WACCInputs(
        beta=BETA,
        market_cap=MARKET_CAP,
        short_term_debt=SHORT_TERM_DEBT,
        long_term_debt=LONG_TERM_DEBT,
        interest_expense=INTEREST_EXPENSE,
        cash_and_equivalents=CASH,
        risk_free_rate=RISK_FREE_RATE,
        equity_risk_premium=ERP,
        tax_rate=TAX_RATE,
    )


@pytest.fixture
def tv_inputs_ggm() -> TerminalValueInputs:
    return TerminalValueInputs(
        method="gordon_growth",
        terminal_growth_rate=0.025,
    )


@pytest.fixture
def tv_inputs_exit() -> TerminalValueInputs:
    return TerminalValueInputs(
        method="exit_multiple",
        terminal_growth_rate=0.025,
        exit_ebitda_multiple=18.0,
    )


@pytest.fixture
def tv_inputs_average() -> TerminalValueInputs:
    return TerminalValueInputs(
        method="average",
        terminal_growth_rate=0.025,
        exit_ebitda_multiple=18.0,
    )


@pytest.fixture
def dcf_inputs(tv_inputs_ggm: TerminalValueInputs) -> DCFInputs:
    return DCFInputs(
        fcff_series=FCFF_SERIES,
        ebitda_series=EBITDA_SERIES,
        fiscal_years=FISCAL_YEARS,
        wacc=0.09,   # will be overridden by WACCResult in pipeline
        terminal_value_inputs=tv_inputs_ggm,
        net_debt=NET_DEBT,
        minority_interest=0.0,
        preferred_equity=0.0,
        shares_outstanding=SHARES_OUTSTANDING,
    )
