"""
tests/valuation/test_dcf.py
----------------------------
Tests for the DCF engine — discount schedule arithmetic, EV computation,
equity bridge, and fair value per share.
"""

from __future__ import annotations

import pytest

from valuation.dcf import DCFEngine
from valuation.models import DCFInputs, TerminalValueInputs, ValuationOutput, WACCInputs
from valuation.wacc import WACCCalculator
from tests.valuation.conftest import (
    EBITDA_SERIES, FCFF_SERIES, FISCAL_YEARS, MARKET_CAP,
    NET_DEBT, SHARES_OUTSTANDING, LONG_TERM_DEBT, SHORT_TERM_DEBT,
    INTEREST_EXPENSE, CASH, BETA, RISK_FREE_RATE, ERP, TAX_RATE,
)

WACC  = 0.09
G     = 0.025


@pytest.fixture
def dcf_engine() -> DCFEngine:
    return DCFEngine(mid_year_convention=False)


@pytest.fixture
def wacc_result(wacc_inputs: WACCInputs):
    return WACCCalculator().compute(wacc_inputs)


@pytest.fixture
def valuation_output(
    dcf_engine: DCFEngine,
    dcf_inputs: DCFInputs,
    wacc_result,
) -> ValuationOutput:
    return dcf_engine.compute(dcf_inputs, wacc_result, ticker="AAPL", scenario="base")


# ══════════════════════════════════════════════════════════════════════════════
# Discount Schedule
# ══════════════════════════════════════════════════════════════════════════════

class TestDiscountSchedule:

    def test_schedule_has_correct_number_of_years(
        self, valuation_output: ValuationOutput
    ) -> None:
        assert len(valuation_output.dcf_schedule) == 10

    def test_year_indices_sequential(self, valuation_output: ValuationOutput) -> None:
        indices = [y.year_index for y in valuation_output.dcf_schedule]
        assert indices == list(range(1, 11))

    def test_discount_factor_year_1(self, valuation_output: ValuationOutput) -> None:
        """Discount factor for year 1 = 1 / (1 + WACC)^1."""
        wacc = valuation_output.wacc
        year1 = valuation_output.dcf_schedule[0]
        expected = 1.0 / (1.0 + wacc)
        assert year1.discount_factor == pytest.approx(expected, rel=1e-4)

    def test_discount_factor_year_10(self, valuation_output: ValuationOutput) -> None:
        """Discount factor for year 10 = 1 / (1 + WACC)^10."""
        wacc = valuation_output.wacc
        year10 = valuation_output.dcf_schedule[-1]
        expected = 1.0 / (1.0 + wacc) ** 10
        assert year10.discount_factor == pytest.approx(expected, rel=1e-4)

    def test_discount_factors_decrease_over_time(
        self, valuation_output: ValuationOutput
    ) -> None:
        factors = [y.discount_factor for y in valuation_output.dcf_schedule]
        for i in range(1, len(factors)):
            assert factors[i] < factors[i - 1]

    def test_pv_fcff_equals_fcff_times_discount_factor(
        self, valuation_output: ValuationOutput
    ) -> None:
        for row in valuation_output.dcf_schedule:
            expected_pv = row.fcff * row.discount_factor
            assert row.pv_fcff == pytest.approx(expected_pv, rel=1e-6)

    def test_sum_pv_fcff_equals_sum_of_schedule(
        self, valuation_output: ValuationOutput
    ) -> None:
        expected = sum(r.pv_fcff for r in valuation_output.dcf_schedule)
        assert valuation_output.sum_pv_fcff == pytest.approx(expected, rel=1e-6)

    def test_mid_year_convention_gives_higher_sum(self, dcf_inputs: DCFInputs, wacc_result) -> None:
        """Mid-year convention discounts by t−0.5 → higher PV than year-end."""
        end_engine = DCFEngine(mid_year_convention=False)
        mid_engine = DCFEngine(mid_year_convention=True)
        result_end = end_engine.compute(dcf_inputs, wacc_result)
        result_mid = mid_engine.compute(dcf_inputs, wacc_result)
        assert result_mid.sum_pv_fcff > result_end.sum_pv_fcff


# ══════════════════════════════════════════════════════════════════════════════
# Enterprise Value
# ══════════════════════════════════════════════════════════════════════════════

class TestEnterpriseValue:

    def test_ev_equals_sum_pv_fcff_plus_pv_tv(
        self, valuation_output: ValuationOutput
    ) -> None:
        """EV = Σ PV(FCFF) + PV(TV)."""
        expected = valuation_output.sum_pv_fcff + valuation_output.pv_terminal_value
        assert valuation_output.enterprise_value == pytest.approx(expected, rel=1e-6)

    def test_ev_is_positive(self, valuation_output: ValuationOutput) -> None:
        assert valuation_output.enterprise_value > 0

    def test_pv_fcff_pct_plus_pv_tv_pct_equals_one(
        self, valuation_output: ValuationOutput
    ) -> None:
        total = valuation_output.pv_fcff_pct_of_ev + valuation_output.pv_tv_pct_of_ev
        assert total == pytest.approx(1.0, rel=1e-6)

    def test_higher_wacc_reduces_ev(self, dcf_inputs: DCFInputs) -> None:
        """Higher WACC → lower discount factors → lower EV."""
        calc = WACCCalculator()
        engine = DCFEngine()

        low_wacc_inputs = WACCInputs(
            beta=0.80, market_cap=MARKET_CAP,
            long_term_debt=LONG_TERM_DEBT, short_term_debt=SHORT_TERM_DEBT,
            interest_expense=INTEREST_EXPENSE, cash_and_equivalents=CASH,
            risk_free_rate=0.035, equity_risk_premium=0.045, tax_rate=TAX_RATE,
        )
        high_wacc_inputs = WACCInputs(
            beta=1.80, market_cap=MARKET_CAP,
            long_term_debt=LONG_TERM_DEBT, short_term_debt=SHORT_TERM_DEBT,
            interest_expense=INTEREST_EXPENSE, cash_and_equivalents=CASH,
            risk_free_rate=0.043, equity_risk_premium=0.065, tax_rate=TAX_RATE,
        )
        result_low  = engine.compute(dcf_inputs, calc.compute(low_wacc_inputs))
        result_high = engine.compute(dcf_inputs, calc.compute(high_wacc_inputs))
        assert result_low.enterprise_value > result_high.enterprise_value


# ══════════════════════════════════════════════════════════════════════════════
# Equity Bridge
# ══════════════════════════════════════════════════════════════════════════════

class TestEquityBridge:

    def test_equity_value_equals_ev_minus_net_debt(
        self, valuation_output: ValuationOutput
    ) -> None:
        """Equity = EV − Net Debt − Minority Interest − Preferred."""
        expected = (
            valuation_output.enterprise_value
            - valuation_output.net_debt
            - valuation_output.minority_interest
            - valuation_output.preferred_equity
        )
        assert valuation_output.equity_value == pytest.approx(expected, rel=1e-6)

    def test_minority_interest_reduces_equity(
        self, dcf_inputs: DCFInputs, wacc_result
    ) -> None:
        """Minority interest is deducted from EV."""
        no_minority = dcf_inputs
        with_minority = dcf_inputs.model_copy(update={"minority_interest": 5_000_000_000})

        engine = DCFEngine()
        result_no  = engine.compute(no_minority,   wacc_result)
        result_with = engine.compute(with_minority, wacc_result)

        assert result_no.equity_value > result_with.equity_value
        assert result_no.equity_value - result_with.equity_value == pytest.approx(
            5_000_000_000, rel=1e-6
        )

    def test_net_debtor_has_lower_equity_than_cash_rich(
        self, dcf_inputs: DCFInputs, wacc_result
    ) -> None:
        debtor    = dcf_inputs.model_copy(update={"net_debt": 100_000_000_000})
        cash_rich = dcf_inputs.model_copy(update={"net_debt": -50_000_000_000})  # net cash position

        engine = DCFEngine()
        assert engine.compute(debtor, wacc_result).equity_value < engine.compute(cash_rich, wacc_result).equity_value


# ══════════════════════════════════════════════════════════════════════════════
# Fair Value per Share
# ══════════════════════════════════════════════════════════════════════════════

class TestFairValuePerShare:

    def test_fvps_equals_equity_value_over_shares(
        self, valuation_output: ValuationOutput
    ) -> None:
        expected = valuation_output.equity_value / valuation_output.shares_outstanding
        assert valuation_output.fair_value_per_share == pytest.approx(expected, rel=1e-6)

    def test_more_shares_reduces_fvps(
        self, dcf_inputs: DCFInputs, wacc_result
    ) -> None:
        """Dilution: more shares → lower FVPS for same equity value."""
        base   = dcf_inputs
        diluted = dcf_inputs.model_copy(
            update={"shares_outstanding": dcf_inputs.shares_outstanding * 2}
        )
        engine = DCFEngine()
        result_base   = engine.compute(base,    wacc_result)
        result_diluted = engine.compute(diluted, wacc_result)
        assert result_diluted.fair_value_per_share == pytest.approx(
            result_base.fair_value_per_share / 2, rel=1e-6
        )

    def test_fvps_is_positive_for_healthy_company(
        self, valuation_output: ValuationOutput
    ) -> None:
        assert valuation_output.fair_value_per_share > 0

    def test_aapl_like_fvps_in_reasonable_range(
        self, valuation_output: ValuationOutput
    ) -> None:
        """
        For AAPL-like inputs (WACC ~9%, growing FCFFs, $175 current price),
        the DCF fair value should be in a reasonable range.
        Not an exact test — WACC and assumptions vary — but sanity-checks
        that the engine isn't off by orders of magnitude.
        """
        assert 50 < valuation_output.fair_value_per_share < 1000

    def test_formula_display_shows_all_bridge_items(
        self, valuation_output: ValuationOutput
    ) -> None:
        formula = valuation_output.formula_display()
        assert "Enterprise Value" in formula
        assert "Net Debt" in formula
        assert "Equity Value" in formula
        assert "Fair Value / Share" in formula


# ══════════════════════════════════════════════════════════════════════════════
# TV Dependence Warning
# ══════════════════════════════════════════════════════════════════════════════

class TestDCFWarnings:

    def test_warning_when_tv_exceeds_80_pct(
        self, dcf_inputs: DCFInputs, wacc_result
    ) -> None:
        """High TV dependence should trigger a warning."""
        # Force very low explicit FCFFs so TV dominates
        tiny_fcff = dcf_inputs.model_copy(
            update={"fcff_series": [1_000_000] * 10}
        )
        engine  = DCFEngine()
        result  = engine.compute(tiny_fcff, wacc_result)
        tv_pct  = result.pv_tv_pct_of_ev
        if tv_pct > 0.80:
            assert any("Terminal value" in w for w in result.warnings)

    def test_no_warnings_for_healthy_company(
        self, valuation_output: ValuationOutput
    ) -> None:
        """Normal AAPL-like valuation should have zero or minimal warnings."""
        non_tv_warnings = [
            w for w in valuation_output.warnings
            if "negative" not in w.lower()
        ]
        # May have a TV% warning — that's fine for a tech company
        # but should not have equity-negative warning
        assert not any("non-positive" in w.lower() for w in valuation_output.warnings)
