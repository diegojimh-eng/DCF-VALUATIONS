"""
tests/comps/test_stats_calculator_implication.py
--------------------------------------------------
Tests for:
  • MultipleStatsCalculator (mean, median, Q1, Q3, IQR, min, max)
  • MultipleCalculator (formula correctness for all five multiples)
  • ImplicationEngine (EV → equity → price bridge; equity-level bridge)
"""

from __future__ import annotations

import pytest

from comps.cleaner import CleanedSeries, PeerCleaner
from comps.implication import ImplicationEngine
from comps.calculator import MultipleCalculator
from comps.models import MultipleType, PeerData, SubjectMetrics
from comps.stats import MultipleStatsCalculator
from tests.comps.conftest import (
    SUBJECT_EBITDA,
    SUBJECT_EPS,
    SUBJECT_NET_DEBT,
    SUBJECT_REVENUE,
    SUBJECT_SHARES,
    SUBJECT_BVPS,
)


# ══════════════════════════════════════════════════════════════════════════════
# MultipleStatsCalculator
# ══════════════════════════════════════════════════════════════════════════════

def _make_series(values: list[float], mt: MultipleType) -> CleanedSeries:
    """Build a CleanedSeries directly from a list of values."""
    tickers = [f"P{i}" for i in range(len(values))]
    return CleanedSeries(
        multiple_type=mt,
        clean_values=values,
        clean_tickers=tickers,
        excluded=[],
    )


@pytest.fixture
def stats_calc() -> MultipleStatsCalculator:
    return MultipleStatsCalculator()


class TestMultipleStatsCalculator:

    def test_mean_exact(self, stats_calc: MultipleStatsCalculator) -> None:
        series = _make_series([10.0, 20.0, 30.0], MultipleType.EV_EBITDA)
        result = stats_calc.compute(series)
        assert result.mean == pytest.approx(20.0)

    def test_median_odd_count(self, stats_calc: MultipleStatsCalculator) -> None:
        series = _make_series([10.0, 30.0, 20.0], MultipleType.EV_EBITDA)
        result = stats_calc.compute(series)
        assert result.median == pytest.approx(20.0)

    def test_median_even_count(self, stats_calc: MultipleStatsCalculator) -> None:
        series = _make_series([10.0, 20.0, 30.0, 40.0], MultipleType.EV_EBITDA)
        result = stats_calc.compute(series)
        assert result.median == pytest.approx(25.0)

    def test_min_max(self, stats_calc: MultipleStatsCalculator) -> None:
        series = _make_series([5.0, 10.0, 15.0, 20.0, 25.0], MultipleType.PE)
        result = stats_calc.compute(series)
        assert result.min == pytest.approx(5.0)
        assert result.max == pytest.approx(25.0)

    def test_q1_q3_interpolation(self, stats_calc: MultipleStatsCalculator) -> None:
        """Q1 and Q3 use linear interpolation (Excel QUARTILE.INC)."""
        series = _make_series([10.0, 20.0, 30.0, 40.0], MultipleType.EV_EBITDA)
        result = stats_calc.compute(series)
        assert result.q1 == pytest.approx(17.5)
        assert result.q3 == pytest.approx(32.5)

    def test_iqr_is_q3_minus_q1(self, stats_calc: MultipleStatsCalculator) -> None:
        series = _make_series([10.0, 20.0, 30.0, 40.0], MultipleType.EV_EBITDA)
        result = stats_calc.compute(series)
        assert result.iqr == pytest.approx(result.q3 - result.q1)

    def test_single_observation_quartiles_equal_value(
        self, stats_calc: MultipleStatsCalculator
    ) -> None:
        series = _make_series([18.0], MultipleType.EV_EBITDA)
        result = stats_calc.compute(series)
        assert result.q1 == pytest.approx(18.0)
        assert result.q3 == pytest.approx(18.0)
        assert result.iqr == pytest.approx(0.0)

    def test_empty_series_raises(self, stats_calc: MultipleStatsCalculator) -> None:
        series = _make_series([], MultipleType.EV_EBITDA)
        with pytest.raises(ValueError, match="no clean observations"):
            stats_calc.compute(series)

    def test_raw_count_and_clean_count_propagated(
        self, stats_calc: MultipleStatsCalculator
    ) -> None:
        series = CleanedSeries(
            multiple_type=MultipleType.EV_EBITDA,
            clean_values=[18.0, 22.0, 25.0],
            clean_tickers=["A", "B", "C"],
            excluded=[("X", float("nan"), "missing")],
        )
        result = stats_calc.compute(series)
        assert result.clean_count == 3
        assert result.excluded_count == 1
        assert result.raw_count == 4

    def test_compute_all_skips_empty_series(
        self, stats_calc: MultipleStatsCalculator
    ) -> None:
        cleaned = {
            MultipleType.EV_EBITDA: _make_series([18.0, 22.0], MultipleType.EV_EBITDA),
            MultipleType.PE:        _make_series([], MultipleType.PE),  # empty
        }
        result = stats_calc.compute_all(cleaned)  # type: ignore[arg-type]
        assert MultipleType.EV_EBITDA in result
        assert MultipleType.PE not in result   # skipped — no clean obs

    def test_summary_string_contains_multiple_label(
        self, stats_calc: MultipleStatsCalculator
    ) -> None:
        series = _make_series([18.0, 22.0, 25.0], MultipleType.EV_EBITDA)
        stats = stats_calc.compute(series)
        assert "EV/EBITDA" in stats.summary()


# ══════════════════════════════════════════════════════════════════════════════
# MultipleCalculator
# ══════════════════════════════════════════════════════════════════════════════

class TestMultipleCalculator:

    def test_ev_revenue_formula(self) -> None:
        assert MultipleCalculator.ev_revenue(1_000.0, 100.0) == pytest.approx(10.0)

    def test_ev_revenue_none_denominator(self) -> None:
        assert MultipleCalculator.ev_revenue(1_000.0, None) is None

    def test_ev_revenue_zero_denominator(self) -> None:
        assert MultipleCalculator.ev_revenue(1_000.0, 0.0) is None

    def test_ev_ebitda_formula(self) -> None:
        assert MultipleCalculator.ev_ebitda(1_000.0, 100.0) == pytest.approx(10.0)

    def test_ev_ebitda_negative_ebitda_returns_none(self) -> None:
        assert MultipleCalculator.ev_ebitda(1_000.0, -50.0) is None

    def test_ev_ebit_formula(self) -> None:
        assert MultipleCalculator.ev_ebit(800.0, 80.0) == pytest.approx(10.0)

    def test_ev_ebit_negative_ebit_returns_none(self) -> None:
        assert MultipleCalculator.ev_ebit(800.0, -10.0) is None

    def test_pe_ratio_formula(self) -> None:
        assert MultipleCalculator.pe_ratio(100.0, 5.0) == pytest.approx(20.0)

    def test_pe_ratio_negative_eps_returns_none(self) -> None:
        assert MultipleCalculator.pe_ratio(100.0, -2.0) is None

    def test_pe_ratio_zero_eps_returns_none(self) -> None:
        assert MultipleCalculator.pe_ratio(100.0, 0.0) is None

    def test_pb_ratio_formula(self) -> None:
        # BVPS = (1000 - 0) / 10 = 100. P/B = 500 / 100 = 5.
        assert MultipleCalculator.pb_ratio(500.0, 1_000.0, 0.0, 10.0) == pytest.approx(5.0)

    def test_pb_ratio_negative_equity_returns_none(self) -> None:
        assert MultipleCalculator.pb_ratio(100.0, -500.0, 0.0, 10.0) is None

    def test_pb_ratio_zero_shares_returns_none(self) -> None:
        assert MultipleCalculator.pb_ratio(100.0, 1_000.0, 0.0, 0.0) is None

    def test_safe_divide_nan_returns_none(self) -> None:
        result = MultipleCalculator._safe_divide(float("inf"), float("inf"))
        assert result is None


# ══════════════════════════════════════════════════════════════════════════════
# ImplicationEngine
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def engine() -> ImplicationEngine:
    return ImplicationEngine()


class TestImplicationEngineEV:
    """EV-based multiples: EV/Revenue, EV/EBITDA, EV/EBIT."""

    def test_ev_ebitda_implied_ev_formula(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        """Implied EV = Subject EBITDA × Peer EV/EBITDA."""
        peer_multiple = 22.0
        result = engine.compute_one(
            multiple_type=MultipleType.EV_EBITDA,
            statistic_used="median",
            subject_metric=SUBJECT_EBITDA,
            peer_statistic=peer_multiple,
            subject=subject,
        )
        expected_ev = SUBJECT_EBITDA * peer_multiple
        assert result.implied_ev == pytest.approx(expected_ev)

    def test_ev_ebitda_equity_bridge(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        """Implied Equity = Implied EV − Net Debt."""
        peer_multiple = 22.0
        result = engine.compute_one(
            multiple_type=MultipleType.EV_EBITDA,
            statistic_used="median",
            subject_metric=SUBJECT_EBITDA,
            peer_statistic=peer_multiple,
            subject=subject,
        )
        expected_equity = (SUBJECT_EBITDA * peer_multiple) - SUBJECT_NET_DEBT
        assert result.implied_equity_value == pytest.approx(max(expected_equity, 0.0))

    def test_ev_ebitda_share_price(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        """Implied Price = Implied Equity / Shares Outstanding."""
        peer_multiple = 22.0
        result = engine.compute_one(
            multiple_type=MultipleType.EV_EBITDA,
            statistic_used="median",
            subject_metric=SUBJECT_EBITDA,
            peer_statistic=peer_multiple,
            subject=subject,
        )
        expected_equity = max((SUBJECT_EBITDA * peer_multiple) - SUBJECT_NET_DEBT, 0.0)
        expected_price  = expected_equity / SUBJECT_SHARES
        assert result.implied_share_price == pytest.approx(expected_price, rel=1e-6)

    def test_ev_revenue_implies_ev(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        result = engine.compute_one(
            multiple_type=MultipleType.EV_REVENUE,
            statistic_used="mean",
            subject_metric=SUBJECT_REVENUE,
            peer_statistic=7.0,
            subject=subject,
        )
        assert result.implied_ev == pytest.approx(SUBJECT_REVENUE * 7.0)

    def test_ev_ebit_formula(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        from tests.comps.conftest import SUBJECT_EBIT
        result = engine.compute_one(
            multiple_type=MultipleType.EV_EBIT,
            statistic_used="median",
            subject_metric=SUBJECT_EBIT,
            peer_statistic=25.0,
            subject=subject,
        )
        assert result.implied_ev == pytest.approx(SUBJECT_EBIT * 25.0)

    def test_net_debt_deduction_recorded(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        result = engine.compute_one(
            multiple_type=MultipleType.EV_EBITDA,
            statistic_used="median",
            subject_metric=SUBJECT_EBITDA,
            peer_statistic=20.0,
            subject=subject,
        )
        assert result.net_debt_deducted == pytest.approx(SUBJECT_NET_DEBT)

    def test_equity_floored_at_zero_when_debt_exceeds_ev(
        self, engine: ImplicationEngine
    ) -> None:
        """Net debt larger than implied EV → equity floored at 0."""
        subject = SubjectMetrics(
            ticker="TEST",
            ebitda_ltm=100.0,
            net_debt=10_000.0,   # much larger than implied EV
            shares_outstanding=100.0,
        )
        result = engine.compute_one(
            multiple_type=MultipleType.EV_EBITDA,
            statistic_used="median",
            subject_metric=100.0,
            peer_statistic=10.0,   # implied EV = 1000 < net_debt 10000
            subject=subject,
        )
        assert result.implied_equity_value == pytest.approx(0.0)
        assert result.implied_share_price == pytest.approx(0.0)


class TestImplicationEngineEquity:
    """Equity-level multiples: P/E, P/B."""

    def test_pe_implied_price_formula(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        """P/E: Implied Price = EPS_LTM × Peer P/E."""
        peer_pe = 30.0
        result = engine.compute_one(
            multiple_type=MultipleType.PE,
            statistic_used="median",
            subject_metric=SUBJECT_EPS,
            peer_statistic=peer_pe,
            subject=subject,
        )
        assert result.implied_share_price == pytest.approx(SUBJECT_EPS * peer_pe)

    def test_pe_implied_equity(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        """P/E: Implied Equity = Price × Shares."""
        peer_pe = 30.0
        result = engine.compute_one(
            multiple_type=MultipleType.PE,
            statistic_used="median",
            subject_metric=SUBJECT_EPS,
            peer_statistic=peer_pe,
            subject=subject,
        )
        expected_equity = SUBJECT_EPS * peer_pe * SUBJECT_SHARES
        assert result.implied_equity_value == pytest.approx(expected_equity, rel=1e-6)

    def test_pe_no_ev_field(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        result = engine.compute_one(
            multiple_type=MultipleType.PE,
            statistic_used="mean",
            subject_metric=SUBJECT_EPS,
            peer_statistic=28.0,
            subject=subject,
        )
        assert result.implied_ev is None

    def test_pb_implied_price(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        """P/B: Implied Price = BVPS × Peer P/B."""
        peer_pb = 8.0
        result = engine.compute_one(
            multiple_type=MultipleType.PB,
            statistic_used="median",
            subject_metric=SUBJECT_BVPS,
            peer_statistic=peer_pb,
            subject=subject,
        )
        assert result.implied_share_price == pytest.approx(SUBJECT_BVPS * peer_pb)

    def test_pe_no_net_debt_deduction(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        result = engine.compute_one(
            multiple_type=MultipleType.PE,
            statistic_used="median",
            subject_metric=SUBJECT_EPS,
            peer_statistic=28.0,
            subject=subject,
        )
        assert result.net_debt_deducted == pytest.approx(0.0)


class TestImplicationComputeAllStatistics:

    def test_returns_four_statistics(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        from comps.stats import MultipleStatsCalculator
        from comps.cleaner import CleanedSeries
        series = CleanedSeries(
            multiple_type=MultipleType.EV_EBITDA,
            clean_values=[18.0, 20.0, 22.0, 25.0, 28.0],
            clean_tickers=["A", "B", "C", "D", "E"],
            excluded=[],
        )
        stats = MultipleStatsCalculator().compute(series)
        results = engine.compute_all_statistics(stats, subject)
        assert set(results.keys()) == {"median", "mean", "q1", "q3"}

    def test_missing_subject_metric_returns_empty(
        self, engine: ImplicationEngine
    ) -> None:
        subject_no_ebitda = SubjectMetrics(
            ticker="TEST",
            ebitda_ltm=None,   # missing
            shares_outstanding=1_000_000.0,
        )
        from comps.stats import MultipleStatsCalculator
        from comps.cleaner import CleanedSeries
        series = CleanedSeries(
            multiple_type=MultipleType.EV_EBITDA,
            clean_values=[18.0, 20.0],
            clean_tickers=["A", "B"],
            excluded=[],
        )
        stats = MultipleStatsCalculator().compute(series)
        results = engine.compute_all_statistics(stats, subject_no_ebitda)
        assert results == {}

    def test_formula_display_contains_key_labels(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        result = engine.compute_one(
            multiple_type=MultipleType.EV_EBITDA,
            statistic_used="median",
            subject_metric=SUBJECT_EBITDA,
            peer_statistic=22.0,
            subject=subject,
        )
        display = result.formula_display()
        assert "EV/EBITDA" in display
        assert "Implied EV" in display
        assert "Implied Equity" in display
        assert "Implied Price" in display

    def test_pe_formula_display(
        self, engine: ImplicationEngine, subject: SubjectMetrics
    ) -> None:
        result = engine.compute_one(
            multiple_type=MultipleType.PE,
            statistic_used="median",
            subject_metric=SUBJECT_EPS,
            peer_statistic=30.0,
            subject=subject,
        )
        display = result.formula_display()
        assert "P/E" in display
        assert "Implied Price" in display
