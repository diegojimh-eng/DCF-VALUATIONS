"""
tests/comps/conftest.py
------------------------
Shared fixtures for all Trading Comparables tests.

Peer set: AAPL-like subject valued against a realistic Big-Tech peer set
(MSFT, GOOG, META, AMZN, NVDA, CRM, ORCL, SAP, ADBE, INTC — all approximate).

All values are in the same unit as the historical data (full dollars).
Multiples are LTM trailing.
"""

from __future__ import annotations

import pytest

from comps.models import (
    MultipleType,
    PeerData,
    SubjectMetrics,
)

# ── Subject company (AAPL LTM FY2023) ────────────────────────────────────────
SUBJECT_REVENUE  = 383_285_000_000
SUBJECT_EBITDA   = 125_820_000_000
SUBJECT_EBIT     = 114_301_000_000
SUBJECT_EPS      = 6.13
SUBJECT_BVPS     = 3.96     # total equity / diluted shares
SUBJECT_NET_DEBT =  74_800_000_000
SUBJECT_SHARES   =  15_671_000_000
SUBJECT_PRICE    = 175.50


@pytest.fixture
def subject() -> SubjectMetrics:
    return SubjectMetrics(
        ticker="AAPL",
        revenue_ltm=SUBJECT_REVENUE,
        ebitda_ltm=SUBJECT_EBITDA,
        ebit_ltm=SUBJECT_EBIT,
        eps_diluted_ltm=SUBJECT_EPS,
        book_value_per_share=SUBJECT_BVPS,
        net_debt=SUBJECT_NET_DEBT,
        minority_interest=0.0,
        preferred_equity=0.0,
        shares_outstanding=SUBJECT_SHARES,
    )


# ── Peer set (Big Tech comps, approximate LTM multiples) ──────────────────────

def _make_peer(
    ticker: str,
    name: str,
    ev_rev: float | None,
    ev_ebitda: float | None,
    ev_ebit: float | None,
    pe: float | None,
    pb: float | None,
    mktcap: float | None = None,
    ev: float | None = None,
    ebitda_margin: float | None = None,
    rev_growth: float | None = None,
) -> PeerData:
    return PeerData(
        ticker=ticker,
        company_name=name,
        market_cap=mktcap,
        enterprise_value=ev,
        ev_revenue=ev_rev,
        ev_ebitda=ev_ebitda,
        ev_ebit=ev_ebit,
        pe_ratio=pe,
        pb_ratio=pb,
        ebitda_margin=ebitda_margin,
        revenue_growth_1y=rev_growth,
    )


@pytest.fixture
def clean_peers() -> list[PeerData]:
    """Eight realistic Big-Tech peers — no outliers."""
    return [
        _make_peer("MSFT",  "Microsoft",    ev_rev=12.5, ev_ebitda=26.8, ev_ebit=30.2, pe=35.1, pb=13.2, ebitda_margin=0.50, rev_growth=0.16),
        _make_peer("GOOG",  "Alphabet",     ev_rev= 5.8, ev_ebitda=18.3, ev_ebit=22.0, pe=27.4, pb= 6.5, ebitda_margin=0.32, rev_growth=0.09),
        _make_peer("META",  "Meta",         ev_rev= 7.2, ev_ebitda=20.1, ev_ebit=24.5, pe=30.0, pb= 7.8, ebitda_margin=0.37, rev_growth=0.16),
        _make_peer("AMZN",  "Amazon",       ev_rev= 3.1, ev_ebitda=22.5, ev_ebit=35.0, pe=62.0, pb=10.1, ebitda_margin=0.14, rev_growth=0.12),
        _make_peer("NVDA",  "Nvidia",       ev_rev=25.0, ev_ebitda=45.0, ev_ebit=50.0, pe=65.0, pb=30.0, ebitda_margin=0.55, rev_growth=1.22),
        _make_peer("CRM",   "Salesforce",   ev_rev= 6.8, ev_ebitda=24.0, ev_ebit=28.0, pe=55.0, pb= 3.9, ebitda_margin=0.28, rev_growth=0.11),
        _make_peer("ORCL",  "Oracle",       ev_rev= 6.0, ev_ebitda=18.0, ev_ebit=20.0, pe=22.0, pb= 7.0, ebitda_margin=0.33, rev_growth=0.09),
        _make_peer("ADBE",  "Adobe",        ev_rev= 9.5, ev_ebitda=28.0, ev_ebit=32.0, pe=40.0, pb=14.0, ebitda_margin=0.34, rev_growth=0.10),
    ]


@pytest.fixture
def peers_with_outliers(clean_peers: list[PeerData]) -> list[PeerData]:
    """Same peers plus two extreme outliers that should be screened."""
    outliers = [
        # EV/EBITDA = 120× (way above 60× ceiling) — near-zero EBITDA company
        _make_peer("XYZ1", "Outlier High",  ev_rev=50.0, ev_ebitda=120.0, ev_ebit=200.0, pe=300.0, pb=80.0),
        # All None — data not available
        _make_peer("XYZ2", "Outlier None",  ev_rev=None, ev_ebitda=None, ev_ebit=None, pe=None, pb=None),
    ]
    return clean_peers + outliers


@pytest.fixture
def minimal_peers() -> list[PeerData]:
    """Two peers — enough for stats, too few for IQR screening."""
    return [
        _make_peer("MSFT", "Microsoft", ev_rev=12.5, ev_ebitda=26.8, ev_ebit=30.2, pe=35.1, pb=13.2),
        _make_peer("GOOG", "Alphabet",  ev_rev= 5.8, ev_ebitda=18.3, ev_ebit=22.0, pe=27.4, pb= 6.5),
    ]


@pytest.fixture
def single_peer() -> list[PeerData]:
    return [_make_peer("MSFT", "Microsoft", ev_rev=12.5, ev_ebitda=26.8, ev_ebit=30.2, pe=35.1, pb=13.2)]
