"""
tests/comps/test_cleaner.py
----------------------------
Tests for PeerCleaner — outlier screening, sanity bounds, and audit trail.
"""

from __future__ import annotations

import pytest

from comps.cleaner import PeerCleaner, CleanedSeries, _quartiles, _is_finite
from comps.models import MultipleType, PeerData


@pytest.fixture
def cleaner() -> PeerCleaner:
    return PeerCleaner(iqr_multiplier=1.5)


# ══════════════════════════════════════════════════════════════════════════════
# CleanedSeries properties
# ══════════════════════════════════════════════════════════════════════════════

class TestCleanedSeries:

    def test_raw_count_is_clean_plus_excluded(self) -> None:
        series = CleanedSeries(
            multiple_type=MultipleType.EV_EBITDA,
            clean_values=[15.0, 18.0, 20.0],
            clean_tickers=["A", "B", "C"],
            excluded=[("D", float("nan"), "missing"), ("E", 120.0, "bounds")],
        )
        assert series.raw_count == 5
        assert series.excluded_count == 2
        assert series.is_reliable is True

    def test_is_reliable_false_when_fewer_than_two(self) -> None:
        series = CleanedSeries(
            multiple_type=MultipleType.EV_EBITDA,
            clean_values=[15.0],
            clean_tickers=["A"],
            excluded=[],
        )
        assert series.is_reliable is False

    def test_excluded_tickers_extracted(self) -> None:
        series = CleanedSeries(
            multiple_type=MultipleType.PE,
            clean_values=[],
            clean_tickers=[],
            excluded=[("X1", 0.0, "missing"), ("X2", 300.0, "bounds")],
        )
        assert series.excluded_tickers == ["X1", "X2"]


# ══════════════════════════════════════════════════════════════════════════════
# Sanity bounds (hard limits)
# ══════════════════════════════════════════════════════════════════════════════

class TestSanityBounds:

    def test_ev_ebitda_above_ceiling_excluded(
        self, cleaner: PeerCleaner, clean_peers: list[PeerData]
    ) -> None:
        from comps.models import PeerData as PD
        high_peer = PD(ticker="HI", company_name="High", ev_ebitda=120.0)
        peers = clean_peers + [high_peer]
        result = cleaner.clean(peers, MultipleType.EV_EBITDA)
        assert "HI" not in result.clean_tickers
        assert any("bounds" in r for _, _, r in result.excluded if _ == "HI")

    def test_ev_ebitda_below_floor_excluded(self, cleaner: PeerCleaner) -> None:
        from comps.models import PeerData as PD
        # EV/EBITDA minimum is 2.0× — value of 1.0× should be excluded
        low_peer = PD(ticker="LO", company_name="Low", ev_ebitda=1.0)
        result = cleaner.clean([low_peer], MultipleType.EV_EBITDA)
        assert "LO" not in result.clean_tickers
        assert result.excluded_count == 1

    def test_none_value_excluded_as_missing(
        self, cleaner: PeerCleaner, clean_peers: list[PeerData]
    ) -> None:
        from comps.models import PeerData as PD
        null_peer = PD(ticker="NULL", company_name="Null", ev_ebitda=None)
        peers = [null_peer]
        result = cleaner.clean(peers, MultipleType.EV_EBITDA)
        assert result.excluded_count == 1
        assert "missing" in result.excluded[0][2]

    def test_pe_allows_high_values_within_range(self, cleaner: PeerCleaner) -> None:
        """P/E can be up to 200× — a value of 60 should pass."""
        from comps.models import PeerData as PD
        peer = PD(ticker="NVDA", company_name="Nvidia", pe_ratio=65.0)
        result = cleaner.clean([peer], MultipleType.PE)
        assert "NVDA" in result.clean_tickers

    def test_pe_above_two_hundred_excluded(self, cleaner: PeerCleaner) -> None:
        from comps.models import PeerData as PD
        peer = PD(ticker="EXT", company_name="Extreme", pe_ratio=250.0)
        result = cleaner.clean([peer], MultipleType.PE)
        assert result.clean_values == []

    def test_pb_zero_excluded_by_floor(self, cleaner: PeerCleaner) -> None:
        from comps.models import PeerData as PD
        peer = PD(ticker="Z", company_name="Zero", pb_ratio=0.0)
        result = cleaner.clean([peer], MultipleType.PB)
        assert result.clean_values == []


# ══════════════════════════════════════════════════════════════════════════════
# IQR outlier screening
# ══════════════════════════════════════════════════════════════════════════════

class TestIQRScreening:

    def test_iqr_screening_requires_4_observations(
        self, cleaner: PeerCleaner, minimal_peers: list[PeerData]
    ) -> None:
        """Fewer than 4 clean candidates → no IQR screening applied."""
        result = cleaner.clean(minimal_peers, MultipleType.EV_EBITDA)
        # Both peers should be kept (no screening with < 4 obs)
        assert result.clean_count == 2

    def test_iqr_outlier_excluded_with_8_peers(
        self, cleaner: PeerCleaner, peers_with_outliers: list[PeerData]
    ) -> None:
        """XYZ1 (EV/EBITDA=120×) is above sanity bound → excluded."""
        result = cleaner.clean(peers_with_outliers, MultipleType.EV_EBITDA)
        assert "XYZ1" not in result.clean_tickers
        assert "XYZ2" not in result.clean_tickers

    def test_clean_peers_pass_through_iqr(
        self, cleaner: PeerCleaner, clean_peers: list[PeerData]
    ) -> None:
        """All clean_peers should pass IQR screening for EV/EBITDA."""
        result = cleaner.clean(clean_peers, MultipleType.EV_EBITDA)
        # Nvidia at 45× may be an IQR outlier but that's expected with 1.5k
        assert result.clean_count >= 5   # majority should pass

    def test_conservative_multiplier_keeps_more_peers(
        self, peers_with_outliers: list[PeerData]
    ) -> None:
        """k=3.0 is less aggressive than k=1.5 — more peers kept."""
        strict  = PeerCleaner(iqr_multiplier=1.5)
        relaxed = PeerCleaner(iqr_multiplier=3.0)
        r_strict  = strict.clean(peers_with_outliers,  MultipleType.EV_EBITDA)
        r_relaxed = relaxed.clean(peers_with_outliers, MultipleType.EV_EBITDA)
        assert r_relaxed.clean_count >= r_strict.clean_count

    def test_excluded_reason_contains_fence_info(
        self, clean_peers: list[PeerData]
    ) -> None:
        """IQR-excluded entries should name the fence values."""
        from comps.models import PeerData as PD
        # Add a value guaranteed to be an IQR outlier: 0.5× EV/Revenue
        extreme_low = PD(ticker="EL", company_name="Extreme Low", ev_revenue=0.01)
        # Note: 0.01 is below the EV/Revenue floor of 0.1×
        cleaner = PeerCleaner()
        result  = cleaner.clean([extreme_low], MultipleType.EV_REVENUE)
        assert result.clean_count == 0


# ══════════════════════════════════════════════════════════════════════════════
# clean_all
# ══════════════════════════════════════════════════════════════════════════════

class TestCleanAll:

    def test_clean_all_returns_all_five_types(
        self, cleaner: PeerCleaner, clean_peers: list[PeerData]
    ) -> None:
        result = cleaner.clean_all(clean_peers)
        assert set(result.keys()) == set(MultipleType)

    def test_clean_all_subset(
        self, cleaner: PeerCleaner, clean_peers: list[PeerData]
    ) -> None:
        types = [MultipleType.EV_EBITDA, MultipleType.PE]
        result = cleaner.clean_all(clean_peers, types)
        assert set(result.keys()) == {MultipleType.EV_EBITDA, MultipleType.PE}

    def test_clean_all_empty_peers_gives_empty_series(
        self, cleaner: PeerCleaner
    ) -> None:
        result = cleaner.clean_all([])
        for mt, series in result.items():
            assert series.clean_values == []
            assert series.raw_count == 0


# ══════════════════════════════════════════════════════════════════════════════
# Helper functions
# ══════════════════════════════════════════════════════════════════════════════

class TestHelpers:

    def test_is_finite_nan(self) -> None:
        assert _is_finite(float("nan")) is False

    def test_is_finite_inf(self) -> None:
        assert _is_finite(float("inf")) is False

    def test_is_finite_negative_inf(self) -> None:
        assert _is_finite(float("-inf")) is False

    def test_is_finite_normal(self) -> None:
        assert _is_finite(18.5) is True
        assert _is_finite(0.0) is True
        assert _is_finite(-5.0) is True

    def test_quartiles_four_values(self) -> None:
        # [10, 20, 30, 40] → Q1=17.5, Q3=32.5
        q1, q3 = _quartiles([10.0, 20.0, 30.0, 40.0])
        assert q1 == pytest.approx(17.5)
        assert q3 == pytest.approx(32.5)

    def test_quartiles_sorted_order_independent(self) -> None:
        vals = [40.0, 10.0, 30.0, 20.0]
        q1, q3 = _quartiles(vals)
        assert q1 < q3

    def test_quartiles_same_values(self) -> None:
        q1, q3 = _quartiles([5.0, 5.0, 5.0, 5.0])
        assert q1 == pytest.approx(5.0)
        assert q3 == pytest.approx(5.0)
