"""
tests/comps/test_engine.py
--------------------------
Integration tests for CompsEngine — the full pipeline from raw peers
to CompsResult. Tests all five multiples end-to-end, outlier handling,
summary output, and football field integration.
"""

from __future__ import annotations

import pytest

from comps.engine import CompsEngine
from comps.models import (
    CompsResult,
    MultipleType,
    PeerData,
    SubjectMetrics,
)
from tests.comps.conftest import (
    SUBJECT_EBITDA,
    SUBJECT_EPS,
    SUBJECT_NET_DEBT,
    SUBJECT_REVENUE,
    SUBJECT_SHARES,
)


@pytest.fixture
def engine() -> CompsEngine:
    return CompsEngine(iqr_multiplier=1.5, min_reliable_peers=3)


@pytest.fixture
def result(
    engine: CompsEngine,
    subject: SubjectMetrics,
    clean_peers: list[PeerData],
) -> CompsResult:
    return engine.run(subject=subject, peers=clean_peers)


# ══════════════════════════════════════════════════════════════════════════════
# Basic structure
# ══════════════════════════════════════════════════════════════════════════════

class TestEngineStructure:

    def test_result_has_correct_ticker(self, result: CompsResult) -> None:
        assert result.ticker == "AAPL"

    def test_result_has_five_multiples_when_all_data_available(
        self, result: CompsResult
    ) -> None:
        assert len(result.multiples) == 5

    def test_all_multiple_types_present(self, result: CompsResult) -> None:
        for mt in MultipleType:
            assert mt.value in result.multiples

    def test_peer_table_has_one_row_per_peer(
        self, result: CompsResult, clean_peers: list[PeerData]
    ) -> None:
        assert len(result.peer_table) == len(clean_peers)

    def test_raw_peers_count(
        self, result: CompsResult, clean_peers: list[PeerData]
    ) -> None:
        assert len(result.raw_peers) == len(clean_peers)

    def test_valuation_date_set(self, result: CompsResult) -> None:
        assert result.valuation_date is not None

    def test_subject_attached(self, result: CompsResult, subject: SubjectMetrics) -> None:
        assert result.subject.ticker == subject.ticker


# ══════════════════════════════════════════════════════════════════════════════
# Per-multiple correctness
# ══════════════════════════════════════════════════════════════════════════════

class TestMultipleValues:

    def test_ev_ebitda_stats_have_positive_median(self, result: CompsResult) -> None:
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        assert cm is not None
        assert cm.stats.median > 0

    def test_ev_ebitda_median_in_reasonable_range(self, result: CompsResult) -> None:
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        assert cm is not None
        # Big tech EV/EBITDA should be somewhere between 15× and 50×
        assert 10.0 < cm.stats.median < 60.0

    def test_pe_stats_have_positive_median(self, result: CompsResult) -> None:
        cm = result.get_multiple(MultipleType.PE)
        assert cm is not None
        assert cm.stats.median > 0

    def test_mean_and_median_close_for_symmetric_distribution(
        self, engine: CompsEngine, subject: SubjectMetrics
    ) -> None:
        """For a tight, symmetric peer set mean ≈ median."""
        from comps.models import PeerData as PD
        symmetric_peers = [
            PD(ticker=f"P{i}", company_name=f"Peer{i}", ev_ebitda=float(v))
            for i, v in enumerate([18.0, 19.0, 20.0, 21.0, 22.0])
        ]
        r = engine.run(subject=subject, peers=symmetric_peers)
        cm = r.get_multiple(MultipleType.EV_EBITDA)
        assert cm is not None
        assert abs(cm.stats.mean - cm.stats.median) < 1.0   # within 1× of each other

    def test_q1_le_median_le_q3(self, result: CompsResult) -> None:
        for cm in result.multiples.values():
            assert cm.stats.q1 <= cm.stats.median
            assert cm.stats.median <= cm.stats.q3

    def test_min_le_q1_and_q3_le_max(self, result: CompsResult) -> None:
        for cm in result.multiples.values():
            assert cm.stats.min <= cm.stats.q1
            assert cm.stats.q3 <= cm.stats.max


# ══════════════════════════════════════════════════════════════════════════════
# Implied values
# ══════════════════════════════════════════════════════════════════════════════

class TestImpliedValues:

    def test_ev_ebitda_implied_ev_is_ebitda_times_median(
        self, result: CompsResult
    ) -> None:
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        assert cm is not None
        expected_ev = SUBJECT_EBITDA * cm.stats.median
        assert cm.implied_at_median.implied_ev == pytest.approx(expected_ev)

    def test_ev_ebitda_implied_equity_deducts_net_debt(
        self, result: CompsResult
    ) -> None:
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        assert cm is not None
        ev     = cm.implied_at_median.implied_ev
        equity = cm.implied_at_median.implied_equity_value
        assert equity == pytest.approx(max(ev - SUBJECT_NET_DEBT, 0.0))

    def test_ev_ebitda_price_is_equity_over_shares(
        self, result: CompsResult
    ) -> None:
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        assert cm is not None
        equity = cm.implied_at_median.implied_equity_value
        price  = cm.implied_at_median.implied_share_price
        assert price == pytest.approx(equity / SUBJECT_SHARES, rel=1e-6)

    def test_pe_implied_price_is_eps_times_median(
        self, result: CompsResult
    ) -> None:
        cm = result.get_multiple(MultipleType.PE)
        assert cm is not None
        expected = SUBJECT_EPS * cm.stats.median
        assert cm.implied_at_median.implied_share_price == pytest.approx(expected, rel=1e-4)

    def test_ev_revenue_implied_ev(self, result: CompsResult) -> None:
        cm = result.get_multiple(MultipleType.EV_REVENUE)
        assert cm is not None
        expected_ev = SUBJECT_REVENUE * cm.stats.median
        assert cm.implied_at_median.implied_ev == pytest.approx(expected_ev)

    def test_all_four_statistics_present(self, result: CompsResult) -> None:
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        assert cm is not None
        assert cm.implied_at_median is not None
        assert cm.implied_at_mean   is not None
        assert cm.implied_at_q1     is not None
        assert cm.implied_at_q3     is not None

    def test_q1_price_le_median_price_le_q3_price_for_ev_multiple(
        self, result: CompsResult
    ) -> None:
        """For EV multiples, Q1 multiple < median < Q3 → Q1 price < median price < Q3 price."""
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        assert cm is not None
        p_q1    = cm.implied_at_q1.implied_share_price
        p_med   = cm.implied_at_median.implied_share_price
        p_q3    = cm.implied_at_q3.implied_share_price
        assert p_q1 <= p_med
        assert p_med <= p_q3


# ══════════════════════════════════════════════════════════════════════════════
# Outlier handling
# ══════════════════════════════════════════════════════════════════════════════

class TestOutlierHandling:

    def test_outlier_peers_excluded_from_clean_tickers(
        self,
        engine: CompsEngine,
        subject: SubjectMetrics,
        peers_with_outliers: list[PeerData],
    ) -> None:
        result = engine.run(subject=subject, peers=peers_with_outliers)
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        if cm:
            assert "XYZ1" not in cm.clean_tickers
            assert "XYZ2" not in cm.clean_tickers

    def test_excluded_peer_marked_in_peer_table(
        self,
        engine: CompsEngine,
        subject: SubjectMetrics,
        peers_with_outliers: list[PeerData],
    ) -> None:
        result = engine.run(subject=subject, peers=peers_with_outliers)
        # Find XYZ1 in peer table
        xyz1_rows = [r for r in result.peer_table if r.ticker == "XYZ1"]
        assert len(xyz1_rows) == 1
        assert xyz1_rows[0].is_excluded is True

    def test_exclusion_reasons_attached(
        self,
        engine: CompsEngine,
        subject: SubjectMetrics,
        peers_with_outliers: list[PeerData],
    ) -> None:
        result = engine.run(subject=subject, peers=peers_with_outliers)
        xyz1_rows = [r for r in result.peer_table if r.ticker == "XYZ1"]
        if xyz1_rows and xyz1_rows[0].is_excluded:
            assert len(xyz1_rows[0].exclusion_reasons) > 0

    def test_result_with_outliers_still_valid(
        self,
        engine: CompsEngine,
        subject: SubjectMetrics,
        peers_with_outliers: list[PeerData],
    ) -> None:
        result = engine.run(subject=subject, peers=peers_with_outliers)
        # Should not raise; should produce a valid result
        assert result.ticker == "AAPL"
        assert len(result.multiples) > 0


# ══════════════════════════════════════════════════════════════════════════════
# Implied price summary
# ══════════════════════════════════════════════════════════════════════════════

class TestImpliedPriceSummary:

    def test_implied_price_central_is_ev_ebitda_median(
        self, result: CompsResult
    ) -> None:
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        if cm and cm.is_reliable:
            assert result.implied_price_central == pytest.approx(
                cm.implied_at_median.implied_share_price, rel=1e-6
            )

    def test_implied_price_low_le_high(self, result: CompsResult) -> None:
        if result.implied_price_low and result.implied_price_high:
            assert result.implied_price_low <= result.implied_price_high

    def test_implied_price_central_within_low_high(
        self, result: CompsResult
    ) -> None:
        lo = result.implied_price_low
        hi = result.implied_price_high
        c  = result.implied_price_central
        if lo and hi and c:
            assert lo <= c <= hi + 0.01   # tiny rounding tolerance


# ══════════════════════════════════════════════════════════════════════════════
# Edge cases
# ══════════════════════════════════════════════════════════════════════════════

class TestEdgeCases:

    def test_empty_peers_returns_result_with_warnings(
        self, engine: CompsEngine, subject: SubjectMetrics
    ) -> None:
        result = engine.run(subject=subject, peers=[])
        assert len(result.warnings) > 0
        assert len(result.multiples) == 0

    def test_single_peer_unreliable(
        self, engine: CompsEngine, subject: SubjectMetrics, single_peer: list[PeerData]
    ) -> None:
        result = engine.run(subject=subject, peers=single_peer)
        for cm in result.multiples.values():
            # min_reliable_peers=3, so a single peer should be unreliable
            assert cm.is_reliable is False

    def test_two_peers_below_min_reliable(
        self,
        engine: CompsEngine,
        subject: SubjectMetrics,
        minimal_peers: list[PeerData],
    ) -> None:
        result = engine.run(subject=subject, peers=minimal_peers)
        ev_ebitda_cm = result.get_multiple(MultipleType.EV_EBITDA)
        if ev_ebitda_cm:
            assert ev_ebitda_cm.is_reliable is False   # min_reliable_peers=3

    def test_warning_when_fewer_than_five_peers(
        self, engine: CompsEngine, subject: SubjectMetrics, minimal_peers: list[PeerData]
    ) -> None:
        result = engine.run(subject=subject, peers=minimal_peers)
        assert any("Only" in w for w in result.warnings)

    def test_subject_with_no_eps_skips_pe(
        self, engine: CompsEngine, clean_peers: list[PeerData]
    ) -> None:
        subject_no_eps = SubjectMetrics(
            ticker="NOEPS",
            revenue_ltm=100_000_000.0,
            ebitda_ltm=30_000_000.0,
            ebit_ltm=20_000_000.0,
            eps_diluted_ltm=None,      # no EPS
            book_value_per_share=5.0,
            shares_outstanding=10_000_000.0,
        )
        result = engine.run(subject=subject_no_eps, peers=clean_peers)
        # PE should either be missing or its implied values should be empty
        pe_cm = result.get_multiple(MultipleType.PE)
        # If PE is computed, its subject_metric should not be None
        if pe_cm:
            assert pe_cm.implied_at_median.subject_metric is not None


# ══════════════════════════════════════════════════════════════════════════════
# Output formats
# ══════════════════════════════════════════════════════════════════════════════

class TestOutputFormats:

    def test_summary_table_has_five_rows(self, result: CompsResult) -> None:
        table = result.summary_table()
        assert len(table) == 5

    def test_summary_table_row_keys(self, result: CompsResult) -> None:
        required_keys = {
            "multiple", "median", "mean", "q1", "q3", "min", "max",
            "n_peers", "n_excluded",
            "implied_price_median", "implied_price_mean",
            "implied_price_q1", "implied_price_q3",
            "is_reliable",
        }
        for row in result.summary_table():
            assert required_keys.issubset(set(row.keys()))

    def test_football_field_ranges_list(self, result: CompsResult) -> None:
        ff_ranges = result.to_football_field_ranges(current_price=175.50)
        # Should have one bar per reliable multiple
        reliable_count = len(result.reliable_multiples)
        assert len(ff_ranges) == reliable_count

    def test_football_field_range_keys(self, result: CompsResult) -> None:
        for bar in result.to_football_field_ranges():
            assert "method" in bar
            assert "low" in bar
            assert "high" in bar
            assert "midpoint" in bar

    def test_football_field_low_le_high(self, result: CompsResult) -> None:
        for bar in result.to_football_field_ranges():
            assert bar["low"] <= bar["high"]

    def test_reliable_multiples_property(self, result: CompsResult) -> None:
        for cm in result.reliable_multiples:
            assert cm.is_reliable is True

    def test_peer_table_ticker_matches_peer(
        self, result: CompsResult, clean_peers: list[PeerData]
    ) -> None:
        peer_tickers = {p.ticker for p in clean_peers}
        table_tickers = {row.ticker for row in result.peer_table}
        assert peer_tickers == table_tickers

    def test_price_range_tuple(self, result: CompsResult) -> None:
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        if cm:
            lo, hi = cm.price_range
            assert lo <= hi or abs(lo - hi) < 0.01  # Q1 ≤ Q3 price

    def test_median_price_property(self, result: CompsResult) -> None:
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        if cm:
            assert cm.median_price == cm.implied_at_median.implied_share_price

    def test_mean_price_property(self, result: CompsResult) -> None:
        cm = result.get_multiple(MultipleType.EV_EBITDA)
        if cm:
            assert cm.mean_price == cm.implied_at_mean.implied_share_price
