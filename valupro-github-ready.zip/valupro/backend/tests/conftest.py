"""
tests/conftest.py
-----------------
Root conftest: shared fixtures available to ALL test modules.
Phase-specific fixtures live in their own conftest.py files.
"""
from __future__ import annotations

import os
import pytest

# ── Ensure test environment is always development ─────────────────────────────
os.environ.setdefault("APP_ENV", "development")
os.environ.setdefault("FMP_API_KEY", "test-fmp-key-not-real")
os.environ.setdefault("ANTHROPIC_API_KEY", "test-anthropic-key-not-real")
os.environ.setdefault("API_SECRET_KEY", "test-jwt-secret-32-chars-minimum!!")
os.environ.setdefault("DATABASE_URL", "postgresql+asyncpg://valupro:valupro@localhost:5432/valupro_test")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379/1")   # DB 1 for tests


@pytest.fixture(autouse=True)
def reset_settings_cache():
    """Clear the lru_cache on get_settings() after each test."""
    yield
    try:
        from config import get_settings
        get_settings.cache_clear()
    except Exception:
        pass
