"""
tests/memo/test_memo_models.py
-------------------------------
Unit tests for the AI memo Pydantic models and context builder.
No external API calls — tests pure data construction logic.
"""
from __future__ import annotations

import pytest
from datetime import datetime

from memo.models import (
    Rating, ConvictionLevel, TokenUsage,
    ExecutiveSummary, Recommendation, InvestmentMemo,
    InvestmentThesis, CompetitiveMoat, GrowthDrivers,
    KeyRisks, Catalysts, ValuationDiscussion,
)


# ── TokenUsage ─────────────────────────────────────────────────────────────────

class TestTokenUsage:
    def test_total_tokens(self):
        u = TokenUsage(input_tokens=100, output_tokens=250)
        assert u.total_tokens == 350

    def test_addition(self):
        a = TokenUsage(input_tokens=100, output_tokens=200)
        b = TokenUsage(input_tokens=150, output_tokens=300)
        c = a + b
        assert c.input_tokens == 250
        assert c.output_tokens == 500

    def test_zero_default(self):
        u = TokenUsage()
        assert u.total_tokens == 0


# ── Rating ─────────────────────────────────────────────────────────────────────

class TestRating:
    def test_buy_signal_color_green(self):
        assert Rating.BUY.signal_color == "green"

    def test_sell_signal_color_red(self):
        assert Rating.SELL.signal_color == "red"

    def test_hold_signal_color_amber(self):
        assert Rating.HOLD.signal_color == "amber"

    def test_strong_buy_is_green(self):
        assert Rating.STRONG_BUY.signal_color == "green"

    def test_underperform_is_red(self):
        assert Rating.UNDERPERFORM.signal_color == "red"


# ── InvestmentMemo ─────────────────────────────────────────────────────────────

def _make_section(cls, text="Test prose text.", **kwargs):
    return cls(raw_text=text, usage=TokenUsage(input_tokens=100, output_tokens=200), **kwargs)


def _make_memo() -> InvestmentMemo:
    return InvestmentMemo(
        ticker="AAPL",
        company_name="Apple Inc.",
        executive_summary=_make_section(ExecutiveSummary, paragraphs=["Para 1.", "Para 2."]),
        investment_thesis=_make_section(InvestmentThesis, thesis_points=["Point 1", "Point 2"]),
        competitive_moat=_make_section(CompetitiveMoat),
        growth_drivers=_make_section(GrowthDrivers),
        key_risks=_make_section(KeyRisks),
        catalysts=_make_section(Catalysts),
        valuation_discussion=_make_section(ValuationDiscussion),
        recommendation=Recommendation(
            raw_text="Rating: BUY | Target: $201 | Upside: +14.5% | Conviction: HIGH",
            usage=TokenUsage(input_tokens=80, output_tokens=150),
            rating=Rating.BUY,
            target_price=201.00,
            current_price=175.50,
            upside_pct=0.145,
            conviction=ConvictionLevel.HIGH,
        ),
        total_usage=TokenUsage(input_tokens=800, output_tokens=1600),
    )


class TestInvestmentMemo:
    def test_memo_to_dict_has_all_sections(self):
        memo = _make_memo()
        d = memo.to_dict()
        assert "sections" in d
        for section in [
            "executive_summary", "investment_thesis", "competitive_moat",
            "growth_drivers", "key_risks", "catalysts",
            "valuation_discussion", "recommendation",
        ]:
            assert section in d["sections"], f"Missing section: {section}"

    def test_memo_to_dict_recommendation_has_rating(self):
        memo = _make_memo()
        rec = memo.to_dict()["sections"]["recommendation"]
        assert rec["rating"] == "BUY"
        assert rec["target_price"] == pytest.approx(201.00)

    def test_memo_full_text_contains_all_headers(self):
        memo = _make_memo()
        text = memo.full_text()
        for header in [
            "EXECUTIVE SUMMARY", "INVESTMENT THESIS", "COMPETITIVE ADVANTAGES",
            "GROWTH DRIVERS", "KEY RISKS", "CATALYSTS",
            "VALUATION DISCUSSION", "RECOMMENDATION",
        ]:
            assert header in text, f"Missing header: {header}"

    def test_memo_total_usage(self):
        memo = _make_memo()
        assert memo.total_usage.total_tokens == 2400

    def test_memo_ticker_normalised(self):
        memo = _make_memo()
        assert memo.ticker == "AAPL"

    def test_recommendation_upside_stored(self):
        memo = _make_memo()
        assert memo.recommendation.upside_pct == pytest.approx(0.145)

    def test_conviction_level_enum(self):
        memo = _make_memo()
        assert memo.recommendation.conviction == ConvictionLevel.HIGH


# ── MemoContext ────────────────────────────────────────────────────────────────

class TestMemoContext:
    def test_context_string_contains_ticker(self):
        from memo.context import MemoContext
        ctx = MemoContext(ticker="NVDA", company_name="NVIDIA Corporation")
        text = ctx.build_context_string()
        assert "NVDA" in text

    def test_context_string_contains_company_name(self):
        from memo.context import MemoContext
        ctx = MemoContext(ticker="NVDA", company_name="NVIDIA Corporation")
        text = ctx.build_context_string()
        assert "NVIDIA" in text

    def test_context_with_all_fields(self):
        from memo.context import MemoContext
        ctx = MemoContext(
            ticker="AAPL",
            company_name="Apple Inc.",
            current_price=175.50,
            base_fvps=201.40,
            wacc=0.0912,
            terminal_growth_rate=0.025,
            enterprise_value=2_982e9,
        )
        text = ctx.build_context_string()
        assert "$175.50" in text
        assert "9.12%" in text
        assert "2.50%" in text

    def test_missing_fields_show_na(self):
        from memo.context import MemoContext
        ctx = MemoContext(ticker="XYZ", company_name="XYZ Corp")
        text = ctx.build_context_string()
        assert "N/A" in text

    def test_context_builder_defensive_on_none_inputs(self):
        from memo.context import MemoContextBuilder
        ctx = MemoContextBuilder.from_pipeline_outputs(
            ticker="TEST",
            company_name="Test Corp",
            valuation_result=None,
            scenario_analysis=None,
            sensitivity_matrix=None,
            comps_result=None,
        )
        assert ctx.ticker == "TEST"
        assert ctx.base_fvps is None   # gracefully None, not an exception
