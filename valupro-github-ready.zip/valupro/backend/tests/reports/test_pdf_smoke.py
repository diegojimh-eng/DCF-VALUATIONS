"""
tests/reports/test_pdf_smoke.py
--------------------------------
Smoke tests for the PDF report builder.
Verifies the full pipeline produces a valid PDF without calling any
external API.
"""
from __future__ import annotations

import warnings
import pytest

warnings.filterwarnings("ignore")

import matplotlib
matplotlib.use("Agg")


@pytest.mark.unit
def test_pdf_has_correct_header():
    """The demo PDF builder must produce a valid PDF file."""
    from reports.renderer import build_report_from_mock
    pdf = build_report_from_mock("AAPL")
    assert pdf[:4] == b"%PDF", "Output is not a valid PDF"


@pytest.mark.unit
def test_pdf_minimum_size():
    """A complete report with 7 charts must be at least 200 KB."""
    from reports.renderer import build_report_from_mock
    pdf = build_report_from_mock("AAPL")
    assert len(pdf) > 200_000, f"PDF too small ({len(pdf) // 1024} KB) — charts may have failed"


@pytest.mark.unit
def test_pdf_ends_with_eof_marker():
    """Valid PDFs always end with %%EOF."""
    from reports.renderer import build_report_from_mock
    pdf = build_report_from_mock("TEST")
    assert b"%%EOF" in pdf[-32:], "PDF missing %%EOF marker"


@pytest.mark.unit
def test_pdf_different_tickers():
    """Builder should work for any ticker string."""
    from reports.renderer import build_report_from_mock
    for ticker in ("MSFT", "GOOG", "NVDA"):
        pdf = build_report_from_mock(ticker)
        assert pdf[:4] == b"%PDF", f"Invalid PDF for ticker {ticker}"
