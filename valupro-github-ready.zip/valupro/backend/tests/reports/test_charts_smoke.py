"""
tests/reports/test_charts_smoke.py
------------------------------------
Smoke tests for all 7 Matplotlib chart renderers.
Verifies each function produces valid PNG bytes without raising.
No display required — uses Agg backend.
"""
from __future__ import annotations

import warnings
import pytest

warnings.filterwarnings("ignore")

import matplotlib
matplotlib.use("Agg")   # headless rendering — must be before any pyplot import


# ── Minimal mock data ─────────────────────────────────────────────────────────

WACC  = 0.0912
G     = 0.025
FCFF  = [99e9 * 1.08 ** (i + 1) for i in range(10)]
YEARS = list(range(2024, 2034))
ND    = 74.8e9
SHR   = 15.67e9


class _FY:
    """Minimal ForecastYear-like object for chart tests."""
    def __init__(self, i: int, mult: float = 1.0) -> None:
        self.fiscal_year         = YEARS[i]
        self.revenue             = 400e9 * 1.08 ** (i + 1)
        self.revenue_growth_rate = 0.08
        self.ebitda              = 120e9 * 1.09 ** (i + 1)
        self.ebitda_margin       = 0.30
        self.ebit                = 110e9 * 1.09 ** (i + 1)
        self.fcff                = FCFF[i] * mult


class _DCFRow:
    def __init__(self, i: int) -> None:
        self.year_index      = i + 1
        self.fiscal_year     = YEARS[i]
        self.fcff            = FCFF[i]
        self.discount_factor = 1 / (1 + WACC) ** (i + 1)
        self.pv_fcff         = self.fcff * self.discount_factor


BASE  = [_FY(i)        for i in range(10)]
BEAR  = [_FY(i, 0.75)  for i in range(10)]
BULL  = [_FY(i, 1.25)  for i in range(10)]
SCHED = [_DCFRow(i)    for i in range(10)]
SUM_PV = sum(r.pv_fcff for r in SCHED)
TV     = FCFF[-1] * (1 + G) / (WACC - G)
PV_TV  = TV / (1 + WACC) ** 10
EV     = SUM_PV + PV_TV


def _fvps(w: float, g: float) -> float:
    if w - g < 0.005:
        return 0.0
    pv_f = sum(FCFF[i] / (1 + w) ** (i + 1) for i in range(10))
    tv_c = FCFF[-1] * (1 + g) / (w - g)
    return max(0, (pv_f + tv_c / (1 + w) ** 10 - ND) / SHR)


WACC_V = [0.07, 0.08, 0.09, 0.10, 0.11]
G_V    = [0.015, 0.020, 0.025, 0.030]
MATRIX = [[_fvps(w, g) for g in G_V] for w in WACC_V]
FF     = [
    {"method": "DCF — Bear", "low": 140.0, "high": 165.0, "midpoint": 152.5},
    {"method": "DCF — Base", "low": 185.0, "high": 215.0, "midpoint": 200.0},
    {"method": "DCF — Bull", "low": 225.0, "high": 265.0, "midpoint": 245.0},
]


# ── Tests ─────────────────────────────────────────────────────────────────────

@pytest.mark.unit
def test_revenue_chart_produces_png():
    from reports.charts.forecast import revenue_chart
    png = revenue_chart(BEAR, BASE, BULL)
    assert png[:4] == b"\x89PNG", "revenue_chart did not produce valid PNG"
    assert len(png) > 10_000, f"PNG too small: {len(png)} bytes"


@pytest.mark.unit
def test_ebitda_chart_produces_png():
    from reports.charts.forecast import ebitda_chart
    png = ebitda_chart(BEAR, BASE, BULL)
    assert png[:4] == b"\x89PNG"
    assert len(png) > 10_000


@pytest.mark.unit
def test_fcff_chart_produces_png():
    from reports.charts.forecast import fcff_chart
    pv = [r.pv_fcff for r in SCHED]
    png = fcff_chart(BEAR, BASE, BULL, pv_fcff=pv)
    assert png[:4] == b"\x89PNG"
    assert len(png) > 10_000


@pytest.mark.unit
def test_dcf_waterfall_produces_png():
    from reports.charts.waterfall import dcf_waterfall_chart
    png = dcf_waterfall_chart(SCHED, PV_TV, EV)
    assert png[:4] == b"\x89PNG"
    assert len(png) > 10_000


@pytest.mark.unit
def test_ev_bridge_produces_png():
    from reports.charts.waterfall import ev_bridge_chart
    equity = EV - ND
    png = ev_bridge_chart(EV, ND, 0.0, 0.0, equity, SHR, equity / SHR)
    assert png[:4] == b"\x89PNG"
    assert len(png) > 10_000


@pytest.mark.unit
def test_sensitivity_heatmap_produces_png():
    from reports.charts.valuation_charts import sensitivity_heatmap
    png = sensitivity_heatmap(WACC_V, G_V, MATRIX, 0.09, 0.025)
    assert png[:4] == b"\x89PNG"
    assert len(png) > 10_000


@pytest.mark.unit
def test_football_field_produces_png():
    from reports.charts.valuation_charts import football_field_chart
    png = football_field_chart(FF, current_price=175.50)
    assert png[:4] == b"\x89PNG"
    assert len(png) > 10_000


@pytest.mark.unit
def test_all_seven_charts_combined_size():
    """Total PNG bytes should be in the 200–600 KB range."""
    import warnings
    warnings.filterwarnings("ignore")
    from reports.charts.forecast import revenue_chart, ebitda_chart, fcff_chart
    from reports.charts.waterfall import dcf_waterfall_chart, ev_bridge_chart
    from reports.charts.valuation_charts import sensitivity_heatmap, football_field_chart

    pv = [r.pv_fcff for r in SCHED]
    equity = EV - ND
    charts = [
        revenue_chart(BEAR, BASE, BULL),
        ebitda_chart(BEAR, BASE, BULL),
        fcff_chart(BEAR, BASE, BULL, pv_fcff=pv),
        dcf_waterfall_chart(SCHED, PV_TV, EV),
        ev_bridge_chart(EV, ND, 0.0, 0.0, equity, SHR, equity / SHR),
        sensitivity_heatmap(WACC_V, G_V, MATRIX, 0.09, 0.025),
        football_field_chart(FF, current_price=175.50),
    ]
    total_kb = sum(len(c) for c in charts) // 1024
    assert 150 < total_kb < 800, f"Unexpected total chart size: {total_kb} KB"
