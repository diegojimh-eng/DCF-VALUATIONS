"""
tests/engine/test_assumption_models.py
---------------------------------------
Tests for assumption Pydantic models — validation rules, defaults,
and normalisation behaviour.
"""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from engine.assumptions.models import (
    CapExAssumptions,
    DAAssumptions,
    ForecastAssumptions,
    MarginAssumptions,
    NWCAssumptions,
    RevenueAssumptions,
    ScenarioType,
    TrendMethod,
)


class TestRevenueAssumptions:

    def test_growth_rates_must_be_10_entries(self) -> None:
        with pytest.raises(ValidationError):
            RevenueAssumptions(growth_rates=[0.10, 0.08])   # only 2 entries

    def test_growth_rates_10_entries_valid(self) -> None:
        ra = RevenueAssumptions(growth_rates=[0.10] * 10)
        assert ra.growth_rates is not None
        assert len(ra.growth_rates) == 10

    def test_all_none_defaults_are_valid(self) -> None:
        ra = RevenueAssumptions()
        assert ra.growth_rates is None
        assert ra.constant_growth_rate is None
        assert ra.near_term_growth is None
        assert ra.trend_method == TrendMethod.CAGR

    def test_floor_and_ceiling_defaults(self) -> None:
        ra = RevenueAssumptions()
        assert ra.growth_floor == pytest.approx(-0.50)
        assert ra.growth_ceiling == pytest.approx(2.00)


class TestMarginAssumptions:

    def test_ebitda_margin_by_year_must_be_10(self) -> None:
        with pytest.raises(ValidationError):
            MarginAssumptions(ebitda_margin_by_year=[0.30] * 5)

    def test_tax_rate_bounds(self) -> None:
        with pytest.raises(ValidationError):
            MarginAssumptions(effective_tax_rate=1.5)   # above 1.0
        with pytest.raises(ValidationError):
            MarginAssumptions(effective_tax_rate=-0.1)  # below 0.0

    def test_valid_tax_rate(self) -> None:
        ma = MarginAssumptions(effective_tax_rate=0.25)
        assert ma.effective_tax_rate == pytest.approx(0.25)

    def test_all_none_is_valid(self) -> None:
        ma = MarginAssumptions()
        assert ma.ebitda_margin is None
        assert ma.effective_tax_rate is None


class TestDAAssumptions:

    def test_da_pct_bounds_enforced(self) -> None:
        with pytest.raises(ValidationError):
            DAAssumptions(da_as_pct_revenue=0.60)   # above 0.5

    def test_da_by_year_must_be_10(self) -> None:
        with pytest.raises(ValidationError):
            DAAssumptions(da_as_pct_revenue_by_year=[0.03] * 3)

    def test_valid_da(self) -> None:
        da = DAAssumptions(da_as_pct_revenue=0.03)
        assert da.da_as_pct_revenue == pytest.approx(0.03)


class TestCapExAssumptions:

    def test_capex_pct_bounds(self) -> None:
        with pytest.raises(ValidationError):
            CapExAssumptions(capex_as_pct_revenue=1.5)   # above 1.0

    def test_by_year_must_be_10(self) -> None:
        with pytest.raises(ValidationError):
            CapExAssumptions(capex_as_pct_revenue_by_year=[0.05] * 5)

    def test_maintenance_and_growth_can_coexist(self) -> None:
        ca = CapExAssumptions(maintenance_capex_pct=0.02, growth_capex_pct=0.03)
        assert ca.maintenance_capex_pct == pytest.approx(0.02)
        assert ca.growth_capex_pct == pytest.approx(0.03)


class TestNWCAssumptions:

    def test_by_year_must_be_10(self) -> None:
        with pytest.raises(ValidationError):
            NWCAssumptions(nwc_as_pct_revenue_by_year=[0.05] * 7)

    def test_component_days_optional(self) -> None:
        na = NWCAssumptions(accounts_receivable_days=45.0)
        assert na.accounts_receivable_days == pytest.approx(45.0)
        assert na.inventory_days is None


class TestForecastAssumptions:

    def test_ticker_normalised_to_uppercase(self) -> None:
        fa = ForecastAssumptions(ticker="aapl")
        assert fa.ticker == "AAPL"

    def test_whitespace_stripped(self) -> None:
        fa = ForecastAssumptions(ticker="  MSFT  ")
        assert fa.ticker == "MSFT"

    def test_defaults_are_trend_based(self) -> None:
        fa = ForecastAssumptions(ticker="AAPL")
        assert fa.revenue.constant_growth_rate is None
        assert fa.margins.ebitda_margin is None
        assert fa.da.da_as_pct_revenue is None
        assert fa.capex.capex_as_pct_revenue is None
        assert fa.nwc.nwc_as_pct_revenue is None

    def test_forecast_years_bounds(self) -> None:
        with pytest.raises(ValidationError):
            ForecastAssumptions(ticker="AAPL", forecast_years=25)  # above 20
        with pytest.raises(ValidationError):
            ForecastAssumptions(ticker="AAPL", forecast_years=0)   # below 1

    def test_scenario_adjustment_default_zero(self) -> None:
        fa = ForecastAssumptions(ticker="AAPL")
        assert fa.revenue_growth_adjustment == pytest.approx(0.0)
        assert fa.ebitda_margin_adjustment == pytest.approx(0.0)
        assert fa.tax_rate_adjustment == pytest.approx(0.0)

    def test_immutable_after_creation(self) -> None:
        fa = ForecastAssumptions(ticker="AAPL")
        with pytest.raises(Exception):   # frozen model
            fa.ticker = "GOOG"  # type: ignore[misc]

    def test_model_copy_with_update_for_scenario(self) -> None:
        base = ForecastAssumptions(ticker="AAPL", scenario=ScenarioType.BASE)
        bear = base.model_copy(update={"scenario": ScenarioType.BEAR,
                                       "revenue_growth_adjustment": -0.03})
        assert bear.scenario == ScenarioType.BEAR
        assert bear.revenue_growth_adjustment == pytest.approx(-0.03)
        assert base.scenario == ScenarioType.BASE  # original unchanged
