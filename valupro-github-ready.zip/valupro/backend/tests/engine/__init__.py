"""
tests/engine/conftest.py
-------------------------
Shared fixtures for all forecasting engine tests.

Provides:
  - Realistic AAPL-like historical financial series (5 years)
  - Pre-built HistoricalSeries for direct forecaster testing
  - Default ForecastAssumptions in manual, trend, and hybrid modes
  - A fake FinancialsBundle for pipeline integration tests
"""

from __future__ import annotations

from datetime import date

import pytest

from engine.assumptions.models import (
    CapExAssumptions,
    DAAssumptions,
    ForecastAssumptions,
    MarginAssumptions,
    NWCAssumptions,
    RevenueAssumptions,
    ScenarioType,
    TrendMethod,
)
from engine.assumptions.trend_analyser import TrendAnalyser
from engine.pipeline.historical_extractor import HistoricalSeries


# ── Historical revenue series (newest-first, AAPL-scale) ──────────────────────
# FY2023, FY2022, FY2021, FY2020, FY2019
HIST_REVENUES = [
    383_285_000_000,   # FY2023
    394_328_000_000,   # FY2022
    365_817_000_000,   # FY2021
    274_515_000_000,   # FY2020
    260_174_000_000,   # FY2019
]

HIST_EBITDA = [
    125_820_000_000,
    130_541_000_000,
    120_233_000_000,
     77_344_000_000,
     76_477_000_000,
]

HIST_EBIT = [
    114_301_000_000,
    119_437_000_000,
    108_949_000_000,
     66_288_000_000,
     63_930_000_000,
]

HIST_TAX_EXPENSE = [
     29_749_000_000,
     19_300_000_000,
     14_527_000_000,
      9_680_000_000,
     10_481_000_000,
]

HIST_PRETAX_INCOME = [
    113_736_000_000,
    119_103_000_000,
    109_207_000_000,
     67_091_000_000,
     65_737_000_000,
]

HIST_DA = [   # from CFS, positive
     11_519_000_000,
     11_104_000_000,
     11_284_000_000,
     11_056_000_000,
     12_547_000_000,
]

HIST_CAPEX = [   # negative (cash outflow)
    -10_959_000_000,
    -10_708_000_000,
    -11_085_000_000,
     -7_309_000_000,
     -6_383_000_000,
]

HIST_NWC = [   # derived: current_assets - current_liabilities
    -1_742_000_000,
     -3_443_000_000,
     -4_016_000_000,
     17_589_000_000,
     22_279_000_000,
]

HIST_COST_OF_REVENUE = [
    214_137_000_000,
    223_546_000_000,
    212_981_000_000,
    169_559_000_000,
    161_782_000_000,
]

HIST_FISCAL_YEARS = [2023, 2022, 2021, 2020, 2019]


@pytest.fixture
def historical_series() -> HistoricalSeries:
    """Realistic AAPL-like historical series for testing trend derivation."""
    return HistoricalSeries(
        fiscal_years=HIST_FISCAL_YEARS,
        revenue=HIST_REVENUES,
        ebitda=HIST_EBITDA,
        ebit=HIST_EBIT,
        tax_expense=HIST_TAX_EXPENSE,
        pretax_income=HIST_PRETAX_INCOME,
        net_income=[None] * 5,
        da_is=HIST_DA,
        cost_of_revenue=HIST_COST_OF_REVENUE,
        da_cfs=HIST_DA,
        capex=HIST_CAPEX,
        total_current_assets=[None] * 5,
        total_current_liabilities=[None] * 5,
        nwc=HIST_NWC,
        cogs_pct_revenue=0.559,   # ~AAPL COGS margin
    )


@pytest.fixture
def analyser() -> TrendAnalyser:
    return TrendAnalyser(default_method=TrendMethod.MEDIAN, max_years=5)


@pytest.fixture
def manual_assumptions() -> ForecastAssumptions:
    """Fully manual assumptions — no trend derivation needed."""
    return ForecastAssumptions(
        ticker="AAPL",
        scenario=ScenarioType.BASE,
        forecast_years=10,
        revenue=RevenueAssumptions(constant_growth_rate=0.08),
        margins=MarginAssumptions(
            ebitda_margin=0.30,
            effective_tax_rate=0.25,
        ),
        da=DAAssumptions(da_as_pct_revenue=0.03),
        capex=CapExAssumptions(capex_as_pct_revenue=0.03),
        nwc=NWCAssumptions(nwc_as_pct_revenue=0.02),
    )


@pytest.fixture
def trend_assumptions() -> ForecastAssumptions:
    """Fully trend-based assumptions — engine derives everything from history."""
    return ForecastAssumptions(
        ticker="AAPL",
        scenario=ScenarioType.BASE,
        forecast_years=10,
        # All sub-models left at defaults → all fields None → trend
    )


@pytest.fixture
def phased_revenue_assumptions() -> ForecastAssumptions:
    """Phased revenue growth with manual near/long-term rates."""
    return ForecastAssumptions(
        ticker="AAPL",
        scenario=ScenarioType.BASE,
        forecast_years=10,
        revenue=RevenueAssumptions(
            near_term_growth=0.10,
            long_term_growth=0.04,
        ),
        margins=MarginAssumptions(ebitda_margin=0.30, effective_tax_rate=0.25),
        da=DAAssumptions(da_as_pct_revenue=0.03),
        capex=CapExAssumptions(capex_as_pct_revenue=0.03),
        nwc=NWCAssumptions(nwc_as_pct_revenue=0.02),
    )
