"""
tests/engine/test_trend_analyser.py
-------------------------------------
Tests for TrendAnalyser — validates all five statistical methods
and the financial reasonableness bounds.
"""

from __future__ import annotations

import pytest

from engine.assumptions.models import AssumptionMode, TrendMethod
from engine.assumptions.trend_analyser import TrendAnalyser


@pytest.fixture
def ta() -> TrendAnalyser:
    return TrendAnalyser(default_method=TrendMethod.MEDIAN, max_years=5)


# ── Revenue growth rate ────────────────────────────────────────────────────────

class TestRevenueGrowthRate:

    def test_cagr_method_on_simple_series(self, ta: TrendAnalyser) -> None:
        # Revenue doubles over 4 years → CAGR ≈ 25.99%
        revenues = [200, 160, 128, 100]   # newest-first
        item = ta.revenue_growth_rate(revenues, method=TrendMethod.CAGR)
        # 3 YoY periods: 28/100, 32/128, 40/160 → geometric mean
        assert 0.20 < item.value < 0.30
        assert item.mode == AssumptionMode.TREND

    def test_median_method(self, ta: TrendAnalyser) -> None:
        revenues = [110, 100, 90, 80]   # ~10% growth each year, newest-first
        item = ta.revenue_growth_rate(revenues, method=TrendMethod.MEDIAN)
        assert 0.09 < item.value < 0.14

    def test_weighted_mean_weights_recent_more(self, ta: TrendAnalyser) -> None:
        # Old growth was low, recent growth was high → weighted mean > simple mean
        revenues = [200, 150, 140, 135, 130]  # recent spike newest-first
        weighted = ta.revenue_growth_rate(revenues, method=TrendMethod.WEIGHTED_MEAN)
        simple   = ta.revenue_growth_rate(revenues, method=TrendMethod.MEAN)
        assert weighted.value >= simple.value * 0.90  # weighted should be >= simple

    def test_regression_method(self, ta: TrendAnalyser) -> None:
        revenues = [120, 110, 100, 90, 80]   # linear growth, newest-first
        item = ta.revenue_growth_rate(revenues, method=TrendMethod.REGRESSION)
        assert item.confidence is not None
        assert 0.0 <= item.confidence <= 1.0
        assert item.value > 0

    def test_single_data_point_returns_fallback(self, ta: TrendAnalyser) -> None:
        item = ta.revenue_growth_rate([100_000_000])
        assert item.value == pytest.approx(0.05)
        assert item.confidence == pytest.approx(0.0)

    def test_none_values_filtered(self, ta: TrendAnalyser) -> None:
        revenues = [None, 110, None, 100, None]
        item = ta.revenue_growth_rate(revenues)  # type: ignore[arg-type]
        assert item.value is not None
        assert -0.5 < item.value < 1.0

    def test_result_clipped_at_bounds(self, ta: TrendAnalyser) -> None:
        # Insane growth should be clamped at 100%
        revenues = [10_000, 100, 90]   # 100x growth (newest first)
        item = ta.revenue_growth_rate(revenues)
        assert item.value <= 1.0

    def test_uses_max_years_window(self) -> None:
        ta3 = TrendAnalyser(max_years=3)
        # Even if we pass 10 years, only 3 most recent are used
        revenues = [110, 100, 90, 50, 40, 30, 20, 10, 5, 2]
        item = ta3.revenue_growth_rate(revenues)
        # Result should reflect ~10% growth (most recent 3 values), not the older huge growth
        assert item.value < 0.40


# ── EBITDA margin ──────────────────────────────────────────────────────────────

class TestEBITDAMargin:

    def test_median_of_margins(self, ta: TrendAnalyser, hist: object) -> None:
        from tests.engine.conftest import HIST_EBITDA, HIST_REVENUES
        item = ta.ebitda_margin(HIST_EBITDA, HIST_REVENUES, method=TrendMethod.MEDIAN)
        # Expected median margin ≈ 32-33% for AAPL
        assert 0.25 < item.value < 0.40
        assert item.mode == AssumptionMode.TREND

    def test_fallback_when_no_data(self, ta: TrendAnalyser) -> None:
        item = ta.ebitda_margin([], [])
        assert item.value == pytest.approx(0.15)
        assert item.confidence == pytest.approx(0.0)

    def test_mismatched_lengths_handled(self, ta: TrendAnalyser) -> None:
        # Extra revenue values are silently ignored (zip stops at shortest)
        ebitda  = [30, 28, 25]
        revenue = [100, 100, 100, 100, 100]
        item = ta.ebitda_margin(ebitda, revenue, method=TrendMethod.MEAN)
        assert item.value == pytest.approx(0.277, rel=0.01)

    def test_zero_revenue_excluded(self, ta: TrendAnalyser) -> None:
        ebitda  = [30, 25, 20]
        revenue = [100, 0, 100]   # zero in middle — should be excluded
        item = ta.ebitda_margin(ebitda, revenue, method=TrendMethod.MEAN)
        # Only 2 valid points: 30/100 and 20/100
        assert item.value == pytest.approx(0.25, rel=0.01)


# ── Effective tax rate ─────────────────────────────────────────────────────────

class TestEffectiveTaxRate:

    def test_tax_rate_from_history(self, ta: TrendAnalyser) -> None:
        from tests.engine.conftest import HIST_TAX, HIST_PRETAX
        item = ta.effective_tax_rate(HIST_TAX, HIST_PRETAX, method=TrendMethod.MEDIAN)
        # AAPL effective rate historically ~18-25%
        assert 0.15 < item.value < 0.30

    def test_negative_pretax_income_excluded(self, ta: TrendAnalyser) -> None:
        tax     = [25,  10, -5]
        pretax  = [100, 80, -20]   # loss year excluded
        item = ta.effective_tax_rate(tax, pretax, method=TrendMethod.MEAN)
        # Only years with positive pretax should be used: 25/100=0.25, 10/80=0.125
        assert 0.15 < item.value < 0.30

    def test_fallback_to_statutory_rate(self, ta: TrendAnalyser) -> None:
        item = ta.effective_tax_rate([], [])
        assert item.value == pytest.approx(0.21)

    def test_extreme_rate_clipped(self, ta: TrendAnalyser) -> None:
        item = ta.effective_tax_rate([90], [100])
        assert item.value <= 0.50


# ── D&A ───────────────────────────────────────────────────────────────────────

class TestDAAsPercentRevenue:

    def test_da_pct_median(self, ta: TrendAnalyser) -> None:
        from tests.engine.conftest import HIST_DA, HIST_REVENUES
        item = ta.da_as_pct_revenue(HIST_DA, HIST_REVENUES, method=TrendMethod.MEDIAN)
        # AAPL D&A ≈ 2.9–3.4% of revenue
        assert 0.02 < item.value < 0.05

    def test_negative_da_values_taken_as_abs(self, ta: TrendAnalyser) -> None:
        # CFS often reports D&A as negative (cash out direction)
        da      = [-10, -9, -11]
        revenue = [300, 280, 320]
        item    = ta.da_as_pct_revenue(da, revenue, method=TrendMethod.MEDIAN)
        assert item.value > 0

    def test_fallback_three_pct(self, ta: TrendAnalyser) -> None:
        item = ta.da_as_pct_revenue([], [])
        assert item.value == pytest.approx(0.03)


# ── CapEx ─────────────────────────────────────────────────────────────────────

class TestCapExAsPercentRevenue:

    def test_capex_pct_positive(self, ta: TrendAnalyser) -> None:
        from tests.engine.conftest import HIST_CAPEX, HIST_REVENUES
        item = ta.capex_as_pct_revenue(HIST_CAPEX, HIST_REVENUES, method=TrendMethod.MEDIAN)
        # AAPL CapEx ≈ 2.7–3% of revenue
        assert 0.02 < item.value < 0.05

    def test_negative_capex_taken_as_abs(self, ta: TrendAnalyser) -> None:
        capex   = [-15, -12, -18]
        revenue = [300, 280, 320]
        item    = ta.capex_as_pct_revenue(capex, revenue, method=TrendMethod.MEDIAN)
        assert item.value > 0

    def test_clipped_at_50pct(self, ta: TrendAnalyser) -> None:
        # Capital-intensive / extreme CapEx should be capped at 50%
        capex   = [200]
        revenue = [100]
        item    = ta.capex_as_pct_revenue(capex, revenue)
        assert item.value <= 0.50


# ── NWC ───────────────────────────────────────────────────────────────────────

class TestNWCAsPercentRevenue:

    def test_nwc_pct_can_be_negative(self, ta: TrendAnalyser) -> None:
        # AAPL NWC is negative (Apple has negative working capital — suppliers fund it)
        from tests.engine.conftest import HIST_NWC, HIST_REVENUES
        item = ta.nwc_as_pct_revenue(HIST_NWC, HIST_REVENUES, method=TrendMethod.MEDIAN)
        # Median of mostly negative NWC values should be negative
        assert item.value < 0.05   # could be negative or very slightly positive

    def test_fallback_five_pct(self, ta: TrendAnalyser) -> None:
        item = ta.nwc_as_pct_revenue([], [])
        assert item.value == pytest.approx(0.05)


# ── Phased CAGR ───────────────────────────────────────────────────────────────

class TestRevenueCAGRPhased:

    def test_returns_near_and_long(self, ta: TrendAnalyser) -> None:
        from tests.engine.conftest import HIST_REVENUES
        near, long_g = ta.revenue_cagr_phased(HIST_REVENUES)
        assert -0.30 < near < 0.50
        assert long_g <= near + 0.01   # long should be ≤ near (fade)
        assert long_g >= 0.01          # floored at 1%

    def test_insufficient_data_returns_defaults(self, ta: TrendAnalyser) -> None:
        near, long_g = ta.revenue_cagr_phased([100])
        assert near  == pytest.approx(0.05)
        assert long_g == pytest.approx(0.03)
