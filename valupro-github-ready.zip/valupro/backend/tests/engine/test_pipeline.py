"""
tests/engine/test_pipeline.py
------------------------------
Integration tests for ForecastPipeline and ScenarioEngine.

Uses a fake FinancialsBundle (no live API calls) to run the pipeline
end-to-end and validate output structure, arithmetic, and business rules.
"""

from __future__ import annotations

from datetime import date
from unittest.mock import MagicMock

import pytest

from data.models.financial import BalanceSheet, CashFlowStatement, IncomeStatement, MarketData
from data.models.company import CompanyProfile
from data.models.responses import FinancialsBundle, ProviderMeta
from engine.assumptions.models import (
    CapExAssumptions,
    DAAssumptions,
    ForecastAssumptions,
    MarginAssumptions,
    NWCAssumptions,
    RevenueAssumptions,
    ScenarioType,
)
from engine.models import ForecastOutput, ForecastYear
from engine.pipeline.forecast_pipeline import ForecastPipeline
from engine.pipeline.scenario_engine import ScenarioDeltas, ScenarioEngine
from tests.engine.conftest import (
    HIST_CAPEX,
    HIST_DA,
    HIST_EBIT,
    HIST_EBITDA,
    HIST_FISCAL_YEARS,
    HIST_NWC,
    HIST_PRETAX,
    HIST_REVENUES,
    HIST_TAX,
)


# ── Fake bundle builder ────────────────────────────────────────────────────────

def _make_bundle(n_years: int = 5) -> FinancialsBundle:
    """Build a realistic FinancialsBundle without hitting any external API."""
    profile = CompanyProfile(
        ticker="AAPL",
        company_name="Apple Inc.",
        source_provider="test",
    )
    market = MarketData(
        ticker="AAPL",
        source_provider="test",
        current_price=175.0,
        market_cap=2_750_000_000_000,
        shares_outstanding=15_671_000_000,
        beta=1.25,
    )
    income_stmts = [
        IncomeStatement(
            ticker="AAPL",
            period_type="annual",
            period_end_date=date(fy, 9, 30),
            fiscal_year=fy,
            source_provider="test",
            revenue=HIST_REVENUES[i],
            ebitda=HIST_EBITDA[i],
            operating_income=HIST_EBIT[i],
            income_tax_expense=HIST_TAX[i],
            pretax_income=HIST_PRETAX[i],
            depreciation_amortisation=HIST_DA[i],
        )
        for i, fy in enumerate(HIST_FISCAL_YEARS[:n_years])
    ]
    cash_flows = [
        CashFlowStatement(
            ticker="AAPL",
            period_type="annual",
            period_end_date=date(fy, 9, 30),
            fiscal_year=fy,
            source_provider="test",
            depreciation_amortisation=HIST_DA[i],
            capital_expenditures=HIST_CAPEX[i],
            operating_cash_flow=HIST_EBITDA[i] * 0.85,
        )
        for i, fy in enumerate(HIST_FISCAL_YEARS[:n_years])
    ]
    balance_sheets = [
        BalanceSheet(
            ticker="AAPL",
            period_type="annual",
            period_end_date=date(fy, 9, 30),
            fiscal_year=fy,
            source_provider="test",
            total_current_assets=abs(HIST_NWC[i]) + 50_000_000_000,
            total_current_liabilities=50_000_000_000,
        )
        for i, fy in enumerate(HIST_FISCAL_YEARS[:n_years])
    ]
    return FinancialsBundle(
        profile=profile,
        market_data=market,
        income_statements=income_stmts,
        balance_sheets=balance_sheets,
        cash_flow_statements=cash_flows,
        meta=ProviderMeta(provider="test"),
    )


@pytest.fixture
def bundle() -> FinancialsBundle:
    return _make_bundle()


@pytest.fixture
def pipeline() -> ForecastPipeline:
    return ForecastPipeline()


@pytest.fixture
def fully_manual_assumptions() -> ForecastAssumptions:
    """Known-value assumptions for deterministic arithmetic tests."""
    return ForecastAssumptions(
        ticker="AAPL",
        scenario=ScenarioType.BASE,
        forecast_years=10,
        revenue=RevenueAssumptions(constant_growth_rate=0.08),
        margins=MarginAssumptions(ebitda_margin=0.30, effective_tax_rate=0.25),
        da=DAAssumptions(da_as_pct_revenue=0.03),
        capex=CapExAssumptions(capex_as_pct_revenue=0.03),
        nwc=NWCAssumptions(nwc_as_pct_revenue=0.02),
    )


# ══════════════════════════════════════════════════════════════════════════════
# ForecastPipeline — structure tests
# ══════════════════════════════════════════════════════════════════════════════

class TestForecastPipelineStructure:

    def test_run_returns_forecast_output(
        self, pipeline: ForecastPipeline, bundle: FinancialsBundle,
        fully_manual_assumptions: ForecastAssumptions,
    ) -> None:
        output = pipeline.run(bundle, fully_manual_assumptions)
        assert isinstance(output, ForecastOutput)

    def test_output_has_10_years(
        self, pipeline: ForecastPipeline, bundle: FinancialsBundle,
        fully_manual_assumptions: ForecastAssumptions,
    ) -> None:
        output = pipeline.run(bundle, fully_manual_assumptions)
        assert len(output.years) == 10

    def test_year_indices_are_sequential(
        self, pipeline: ForecastPipeline, bundle: FinancialsBundle,
        fully_manual_assumptions: ForecastAssumptions,
    ) -> None:
        output = pipeline.run(bundle, fully_manual_assumptions)
        assert [y.year_index for y in output.years] == list(range(1, 11))

    def test_fiscal_years_start_after_base(
        self, pipeline: ForecastPipeline, bundle: FinancialsBundle,
        fully_manual_assumptions: ForecastAssumptions,
    ) -> None:
        output = pipeline.run(bundle, fully_manual_assumptions)
        assert output.years[0].fiscal_year == 2024   # base is 2023

    def test_ticker_normalised(
        self, pipeline: ForecastPipeline, bundle: FinancialsBundle,
    ) -> None:
        assumptions = ForecastAssumptions(
            ticker="aapl",   # lowercase
            revenue=RevenueAssumptions(constant_growth_rate=0.08),
            margins=MarginAssumptions(ebitda_margin=0.30, effective_tax_rate=0.25),
            da=DAAssumptions(da_as_pct_revenue=0.03),
            capex=CapExAssumptions(capex_as_pct_revenue=0.03),
            nwc=NWCAssumptions(nwc_as_pct_revenue=0.02),
        )
        output = pipeline.run(bundle, assumptions)
        assert output.ticker == "AAPL"


# ══════════════════════════════════════════════════════════════════════════════
# ForecastPipeline — arithmetic correctness
# ══════════════════════════════════════════════════════════════════════════════

class TestForecastPipelineArithmetic:

    @pytest.fixture
    def output(
        self,
        pipeline: ForecastPipeline,
        bundle: FinancialsBundle,
        fully_manual_assumptions: ForecastAssumptions,
    ) -> ForecastOutput:
        return pipeline.run(bundle, fully_manual_assumptions)

    def test_revenue_compounds_at_8pct(self, output: ForecastOutput) -> None:
        base = output.history.base_revenue
        y1_rev = output.years[0].revenue
        assert y1_rev == pytest.approx(base * 1.08, rel=0.001)

    def test_ebitda_is_revenue_times_margin(self, output: ForecastOutput) -> None:
        for year in output.years:
            assert year.ebitda == pytest.approx(year.revenue * 0.30, rel=0.001)

    def test_da_is_revenue_times_da_pct(self, output: ForecastOutput) -> None:
        for year in output.years:
            assert year.depreciation_amortisation == pytest.approx(year.revenue * 0.03, rel=0.001)

    def test_ebit_is_ebitda_minus_da(self, output: ForecastOutput) -> None:
        for year in output.years:
            assert year.ebit == pytest.approx(year.ebitda - year.depreciation_amortisation, rel=0.001)

    def test_nopat_is_ebit_times_one_minus_tax(self, output: ForecastOutput) -> None:
        for year in output.years:
            expected_nopat = year.ebit * (1.0 - 0.25)
            assert year.nopat == pytest.approx(expected_nopat, rel=0.001)

    def test_capex_is_revenue_times_capex_pct(self, output: ForecastOutput) -> None:
        for year in output.years:
            assert year.capital_expenditures == pytest.approx(year.revenue * 0.03, rel=0.001)

    def test_nwc_is_revenue_times_nwc_pct(self, output: ForecastOutput) -> None:
        for year in output.years:
            assert year.net_working_capital == pytest.approx(year.revenue * 0.02, rel=0.001)

    def test_fcff_formula_holds(self, output: ForecastOutput) -> None:
        """FCFF = NOPAT + D&A − CapEx − ΔNWC"""
        for year in output.years:
            expected = (
                year.nopat
                + year.depreciation_amortisation
                - year.capital_expenditures
                - year.change_in_nwc
            )
            assert year.fcff == pytest.approx(expected, rel=0.001)

    def test_ebit_margin_computed_correctly(self, output: ForecastOutput) -> None:
        for year in output.years:
            expected_margin = year.ebit / year.revenue
            assert year.ebit_margin == pytest.approx(expected_margin, rel=0.001)

    def test_revenues_increase_monotonically(self, output: ForecastOutput) -> None:
        revenues = output.forecast_revenues
        for i in range(1, len(revenues)):
            assert revenues[i] > revenues[i - 1]

    def test_all_fcff_are_positive_for_healthy_company(self, output: ForecastOutput) -> None:
        # With 30% EBITDA, 25% tax, low CapEx/NWC → FCFF should be positive
        assert all(y.fcff > 0 for y in output.years)


# ══════════════════════════════════════════════════════════════════════════════
# Trend-based pipeline
# ══════════════════════════════════════════════════════════════════════════════

class TestForecastPipelineTrend:

    def test_trend_mode_completes_without_error(
        self, pipeline: ForecastPipeline, bundle: FinancialsBundle,
        trend_assumptions: ForecastAssumptions,
    ) -> None:
        output = pipeline.run(bundle, trend_assumptions)
        assert len(output.years) == 10

    def test_trend_mode_revenues_positive(
        self, pipeline: ForecastPipeline, bundle: FinancialsBundle,
        trend_assumptions: ForecastAssumptions,
    ) -> None:
        output = pipeline.run(bundle, trend_assumptions)
        assert all(y.revenue > 0 for y in output.years)

    def test_resolved_assumptions_attached(
        self, pipeline: ForecastPipeline, bundle: FinancialsBundle,
        trend_assumptions: ForecastAssumptions,
    ) -> None:
        output = pipeline.run(bundle, trend_assumptions)
        assert output.resolved is not None
        assert len(output.resolved.revenue_growth_rates) == 10

    def test_history_summary_populated(
        self, pipeline: ForecastPipeline, bundle: FinancialsBundle,
        trend_assumptions: ForecastAssumptions,
    ) -> None:
        output = pipeline.run(bundle, trend_assumptions)
        assert output.history.base_revenue > 0
        assert output.history.years_of_history == 5


# ══════════════════════════════════════════════════════════════════════════════
# ForecastOutput convenience methods
# ══════════════════════════════════════════════════════════════════════════════

class TestForecastOutputConvenience:

    @pytest.fixture
    def output(
        self,
        pipeline: ForecastPipeline,
        bundle: FinancialsBundle,
        fully_manual_assumptions: ForecastAssumptions,
    ) -> ForecastOutput:
        return pipeline.run(bundle, fully_manual_assumptions)

    def test_forecast_revenues_property(self, output: ForecastOutput) -> None:
        revenues = output.forecast_revenues
        assert len(revenues) == 10
        assert all(isinstance(r, float) for r in revenues)

    def test_forecast_fcffs_property(self, output: ForecastOutput) -> None:
        fcffs = output.forecast_fcffs
        assert len(fcffs) == 10

    def test_year_accessor(self, output: ForecastOutput) -> None:
        y1 = output.year(1)
        assert y1.year_index == 1

    def test_year_accessor_out_of_range(self, output: ForecastOutput) -> None:
        with pytest.raises(IndexError):
            output.year(11)

    def test_to_table_has_correct_keys(self, output: ForecastOutput) -> None:
        table = output.to_table()
        assert len(table) == 10
        required_keys = {
            "year_index", "fiscal_year", "revenue", "ebitda", "ebit",
            "fcff", "taxes", "nopat", "capital_expenditures",
            "depreciation_amortisation", "net_working_capital", "change_in_nwc",
        }
        assert required_keys.issubset(set(table[0].keys()))


# ══════════════════════════════════════════════════════════════════════════════
# ScenarioEngine
# ══════════════════════════════════════════════════════════════════════════════

class TestScenarioEngine:

    @pytest.fixture
    def scenario_engine(self, pipeline: ForecastPipeline) -> ScenarioEngine:
        return ScenarioEngine(pipeline)

    @pytest.fixture
    def results(
        self,
        scenario_engine: ScenarioEngine,
        bundle: FinancialsBundle,
        fully_manual_assumptions: ForecastAssumptions,
    ):
        return scenario_engine.run_all(bundle, fully_manual_assumptions)

    def test_all_three_scenarios_produced(self, results) -> None:
        assert results.bear is not None
        assert results.base is not None
        assert results.bull is not None

    def test_bear_revenue_lower_than_base(self, results) -> None:
        bear_revs = results.bear.forecast_revenues
        base_revs = results.base.forecast_revenues
        assert all(b < a for b, a in zip(bear_revs, base_revs))

    def test_bull_revenue_higher_than_base(self, results) -> None:
        bull_revs = results.bull.forecast_revenues
        base_revs = results.base.forecast_revenues
        assert all(b > a for b, a in zip(bull_revs, base_revs))

    def test_bear_ebitda_lower_than_base(self, results) -> None:
        bear_ebitda = results.bear.forecast_ebitdas
        base_ebitda = results.base.forecast_ebitdas
        assert all(b < a for b, a in zip(bear_ebitda, base_ebitda))

    def test_bull_ebitda_higher_than_base(self, results) -> None:
        bull_ebitda = results.bull.forecast_ebitdas
        base_ebitda = results.base.forecast_ebitdas
        assert all(b > a for b, a in zip(bull_ebitda, base_ebitda))

    def test_bear_fcff_lower_than_bull(self, results) -> None:
        bear_fcff = sum(results.bear.forecast_fcffs)
        bull_fcff = sum(results.bull.forecast_fcffs)
        assert bear_fcff < bull_fcff

    def test_base_scenario_type_correct(self, results) -> None:
        assert results.base.scenario == ScenarioType.BASE
        assert results.bear.scenario == ScenarioType.BEAR
        assert results.bull.scenario == ScenarioType.BULL

    def test_fcff_summary_format(self, results) -> None:
        summary = results.fcff_summary()
        assert "bear" in summary
        assert "base" in summary
        assert "bull" in summary
        assert "fiscal_years" in summary
        assert len(summary["base"]) == 10

    def test_custom_deltas_applied(
        self,
        pipeline: ForecastPipeline,
        bundle: FinancialsBundle,
        fully_manual_assumptions: ForecastAssumptions,
    ) -> None:
        # Wider spread — bear gets extra −5% growth
        deltas = ScenarioDeltas(
            bear_revenue_growth_delta=-0.05,
            bull_revenue_growth_delta=+0.05,
        )
        engine = ScenarioEngine(pipeline, deltas)
        results = engine.run_all(bundle, fully_manual_assumptions)

        default_engine = ScenarioEngine(pipeline)
        default_results = default_engine.run_all(bundle, fully_manual_assumptions)

        # Custom bear should have lower revenue than default bear
        custom_bear_total = sum(results.bear.forecast_revenues)
        default_bear_total = sum(default_results.bear.forecast_revenues)
        assert custom_bear_total < default_bear_total
