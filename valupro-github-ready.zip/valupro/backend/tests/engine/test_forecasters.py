"""
tests/engine/test_forecasters.py
----------------------------------
Unit tests for each individual forecaster module.
Tests assumption priority ordering, manual vs trend modes, and arithmetic.
"""

from __future__ import annotations

import pytest

from engine.assumptions.models import (
    AssumptionMode,
    CapExAssumptions,
    DAAssumptions,
    MarginAssumptions,
    NWCAssumptions,
    RevenueAssumptions,
    TrendMethod,
)
from engine.assumptions.trend_analyser import TrendAnalyser
from engine.forecasters.capex import CapExForecaster
from engine.forecasters.da import DAForecaster
from engine.forecasters.fcff import FCFFCalculator, FCFFComponents
from engine.forecasters.margins import MarginsForecaster
from engine.forecasters.nwc import NWCForecaster
from engine.forecasters.revenue import RevenueForecaster
from tests.engine.conftest import HIST_CAPEX, HIST_DA, HIST_EBITDA, HIST_NWC, HIST_REVENUES


@pytest.fixture
def ta() -> TrendAnalyser:
    return TrendAnalyser(default_method=TrendMethod.MEDIAN, max_years=5)


@pytest.fixture
def rev_forecaster(ta: TrendAnalyser) -> RevenueForecaster:
    return RevenueForecaster(ta)


@pytest.fixture
def margins_forecaster(ta: TrendAnalyser) -> MarginsForecaster:
    return MarginsForecaster(ta)


@pytest.fixture
def da_forecaster(ta: TrendAnalyser) -> DAForecaster:
    return DAForecaster(ta)


@pytest.fixture
def capex_forecaster(ta: TrendAnalyser) -> CapExForecaster:
    return CapExForecaster(ta)


@pytest.fixture
def nwc_forecaster(ta: TrendAnalyser) -> NWCForecaster:
    return NWCForecaster(ta)


# ══════════════════════════════════════════════════════════════════════════════
# Revenue forecaster
# ══════════════════════════════════════════════════════════════════════════════

class TestRevenueForecaster:

    def test_constant_growth_rate_produces_exact_revenues(
        self, rev_forecaster: RevenueForecaster
    ) -> None:
        rates, item = rev_forecaster.resolve_growth_rates(
            RevenueAssumptions(constant_growth_rate=0.10),
            HIST_REVENUES,
            forecast_years=10,
        )
        assert len(rates) == 10
        assert all(r == pytest.approx(0.10) for r in rates)
        assert item.mode == AssumptionMode.MANUAL

    def test_explicit_growth_list_used_directly(
        self, rev_forecaster: RevenueForecaster
    ) -> None:
        explicit = [0.10] * 5 + [0.05] * 5
        rates, item = rev_forecaster.resolve_growth_rates(
            RevenueAssumptions(growth_rates=explicit),
            HIST_REVENUES,
        )
        assert rates[:5] == pytest.approx([0.10] * 5)
        assert rates[5:] == pytest.approx([0.05] * 5)
        assert item.mode == AssumptionMode.MANUAL

    def test_phased_growth_interpolates(
        self, rev_forecaster: RevenueForecaster
    ) -> None:
        rates, _ = rev_forecaster.resolve_growth_rates(
            RevenueAssumptions(near_term_growth=0.12, long_term_growth=0.04),
            HIST_REVENUES,
        )
        assert rates[0]  == pytest.approx(0.12)          # Y1
        assert rates[-1] == pytest.approx(0.04)           # Y10
        # Y4 should be between near and long
        assert 0.04 < rates[3] < 0.12

    def test_trend_fallback_when_no_manual(
        self, rev_forecaster: RevenueForecaster
    ) -> None:
        rates, item = rev_forecaster.resolve_growth_rates(
            RevenueAssumptions(),   # all None
            HIST_REVENUES,
        )
        assert len(rates) == 10
        assert item.mode == AssumptionMode.TREND
        assert all(-0.5 <= r <= 2.0 for r in rates)

    def test_growth_floor_ceiling_respected(
        self, rev_forecaster: RevenueForecaster
    ) -> None:
        rates, _ = rev_forecaster.resolve_growth_rates(
            RevenueAssumptions(
                constant_growth_rate=5.0,    # way above ceiling
                growth_ceiling=0.50,
            ),
            HIST_REVENUES,
        )
        assert all(r <= 0.50 for r in rates)

    def test_project_revenues_compounds_correctly(
        self, rev_forecaster: RevenueForecaster
    ) -> None:
        base = 100.0
        rates = [0.10] * 3
        revenues = rev_forecaster.project_revenues(base, rates)
        assert revenues[0] == pytest.approx(110.0)
        assert revenues[1] == pytest.approx(121.0)
        assert revenues[2] == pytest.approx(133.1)

    def test_project_revenues_length_matches_rates(
        self, rev_forecaster: RevenueForecaster
    ) -> None:
        revenues = rev_forecaster.project_revenues(100.0, [0.05] * 10)
        assert len(revenues) == 10


# ══════════════════════════════════════════════════════════════════════════════
# Margins forecaster
# ══════════════════════════════════════════════════════════════════════════════

class TestMarginsForecaster:

    def test_manual_ebitda_margin(self, margins_forecaster: MarginsForecaster) -> None:
        margins, item = margins_forecaster.resolve_ebitda_margins(
            MarginAssumptions(ebitda_margin=0.30),
            HIST_EBITDA, HIST_REVENUES,
        )
        assert all(m == pytest.approx(0.30) for m in margins)
        assert item.mode == AssumptionMode.MANUAL

    def test_per_year_margins_list(self, margins_forecaster: MarginsForecaster) -> None:
        by_year = [0.28] * 5 + [0.30] * 5
        margins, item = margins_forecaster.resolve_ebitda_margins(
            MarginAssumptions(ebitda_margin_by_year=by_year),
            HIST_EBITDA, HIST_REVENUES,
        )
        assert margins[:5] == pytest.approx([0.28] * 5, rel=0.01)
        assert item.mode == AssumptionMode.MANUAL

    def test_scenario_adjustment_applied(self, margins_forecaster: MarginsForecaster) -> None:
        margins, _ = margins_forecaster.resolve_ebitda_margins(
            MarginAssumptions(ebitda_margin=0.30),
            HIST_EBITDA, HIST_REVENUES,
            scenario_adjustment=0.02,
        )
        assert all(m == pytest.approx(0.32) for m in margins)

    def test_trend_ebitda_margin_returns_10_values(
        self, margins_forecaster: MarginsForecaster
    ) -> None:
        margins, item = margins_forecaster.resolve_ebitda_margins(
            MarginAssumptions(),   # all None → trend
            HIST_EBITDA, HIST_REVENUES,
        )
        assert len(margins) == 10
        assert item.mode == AssumptionMode.TREND

    def test_manual_tax_rate(self, margins_forecaster: MarginsForecaster) -> None:
        rates, item = margins_forecaster.resolve_tax_rates(
            MarginAssumptions(effective_tax_rate=0.25),
            [], [],
        )
        assert all(r == pytest.approx(0.25) for r in rates)
        assert item.mode == AssumptionMode.MANUAL

    def test_compute_ebit(self) -> None:
        assert MarginsForecaster.compute_ebit(100.0, 10.0) == pytest.approx(90.0)

    def test_compute_taxes_zero_when_ebit_negative(self) -> None:
        assert MarginsForecaster.compute_taxes(-50.0, 0.25) == pytest.approx(0.0)

    def test_compute_taxes_positive_ebit(self) -> None:
        assert MarginsForecaster.compute_taxes(100.0, 0.25) == pytest.approx(25.0)

    def test_compute_nopat(self) -> None:
        assert MarginsForecaster.compute_nopat(100.0, 0.25) == pytest.approx(75.0)

    def test_compute_nopat_loss_year(self) -> None:
        # Loss year — no tax benefit modelled
        assert MarginsForecaster.compute_nopat(-50.0, 0.25) == pytest.approx(-50.0)


# ══════════════════════════════════════════════════════════════════════════════
# D&A forecaster
# ══════════════════════════════════════════════════════════════════════════════

class TestDAForecaster:

    def test_manual_da_pct(self, da_forecaster: DAForecaster) -> None:
        pcts, item = da_forecaster.resolve_da_pct(
            DAAssumptions(da_as_pct_revenue=0.03),
            HIST_DA, HIST_REVENUES,
        )
        assert all(p == pytest.approx(0.03) for p in pcts)
        assert item.mode == AssumptionMode.MANUAL

    def test_trend_da_pct(self, da_forecaster: DAForecaster) -> None:
        pcts, item = da_forecaster.resolve_da_pct(
            DAAssumptions(),
            HIST_DA, HIST_REVENUES,
        )
        assert len(pcts) == 10
        assert all(p > 0 for p in pcts)
        assert item.mode == AssumptionMode.TREND

    def test_compute_da_absolute(self, da_forecaster: DAForecaster) -> None:
        da = da_forecaster.compute_da_absolute(revenue=1_000.0, da_pct=0.03)
        assert da == pytest.approx(30.0)

    def test_da_always_positive(self, da_forecaster: DAForecaster) -> None:
        # Even if somehow a negative pct sneaks in, result should be floored at 0
        da = da_forecaster.compute_da_absolute(revenue=1_000.0, da_pct=-0.01)
        assert da >= 0.0

    def test_by_year_list_priority_over_constant(self, da_forecaster: DAForecaster) -> None:
        by_year = [0.04] * 10
        pcts, item = da_forecaster.resolve_da_pct(
            DAAssumptions(
                da_as_pct_revenue=0.03,         # should be ignored
                da_as_pct_revenue_by_year=by_year,
            ),
            HIST_DA, HIST_REVENUES,
        )
        assert all(p == pytest.approx(0.04) for p in pcts)


# ══════════════════════════════════════════════════════════════════════════════
# CapEx forecaster
# ══════════════════════════════════════════════════════════════════════════════

class TestCapExForecaster:

    def test_manual_capex_pct(self, capex_forecaster: CapExForecaster) -> None:
        pcts, item = capex_forecaster.resolve_capex_pct(
            CapExAssumptions(capex_as_pct_revenue=0.04),
            HIST_CAPEX, HIST_REVENUES,
        )
        assert all(p == pytest.approx(0.04) for p in pcts)
        assert item.mode == AssumptionMode.MANUAL

    def test_maintenance_plus_growth_summed(self, capex_forecaster: CapExForecaster) -> None:
        pcts, item = capex_forecaster.resolve_capex_pct(
            CapExAssumptions(maintenance_capex_pct=0.02, growth_capex_pct=0.03),
            HIST_CAPEX, HIST_REVENUES,
        )
        assert all(p == pytest.approx(0.05) for p in pcts)
        assert "Maintenance" in (item.note or "")

    def test_trend_capex_pct(self, capex_forecaster: CapExForecaster) -> None:
        pcts, item = capex_forecaster.resolve_capex_pct(
            CapExAssumptions(),
            HIST_CAPEX, HIST_REVENUES,
        )
        assert len(pcts) == 10
        assert all(p > 0 for p in pcts)

    def test_compute_capex_absolute_positive(self, capex_forecaster: CapExForecaster) -> None:
        capex = capex_forecaster.compute_capex_absolute(revenue=1_000.0, capex_pct=0.05)
        assert capex == pytest.approx(50.0)


# ══════════════════════════════════════════════════════════════════════════════
# NWC forecaster
# ══════════════════════════════════════════════════════════════════════════════

class TestNWCForecaster:

    def test_manual_nwc_pct(self, nwc_forecaster: NWCForecaster) -> None:
        pcts, item = nwc_forecaster.resolve_nwc_pct(
            NWCAssumptions(nwc_as_pct_revenue=0.05),
            HIST_NWC, HIST_REVENUES,
        )
        assert all(p == pytest.approx(0.05) for p in pcts)
        assert item.mode == AssumptionMode.MANUAL

    def test_component_level_dso_dio_dpo(self, nwc_forecaster: NWCForecaster) -> None:
        pcts, item = nwc_forecaster.resolve_nwc_pct(
            NWCAssumptions(
                accounts_receivable_days=45.0,
                inventory_days=30.0,
                accounts_payable_days=60.0,
            ),
            HIST_NWC, HIST_REVENUES,
            historical_cogs_pct=0.60,
        )
        # AR/Rev = 45/365, Inv/Rev = 30/365 * 0.6, AP/Rev = 60/365 * 0.6
        # NWC% = 45/365 + 18/365 - 36/365 = 27/365 ≈ 0.0740
        assert pcts[0] == pytest.approx(0.0740, rel=0.01)
        assert "DSO" in (item.note or "")

    def test_compute_nwc_absolute(self, nwc_forecaster: NWCForecaster) -> None:
        nwc = nwc_forecaster.compute_nwc_absolute(revenue=1_000.0, nwc_pct=0.10)
        assert nwc == pytest.approx(100.0)

    def test_compute_change_in_nwc_positive(self, nwc_forecaster: NWCForecaster) -> None:
        delta = nwc_forecaster.compute_change_in_nwc(nwc_current=110.0, nwc_prior=100.0)
        assert delta == pytest.approx(10.0)

    def test_compute_change_in_nwc_negative(self, nwc_forecaster: NWCForecaster) -> None:
        delta = nwc_forecaster.compute_change_in_nwc(nwc_current=90.0, nwc_prior=100.0)
        assert delta == pytest.approx(-10.0)

    def test_negative_nwc_pct_allowed(self, nwc_forecaster: NWCForecaster) -> None:
        # Apple-like negative NWC
        pcts, _ = nwc_forecaster.resolve_nwc_pct(
            NWCAssumptions(nwc_as_pct_revenue=-0.01),
            HIST_NWC, HIST_REVENUES,
        )
        assert all(p == pytest.approx(-0.01) for p in pcts)


# ══════════════════════════════════════════════════════════════════════════════
# FCFF calculator
# ══════════════════════════════════════════════════════════════════════════════

class TestFCFFCalculator:

    @pytest.fixture
    def calc(self) -> FCFFCalculator:
        return FCFFCalculator()

    def test_fcff_formula(self, calc: FCFFCalculator) -> None:
        # FCFF = NOPAT + D&A − CapEx − ΔNWC
        # = 75 + 10 - 5 - 3 = 77
        components = FCFFComponents(
            revenue=100.0,
            ebitda=35.0,
            ebitda_margin=0.35,
            da=10.0,
            ebit=25.0,
            tax_rate=0.25,
            taxes=6.25,
            nopat=75.0,
            capex=5.0,
            nwc=20.0,
            delta_nwc=3.0,
        )
        fcff = calc.compute(components)
        assert fcff == pytest.approx(75.0 + 10.0 - 5.0 - 3.0)

    def test_fcff_can_be_negative(self, calc: FCFFCalculator) -> None:
        components = FCFFComponents(
            revenue=100.0,
            ebitda=5.0,
            ebitda_margin=0.05,
            da=3.0,
            ebit=2.0,
            tax_rate=0.25,
            taxes=0.5,
            nopat=1.5,
            capex=50.0,    # heavy capex year
            nwc=10.0,
            delta_nwc=5.0,
        )
        fcff = calc.compute(components)
        assert fcff < 0

    def test_fcff_yield(self, calc: FCFFCalculator) -> None:
        yield_ = calc.fcff_yield(fcff=80.0, revenue=200.0)
        assert yield_ == pytest.approx(0.40)

    def test_fcff_yield_zero_revenue(self, calc: FCFFCalculator) -> None:
        assert calc.fcff_yield(fcff=80.0, revenue=0.0) is None

    def test_reinvestment_rate(self, calc: FCFFCalculator) -> None:
        # Net reinvestment = capex - da + delta_nwc = 10 - 5 + 3 = 8
        # Reinvestment rate = 8 / 75 ≈ 10.67%
        rr = calc.reinvestment_rate(capex=10.0, da=5.0, delta_nwc=3.0, nopat=75.0)
        assert rr == pytest.approx(8.0 / 75.0)

    def test_reinvestment_rate_none_when_nopat_zero(self, calc: FCFFCalculator) -> None:
        assert calc.reinvestment_rate(capex=10.0, da=5.0, delta_nwc=3.0, nopat=0.0) is None
