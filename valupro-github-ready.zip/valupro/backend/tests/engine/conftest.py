"""
tests/engine/conftest.py — shared engine test fixtures.
"""
from __future__ import annotations

from datetime import date

import pytest

from engine.assumptions.models import (
    CapExAssumptions,
    DAAssumptions,
    ForecastAssumptions,
    MarginAssumptions,
    NWCAssumptions,
    RevenueAssumptions,
    ScenarioType,
    TrendMethod,
)
from engine.assumptions.trend_analyser import TrendAnalyser
from engine.pipeline.historical_extractor import HistoricalSeries

# AAPL-scale numbers (newest-first, FY2023..FY2019)
HIST_REVENUES    = [383_285e6, 394_328e6, 365_817e6, 274_515e6, 260_174e6]
HIST_EBITDA      = [125_820e6, 130_541e6, 120_233e6,  77_344e6,  76_477e6]
HIST_EBIT        = [114_301e6, 119_437e6, 108_949e6,  66_288e6,  63_930e6]
HIST_TAX         = [ 29_749e6,  19_300e6,  14_527e6,   9_680e6,  10_481e6]
HIST_PRETAX      = [113_736e6, 119_103e6, 109_207e6,  67_091e6,  65_737e6]
HIST_DA          = [ 11_519e6,  11_104e6,  11_284e6,  11_056e6,  12_547e6]
HIST_CAPEX       = [-10_959e6, -10_708e6, -11_085e6,  -7_309e6,  -6_383e6]
HIST_NWC         = [ -1_742e6,  -3_443e6,  -4_016e6,  17_589e6,  22_279e6]
HIST_COGS        = [214_137e6, 223_546e6, 212_981e6, 169_559e6, 161_782e6]
HIST_FISCAL_YEARS = [2023, 2022, 2021, 2020, 2019]


@pytest.fixture
def hist() -> HistoricalSeries:
    """AAPL-like 5-year historical series."""
    return HistoricalSeries(
        fiscal_years=HIST_FISCAL_YEARS,
        revenue=HIST_REVENUES,
        ebitda=HIST_EBITDA,
        ebit=HIST_EBIT,
        tax_expense=HIST_TAX,
        pretax_income=HIST_PRETAX,
        net_income=[None] * 5,
        da_is=HIST_DA,
        cost_of_revenue=HIST_COGS,
        da_cfs=HIST_DA,
        capex=HIST_CAPEX,
        total_current_assets=[None] * 5,
        total_current_liabilities=[None] * 5,
        nwc=HIST_NWC,
        cogs_pct_revenue=0.559,
    )


@pytest.fixture
def analyser() -> TrendAnalyser:
    return TrendAnalyser(default_method=TrendMethod.MEDIAN, max_years=5)


@pytest.fixture
def manual_assumptions() -> ForecastAssumptions:
    return ForecastAssumptions(
        ticker="AAPL",
        scenario=ScenarioType.BASE,
        forecast_years=10,
        revenue=RevenueAssumptions(constant_growth_rate=0.08),
        margins=MarginAssumptions(ebitda_margin=0.30, effective_tax_rate=0.25),
        da=DAAssumptions(da_as_pct_revenue=0.03),
        capex=CapExAssumptions(capex_as_pct_revenue=0.03),
        nwc=NWCAssumptions(nwc_as_pct_revenue=0.02),
    )


@pytest.fixture
def trend_assumptions() -> ForecastAssumptions:
    return ForecastAssumptions(ticker="AAPL", scenario=ScenarioType.BASE, forecast_years=10)
