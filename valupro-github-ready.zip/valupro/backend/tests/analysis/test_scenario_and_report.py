"""
tests/analysis/test_scenario_and_report.py
-------------------------------------------
Tests for ScenarioAnalyser, ScenarioAnalysis, ScenarioDelta, TornadoItem,
and AnalysisReportBuilder.
"""

from __future__ import annotations

import pytest

from analysis.models import (
    AnalysisReport,
    ScenarioAnalysis,
    ScenarioDelta,
    ScenarioValuation,
    TornadoItem,
)
from analysis.report import AnalysisReportBuilder
from analysis.scenario import ScenarioAnalyser, ScenarioWeights
from valuation.models import DCFInputs, WACCResult


@pytest.fixture
def analyser() -> ScenarioAnalyser:
    return ScenarioAnalyser(build_tornado=True)


@pytest.fixture
def analysis(
    analyser: ScenarioAnalyser,
    scenario_results,
    bear_output,
    base_output,
    bull_output,
    bear_dcf_inputs: DCFInputs,
    base_dcf_inputs: DCFInputs,
    bull_dcf_inputs: DCFInputs,
    wacc_result: WACCResult,
) -> ScenarioAnalysis:
    return analyser.run(
        ticker="AAPL",
        scenario_results=scenario_results,
        bear_output=bear_output,
        base_output=base_output,
        bull_output=bull_output,
        bear_dcf_inputs=bear_dcf_inputs,
        base_dcf_inputs=base_dcf_inputs,
        bull_dcf_inputs=bull_dcf_inputs,
        wacc_result=wacc_result,
        current_price=175.50,
    )


# ══════════════════════════════════════════════════════════════════════════════
# ScenarioValuation
# ══════════════════════════════════════════════════════════════════════════════

class TestScenarioValuation:

    def test_all_three_scenarios_present(self, analysis: ScenarioAnalysis) -> None:
        assert analysis.bear is not None
        assert analysis.base is not None
        assert analysis.bull is not None

    def test_scenario_labels_correct(self, analysis: ScenarioAnalysis) -> None:
        assert analysis.bear.scenario == "bear"
        assert analysis.base.scenario == "base"
        assert analysis.bull.scenario == "bull"
        assert "Bear" in analysis.bear.label
        assert "Base" in analysis.base.label
        assert "Bull" in analysis.bull.label

    def test_bear_ev_lower_than_base(self, analysis: ScenarioAnalysis) -> None:
        assert analysis.bear.enterprise_value < analysis.base.enterprise_value

    def test_bull_ev_higher_than_base(self, analysis: ScenarioAnalysis) -> None:
        assert analysis.bull.enterprise_value > analysis.base.enterprise_value

    def test_bear_fvps_lower_than_base(self, analysis: ScenarioAnalysis) -> None:
        assert analysis.bear.fair_value_per_share < analysis.base.fair_value_per_share

    def test_bull_fvps_higher_than_base(self, analysis: ScenarioAnalysis) -> None:
        assert analysis.bull.fair_value_per_share > analysis.base.fair_value_per_share

    def test_all_evs_positive(self, analysis: ScenarioAnalysis) -> None:
        for sv in (analysis.bear, analysis.base, analysis.bull):
            assert sv.enterprise_value > 0

    def test_all_fvps_positive(self, analysis: ScenarioAnalysis) -> None:
        for sv in (analysis.bear, analysis.base, analysis.bull):
            assert sv.fair_value_per_share > 0

    def test_pv_tv_pct_between_zero_and_one(self, analysis: ScenarioAnalysis) -> None:
        for sv in (analysis.bear, analysis.base, analysis.bull):
            assert 0.0 <= sv.pv_tv_pct <= 1.0

    def test_sum_pv_fcff_plus_pv_tv_equals_ev(self, analysis: ScenarioAnalysis) -> None:
        for sv in (analysis.bear, analysis.base, analysis.bull):
            expected_ev = sv.sum_pv_fcff + sv.pv_terminal_value
            assert expected_ev == pytest.approx(sv.enterprise_value, rel=0.001)

    def test_fcff_y1_positive(self, analysis: ScenarioAnalysis) -> None:
        for sv in (analysis.bear, analysis.base, analysis.bull):
            assert sv.fcff_y1 > 0

    def test_ebitda_margin_avg_in_range(self, analysis: ScenarioAnalysis) -> None:
        for sv in (analysis.bear, analysis.base, analysis.bull):
            assert 0.0 < sv.ebitda_margin_avg < 1.0

    def test_to_dict_has_all_required_keys(self, analysis: ScenarioAnalysis) -> None:
        d = analysis.base.to_dict()
        required = {
            "scenario", "label", "enterprise_value", "equity_value",
            "fair_value_per_share", "sum_pv_fcff", "pv_terminal_value",
            "pv_tv_pct", "wacc", "terminal_growth_rate",
            "revenue_growth_y1", "revenue_growth_y10", "ebitda_margin_avg",
            "fcff_y1", "fcff_y10", "net_debt", "shares_outstanding",
        }
        assert required.issubset(set(d.keys()))


# ══════════════════════════════════════════════════════════════════════════════
# Deltas vs base
# ══════════════════════════════════════════════════════════════════════════════

class TestScenarioDeltas:

    def test_bear_ev_delta_negative(self, analysis: ScenarioAnalysis) -> None:
        assert analysis.bear_vs_base.ev_delta < 0

    def test_bull_ev_delta_positive(self, analysis: ScenarioAnalysis) -> None:
        assert analysis.bull_vs_base.ev_delta > 0

    def test_bear_fvps_delta_negative(self, analysis: ScenarioAnalysis) -> None:
        assert analysis.bear_vs_base.fvps_delta < 0

    def test_bull_fvps_delta_positive(self, analysis: ScenarioAnalysis) -> None:
        assert analysis.bull_vs_base.fvps_delta > 0

    def test_delta_pct_formula(self, analysis: ScenarioAnalysis) -> None:
        """ev_delta_pct = ev_delta / base_ev."""
        d = analysis.bear_vs_base
        base_ev = analysis.base.enterprise_value
        expected_pct = d.ev_delta / base_ev
        assert d.ev_delta_pct == pytest.approx(expected_pct, rel=1e-6)

    def test_equity_delta_consistent_with_fvps(self, analysis: ScenarioAnalysis) -> None:
        """equity_delta / shares ≈ fvps_delta."""
        from tests.analysis.conftest import SHARES
        d = analysis.bear_vs_base
        implied_fvps_delta = d.equity_delta / SHARES
        assert implied_fvps_delta == pytest.approx(d.fvps_delta, rel=0.01)


# ══════════════════════════════════════════════════════════════════════════════
# Blended value
# ══════════════════════════════════════════════════════════════════════════════

class TestBlendedValue:

    def test_blended_fvps_formula(self, analysis: ScenarioAnalysis) -> None:
        """w_bear×bear + w_base×base + w_bull×bull."""
        expected = (
            analysis.weight_bear * analysis.bear.fair_value_per_share
            + analysis.weight_base * analysis.base.fair_value_per_share
            + analysis.weight_bull * analysis.bull.fair_value_per_share
        )
        assert analysis.blended_fair_value == pytest.approx(expected, rel=1e-6)

    def test_blended_ev_formula(self, analysis: ScenarioAnalysis) -> None:
        expected = (
            analysis.weight_bear * analysis.bear.enterprise_value
            + analysis.weight_base * analysis.base.enterprise_value
            + analysis.weight_bull * analysis.bull.enterprise_value
        )
        assert analysis.blended_enterprise_value == pytest.approx(expected, rel=1e-6)

    def test_blended_equity_formula(self, analysis: ScenarioAnalysis) -> None:
        expected = (
            analysis.weight_bear * analysis.bear.equity_value
            + analysis.weight_base * analysis.base.equity_value
            + analysis.weight_bull * analysis.bull.equity_value
        )
        assert analysis.blended_equity_value == pytest.approx(expected, rel=1e-6)

    def test_default_weights_sum_to_one(self, analysis: ScenarioAnalysis) -> None:
        total = analysis.weight_bear + analysis.weight_base + analysis.weight_bull
        assert total == pytest.approx(1.0, rel=1e-6)

    def test_custom_weights_applied(
        self,
        scenario_results,
        bear_output, base_output, bull_output,
        bear_dcf_inputs, base_dcf_inputs, bull_dcf_inputs,
        wacc_result,
    ) -> None:
        weights = ScenarioWeights(bear=1/3, base=1/3, bull=1/3)
        analyser = ScenarioAnalyser(weights=weights, build_tornado=False)
        result = analyser.run(
            ticker="AAPL",
            scenario_results=scenario_results,
            bear_output=bear_output, base_output=base_output, bull_output=bull_output,
            bear_dcf_inputs=bear_dcf_inputs, base_dcf_inputs=base_dcf_inputs,
            bull_dcf_inputs=bull_dcf_inputs,
            wacc_result=wacc_result,
        )
        expected = (
            result.bear.fair_value_per_share
            + result.base.fair_value_per_share
            + result.bull.fair_value_per_share
        ) / 3.0
        assert result.blended_fair_value == pytest.approx(expected, rel=1e-6)

    def test_invalid_weights_raises(self) -> None:
        with pytest.raises(ValueError, match="sum to 1.0"):
            ScenarioWeights(bear=0.40, base=0.40, bull=0.40)


# ══════════════════════════════════════════════════════════════════════════════
# Price vs intrinsic
# ══════════════════════════════════════════════════════════════════════════════

class TestPriceVsIntrinsic:

    def test_current_price_attached(self, analysis: ScenarioAnalysis) -> None:
        assert analysis.current_price == pytest.approx(175.50)

    def test_price_vs_base_returns_string(self, analysis: ScenarioAnalysis) -> None:
        result = analysis.price_vs_base
        assert result in ("UNDERVALUED", "OVERVALUED", "FAIRLY VALUED")

    def test_price_vs_blended_returns_string(self, analysis: ScenarioAnalysis) -> None:
        result = analysis.price_vs_blended
        assert result in ("UNDERVALUED", "OVERVALUED", "FAIRLY VALUED")

    def test_no_price_gives_none(
        self,
        analyser: ScenarioAnalyser,
        scenario_results,
        bear_output, base_output, bull_output,
        bear_dcf_inputs, base_dcf_inputs, bull_dcf_inputs,
        wacc_result,
    ) -> None:
        result = analyser.run(
            ticker="AAPL",
            scenario_results=scenario_results,
            bear_output=bear_output, base_output=base_output, bull_output=bull_output,
            bear_dcf_inputs=bear_dcf_inputs, base_dcf_inputs=base_dcf_inputs,
            bull_dcf_inputs=bull_dcf_inputs,
            wacc_result=wacc_result,
            current_price=None,
        )
        assert result.price_vs_base is None
        assert result.price_vs_blended is None

    def test_scenario_range_is_bear_to_bull(self, analysis: ScenarioAnalysis) -> None:
        lo, hi = analysis.scenario_range()
        assert lo == pytest.approx(analysis.bear.fair_value_per_share)
        assert hi == pytest.approx(analysis.bull.fair_value_per_share)


# ══════════════════════════════════════════════════════════════════════════════
# Tornado chart
# ══════════════════════════════════════════════════════════════════════════════

class TestTornadoChart:

    def test_tornado_has_items(self, analysis: ScenarioAnalysis) -> None:
        assert len(analysis.tornado) > 0

    def test_tornado_sorted_by_range_descending(self, analysis: ScenarioAnalysis) -> None:
        ranges = [item.total_range for item in analysis.tornado]
        assert ranges == sorted(ranges, reverse=True)

    def test_all_items_have_base_price(self, analysis: ScenarioAnalysis) -> None:
        base_price = analysis.base.fair_value_per_share
        for item in analysis.tornado:
            assert item.base_price == pytest.approx(base_price, rel=0.01)

    def test_bear_delta_negative_or_zero(self, analysis: ScenarioAnalysis) -> None:
        """Bear assumptions should reduce or keep flat the FVPS."""
        for item in analysis.tornado:
            # Not all assumptions strictly reduce price in every scenario
            # but the bear price should be ≤ bull price
            assert item.bear_price <= item.bull_price + 0.01

    def test_total_range_is_bull_minus_bear(self, analysis: ScenarioAnalysis) -> None:
        for item in analysis.tornado:
            expected = abs(item.bull_price - item.bear_price)
            assert item.total_range == pytest.approx(expected, rel=0.01)

    def test_wacc_and_g_items_in_tornado(self, analysis: ScenarioAnalysis) -> None:
        assumptions = [item.assumption for item in analysis.tornado]
        assert any("WACC" in a for a in assumptions)
        assert any("Terminal" in a or "Growth" in a for a in assumptions)

    def test_no_tornado_when_disabled(
        self,
        scenario_results,
        bear_output, base_output, bull_output,
        bear_dcf_inputs, base_dcf_inputs, bull_dcf_inputs,
        wacc_result,
    ) -> None:
        analyser = ScenarioAnalyser(build_tornado=False)
        result = analyser.run(
            ticker="AAPL",
            scenario_results=scenario_results,
            bear_output=bear_output, base_output=base_output, bull_output=bull_output,
            bear_dcf_inputs=bear_dcf_inputs, base_dcf_inputs=base_dcf_inputs,
            bull_dcf_inputs=bull_dcf_inputs,
            wacc_result=wacc_result,
        )
        assert result.tornado == []


# ══════════════════════════════════════════════════════════════════════════════
# to_dict output
# ══════════════════════════════════════════════════════════════════════════════

class TestScenarioToDictOutput:

    def test_to_dict_has_all_top_keys(self, analysis: ScenarioAnalysis) -> None:
        d = analysis.to_dict()
        required = {
            "ticker", "valuation_date", "bear", "base", "bull",
            "bear_vs_base", "bull_vs_base", "blended",
            "scenario_range", "current_price", "price_vs_base",
            "price_vs_blended", "tornado",
        }
        assert required.issubset(set(d.keys()))

    def test_blended_dict_has_weights(self, analysis: ScenarioAnalysis) -> None:
        d = analysis.to_dict()
        assert "weights" in d["blended"]
        assert d["blended"]["weights"]["bear"] == pytest.approx(0.25)

    def test_tornado_list_serialisable(self, analysis: ScenarioAnalysis) -> None:
        d = analysis.to_dict()
        for item in d["tornado"]:
            assert "assumption" in item
            assert "bear_price" in item
            assert "bull_price" in item
            assert "total_range" in item


# ══════════════════════════════════════════════════════════════════════════════
# AnalysisReportBuilder (integration)
# ══════════════════════════════════════════════════════════════════════════════

class TestAnalysisReportBuilder:

    @pytest.fixture
    def report(
        self,
        scenario_results,
        bear_output, base_output, bull_output,
        bear_dcf_inputs, base_dcf_inputs, bull_dcf_inputs,
        wacc_result,
    ) -> AnalysisReport:
        builder = AnalysisReportBuilder(
            sensitivity_wacc_steps=2,
            sensitivity_growth_steps=1,
            build_tornado=True,
        )
        return builder.build(
            ticker="AAPL",
            bear_output=bear_output,
            base_output=base_output,
            bull_output=bull_output,
            bear_dcf_inputs=bear_dcf_inputs,
            base_dcf_inputs=base_dcf_inputs,
            bull_dcf_inputs=bull_dcf_inputs,
            wacc_result=wacc_result,
            scenario_results=scenario_results,
            current_price=175.50,
        )

    def test_report_has_ticker(self, report: AnalysisReport) -> None:
        assert report.ticker == "AAPL"

    def test_report_has_sensitivity(self, report: AnalysisReport) -> None:
        assert report.sensitivity is not None
        assert len(report.sensitivity.grid) > 0

    def test_report_has_scenarios(self, report: AnalysisReport) -> None:
        assert report.scenarios is not None
        assert report.scenarios.bear is not None
        assert report.scenarios.base is not None
        assert report.scenarios.bull is not None

    def test_report_to_dict_has_both_sections(self, report: AnalysisReport) -> None:
        d = report.to_dict()
        assert "sensitivity" in d
        assert "scenarios" in d

    def test_report_sensitivity_ranges_consistent(self, report: AnalysisReport) -> None:
        lo, hi = report.sensitivity.fvps_range()
        assert lo <= hi
        assert lo > 0

    def test_report_scenario_ordering(self, report: AnalysisReport) -> None:
        scenarios = report.scenarios
        assert scenarios.bear.fair_value_per_share < scenarios.base.fair_value_per_share < scenarios.bull.fair_value_per_share

    def test_report_warnings_deduplicated(self, report: AnalysisReport) -> None:
        # No duplicate warnings
        assert len(report.all_warnings) == len(set(report.all_warnings))
