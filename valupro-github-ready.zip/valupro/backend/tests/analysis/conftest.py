"""
tests/analysis/conftest.py
---------------------------
Shared fixtures for Phase 7 Sensitivity & Scenario Analysis tests.

Provides fully built ValuationOutput and DCFInputs objects for Bear / Base / Bull,
constructed from realistic AAPL-scale numbers without hitting any external API.
"""

from __future__ import annotations

from datetime import date, datetime
from unittest.mock import MagicMock

import pytest

from engine.assumptions.models import ScenarioType
from engine.models import ForecastOutput, ForecastYear, ResolvedAssumptions, HistoricalSummary
from engine.pipeline.scenario_engine import ScenarioResults
from valuation.dcf import DCFEngine
from valuation.models import DCFInputs, TerminalValueInputs, WACCInputs, WACCResult
from valuation.wacc import WACCCalculator

# ── AAPL-scale constants ───────────────────────────────────────────────────────
MARKET_CAP     = 2_750_000_000_000
LONG_TERM_DEBT =    95_000_000_000
SHORT_TERM_DEBT=     9_800_000_000
CASH           =    30_000_000_000
SHARES         =    15_671_000_000
NET_DEBT       = LONG_TERM_DEBT + SHORT_TERM_DEBT - CASH
WACC           = 0.09
G              = 0.025

# FCFF series by scenario (10 years, AAPL-scale)
_FCFF_BASE = [
     99_000_000_000, 106_920_000_000, 115_474_000_000, 124_711_000_000,
    134_688_000_000, 145_463_000_000, 157_100_000_000, 169_668_000_000,
    181_244_000_000, 193_931_000_000,
]
_FCFF_BEAR = [f * 0.75 for f in _FCFF_BASE]   # 25% haircut
_FCFF_BULL = [f * 1.25 for f in _FCFF_BASE]   # 25% uplift

_EBITDA_BASE = [
    125_820_000_000, 135_885_000_000, 146_756_000_000, 158_496_000_000,
    171_176_000_000, 184_870_000_000, 199_659_000_000, 215_632_000_000,
    232_882_000_000, 251_512_000_000,
]
_EBITDA_BEAR = [e * 0.80 for e in _EBITDA_BASE]
_EBITDA_BULL = [e * 1.20 for e in _EBITDA_BASE]
_FISCAL_YEARS = list(range(2024, 2034))


def _make_wacc_result() -> WACCResult:
    return WACCCalculator().compute(WACCInputs(
        beta=1.25,
        market_cap=MARKET_CAP,
        short_term_debt=SHORT_TERM_DEBT,
        long_term_debt=LONG_TERM_DEBT,
        interest_expense=3_900_000_000,
        cash_and_equivalents=CASH,
        risk_free_rate=0.043,
        equity_risk_premium=0.055,
        tax_rate=0.25,
    ))


def _make_dcf_inputs(fcff: list[float], ebitda: list[float]) -> DCFInputs:
    return DCFInputs(
        fcff_series=fcff,
        ebitda_series=ebitda,
        fiscal_years=_FISCAL_YEARS,
        wacc=WACC,
        terminal_value_inputs=TerminalValueInputs(
            method="gordon_growth",
            terminal_growth_rate=G,
        ),
        net_debt=NET_DEBT,
        minority_interest=0.0,
        preferred_equity=0.0,
        shares_outstanding=SHARES,
    )


def _make_valuation_output(dcf_inputs: DCFInputs, wacc_result: WACCResult, scenario: str):
    return DCFEngine().compute(dcf_inputs, wacc_result, ticker="AAPL", scenario=scenario)


def _make_forecast_output(fcff: list[float], ebitda: list[float], scenario: ScenarioType):
    """Minimal ForecastOutput for ScenarioAnalyser tests."""
    from engine.assumptions.models import ForecastAssumptions, TrendMethod
    from engine.assumptions.models import RevenueAssumptions, MarginAssumptions, DAAssumptions, CapExAssumptions, NWCAssumptions

    years = []
    for i, (f, e) in enumerate(zip(fcff, ebitda)):
        rev = e / 0.30  # EBITDA/Rev = 30%
        years.append(ForecastYear(
            year_index=i + 1,
            fiscal_year=2024 + i,
            period_end_date=date(2024 + i, 12, 31),
            revenue=rev,
            revenue_growth_rate=0.08,
            ebitda=e,
            ebitda_margin=0.30,
            depreciation_amortisation=rev * 0.03,
            da_as_pct_revenue=0.03,
            ebit=e - rev * 0.03,
            ebit_margin=0.27,
            effective_tax_rate=0.25,
            taxes=(e - rev * 0.03) * 0.25,
            nopat=(e - rev * 0.03) * 0.75,
            capital_expenditures=rev * 0.03,
            capex_as_pct_revenue=0.03,
            net_working_capital=rev * 0.02,
            nwc_as_pct_revenue=0.02,
            change_in_nwc=rev * 0.001,
            fcff=f,
        ))

    dummy_assumptions = ForecastAssumptions(
        ticker="AAPL",
        scenario=scenario,
        forecast_years=10,
        revenue=RevenueAssumptions(constant_growth_rate=0.08),
        margins=MarginAssumptions(ebitda_margin=0.30, effective_tax_rate=0.25),
        da=DAAssumptions(da_as_pct_revenue=0.03),
        capex=CapExAssumptions(capex_as_pct_revenue=0.03),
        nwc=NWCAssumptions(nwc_as_pct_revenue=0.02),
    )

    from engine.assumptions.models import AssumptionMode, ItemAssumption, TrendMethod as TM
    dummy_item = ItemAssumption(value=0.08, mode=AssumptionMode.MANUAL)
    dummy_resolved = ResolvedAssumptions(
        revenue_growth_rates=[0.08] * 10,
        ebitda_margins=[0.30] * 10,
        ebit_margins=[0.27] * 10,
        effective_tax_rates=[0.25] * 10,
        da_pct_revenues=[0.03] * 10,
        capex_pct_revenues=[0.03] * 10,
        nwc_pct_revenues=[0.02] * 10,
        revenue_growth_item=dummy_item,
        ebitda_margin_item=dummy_item,
        tax_rate_item=dummy_item,
        da_item=dummy_item,
        capex_item=dummy_item,
        nwc_item=dummy_item,
    )
    return ForecastOutput(
        ticker="AAPL",
        scenario=scenario,
        years=years,
        assumptions=dummy_assumptions,
        resolved=dummy_resolved,
        history=HistoricalSummary(
            ticker="AAPL",
            years_of_history=5,
            base_year=2023,
            base_revenue=383_285_000_000,
        ),
    )


# ── Fixtures ───────────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def wacc_result() -> WACCResult:
    return _make_wacc_result()


@pytest.fixture(scope="session")
def base_dcf_inputs() -> DCFInputs:
    return _make_dcf_inputs(_FCFF_BASE, _EBITDA_BASE)


@pytest.fixture(scope="session")
def bear_dcf_inputs() -> DCFInputs:
    return _make_dcf_inputs(_FCFF_BEAR, _EBITDA_BEAR)


@pytest.fixture(scope="session")
def bull_dcf_inputs() -> DCFInputs:
    return _make_dcf_inputs(_FCFF_BULL, _EBITDA_BULL)


@pytest.fixture(scope="session")
def base_output(base_dcf_inputs: DCFInputs, wacc_result: WACCResult):
    return _make_valuation_output(base_dcf_inputs, wacc_result, "base")


@pytest.fixture(scope="session")
def bear_output(bear_dcf_inputs: DCFInputs, wacc_result: WACCResult):
    return _make_valuation_output(bear_dcf_inputs, wacc_result, "bear")


@pytest.fixture(scope="session")
def bull_output(bull_dcf_inputs: DCFInputs, wacc_result: WACCResult):
    return _make_valuation_output(bull_dcf_inputs, wacc_result, "bull")


@pytest.fixture(scope="session")
def scenario_results() -> ScenarioResults:
    return ScenarioResults(
        bear=_make_forecast_output(_FCFF_BEAR, _EBITDA_BEAR, ScenarioType.BEAR),
        base=_make_forecast_output(_FCFF_BASE, _EBITDA_BASE, ScenarioType.BASE),
        bull=_make_forecast_output(_FCFF_BULL, _EBITDA_BULL, ScenarioType.BULL),
    )
