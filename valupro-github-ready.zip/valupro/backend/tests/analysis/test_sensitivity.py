"""
tests/analysis/test_sensitivity.py
------------------------------------
Tests for FullSensitivityEngine — WACC × g matrix with EV, Equity, FVPS outputs.
"""

from __future__ import annotations

import pytest

from analysis.models import SensitivityMatrix, SensitivityMatrixCell
from analysis.sensitivity import FullSensitivityEngine
from valuation.models import DCFInputs, WACCResult


@pytest.fixture
def engine() -> FullSensitivityEngine:
    return FullSensitivityEngine()


@pytest.fixture
def matrix(
    engine: FullSensitivityEngine,
    base_output,
    base_dcf_inputs: DCFInputs,
    wacc_result: WACCResult,
) -> SensitivityMatrix:
    return engine.compute(
        ticker="AAPL",
        base_output=base_output,
        dcf_inputs=base_dcf_inputs,
        wacc_result=wacc_result,
        wacc_steps=3,
        growth_steps=2,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Grid structure
# ══════════════════════════════════════════════════════════════════════════════

class TestSensitivityGridStructure:

    def test_wacc_rows_count(self, matrix: SensitivityMatrix) -> None:
        """wacc_steps=3 → 7 rows (base ± 3 × 50 bps)."""
        assert len(matrix.wacc_values) == 7
        assert len(matrix.grid) == 7

    def test_growth_cols_count(self, matrix: SensitivityMatrix) -> None:
        """growth_steps=2 → up to 5 cols, minus any g ≥ WACC − 50 bps."""
        # All cols must have valid growth rates
        assert len(matrix.growth_values) >= 1
        assert len(matrix.grid[0]) == len(matrix.growth_values)

    def test_grid_is_rectangular(self, matrix: SensitivityMatrix) -> None:
        col_count = len(matrix.growth_values)
        for row in matrix.grid:
            assert len(row) == col_count

    def test_wacc_values_ascending(self, matrix: SensitivityMatrix) -> None:
        assert matrix.wacc_values == sorted(matrix.wacc_values)

    def test_growth_values_ascending(self, matrix: SensitivityMatrix) -> None:
        assert matrix.growth_values == sorted(matrix.growth_values)

    def test_all_growth_below_min_wacc_minus_spread(
        self, matrix: SensitivityMatrix
    ) -> None:
        min_wacc = min(matrix.wacc_values)
        for g in matrix.growth_values:
            assert g < min_wacc - 0.004

    def test_exactly_one_base_case_cell(self, matrix: SensitivityMatrix) -> None:
        base_cells = [
            cell for row in matrix.grid for cell in row if cell.is_base_case
        ]
        assert len(base_cells) == 1

    def test_base_cell_wacc_matches_base_wacc(self, matrix: SensitivityMatrix) -> None:
        cell = matrix.base_case_cell()
        assert cell is not None
        assert abs(cell.wacc - matrix.base_wacc) < 0.0001

    def test_base_cell_growth_matches_base_g(self, matrix: SensitivityMatrix) -> None:
        cell = matrix.base_case_cell()
        assert cell is not None
        assert abs(cell.terminal_growth_rate - matrix.base_growth_rate) < 0.0001


# ══════════════════════════════════════════════════════════════════════════════
# Arithmetic correctness
# ══════════════════════════════════════════════════════════════════════════════

class TestSensitivityArithmetic:

    def test_base_cell_ev_matches_base_output(
        self, matrix: SensitivityMatrix, base_output
    ) -> None:
        cell = matrix.base_case_cell()
        assert cell is not None
        assert cell.enterprise_value == pytest.approx(
            base_output.enterprise_value, rel=0.01
        )

    def test_base_cell_fvps_matches_base_output(
        self, matrix: SensitivityMatrix, base_output
    ) -> None:
        cell = matrix.base_case_cell()
        assert cell is not None
        assert cell.fair_value_per_share == pytest.approx(
            base_output.fair_value_per_share, rel=0.01
        )

    def test_base_cell_pct_vs_base_is_zero(self, matrix: SensitivityMatrix) -> None:
        cell = matrix.base_case_cell()
        assert cell is not None
        if cell.ev_vs_base_pct is not None:
            assert abs(cell.ev_vs_base_pct) < 0.001
        if cell.fvps_vs_base_pct is not None:
            assert abs(cell.fvps_vs_base_pct) < 0.001

    def test_equity_value_is_ev_minus_net_debt(self, matrix: SensitivityMatrix) -> None:
        net_debt = matrix.net_debt + matrix.minority_interest + matrix.preferred_equity
        for row in matrix.grid:
            for cell in row:
                if cell.enterprise_value > 0:
                    expected_equity = max(cell.enterprise_value - net_debt, 0.0)
                    assert cell.equity_value == pytest.approx(expected_equity, rel=0.01)

    def test_fvps_is_equity_over_shares(self, matrix: SensitivityMatrix) -> None:
        shares = matrix.shares_outstanding
        for row in matrix.grid:
            for cell in row:
                if cell.equity_value > 0 and shares > 0:
                    expected = cell.equity_value / shares
                    assert cell.fair_value_per_share == pytest.approx(expected, rel=0.01)

    def test_pct_vs_base_correct_sign(self, matrix: SensitivityMatrix) -> None:
        """Cells with FVPS > base should have positive fvps_vs_base_pct."""
        base_fvps = matrix.base_fair_value_per_share
        for row in matrix.grid:
            for cell in row:
                if cell.fvps_vs_base_pct is not None and cell.fair_value_per_share > 0:
                    expected_sign = 1 if cell.fair_value_per_share > base_fvps else -1
                    if abs(cell.fair_value_per_share - base_fvps) > 0.01:
                        assert (cell.fvps_vs_base_pct * expected_sign) > 0


# ══════════════════════════════════════════════════════════════════════════════
# Monotonicity
# ══════════════════════════════════════════════════════════════════════════════

class TestSensitivityMonotonicity:

    def test_higher_wacc_lower_ev(self, matrix: SensitivityMatrix) -> None:
        """For a fixed column (g), EV decreases as WACC increases."""
        n_cols = len(matrix.growth_values)
        for col in range(n_cols):
            evs = [row[col].enterprise_value for row in matrix.grid if row[col].enterprise_value > 0]
            for i in range(1, len(evs)):
                assert evs[i] <= evs[i - 1] + 1.0  # tiny rounding tolerance

    def test_higher_g_higher_ev(self, matrix: SensitivityMatrix) -> None:
        """For a fixed row (WACC), EV increases as g increases."""
        for row in matrix.grid:
            evs = [cell.enterprise_value for cell in row if cell.enterprise_value > 0]
            for i in range(1, len(evs)):
                assert evs[i] >= evs[i - 1] - 1.0

    def test_higher_wacc_lower_fvps(self, matrix: SensitivityMatrix) -> None:
        n_cols = len(matrix.growth_values)
        for col in range(n_cols):
            prices = [
                row[col].fair_value_per_share
                for row in matrix.grid
                if row[col].fair_value_per_share > 0
            ]
            for i in range(1, len(prices)):
                assert prices[i] <= prices[i - 1] + 0.01

    def test_higher_g_higher_fvps(self, matrix: SensitivityMatrix) -> None:
        for row in matrix.grid:
            prices = [cell.fair_value_per_share for cell in row if cell.fair_value_per_share > 0]
            for i in range(1, len(prices)):
                assert prices[i] >= prices[i - 1] - 0.01


# ══════════════════════════════════════════════════════════════════════════════
# Output methods
# ══════════════════════════════════════════════════════════════════════════════

class TestSensitivityOutputMethods:

    def test_ev_matrix_dimensions(self, matrix: SensitivityMatrix) -> None:
        m = matrix.ev_matrix()
        assert len(m) == len(matrix.wacc_values)
        assert all(len(row) == len(matrix.growth_values) for row in m)

    def test_equity_matrix_dimensions(self, matrix: SensitivityMatrix) -> None:
        m = matrix.equity_matrix()
        assert len(m) == len(matrix.wacc_values)

    def test_fvps_matrix_dimensions(self, matrix: SensitivityMatrix) -> None:
        m = matrix.fvps_matrix()
        assert len(m) == len(matrix.wacc_values)

    def test_fvps_range_min_le_max(self, matrix: SensitivityMatrix) -> None:
        lo, hi = matrix.fvps_range()
        assert lo <= hi

    def test_ev_range_min_le_max(self, matrix: SensitivityMatrix) -> None:
        lo, hi = matrix.ev_range()
        assert lo <= hi

    def test_base_fvps_within_range(self, matrix: SensitivityMatrix) -> None:
        lo, hi = matrix.fvps_range()
        assert lo <= matrix.base_fair_value_per_share <= hi + 0.01

    def test_to_dict_has_all_keys(self, matrix: SensitivityMatrix) -> None:
        d = matrix.to_dict()
        required = {
            "ticker", "wacc_values", "growth_values",
            "base_wacc", "base_growth_rate",
            "base_enterprise_value", "base_equity_value", "base_fair_value_per_share",
            "enterprise_value_matrix", "equity_value_matrix", "fair_value_matrix",
            "fvps_range", "ev_range",
        }
        assert required.issubset(set(d.keys()))

    def test_to_dict_matrix_sizes_match_axes(self, matrix: SensitivityMatrix) -> None:
        d = matrix.to_dict()
        n_wacc = len(d["wacc_values"])
        n_g    = len(d["growth_values"])
        for key in ("enterprise_value_matrix", "equity_value_matrix", "fair_value_matrix"):
            m = d[key]
            assert len(m) == n_wacc
            assert all(len(r) == n_g for r in m)

    def test_grid_step_size_respected(
        self,
        engine: FullSensitivityEngine,
        base_output,
        base_dcf_inputs: DCFInputs,
        wacc_result: WACCResult,
    ) -> None:
        """With step_size=0.01, adjacent WACC values should differ by 0.01."""
        matrix = engine.compute(
            ticker="AAPL",
            base_output=base_output,
            dcf_inputs=base_dcf_inputs,
            wacc_result=wacc_result,
            wacc_steps=2,
            growth_steps=1,
            wacc_step_size=0.01,
        )
        waccs = matrix.wacc_values
        for i in range(1, len(waccs)):
            assert abs((waccs[i] - waccs[i - 1]) - 0.01) < 0.0001
