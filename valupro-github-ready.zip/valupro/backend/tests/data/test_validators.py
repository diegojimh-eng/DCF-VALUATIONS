"""
tests/data/test_validators.py
------------------------------
Unit tests for FinancialDataValidator business rules.
No external dependencies — pure logic tests.
"""

from __future__ import annotations

from datetime import date

import pytest

from data.models import BalanceSheet, CashFlowStatement, IncomeStatement, MarketData
from data.validators import FinancialDataValidator, Severity


@pytest.fixture
def validator() -> FinancialDataValidator:
    return FinancialDataValidator()


def _base_is(**overrides: object) -> IncomeStatement:
    defaults: dict = dict(
        ticker="AAPL",
        period_type="annual",
        period_end_date=date(2023, 9, 30),
        fiscal_year=2023,
        source_provider="fmp",
        revenue=383_285_000_000,
        gross_profit=169_148_000_000,
        ebitda=125_820_000_000,
        net_income=96_995_000_000,
        eps_diluted=6.13,
        weighted_avg_shares_diluted=15_812_547_000,
    )
    defaults.update(overrides)
    return IncomeStatement(**defaults)


def _base_bs(**overrides: object) -> BalanceSheet:
    defaults: dict = dict(
        ticker="AAPL",
        period_type="annual",
        period_end_date=date(2023, 9, 30),
        fiscal_year=2023,
        source_provider="fmp",
        total_assets=352_583_000_000,
        total_liabilities=290_437_000_000,
        total_stockholders_equity=62_146_000_000,
        total_current_assets=143_566_000_000,
        total_current_liabilities=145_308_000_000,
        long_term_debt=95_281_000_000,
    )
    defaults.update(overrides)
    return BalanceSheet(**defaults)


def _base_cfs(**overrides: object) -> CashFlowStatement:
    defaults: dict = dict(
        ticker="AAPL",
        period_type="annual",
        period_end_date=date(2023, 9, 30),
        fiscal_year=2023,
        source_provider="fmp",
        operating_cash_flow=110_543_000_000,
        capital_expenditures=-10_959_000_000,
        free_cash_flow=99_584_000_000,
        net_income=96_995_000_000,
    )
    defaults.update(overrides)
    return CashFlowStatement(**defaults)


def _base_md(**overrides: object) -> MarketData:
    defaults: dict = dict(
        ticker="AAPL",
        source_provider="fmp",
        current_price=175.50,
        market_cap=2_750_000_000_000,
        shares_outstanding=15_671_000_000,
        beta=1.25,
    )
    defaults.update(overrides)
    return MarketData(**defaults)


# ── Income Statement validation ────────────────────────────────────────────────

class TestIncomeStatementValidation:

    def test_clean_statement_has_no_issues(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_income_statement(_base_is())
        assert result.is_clean

    def test_missing_revenue_is_error(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_income_statement(_base_is(revenue=None))
        assert result.has_errors
        codes = [i.code for i in result.issues]
        assert "IS_MISSING_REVENUE" in codes

    def test_negative_revenue_is_error(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_income_statement(_base_is(revenue=-1_000_000))
        assert result.has_errors
        assert any(i.code == "IS_NEGATIVE_REVENUE" for i in result.issues)

    def test_ebitda_margin_extreme_high_warns(self, validator: FinancialDataValidator) -> None:
        # ebitda > 90% of revenue is suspicious
        stmt = _base_is(revenue=100_000_000, ebitda=95_000_000)
        result = validator.validate_income_statement(stmt)
        assert any(i.code == "IS_EBITDA_MARGIN_EXTREME_HIGH" for i in result.issues)

    def test_ebitda_margin_extreme_low_warns(self, validator: FinancialDataValidator) -> None:
        stmt = _base_is(revenue=100_000_000, ebitda=-60_000_000)
        result = validator.validate_income_statement(stmt)
        assert any(i.code == "IS_EBITDA_MARGIN_EXTREME_LOW" for i in result.issues)

    def test_eps_inconsistency_warns(self, validator: FinancialDataValidator) -> None:
        # net_income / shares = 6.13, but reported EPS = 10.00 → >10% discrepancy
        stmt = _base_is(eps_diluted=10.00)
        result = validator.validate_income_statement(stmt)
        assert any(i.code == "IS_EPS_INCONSISTENCY" for i in result.issues)

    def test_gross_exceeds_revenue_warns(self, validator: FinancialDataValidator) -> None:
        stmt = _base_is(revenue=100_000_000, gross_profit=110_000_000)
        result = validator.validate_income_statement(stmt)
        assert any(i.code == "IS_GROSS_EXCEEDS_REVENUE" for i in result.issues)


# ── Balance Sheet validation ───────────────────────────────────────────────────

class TestBalanceSheetValidation:

    def test_clean_balance_sheet_has_no_issues(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_balance_sheet(_base_bs())
        assert result.is_clean

    def test_missing_total_assets_is_error(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_balance_sheet(_base_bs(total_assets=None))
        assert result.has_errors
        assert any(i.code == "BS_MISSING_TOTAL_ASSETS" for i in result.issues)

    def test_accounting_identity_violation_warns(self, validator: FinancialDataValidator) -> None:
        # Assets 352B ≠ Liabilities 290B + Equity 10B (= 300B)
        result = validator.validate_balance_sheet(
            _base_bs(total_assets=352_583_000_000, total_stockholders_equity=10_000_000_000)
        )
        assert any(i.code == "BS_ACCOUNTING_IDENTITY_VIOLATION" for i in result.issues)

    def test_extreme_leverage_warns(self, validator: FinancialDataValidator) -> None:
        # D/E > 20x
        result = validator.validate_balance_sheet(
            _base_bs(long_term_debt=500_000_000_000, total_stockholders_equity=1_000_000)
        )
        assert any(i.code == "BS_EXTREME_LEVERAGE" for i in result.issues)


# ── Cash Flow validation ───────────────────────────────────────────────────────

class TestCashFlowValidation:

    def test_clean_cfs_has_no_issues(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_cash_flow_statement(_base_cfs())
        assert result.is_clean

    def test_missing_cfo_is_error(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_cash_flow_statement(_base_cfs(operating_cash_flow=None))
        assert result.has_errors
        assert any(i.code == "CFS_MISSING_CFO" for i in result.issues)

    def test_positive_capex_warns(self, validator: FinancialDataValidator) -> None:
        # CapEx should be negative (cash outflow)
        result = validator.validate_cash_flow_statement(
            _base_cfs(capital_expenditures=10_959_000_000)
        )
        assert any(i.code == "CFS_CAPEX_POSITIVE" for i in result.issues)

    def test_fcf_inconsistency_warns(self, validator: FinancialDataValidator) -> None:
        # CFO=100, CapEx=-10, implied FCF=90, but reported FCF=200 (>5% discrepancy)
        result = validator.validate_cash_flow_statement(
            _base_cfs(
                operating_cash_flow=100_000_000_000,
                capital_expenditures=-10_000_000_000,
                free_cash_flow=200_000_000_000,
            )
        )
        assert any(i.code == "CFS_FCF_INCONSISTENCY" for i in result.issues)


# ── Market Data validation ─────────────────────────────────────────────────────

class TestMarketDataValidation:

    def test_clean_market_data_has_no_issues(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_market_data(_base_md())
        assert result.is_clean

    def test_missing_price_is_error(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_market_data(_base_md(current_price=None))
        assert result.has_errors
        assert any(i.code == "MD_MISSING_PRICE" for i in result.issues)

    def test_negative_price_is_error(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_market_data(_base_md(current_price=-10.0))
        assert result.has_errors

    def test_missing_beta_warns(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_market_data(_base_md(beta=None))
        assert result.has_warnings
        assert any(i.code == "MD_MISSING_BETA" for i in result.issues)

    def test_extreme_beta_warns(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_market_data(_base_md(beta=8.5))
        assert any(i.code == "MD_EXTREME_BETA" for i in result.issues)

    def test_missing_shares_is_error(self, validator: FinancialDataValidator) -> None:
        result = validator.validate_market_data(_base_md(shares_outstanding=None))
        assert result.has_errors
        assert any(i.code == "MD_MISSING_SHARES" for i in result.issues)

    def test_market_cap_inconsistency_warns(self, validator: FinancialDataValidator) -> None:
        # price=175.50, shares=15.6B → implied MC ≈ 2.75T
        # but reported market_cap=1T → >5% discrepancy
        result = validator.validate_market_data(
            _base_md(market_cap=1_000_000_000_000)
        )
        assert any(i.code == "MD_MARKET_CAP_INCONSISTENCY" for i in result.issues)


# ── Series validation ──────────────────────────────────────────────────────────

class TestSeriesValidation:

    def test_implausible_revenue_jump_warns(self, validator: FinancialDataValidator) -> None:
        older = _base_is(
            period_end_date=date(2022, 9, 30),
            fiscal_year=2022,
            revenue=100_000_000,
        )
        newer = _base_is(
            period_end_date=date(2023, 9, 30),
            fiscal_year=2023,
            revenue=600_000_000,   # 500% jump
        )
        result = validator.validate_income_series([newer, older])
        assert any(i.code == "SERIES_REVENUE_JUMP" for i in result.issues)

    def test_normal_revenue_growth_clean(self, validator: FinancialDataValidator) -> None:
        older = _base_is(
            period_end_date=date(2022, 9, 30),
            fiscal_year=2022,
            revenue=350_000_000_000,
        )
        newer = _base_is(
            period_end_date=date(2023, 9, 30),
            fiscal_year=2023,
            revenue=383_285_000_000,   # ~9.5% growth — normal
        )
        result = validator.validate_income_series([newer, older])
        assert result.is_clean
