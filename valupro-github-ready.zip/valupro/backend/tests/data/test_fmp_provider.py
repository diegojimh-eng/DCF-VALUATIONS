"""
tests/data/test_fmp_provider.py
--------------------------------
Unit tests for the FMP provider.

All tests use respx to mock HTTP calls — no real network requests.
"""

from __future__ import annotations

import json

import httpx
import pytest
import respx

from data.providers.fmp_provider import FMPProvider
from data.providers.base import ProviderAuthError, ProviderDataError, ProviderRateLimitError


# ── Fixtures ───────────────────────────────────────────────────────────────────

@pytest.fixture
def provider() -> FMPProvider:
    """FMPProvider with a real (but mocked) httpx client."""
    client = httpx.AsyncClient()
    return FMPProvider(client)


# ── Profile tests ──────────────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_get_company_profile_success(
    provider: FMPProvider,
    sample_fmp_profile_response: list,
) -> None:
    """Profile fetch returns correctly mapped CompanyProfile."""
    respx.get("https://financialmodelingprep.com/api/v3/profile/AAPL").mock(
        return_value=httpx.Response(200, json=sample_fmp_profile_response)
    )

    profile = await provider.get_company_profile("AAPL")

    assert profile.ticker == "AAPL"
    assert profile.company_name == "Apple Inc."
    assert profile.sector == "Technology"
    assert profile.country == "US"
    assert profile.exchange == "NASDAQ"
    assert profile.employees == 164_000
    assert profile.source_provider == "fmp"


@respx.mock
@pytest.mark.asyncio
async def test_get_company_profile_empty_response_raises(
    provider: FMPProvider,
) -> None:
    """Empty list response raises ProviderDataError."""
    respx.get("https://financialmodelingprep.com/api/v3/profile/ZZZZ").mock(
        return_value=httpx.Response(200, json=[])
    )

    with pytest.raises(ProviderDataError, match="No profile data"):
        await provider.get_company_profile("ZZZZ")


@respx.mock
@pytest.mark.asyncio
async def test_get_company_profile_401_raises(provider: FMPProvider) -> None:
    """401 response raises ProviderAuthError."""
    respx.get("https://financialmodelingprep.com/api/v3/profile/AAPL").mock(
        return_value=httpx.Response(401)
    )

    with pytest.raises(ProviderAuthError):
        await provider.get_company_profile("AAPL")


@respx.mock
@pytest.mark.asyncio
async def test_get_company_profile_429_raises(provider: FMPProvider) -> None:
    """429 response raises ProviderRateLimitError."""
    respx.get("https://financialmodelingprep.com/api/v3/profile/AAPL").mock(
        return_value=httpx.Response(429, headers={"Retry-After": "30"})
    )

    with pytest.raises(ProviderRateLimitError) as exc_info:
        await provider.get_company_profile("AAPL")
    assert exc_info.value.retry_after_seconds == 30.0


# ── Income Statement tests ─────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_get_income_statements_success(
    provider: FMPProvider,
    sample_fmp_income_response: list,
) -> None:
    """Income statements are correctly parsed and ordered newest-first."""
    respx.get("https://financialmodelingprep.com/api/v3/income-statement/AAPL").mock(
        return_value=httpx.Response(200, json=sample_fmp_income_response)
    )

    stmts = await provider.get_income_statements("AAPL", years=2)

    assert len(stmts) == 2
    # Newest first
    assert stmts[0].fiscal_year == 2023
    assert stmts[1].fiscal_year == 2022

    s = stmts[0]
    assert s.ticker == "AAPL"
    assert s.revenue == pytest.approx(383_285_000_000)
    assert s.gross_profit == pytest.approx(169_148_000_000)
    assert s.ebitda == pytest.approx(125_820_000_000)
    assert s.net_income == pytest.approx(96_995_000_000)
    assert s.eps_diluted == pytest.approx(6.13)
    assert s.source_provider == "fmp"


@respx.mock
@pytest.mark.asyncio
async def test_income_statement_margin_derivation(
    provider: FMPProvider,
    sample_fmp_income_response: list,
) -> None:
    """Pydantic model should auto-derive EBITDA margin from revenue and EBITDA."""
    respx.get("https://financialmodelingprep.com/api/v3/income-statement/AAPL").mock(
        return_value=httpx.Response(200, json=sample_fmp_income_response)
    )

    stmts = await provider.get_income_statements("AAPL", years=1)
    s = stmts[0]

    expected_margin = 125_820_000_000 / 383_285_000_000
    assert s.ebitda_margin == pytest.approx(expected_margin, rel=1e-3)


@respx.mock
@pytest.mark.asyncio
async def test_income_statement_non_list_response(provider: FMPProvider) -> None:
    """Non-list response raises ProviderDataError."""
    respx.get("https://financialmodelingprep.com/api/v3/income-statement/AAPL").mock(
        return_value=httpx.Response(200, json={"Error": "Not found"})
    )

    with pytest.raises(ProviderDataError):
        await provider.get_income_statements("AAPL")


# ── Balance Sheet tests ────────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_get_balance_sheets_success(
    provider: FMPProvider,
    sample_fmp_balance_sheet_response: list,
) -> None:
    """Balance sheet fields are correctly mapped including derived net_debt."""
    respx.get("https://financialmodelingprep.com/api/v3/balance-sheet-statement/AAPL").mock(
        return_value=httpx.Response(200, json=sample_fmp_balance_sheet_response)
    )

    sheets = await provider.get_balance_sheets("AAPL", years=1)

    assert len(sheets) == 1
    bs = sheets[0]
    assert bs.total_assets == pytest.approx(352_583_000_000)
    assert bs.cash_and_equivalents == pytest.approx(29_965_000_000)
    assert bs.long_term_debt == pytest.approx(95_281_000_000)
    assert bs.total_stockholders_equity == pytest.approx(62_146_000_000)

    # Derived net_debt = short_term_debt + long_term_debt - cash - short_term_investments
    expected_net_debt = (9_822_000_000 + 95_281_000_000) - (29_965_000_000 + 31_590_000_000)
    assert bs.net_debt == pytest.approx(expected_net_debt)


# ── Cash Flow tests ────────────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_get_cash_flows_success(
    provider: FMPProvider,
    sample_fmp_cashflow_response: list,
) -> None:
    """Cash flow statement fields including FCF are correctly parsed."""
    respx.get("https://financialmodelingprep.com/api/v3/cash-flow-statement/AAPL").mock(
        return_value=httpx.Response(200, json=sample_fmp_cashflow_response)
    )

    stmts = await provider.get_cash_flow_statements("AAPL", years=1)

    assert len(stmts) == 1
    cfs = stmts[0]
    assert cfs.operating_cash_flow == pytest.approx(110_543_000_000)
    assert cfs.capital_expenditures == pytest.approx(-10_959_000_000)
    assert cfs.free_cash_flow == pytest.approx(99_584_000_000)


# ── Market Data tests ──────────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_get_market_data_success(
    provider: FMPProvider,
    sample_fmp_quote_response: list,
    sample_fmp_key_metrics_response: list,
) -> None:
    """Market data correctly merges quote and key-metrics endpoints."""
    respx.get("https://financialmodelingprep.com/api/v3/quote/AAPL").mock(
        return_value=httpx.Response(200, json=sample_fmp_quote_response)
    )
    respx.get("https://financialmodelingprep.com/api/v3/key-metrics/AAPL").mock(
        return_value=httpx.Response(200, json=sample_fmp_key_metrics_response)
    )

    md = await provider.get_market_data("AAPL")

    assert md.ticker == "AAPL"
    assert md.current_price == pytest.approx(175.50)
    assert md.market_cap == pytest.approx(2_750_000_000_000)
    assert md.shares_outstanding == pytest.approx(15_671_000_000)
    assert md.beta == pytest.approx(1.25)
    assert md.pe_ratio_ttm == pytest.approx(28.5)
    assert md.ev_ebitda_ttm == pytest.approx(22.1)


@respx.mock
@pytest.mark.asyncio
async def test_get_market_data_empty_quote(provider: FMPProvider) -> None:
    """Empty quote response raises ProviderDataError."""
    respx.get("https://financialmodelingprep.com/api/v3/quote/AAPL").mock(
        return_value=httpx.Response(200, json=[])
    )

    with pytest.raises(ProviderDataError, match="No quote data"):
        await provider.get_market_data("AAPL")


# ── Search tests ───────────────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_search_companies(provider: FMPProvider) -> None:
    """Search returns correctly mapped results."""
    respx.get("https://financialmodelingprep.com/api/v3/search").mock(
        return_value=httpx.Response(200, json=[
            {"symbol": "AAPL", "name": "Apple Inc.", "stockExchange": "NASDAQ", "currency": "USD"},
            {"symbol": "AAPLF", "name": "Apple Inc. (Pink Sheets)", "stockExchange": "OTC", "currency": "USD"},
        ])
    )

    results = await provider.search_companies("Apple", limit=5)

    assert len(results) == 2
    assert results[0].ticker == "AAPL"
    assert results[0].company_name == "Apple Inc."


@respx.mock
@pytest.mark.asyncio
async def test_search_companies_empty_response(provider: FMPProvider) -> None:
    """Empty search response returns empty list (not an error)."""
    respx.get("https://financialmodelingprep.com/api/v3/search").mock(
        return_value=httpx.Response(200, json=[])
    )

    results = await provider.search_companies("XYZNOTREAL")
    assert results == []


# ── Ticker normalisation ───────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_ticker_case_normalised(
    provider: FMPProvider,
    sample_fmp_profile_response: list,
) -> None:
    """Lowercase ticker input is normalised to uppercase in the output model."""
    respx.get("https://financialmodelingprep.com/api/v3/profile/AAPL").mock(
        return_value=httpx.Response(200, json=sample_fmp_profile_response)
    )

    profile = await provider.get_company_profile("aapl")
    assert profile.ticker == "AAPL"


# ── No API key ─────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_missing_api_key_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    """Missing FMP key raises ProviderAuthError immediately (no network call)."""
    monkeypatch.setenv("FMP_API_KEY", "")
    from config import get_settings
    get_settings.cache_clear()

    client = httpx.AsyncClient()
    provider = FMPProvider(client)

    with pytest.raises(ProviderAuthError, match="API key not configured"):
        await provider.get_company_profile("AAPL")

    get_settings.cache_clear()
