"""
tests/data/test_data_router.py
-------------------------------
Unit tests for DataRouter — the orchestration layer.

Uses InMemoryCache from conftest and AsyncMock providers.
No real HTTP calls, no real Redis.
"""

from __future__ import annotations

from datetime import date
from unittest.mock import AsyncMock, MagicMock

import pytest

from data.models import (
    BalanceSheet,
    CashFlowStatement,
    CompanyProfile,
    IncomeStatement,
    MarketData,
)
from data.providers.base import ProviderAuthError, ProviderDataError
from data.router import DataRouter
from tests.conftest import InMemoryCache


# ── Shared fixtures ────────────────────────────────────────────────────────────

def _mock_provider(name: str = "fmp", supports_realtime: bool = True) -> MagicMock:
    """Create a fully-mocked provider."""
    p = MagicMock()
    p.name = name
    p.supports_realtime = supports_realtime
    return p


def _sample_profile() -> CompanyProfile:
    return CompanyProfile(
        ticker="AAPL",
        company_name="Apple Inc.",
        exchange="NASDAQ",
        sector="Technology",
        source_provider="fmp",
    )


def _sample_market_data() -> MarketData:
    return MarketData(
        ticker="AAPL",
        source_provider="fmp",
        current_price=175.50,
        market_cap=2_750_000_000_000,
        shares_outstanding=15_671_000_000,
        beta=1.25,
    )


def _sample_income_statement() -> IncomeStatement:
    return IncomeStatement(
        ticker="AAPL",
        period_type="annual",
        period_end_date=date(2023, 9, 30),
        fiscal_year=2023,
        source_provider="fmp",
        revenue=383_285_000_000,
        net_income=96_995_000_000,
        eps_diluted=6.13,
        weighted_avg_shares_diluted=15_812_547_000,
    )


def _sample_balance_sheet() -> BalanceSheet:
    return BalanceSheet(
        ticker="AAPL",
        period_type="annual",
        period_end_date=date(2023, 9, 30),
        fiscal_year=2023,
        source_provider="fmp",
        total_assets=352_583_000_000,
        total_liabilities=290_437_000_000,
        total_stockholders_equity=62_146_000_000,
    )


def _sample_cash_flow() -> CashFlowStatement:
    return CashFlowStatement(
        ticker="AAPL",
        period_type="annual",
        period_end_date=date(2023, 9, 30),
        fiscal_year=2023,
        source_provider="fmp",
        operating_cash_flow=110_543_000_000,
        capital_expenditures=-10_959_000_000,
    )


@pytest.fixture
def primary_provider() -> MagicMock:
    p = _mock_provider("fmp")
    p.get_company_profile = AsyncMock(return_value=_sample_profile())
    p.get_market_data = AsyncMock(return_value=_sample_market_data())
    p.get_income_statements = AsyncMock(return_value=[_sample_income_statement()])
    p.get_balance_sheets = AsyncMock(return_value=[_sample_balance_sheet()])
    p.get_cash_flow_statements = AsyncMock(return_value=[_sample_cash_flow()])
    p.get_peer_multiples = AsyncMock(return_value=[])
    return p


@pytest.fixture
def router(cache: InMemoryCache, primary_provider: MagicMock) -> DataRouter:
    return DataRouter(
        cache=cache,
        providers={"fmp": primary_provider},
    )


# ── Market data tests ──────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_market_data_success(router: DataRouter) -> None:
    resp = await router.get_market_data("AAPL")
    assert resp.status == "ok"
    assert resp.data is not None
    assert resp.data.current_price == pytest.approx(175.50)
    assert resp.meta.cache_hit is False
    assert resp.meta.provider == "fmp"


@pytest.mark.asyncio
async def test_get_market_data_cache_hit(
    router: DataRouter,
    cache: InMemoryCache,
    primary_provider: MagicMock,
) -> None:
    """Second request should return from cache without calling the provider."""
    await router.get_market_data("AAPL")      # populate cache
    await router.get_market_data("AAPL")      # should hit cache

    # Provider called exactly once across both requests
    assert primary_provider.get_market_data.call_count == 1


@pytest.mark.asyncio
async def test_get_market_data_provider_error_returns_error_response(
    cache: InMemoryCache,
) -> None:
    failing_provider = _mock_provider("fmp")
    failing_provider.get_market_data = AsyncMock(
        side_effect=ProviderAuthError("fmp", "Invalid key")
    )
    failing_provider.get_income_statements = AsyncMock(return_value=[])
    router = DataRouter(cache=cache, providers={"fmp": failing_provider})

    resp = await router.get_market_data("AAPL")
    assert resp.status == "error"
    assert resp.data is None
    assert len(resp.errors) > 0


# ── Provider fallback tests ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_fallback_to_secondary_provider(cache: InMemoryCache) -> None:
    """When primary fails with auth error, secondary provider is used."""
    failing = _mock_provider("fmp")
    failing.get_market_data = AsyncMock(
        side_effect=ProviderDataError("fmp", "No data")
    )

    working = _mock_provider("alpha_vantage")
    working.get_market_data = AsyncMock(
        return_value=MarketData(
            ticker="AAPL",
            source_provider="alpha_vantage",
            current_price=175.00,
            market_cap=2_740_000_000_000,
            shares_outstanding=15_671_000_000,
            beta=1.25,
        )
    )

    router = DataRouter(
        cache=cache,
        providers={"fmp": failing, "alpha_vantage": working},
    )
    # Need to patch settings.provider_priority for this test
    import unittest.mock as mock
    with mock.patch.object(router, "_priority", ["fmp", "alpha_vantage"]):
        resp = await router.get_market_data("AAPL")

    assert resp.status == "ok"
    assert resp.data is not None
    assert resp.data.source_provider == "alpha_vantage"


# ── Income statement tests ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_income_statements_success(router: DataRouter) -> None:
    resp = await router.get_income_statements("AAPL", years=1)
    assert resp.status in ("ok", "partial")
    assert resp.data is not None
    assert len(resp.data) == 1
    assert resp.data[0].revenue == pytest.approx(383_285_000_000)


@pytest.mark.asyncio
async def test_get_income_statements_cache_hit(
    router: DataRouter,
    primary_provider: MagicMock,
) -> None:
    await router.get_income_statements("AAPL", years=5)
    await router.get_income_statements("AAPL", years=5)
    assert primary_provider.get_income_statements.call_count == 1


# ── Bundle tests ───────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_financials_bundle_returns_complete_data(router: DataRouter) -> None:
    bundle = await router.get_financials_bundle("AAPL")

    assert bundle.profile.ticker == "AAPL"
    assert bundle.market_data.current_price == pytest.approx(175.50)
    assert len(bundle.income_statements) == 1
    assert len(bundle.balance_sheets) == 1
    assert len(bundle.cash_flow_statements) == 1


@pytest.mark.asyncio
async def test_bundle_uses_concurrent_fetching(
    cache: InMemoryCache,
    primary_provider: MagicMock,
) -> None:
    """All three statement types should be fetched in the same coroutine call."""
    import asyncio
    call_times: list[float] = []

    async def slow_is(*args: object, **kwargs: object) -> list:
        call_times.append(asyncio.get_event_loop().time())
        await asyncio.sleep(0.05)
        return [_sample_income_statement()]

    async def slow_bs(*args: object, **kwargs: object) -> list:
        call_times.append(asyncio.get_event_loop().time())
        await asyncio.sleep(0.05)
        return [_sample_balance_sheet()]

    async def slow_cfs(*args: object, **kwargs: object) -> list:
        call_times.append(asyncio.get_event_loop().time())
        await asyncio.sleep(0.05)
        return [_sample_cash_flow()]

    primary_provider.get_income_statements = slow_is
    primary_provider.get_balance_sheets = slow_bs
    primary_provider.get_cash_flow_statements = slow_cfs

    router = DataRouter(cache=cache, providers={"fmp": primary_provider})
    import time
    t0 = time.perf_counter()
    await router.get_financials_bundle("AAPL")
    elapsed = time.perf_counter() - t0

    # If concurrent: ~0.05s total. If sequential: ~0.15s total.
    # We allow generous headroom for CI overhead.
    assert elapsed < 0.12, f"Bundle fetch was sequential (took {elapsed:.3f}s)"


@pytest.mark.asyncio
async def test_bundle_cached_on_second_call(
    router: DataRouter,
    primary_provider: MagicMock,
) -> None:
    await router.get_financials_bundle("AAPL")
    await router.get_financials_bundle("AAPL")
    # Profile should only be fetched once (rest come from bundle cache)
    assert primary_provider.get_company_profile.call_count == 1


# ── Profile tests ──────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_company_profile_success(router: DataRouter) -> None:
    resp = await router.get_company_profile("AAPL")
    assert resp.status == "ok"
    assert resp.data is not None
    assert resp.data.company_name == "Apple Inc."
