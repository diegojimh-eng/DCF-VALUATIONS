"""
tests/data/test_financial_models.py
------------------------------------
Tests for Pydantic model auto-derivation logic (margins, net_debt, FCF).
"""

from __future__ import annotations

from datetime import date

import pytest

from data.models import BalanceSheet, CashFlowStatement, IncomeStatement, MarketData


def _is(**kwargs: object) -> IncomeStatement:
    base = dict(
        ticker="TEST",
        period_type="annual",
        period_end_date=date(2023, 12, 31),
        fiscal_year=2023,
        source_provider="fmp",
    )
    base.update(kwargs)
    return IncomeStatement(**base)


def _bs(**kwargs: object) -> BalanceSheet:
    base = dict(
        ticker="TEST",
        period_type="annual",
        period_end_date=date(2023, 12, 31),
        fiscal_year=2023,
        source_provider="fmp",
    )
    base.update(kwargs)
    return BalanceSheet(**base)


def _cfs(**kwargs: object) -> CashFlowStatement:
    base = dict(
        ticker="TEST",
        period_type="annual",
        period_end_date=date(2023, 12, 31),
        fiscal_year=2023,
        source_provider="fmp",
    )
    base.update(kwargs)
    return CashFlowStatement(**base)


# ── IncomeStatement margin derivation ─────────────────────────────────────────

class TestIncomeStatementDerivation:

    def test_gross_margin_derived_from_revenue_and_gross_profit(self) -> None:
        stmt = _is(revenue=100_000_000, gross_profit=60_000_000)
        assert stmt.gross_margin == pytest.approx(0.60)

    def test_ebitda_margin_derived(self) -> None:
        stmt = _is(revenue=200_000_000, ebitda=50_000_000)
        assert stmt.ebitda_margin == pytest.approx(0.25)

    def test_net_income_margin_derived(self) -> None:
        stmt = _is(revenue=100_000_000, net_income=20_000_000)
        assert stmt.net_income_margin == pytest.approx(0.20)

    def test_no_derivation_without_revenue(self) -> None:
        stmt = _is(revenue=None, gross_profit=50_000_000)
        assert stmt.gross_margin is None

    def test_pre_populated_margin_not_overwritten(self) -> None:
        # If margin is already set, the model_validator should not overwrite it
        stmt = _is(revenue=100_000_000, gross_profit=60_000_000, gross_margin=0.55)
        # Current validator only fills if margin is None, so 0.55 should stay
        assert stmt.gross_margin == pytest.approx(0.55)

    def test_ticker_normalised_to_uppercase(self) -> None:
        stmt = _is(ticker="aapl")
        assert stmt.ticker == "AAPL"


# ── BalanceSheet derivation ────────────────────────────────────────────────────

class TestBalanceSheetDerivation:

    def test_net_debt_derived(self) -> None:
        bs = _bs(
            cash_and_equivalents=30_000_000_000,
            short_term_investments=30_000_000_000,
            short_term_debt=10_000_000_000,
            long_term_debt=90_000_000_000,
        )
        # net_debt = (10B + 90B) - (30B + 30B) = 40B
        assert bs.net_debt == pytest.approx(40_000_000_000)

    def test_net_working_capital_derived(self) -> None:
        bs = _bs(
            total_current_assets=143_000_000_000,
            total_current_liabilities=145_000_000_000,
        )
        assert bs.net_working_capital == pytest.approx(-2_000_000_000)

    def test_net_debt_zero_when_cash_exceeds_debt(self) -> None:
        bs = _bs(
            cash_and_equivalents=100_000_000_000,
            long_term_debt=50_000_000_000,
        )
        assert bs.net_debt == pytest.approx(-50_000_000_000)


# ── CashFlowStatement FCF derivation ──────────────────────────────────────────

class TestCashFlowStatementDerivation:

    def test_fcf_derived_from_cfo_and_capex(self) -> None:
        cfs = _cfs(
            operating_cash_flow=110_000_000_000,
            capital_expenditures=-10_000_000_000,
        )
        # FCF = CFO + CapEx (CapEx is negative)
        assert cfs.free_cash_flow == pytest.approx(100_000_000_000)

    def test_fcf_not_overwritten_when_provided(self) -> None:
        cfs = _cfs(
            operating_cash_flow=110_000_000_000,
            capital_expenditures=-10_000_000_000,
            free_cash_flow=95_000_000_000,   # explicitly set
        )
        # model_validator only fills if free_cash_flow is None
        assert cfs.free_cash_flow == pytest.approx(95_000_000_000)

    def test_fcf_none_when_cfo_missing(self) -> None:
        cfs = _cfs(capital_expenditures=-10_000_000_000)
        assert cfs.free_cash_flow is None


# ── MarketData beta validator ──────────────────────────────────────────────────

class TestMarketDataValidation:

    def test_extreme_beta_becomes_none(self) -> None:
        # field_validator clips beta > 10 to None
        md = MarketData(ticker="TEST", source_provider="fmp", beta=15.0)
        assert md.beta is None

    def test_negative_extreme_beta_becomes_none(self) -> None:
        md = MarketData(ticker="TEST", source_provider="fmp", beta=-6.0)
        assert md.beta is None

    def test_normal_beta_preserved(self) -> None:
        md = MarketData(ticker="TEST", source_provider="fmp", beta=1.25)
        assert md.beta == pytest.approx(1.25)
