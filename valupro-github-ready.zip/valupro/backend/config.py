"""
config.py
---------
Central configuration loaded from environment variables / .env file.
Pydantic-settings validates types and provides clear error messages when
a required variable is missing at startup — no silent None surprises.
"""

from functools import lru_cache
from typing import Literal

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    All application configuration in one validated model.

    Precedence (highest → lowest):
      1. Actual environment variables
      2. .env file in the project root
      3. Default values declared here

    Usage:
        from config import get_settings
        cfg = get_settings()
        print(cfg.fmp_api_key.get_secret_value())
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",          # don't fail on unknown env vars
    )

    # ── Application ────────────────────────────────────────────────────────
    app_env: Literal["development", "staging", "production"] = "development"
    app_name: str = "ValuPro"
    log_level: str = "INFO"
    debug: bool = False

    # ── Database ────────────────────────────────────────────────────────────
    database_url: str = Field(
        default="postgresql+asyncpg://valupro:valupro@localhost:5432/valupro",
        description="Async PostgreSQL DSN (asyncpg driver)",
    )
    db_pool_size: int = 10
    db_max_overflow: int = 20
    db_pool_recycle_seconds: int = 3600

    # ── Redis ───────────────────────────────────────────────────────────────
    redis_url: str = Field(
        default="redis://localhost:6379/0",
        description="Redis DSN for caching layer",
    )
    # TTL values in seconds
    cache_ttl_market_data: int = 900        # 15 minutes  — prices / beta
    cache_ttl_financials: int = 86_400      # 24 hours    — quarterly statements
    cache_ttl_company_profile: int = 604_800  # 7 days   — static metadata

    # ── Financial Data Providers ────────────────────────────────────────────
    # Financial Modeling Prep  (primary)
    fmp_api_key: SecretStr = Field(
        default=SecretStr(""),
        description="FMP API key — https://financialmodelingprep.com",
    )
    fmp_base_url: str = "https://financialmodelingprep.com/api/v3"
    fmp_timeout_seconds: float = 15.0
    fmp_max_retries: int = 3

    # Alpha Vantage  (secondary)
    alpha_vantage_api_key: SecretStr = Field(
        default=SecretStr(""),
        description="Alpha Vantage key — https://www.alphavantage.co",
    )
    alpha_vantage_base_url: str = "https://www.alphavantage.co/query"
    alpha_vantage_timeout_seconds: float = 20.0

    # SEC EDGAR  (no key needed — public API)
    sec_edgar_base_url: str = "https://data.sec.gov"
    sec_edgar_user_agent: str = Field(
        default="ValuPro research@valupro.io",
        description=(
            "EDGAR requires a descriptive User-Agent string. "
            "Must include contact email per SEC fair-use policy."
        ),
    )
    sec_edgar_timeout_seconds: float = 30.0

    # Yahoo Finance  (tertiary fallback — no key)
    yfinance_timeout_seconds: float = 15.0

    # ── Provider priority ───────────────────────────────────────────────────
    # Ordered list of provider names; DataRouter tries them left-to-right.
    provider_priority: list[str] = ["fmp", "alpha_vantage", "sec_edgar", "yahoo_finance"]

    # ── HTTP client ─────────────────────────────────────────────────────────
    http_connect_timeout: float = 5.0
    http_read_timeout: float = 30.0

    # ── Anthropic Claude (Phase 5 — AI memo generation) ────────────────────
    anthropic_api_key: SecretStr = Field(default=SecretStr(""))
    anthropic_model: str = "claude-sonnet-4-6"

    # ── AWS / Storage (Phase 5 — PDF reports) ──────────────────────────────
    aws_access_key_id: SecretStr = Field(default=SecretStr(""))
    aws_secret_access_key: SecretStr = Field(default=SecretStr(""))
    aws_region: str = "us-east-1"
    s3_bucket_reports: str = "valupro-reports"

    # ── Validation ──────────────────────────────────────────────────────────
    @field_validator("log_level")
    @classmethod
    def normalise_log_level(cls, v: str) -> str:
        valid = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        upper = v.upper()
        if upper not in valid:
            raise ValueError(f"log_level must be one of {valid}")
        return upper

    def is_production(self) -> bool:
        return self.app_env == "production"

    def fmp_key_configured(self) -> bool:
        return bool(self.fmp_api_key.get_secret_value())

    def alpha_vantage_key_configured(self) -> bool:
        return bool(self.alpha_vantage_api_key.get_secret_value())


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """
    Return the singleton Settings instance.
    Cached so environment is only parsed once per process lifetime.
    Call get_settings.cache_clear() in tests to force re-read.
    """
    return Settings()

    # ── Security / CORS ─────────────────────────────────────────────────────
    # In production set: CORS_ALLOWED_ORIGINS=https://app.valupro.io
    cors_allowed_origins: list[str] = Field(
        default_factory=lambda: ["http://localhost:3000"],
        description="Allowed CORS origins. Use CSV in env var.",
    )

    # ── Rate limiting ────────────────────────────────────────────────────────
    rate_limit_default: str = "60/minute"
    rate_limit_memo:    str = "10/minute"
    rate_limit_reports: str = "20/minute"

    # ── API auth ─────────────────────────────────────────────────────────────
    # Generate: python3 -c "import secrets; print(secrets.token_hex(32))"
    api_secret_key: SecretStr = Field(
        default=SecretStr("dev-insecure-secret-change-in-production"),
        description="JWT signing secret — MUST be overridden in production.",
    )
    api_token_expire_minutes: int = 1440  # 24 hours
