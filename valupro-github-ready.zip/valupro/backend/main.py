"""
main.py
-------
ValuPro FastAPI application entry point — production-ready.

Application lifecycle:
  startup  → setup logging, connect Redis, build HTTP client,
              instantiate providers and DataRouter
  shutdown → close HTTP client, close Redis connection

Dependency injection:
  All shared resources attach to app.state and are injected via
  FastAPI Depends() functions in api/dependencies.py.
  No module-level globals — safe for multi-worker deployments.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from config import get_settings
from data import DataRouter, FinancialCache, create_redis_client
from data.providers import PROVIDER_REGISTRY, build_http_client
from logger import get_logger, setup_logging

setup_logging()
log = get_logger(__name__)


# ── Lifespan ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Application lifespan — startup and shutdown."""
    cfg = get_settings()
    log.info("valupro.startup", env=cfg.app_env, providers=cfg.provider_priority)

    async with build_http_client() as http_client:
        redis_client = await create_redis_client()
        cache        = FinancialCache(redis_client)

        providers = {
            name: cls(http_client)
            for name, cls in PROVIDER_REGISTRY.items()
            if name in cfg.provider_priority
        }

        router = DataRouter(cache=cache, providers=providers)

        app.state.http_client = http_client
        app.state.redis       = redis_client
        app.state.cache       = cache
        app.state.data_router = router

        log.info("valupro.ready", providers=list(providers.keys()))
        yield

    await redis_client.aclose()
    log.info("valupro.shutdown")


# ── App factory ───────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    cfg = get_settings()

    app = FastAPI(
        title="ValuPro API",
        description="Institutional-grade company valuation platform",
        version="1.0.0",
        # Disable interactive docs in production — no free recon
        docs_url="/docs"   if not cfg.is_production() else None,
        redoc_url="/redoc" if not cfg.is_production() else None,
        openapi_url="/openapi.json" if not cfg.is_production() else None,
        lifespan=lifespan,
    )

    # ── Middleware (order matters — outermost first) ───────────────────────

    # Gzip responses >= 1 KB
    app.add_middleware(GZipMiddleware, minimum_size=1024)

    # CORS — read allowed origins from environment in production
    allowed_origins: list[str] = (
        cfg.cors_allowed_origins
        if cfg.is_production()
        else ["http://localhost:3000", "http://localhost:5173", "http://127.0.0.1:3000"]
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allowed_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
        max_age=600,
    )

    # ── Routes ────────────────────────────────────────────────────────────

    # Root-level health (load-balancer / k8s probe — no auth required)
    @app.get("/health/live",  include_in_schema=False, tags=["health"])
    async def liveness()  -> dict: return {"status": "ok"}

    @app.get("/health/ready", include_in_schema=False, tags=["health"])
    async def readiness(request: Request) -> dict:
        """Readiness: Redis must be reachable."""
        try:
            await request.app.state.cache.ping()
            return {"status": "ok"}
        except Exception as exc:
            return JSONResponse(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                content={"status": "down", "detail": str(exc)},
            )

    from api.routes import (
        company, data_health, forecast, valuation,
        terminal_value, comps, analysis, reports, memo,
    )
    prefix = "/api/v1"
    app.include_router(company.router,        prefix=prefix, tags=["company"])
    app.include_router(data_health.router,    prefix=prefix, tags=["health"])
    app.include_router(forecast.router,       prefix=prefix, tags=["forecast"])
    app.include_router(valuation.router,      prefix=prefix, tags=["valuation"])
    app.include_router(terminal_value.router, prefix=prefix, tags=["terminal-value"])
    app.include_router(comps.router,          prefix=prefix, tags=["comps"])
    app.include_router(analysis.router,       prefix=prefix, tags=["analysis"])
    app.include_router(reports.router,        prefix=prefix, tags=["reports"])
    app.include_router(memo.router,           prefix=prefix, tags=["memo"])

    # ── Exception handlers ────────────────────────────────────────────────

    @app.exception_handler(ValueError)
    async def value_error_handler(request: object, exc: ValueError) -> JSONResponse:
        return JSONResponse(status_code=422, content={"detail": str(exc)})

    @app.exception_handler(Exception)
    async def generic_error_handler(request: Request, exc: Exception) -> JSONResponse:
        log.error("unhandled_exception", path=str(request.url), error=str(exc), exc_info=True)
        # Never leak stack traces to clients in production
        msg = str(exc) if not cfg.is_production() else "An internal error occurred."
        return JSONResponse(status_code=500, content={"detail": msg})

    return app


app = create_app()
