"""
engine/forecasters/da.py
-------------------------
Depreciation & Amortisation (D&A) forecaster.

D&A is modelled as a percentage of revenue, the industry-standard approach
for DCF models where the full asset schedule is not available.

    D&A_t = Revenue_t × da_pct_revenue_t

The absolute D&A value feeds into two places in the model:
  1. EBIT  = EBITDA − D&A
  2. FCFF  = NOPAT + D&A − CapEx − ΔNWC   (D&A added back as non-cash)

Assumption priority:
  1. Per-year percentage list
  2. Single constant percentage
  3. Trend-derived median from history

Notes on sign convention:
  • D&A is always stored and returned as a POSITIVE absolute value.
  • The CFS adds D&A back (positive add-back), IS subtracts it (non-cash charge).
  • CapEx sign is handled separately in capex.py.
"""

from __future__ import annotations

from engine.assumptions import TrendAnalyser
from engine.assumptions.models import (
    AssumptionMode,
    DAAssumptions,
    ItemAssumption,
)
from logger import get_logger

log = get_logger(__name__)


class DAForecaster:
    """
    Resolves D&A as a percentage of revenue for each forecast year.
    """

    def __init__(self, analyser: TrendAnalyser) -> None:
        self._analyser = analyser

    def resolve_da_pct(
        self,
        da_assumptions: DAAssumptions,
        historical_da: list[float | None],
        historical_revenue: list[float | None],
        forecast_years: int = 10,
    ) -> tuple[list[float], ItemAssumption]:
        """
        Resolve D&A / Revenue for each forecast year.

        Args:
            da_assumptions:    DAAssumptions config.
            historical_da:     D&A values newest-first (may be negative from CFS).
            historical_revenue: Revenue values newest-first.
            forecast_years:    Number of projection years.

        Returns:
            (pct_list, ItemAssumption)
            pct_list: positive fractions (e.g. 0.03 = 3% of revenue).
        """
        da = da_assumptions

        # ── Priority 1: Per-year list ──────────────────────────────────────
        if da.da_as_pct_revenue_by_year is not None:
            base = [abs(p) for p in da.da_as_pct_revenue_by_year[:forecast_years]]
            base = [min(p, 0.30) for p in base]
            assumption = ItemAssumption(
                value=sum(base) / len(base) if base else 0.03,
                mode=AssumptionMode.MANUAL,
                note="Analyst-provided per-year D&A % of revenue",
            )
            return self._pad(base, forecast_years), assumption

        # ── Priority 2: Single constant ────────────────────────────────────
        if da.da_as_pct_revenue is not None:
            pct = min(abs(da.da_as_pct_revenue), 0.30)
            pcts = [pct] * forecast_years
            assumption = ItemAssumption(
                value=pct,
                mode=AssumptionMode.MANUAL,
                note=f"Analyst-specified D&A/Revenue: {pct:.2%}",
            )
            return pcts, assumption

        # ── Priority 3: Trend-derived ──────────────────────────────────────
        item = self._analyser.da_as_pct_revenue(
            historical_da,
            historical_revenue,
            method=da.trend_method,
        )
        pcts = [item.value] * forecast_years
        log.debug("da.resolve.trend", pct=item.value)
        return pcts, item

    def compute_da_absolute(
        self,
        revenue: float,
        da_pct: float,
    ) -> float:
        """
        Compute absolute D&A from revenue and percentage.

        Args:
            revenue: Projected revenue for the year.
            da_pct:  D&A as fraction of revenue (positive decimal).

        Returns:
            Positive D&A absolute value.
        """
        return max(0.0, revenue * da_pct)

    @staticmethod
    def _pad(values: list[float], target_len: int) -> list[float]:
        if not values:
            return [0.03] * target_len
        while len(values) < target_len:
            values.append(values[-1])
        return values[:target_len]
