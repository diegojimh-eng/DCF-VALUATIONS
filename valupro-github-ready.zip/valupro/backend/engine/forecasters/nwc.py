"""
engine/forecasters/nwc.py
--------------------------
Net Working Capital (NWC) forecaster.

NWC = Operating Current Assets − Operating Current Liabilities
    = (AR + Inventory + Other Current Assets)
      − (AP + Accrued Liabilities + Other Current Liabilities)

NWC is modelled as a percentage of revenue:
    NWC_t = Revenue_t × nwc_pct_revenue_t

What enters the FCFF formula is the *change* in NWC:
    ΔNWC_t = NWC_t − NWC_{t-1}

Sign convention:
  • Positive ΔNWC = cash use  (business growing, absorbing working capital)
  • Negative ΔNWC = cash source (business shrinking or improving efficiency)
  • In FCFF formula: FCFF = NOPAT + D&A − CapEx − ΔNWC
    (positive ΔNWC reduces FCFF — it's a cash drain)

Alternative component-level modelling (DSO / DIO / DPO):
    AR  = Revenue × DSO / 365
    Inv = COGS   × DIO / 365  (approximated as Revenue × COGS% × DIO / 365)
    AP  = COGS   × DPO / 365

    NWC = AR + Inventory − AP

If DSO / DIO / DPO are provided they take precedence over the aggregate
nwc_pct_revenue approach.

Assumption priority:
  1. Per-year NWC % list
  2. Component-level (DSO + DIO + DPO) — requires all three
  3. Single constant NWC %
  4. Trend-derived median from history
"""

from __future__ import annotations

from engine.assumptions import TrendAnalyser
from engine.assumptions.models import (
    AssumptionMode,
    ItemAssumption,
    NWCAssumptions,
)
from logger import get_logger

log = get_logger(__name__)

_DAYS_IN_YEAR = 365.0
_DEFAULT_COGS_PCT = 0.60   # fallback when COGS not available for inventory calc


class NWCForecaster:
    """
    Resolves NWC as a percentage of revenue and computes year-over-year changes.
    """

    def __init__(self, analyser: TrendAnalyser) -> None:
        self._analyser = analyser

    def resolve_nwc_pct(
        self,
        nwc_assumptions: NWCAssumptions,
        historical_nwc: list[float | None],
        historical_revenue: list[float | None],
        forecast_years: int = 10,
        historical_cogs_pct: float | None = None,
    ) -> tuple[list[float], ItemAssumption]:
        """
        Resolve NWC / Revenue for each forecast year.

        Args:
            nwc_assumptions:    NWCAssumptions config.
            historical_nwc:     NWC values newest-first (may be negative).
            historical_revenue: Revenue values newest-first.
            forecast_years:     Number of projection years.
            historical_cogs_pct: COGS as % of revenue (for DIO-based modelling).

        Returns:
            (pct_list, ItemAssumption)
            pct_list: NWC as fraction of revenue (may be negative if AP > AR+Inv).
        """
        na = nwc_assumptions

        # ── Priority 1: Per-year NWC % list ───────────────────────────────
        if na.nwc_as_pct_revenue_by_year is not None:
            base = list(na.nwc_as_pct_revenue_by_year[:forecast_years])
            base = [max(-0.30, min(p, 0.60)) for p in base]
            assumption = ItemAssumption(
                value=sum(base) / len(base) if base else 0.05,
                mode=AssumptionMode.MANUAL,
                note="Analyst-provided per-year NWC % of revenue",
            )
            return self._pad(base, forecast_years), assumption

        # ── Priority 2: Component-level (DSO + DIO + DPO) ─────────────────
        if all(
            x is not None
            for x in (na.accounts_receivable_days, na.inventory_days, na.accounts_payable_days)
        ):
            pct = self._component_nwc_pct(
                dso=na.accounts_receivable_days,   # type: ignore[arg-type]
                dio=na.inventory_days,              # type: ignore[arg-type]
                dpo=na.accounts_payable_days,       # type: ignore[arg-type]
                cogs_pct=historical_cogs_pct or _DEFAULT_COGS_PCT,
            )
            pct = max(-0.30, min(pct, 0.60))
            pcts = [pct] * forecast_years
            assumption = ItemAssumption(
                value=pct,
                mode=AssumptionMode.MANUAL,
                note=(
                    f"DSO={na.accounts_receivable_days:.0f}d, "
                    f"DIO={na.inventory_days:.0f}d, "
                    f"DPO={na.accounts_payable_days:.0f}d → NWC={pct:.2%}"
                ),
            )
            return pcts, assumption

        # ── Priority 3: Single constant ────────────────────────────────────
        if na.nwc_as_pct_revenue is not None:
            pct = max(-0.30, min(na.nwc_as_pct_revenue, 0.60))
            pcts = [pct] * forecast_years
            assumption = ItemAssumption(
                value=pct,
                mode=AssumptionMode.MANUAL,
                note=f"Analyst-specified NWC/Revenue: {pct:.2%}",
            )
            return pcts, assumption

        # ── Priority 4: Trend-derived ──────────────────────────────────────
        item = self._analyser.nwc_as_pct_revenue(
            historical_nwc,
            historical_revenue,
            method=na.trend_method,
        )
        pcts = [item.value] * forecast_years
        log.debug("nwc.resolve.trend", pct=item.value)
        return pcts, item

    def compute_nwc_absolute(
        self,
        revenue: float,
        nwc_pct: float,
    ) -> float:
        """NWC in absolute currency units."""
        return revenue * nwc_pct

    def compute_change_in_nwc(
        self,
        nwc_current: float,
        nwc_prior: float,
    ) -> float:
        """
        ΔNWC = NWC_t − NWC_{t-1}

        Positive = cash use (growing business ties up more working capital).
        Negative = cash source (efficiency improvement or revenue decline).
        """
        return nwc_current - nwc_prior

    # ── Component-level helper ─────────────────────────────────────────────

    @staticmethod
    def _component_nwc_pct(
        dso: float,
        dio: float,
        dpo: float,
        cogs_pct: float,
    ) -> float:
        """
        Derive NWC / Revenue from day-based metrics.

            AR / Revenue  = DSO / 365
            Inv / Revenue = DIO / 365 × COGS%   (COGS proxied from history)
            AP / Revenue  = DPO / 365 × COGS%

            NWC / Revenue = AR/Rev + Inv/Rev − AP/Rev
        """
        ar_pct  = dso / _DAYS_IN_YEAR
        inv_pct = (dio / _DAYS_IN_YEAR) * cogs_pct
        ap_pct  = (dpo / _DAYS_IN_YEAR) * cogs_pct
        return ar_pct + inv_pct - ap_pct

    @staticmethod
    def _pad(values: list[float], target_len: int) -> list[float]:
        if not values:
            return [0.05] * target_len
        while len(values) < target_len:
            values.append(values[-1])
        return values[:target_len]
