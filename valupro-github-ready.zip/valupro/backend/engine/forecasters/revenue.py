"""
engine/forecasters/revenue.py
------------------------------
Revenue forecaster.

Supports three configuration modes:
  1. Fully manual   — analyst provides all 10 growth rates explicitly
  2. Constant rate  — one rate applied to every year
  3. Phased growth  — near-term rate fades linearly to long-term rate
                      (both can be manually specified or trend-derived)

All modes clamp results to the growth_floor / growth_ceiling bounds
set in RevenueAssumptions to prevent unbounded projections.

Output contract:
  resolve(base_revenue, assumptions, history) → (rates, base_assumption)

  rates: list[float] — 10 annual growth rates (decimal), year 1 first
  base_assumption: ItemAssumption — provenance of the trend-derived value
"""

from __future__ import annotations

import statistics

from engine.assumptions import ForecastAssumptions, ItemAssumption, TrendAnalyser
from engine.assumptions.models import AssumptionMode, RevenueAssumptions, TrendMethod
from logger import get_logger

log = get_logger(__name__)


class RevenueForecaster:
    """
    Resolves 10 annual revenue growth rates from assumptions and history.

    Instantiated once per pipeline run; stateless between calls.
    """

    def __init__(self, analyser: TrendAnalyser) -> None:
        self._analyser = analyser

    def resolve_growth_rates(
        self,
        revenue_assumptions: RevenueAssumptions,
        historical_revenues: list[float | None],
        forecast_years: int = 10,
    ) -> tuple[list[float], ItemAssumption]:
        """
        Resolve the sequence of annual growth rates for the forecast.

        Priority order:
          1. growth_rates (explicit per-year list)
          2. near_term_growth + long_term_growth (phased)
          3. constant_growth_rate (flat)
          4. trend-derived CAGR (if all above are None)

        Args:
            revenue_assumptions: RevenueAssumptions config object.
            historical_revenues: Revenue values, newest-first.
            forecast_years: Number of years to project (default 10).

        Returns:
            (growth_rates_list, base_ItemAssumption)
        """
        rev = revenue_assumptions
        floor = rev.growth_floor
        ceiling = rev.growth_ceiling

        # ── Priority 1: Fully manual per-year list ─────────────────────────
        if rev.growth_rates is not None:
            clipped = [max(floor, min(r, ceiling)) for r in rev.growth_rates[:forecast_years]]
            # Pad with last value if fewer than forecast_years entries
            while len(clipped) < forecast_years:
                clipped.append(clipped[-1] if clipped else 0.05)
            assumption = ItemAssumption(
                value=statistics.mean(clipped),
                mode=AssumptionMode.MANUAL,
                note="Analyst-provided per-year growth rates",
            )
            log.debug("revenue.resolve.manual_list", ticker="?", n=len(clipped))
            return clipped, assumption

        # ── Priority 2: Phased (near-term + long-term specified) ───────────
        if rev.near_term_growth is not None or rev.long_term_growth is not None:
            near, long_g, source_note = self._resolve_phased_inputs(
                rev, historical_revenues
            )
            rates = self._interpolate_phased(near, long_g, forecast_years)
            rates = [max(floor, min(r, ceiling)) for r in rates]
            assumption = ItemAssumption(
                value=near,
                mode=AssumptionMode.HYBRID
                if (rev.near_term_growth is None or rev.long_term_growth is None)
                else AssumptionMode.MANUAL,
                note=source_note,
            )
            log.debug("revenue.resolve.phased", near=near, long=long_g)
            return rates, assumption

        # ── Priority 3: Single constant rate ───────────────────────────────
        if rev.constant_growth_rate is not None:
            rate = max(floor, min(rev.constant_growth_rate, ceiling))
            rates = [rate] * forecast_years
            assumption = ItemAssumption(
                value=rate,
                mode=AssumptionMode.MANUAL,
                note=f"Analyst-specified constant growth rate: {rate:.1%}",
            )
            log.debug("revenue.resolve.constant", rate=rate)
            return rates, assumption

        # ── Priority 4: Trend-derived ──────────────────────────────────────
        base_assumption = self._analyser.revenue_growth_rate(
            historical_revenues,
            method=rev.trend_method,
        )
        near_trend, long_trend = self._analyser.revenue_cagr_phased(historical_revenues)
        rates = self._interpolate_phased(near_trend, long_trend, forecast_years)
        rates = [max(floor, min(r, ceiling)) for r in rates]
        log.debug(
            "revenue.resolve.trend",
            near=near_trend,
            long=long_trend,
            method=rev.trend_method.value,
        )
        return rates, base_assumption

    def project_revenues(
        self,
        base_revenue: float,
        growth_rates: list[float],
    ) -> list[float]:
        """
        Apply growth rates to base revenue to produce projected revenues.

        Args:
            base_revenue: Revenue in the last historical year (year 0).
            growth_rates: List of annual growth rates (decimal), year 1 first.

        Returns:
            List of projected revenues, year 1 first.
        """
        revenues: list[float] = []
        prior = base_revenue
        for rate in growth_rates:
            projected = prior * (1.0 + rate)
            revenues.append(projected)
            prior = projected
        return revenues

    # ── Internal helpers ───────────────────────────────────────────────────

    def _resolve_phased_inputs(
        self,
        rev: RevenueAssumptions,
        historical_revenues: list[float | None],
    ) -> tuple[float, float, str]:
        """Resolve near/long-term rates, trend-filling any missing values."""
        trend_near, trend_long = self._analyser.revenue_cagr_phased(historical_revenues)

        near = rev.near_term_growth if rev.near_term_growth is not None else trend_near
        long_g = rev.long_term_growth if rev.long_term_growth is not None else trend_long

        missing = []
        if rev.near_term_growth is None:
            missing.append(f"near={trend_near:.1%} from trend")
        if rev.long_term_growth is None:
            missing.append(f"long={trend_long:.1%} from trend")
        note = "Phased growth" + (f" ({', '.join(missing)})" if missing else "")
        return near, long_g, note

    @staticmethod
    def _interpolate_phased(
        near: float,
        long_g: float,
        forecast_years: int,
        near_term_end: int = 3,
        long_term_start: int = 7,
    ) -> list[float]:
        """
        Build a year-by-year growth rate list that linearly interpolates
        from near_term_growth (years 1–3) to long_term_growth (years 7–10),
        with a linear transition zone in years 4–6.

        Example for forecast_years=10, near=0.12, long=0.04:
          Y1–Y3:  0.12
          Y4:     0.10  (interpolated)
          Y5:     0.08
          Y6:     0.06
          Y7–Y10: 0.04
        """
        rates: list[float] = []
        for i in range(1, forecast_years + 1):
            if i <= near_term_end:
                rates.append(near)
            elif i >= long_term_start:
                rates.append(long_g)
            else:
                # Linear interpolation in transition zone
                span = long_term_start - near_term_end
                progress = (i - near_term_end) / span
                rate = near + (long_g - near) * progress
                rates.append(rate)
        return rates
