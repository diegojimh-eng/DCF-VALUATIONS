"""
engine/forecasters — Individual line-item forecasters.

Each forecaster is a single-responsibility class that:
  1. Accepts assumption config + historical data
  2. Resolves the relevant parameter series (manual or trend)
  3. Returns a typed list of per-year values + an ItemAssumption (provenance)

The ForecastPipeline wires them together in the correct dependency order.
"""

from .capex import CapExForecaster
from .da import DAForecaster
from .fcff import FCFFCalculator, FCFFComponents
from .margins import MarginsForecaster
from .nwc import NWCForecaster
from .revenue import RevenueForecaster

__all__ = [
    "CapExForecaster",
    "DAForecaster",
    "FCFFCalculator",
    "FCFFComponents",
    "MarginsForecaster",
    "NWCForecaster",
    "RevenueForecaster",
]
