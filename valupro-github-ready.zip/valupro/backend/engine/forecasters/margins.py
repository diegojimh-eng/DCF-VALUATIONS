"""
engine/forecasters/margins.py
------------------------------
EBITDA margin, EBIT margin, and effective tax rate forecasters.

All three line items are modelled as fractions of revenue, which is the
standard approach in sell-side financial modelling:

    EBITDA  = Revenue × ebitda_margin
    D&A     = Revenue × da_pct_revenue          (computed in da.py)
    EBIT    = EBITDA − D&A
    Taxes   = max(EBIT, 0) × effective_tax_rate
    NOPAT   = EBIT − Taxes  = EBIT × (1 − tax_rate)

Assumption priority for each item:
  1. Per-year list           (most specific — full analyst control)
  2. Single constant value   (flat rate applied to every year)
  3. Trend-derived           (historical median / mean / regression)
"""

from __future__ import annotations

from engine.assumptions import TrendAnalyser
from engine.assumptions.models import (
    AssumptionMode,
    ItemAssumption,
    MarginAssumptions,
    TrendMethod,
)
from logger import get_logger

log = get_logger(__name__)


class MarginsForecaster:
    """
    Resolves EBITDA margin, EBIT margin, and tax rate series for the forecast.

    All outputs are lists of length == forecast_years where each element is
    the assumption value for that year.
    """

    def __init__(self, analyser: TrendAnalyser) -> None:
        self._analyser = analyser

    # ── EBITDA margin ──────────────────────────────────────────────────────

    def resolve_ebitda_margins(
        self,
        margin_assumptions: MarginAssumptions,
        historical_ebitda: list[float | None],
        historical_revenue: list[float | None],
        forecast_years: int = 10,
        scenario_adjustment: float = 0.0,
    ) -> tuple[list[float], ItemAssumption]:
        """
        Resolve the EBITDA margin for each forecast year.

        Args:
            margin_assumptions:  MarginAssumptions config.
            historical_ebitda:   EBITDA values, newest-first.
            historical_revenue:  Revenue values, newest-first.
            forecast_years:      Number of years to project.
            scenario_adjustment: Additive delta from scenario engine (e.g. +0.02 = Bull).

        Returns:
            (margins_list, ItemAssumption) — margins_list has `forecast_years` entries.
        """
        ma = margin_assumptions

        # ── Priority 1: Per-year list ──────────────────────────────────────
        if ma.ebitda_margin_by_year is not None:
            base = [m + scenario_adjustment for m in ma.ebitda_margin_by_year[:forecast_years]]
            base = self._clip_margins(base)
            assumption = ItemAssumption(
                value=sum(base) / len(base),
                mode=AssumptionMode.MANUAL,
                note="Analyst-provided per-year EBITDA margins",
            )
            return self._pad(base, forecast_years), assumption

        # ── Priority 2: Single constant ────────────────────────────────────
        if ma.ebitda_margin is not None:
            adjusted = max(-0.5, min(ma.ebitda_margin + scenario_adjustment, 0.9))
            margins = [adjusted] * forecast_years
            assumption = ItemAssumption(
                value=adjusted,
                mode=AssumptionMode.MANUAL,
                note=f"Analyst-specified EBITDA margin: {adjusted:.1%}",
            )
            return margins, assumption

        # ── Priority 3: Trend-derived ──────────────────────────────────────
        item = self._analyser.ebitda_margin(
            historical_ebitda,
            historical_revenue,
            method=ma.ebitda_margin_trend_method,
        )
        adjusted_value = max(-0.5, min(item.value + scenario_adjustment, 0.9))
        margins = [adjusted_value] * forecast_years

        adjusted_item = ItemAssumption(
            value=adjusted_value,
            mode=item.mode,
            trend_method=item.trend_method,
            confidence=item.confidence,
            note=(item.note or "") + (
                f" | scenario adj: {scenario_adjustment:+.1%}" if scenario_adjustment != 0 else ""
            ),
        )
        log.debug("margins.ebitda.trend", margin=adjusted_value)
        return margins, adjusted_item

    # ── Tax rate ───────────────────────────────────────────────────────────

    def resolve_tax_rates(
        self,
        margin_assumptions: MarginAssumptions,
        historical_tax_expense: list[float | None],
        historical_pretax_income: list[float | None],
        forecast_years: int = 10,
        scenario_adjustment: float = 0.0,
    ) -> tuple[list[float], ItemAssumption]:
        """
        Resolve the effective tax rate for each forecast year.

        Args:
            scenario_adjustment: Additive delta (positive = higher taxes = bear).

        Returns:
            (tax_rates_list, ItemAssumption)
        """
        ma = margin_assumptions

        if ma.effective_tax_rate is not None:
            adjusted = max(0.0, min(ma.effective_tax_rate + scenario_adjustment, 0.60))
            rates = [adjusted] * forecast_years
            assumption = ItemAssumption(
                value=adjusted,
                mode=AssumptionMode.MANUAL,
                note=f"Analyst-specified tax rate: {adjusted:.1%}",
            )
            return rates, assumption

        item = self._analyser.effective_tax_rate(
            historical_tax_expense,
            historical_pretax_income,
            method=ma.tax_rate_trend_method,
        )
        adjusted_value = max(0.0, min(item.value + scenario_adjustment, 0.60))
        rates = [adjusted_value] * forecast_years

        adjusted_item = ItemAssumption(
            value=adjusted_value,
            mode=item.mode,
            trend_method=item.trend_method,
            confidence=item.confidence,
            note=(item.note or "") + (
                f" | scenario adj: {scenario_adjustment:+.1%}" if scenario_adjustment != 0 else ""
            ),
        )
        log.debug("margins.tax.trend", rate=adjusted_value)
        return rates, adjusted_item

    # ── EBITDA → EBIT derivation (per year, after D&A is known) ───────────

    @staticmethod
    def compute_ebit(ebitda: float, da: float) -> float:
        """EBIT = EBITDA − D&A. D&A must be positive."""
        return ebitda - abs(da)

    @staticmethod
    def compute_taxes(ebit: float, tax_rate: float) -> float:
        """
        Taxes are only paid on positive EBIT.
        Tax shield on losses is not modelled here (conservative).
        """
        return max(ebit, 0.0) * tax_rate

    @staticmethod
    def compute_nopat(ebit: float, tax_rate: float) -> float:
        """NOPAT = EBIT × (1 − tax_rate), floored at EBIT when EBIT < 0."""
        if ebit <= 0:
            return ebit   # no tax benefit modelled on losses
        return ebit * (1.0 - tax_rate)

    # ── Helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _clip_margins(margins: list[float]) -> list[float]:
        return [max(-0.5, min(m, 0.9)) for m in margins]

    @staticmethod
    def _pad(values: list[float], target_len: int) -> list[float]:
        """Extend list by repeating last value until target_len is reached."""
        if not values:
            return [0.0] * target_len
        while len(values) < target_len:
            values.append(values[-1])
        return values[:target_len]
