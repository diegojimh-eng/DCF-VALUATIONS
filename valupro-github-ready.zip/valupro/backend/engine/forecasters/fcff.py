"""
engine/forecasters/fcff.py
---------------------------
Free Cash Flow to Firm (FCFF) calculator.

FCFF is the cash flow available to ALL capital providers (debt and equity)
before interest payments. It is the input to the DCF valuation engine.

Formula (unlevered free cash flow):
    FCFF = NOPAT + D&A − CapEx − ΔNWC

Where:
    NOPAT = EBIT × (1 − tax_rate)   [Net Operating Profit After Tax]
    D&A   = positive add-back of the non-cash depreciation charge
    CapEx = positive cash outflow for capital expenditure
    ΔNWC  = NWC_t − NWC_{t−1} (positive = cash use)

This module is intentionally pure arithmetic — it takes already-resolved
year values and computes FCFF. All assumption resolution happens upstream
in the individual forecasters (revenue.py, margins.py, da.py, capex.py,
nwc.py) and is orchestrated by the pipeline.

No assumptions are resolved here; only computations are performed.
"""

from __future__ import annotations

from dataclasses import dataclass
from logger import get_logger

log = get_logger(__name__)


@dataclass(frozen=True)
class FCFFComponents:
    """
    All inputs needed to compute FCFF for a single year.
    Passed into FCFFCalculator.compute() to produce a single FCFF value.
    """
    revenue: float
    ebitda: float
    ebitda_margin: float
    da: float            # positive
    ebit: float
    tax_rate: float
    taxes: float
    nopat: float
    capex: float         # positive (cash outflow)
    nwc: float           # absolute NWC level
    delta_nwc: float     # change in NWC (positive = cash use)


class FCFFCalculator:
    """
    Computes FCFF from pre-resolved per-year financial components.

    Stateless — safe to call concurrently.
    """

    def compute(self, components: FCFFComponents) -> float:
        """
        FCFF = NOPAT + D&A − CapEx − ΔNWC

        All inputs must use the same currency/unit as the underlying
        historical data (typically full dollars, not millions).

        Args:
            components: FCFFComponents dataclass with all year values.

        Returns:
            FCFF as a float. Can be negative (e.g. heavy-investment years).
        """
        fcff = (
            components.nopat
            + components.da          # non-cash add-back
            - components.capex       # cash outflow (positive stored as positive)
            - components.delta_nwc   # positive ΔNWC = cash use
        )
        log.debug(
            "fcff.compute",
            revenue=components.revenue,
            nopat=components.nopat,
            da=components.da,
            capex=components.capex,
            delta_nwc=components.delta_nwc,
            fcff=fcff,
        )
        return fcff

    @staticmethod
    def fcff_yield(fcff: float, revenue: float) -> float | None:
        """FCFF / Revenue conversion rate. Returns None if revenue is zero."""
        if revenue > 0:
            return fcff / revenue
        return None

    @staticmethod
    def reinvestment_rate(capex: float, da: float, delta_nwc: float, nopat: float) -> float | None:
        """
        Reinvestment Rate = (CapEx − D&A + ΔNWC) / NOPAT
        Measures what fraction of NOPAT is reinvested back into the business.
        Returns None when NOPAT ≤ 0.
        """
        if nopat <= 0:
            return None
        net_reinvestment = capex - da + delta_nwc
        return net_reinvestment / nopat

    @staticmethod
    def implied_roic(nopat: float, invested_capital: float) -> float | None:
        """
        Return on Invested Capital = NOPAT / Invested Capital.
        IC = Net PP&E + NWC (simplified; full version requires debt schedule).
        """
        if invested_capital > 0:
            return nopat / invested_capital
        return None
