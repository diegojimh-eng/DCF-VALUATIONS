"""
engine/forecasters/capex.py
----------------------------
Capital Expenditure (CapEx) forecaster.

CapEx is modelled as a percentage of revenue. This is the most common
approach when the full fixed-asset schedule and depreciation waterfall
are not available (as is standard in sell-side modelling).

    CapEx_t = Revenue_t × capex_pct_revenue_t

Optional maintenance / growth decomposition:
    CapEx_t = Revenue_t × (maintenance_capex_pct + growth_capex_pct)

Sign convention:
  • capex_pct_revenue is stored as a POSITIVE fraction.
  • capital_expenditures in ForecastYear is POSITIVE (cash outflow).
  • In the FCFF formula: FCFF = NOPAT + D&A − CapEx − ΔNWC
    so it is subtracted as a positive number.
  • This matches most sell-side models. The CFS provider data (negative)
    is abs()-normalised in DAAssumptions.capex_values before it reaches here.

Assumption priority:
  1. Per-year percentage list
  2. Maintenance + growth decomposition (both must be provided)
  3. Single constant percentage
  4. Trend-derived median from history
"""

from __future__ import annotations

from engine.assumptions import TrendAnalyser
from engine.assumptions.models import (
    AssumptionMode,
    CapExAssumptions,
    ItemAssumption,
)
from logger import get_logger

log = get_logger(__name__)


class CapExForecaster:
    """
    Resolves CapEx as a percentage of revenue for each forecast year.
    """

    def __init__(self, analyser: TrendAnalyser) -> None:
        self._analyser = analyser

    def resolve_capex_pct(
        self,
        capex_assumptions: CapExAssumptions,
        historical_capex: list[float | None],
        historical_revenue: list[float | None],
        forecast_years: int = 10,
    ) -> tuple[list[float], ItemAssumption]:
        """
        Resolve CapEx / Revenue for each forecast year.

        Args:
            capex_assumptions:  CapExAssumptions config.
            historical_capex:   CapEx values newest-first (may be negative from CFS).
            historical_revenue: Revenue values newest-first.
            forecast_years:     Number of projection years.

        Returns:
            (pct_list, ItemAssumption)
            pct_list: positive fractions.
        """
        ca = capex_assumptions

        # ── Priority 1: Per-year list ──────────────────────────────────────
        if ca.capex_as_pct_revenue_by_year is not None:
            base = [abs(p) for p in ca.capex_as_pct_revenue_by_year[:forecast_years]]
            base = [min(p, 0.50) for p in base]
            assumption = ItemAssumption(
                value=sum(base) / len(base) if base else 0.05,
                mode=AssumptionMode.MANUAL,
                note="Analyst-provided per-year CapEx % of revenue",
            )
            return self._pad(base, forecast_years), assumption

        # ── Priority 2: Maintenance + growth decomposition ────────────────
        if ca.maintenance_capex_pct is not None and ca.growth_capex_pct is not None:
            total_pct = min(abs(ca.maintenance_capex_pct) + abs(ca.growth_capex_pct), 0.50)
            pcts = [total_pct] * forecast_years
            assumption = ItemAssumption(
                value=total_pct,
                mode=AssumptionMode.MANUAL,
                note=(
                    f"Maintenance {ca.maintenance_capex_pct:.2%} + "
                    f"Growth {ca.growth_capex_pct:.2%} = {total_pct:.2%}"
                ),
            )
            return pcts, assumption

        # ── Priority 3: Single constant ────────────────────────────────────
        if ca.capex_as_pct_revenue is not None:
            pct = min(abs(ca.capex_as_pct_revenue), 0.50)
            pcts = [pct] * forecast_years
            assumption = ItemAssumption(
                value=pct,
                mode=AssumptionMode.MANUAL,
                note=f"Analyst-specified CapEx/Revenue: {pct:.2%}",
            )
            return pcts, assumption

        # ── Priority 4: Trend-derived ──────────────────────────────────────
        item = self._analyser.capex_as_pct_revenue(
            historical_capex,
            historical_revenue,
            method=ca.trend_method,
        )
        pcts = [item.value] * forecast_years
        log.debug("capex.resolve.trend", pct=item.value)
        return pcts, item

    def compute_capex_absolute(
        self,
        revenue: float,
        capex_pct: float,
    ) -> float:
        """
        Compute absolute CapEx from revenue and percentage.

        Returns:
            Positive CapEx absolute value (cash outflow before sign).
        """
        return max(0.0, revenue * capex_pct)

    @staticmethod
    def _pad(values: list[float], target_len: int) -> list[float]:
        if not values:
            return [0.05] * target_len
        while len(values) < target_len:
            values.append(values[-1])
        return values[:target_len]
