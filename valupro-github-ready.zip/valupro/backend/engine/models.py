"""
engine/models.py
-----------------
Output data models for the forecasting engine.

Every forecast year produces a ForecastYear — a single row in the projection
table. The ForecastOutput collects all years, all assumptions used, and
diagnostic metadata.

Design principles:
  • Immutable (frozen=True) after creation — no partial mutation bugs.
  • All monetary values in the same currency/unit as the historical data.
  • Every derived field carries the formula used in its docstring.
  • None means "could not be computed" (not "zero").
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

from pydantic import BaseModel, Field

from engine.assumptions.models import (
    AssumptionMode,
    ForecastAssumptions,
    ItemAssumption,
    ScenarioType,
)


# ── Single forecast year ───────────────────────────────────────────────────────

class ForecastYear(BaseModel):
    """
    One row of the 10-year projection table.

    All line items use the same currency unit as the historical statements
    (typically full dollars/pounds/euros, not millions, for consistency with
    the data layer's raw provider output).
    """

    # Period
    year_index: int = Field(..., ge=1, le=20, description="1 = first forecast year")
    fiscal_year: int = Field(..., description="Calendar year of this forecast period")
    period_end_date: date

    # ── Revenue ───────────────────────────────────────────────────────────
    revenue: float = Field(..., description="Projected total revenue")
    revenue_growth_rate: float = Field(..., description="YoY growth rate (decimal)")

    # ── EBITDA ────────────────────────────────────────────────────────────
    ebitda: float = Field(..., description="EBITDA = Revenue × ebitda_margin")
    ebitda_margin: float = Field(..., description="EBITDA / Revenue")

    # ── D&A ───────────────────────────────────────────────────────────────
    depreciation_amortisation: float = Field(
        ..., description="D&A = Revenue × da_pct_revenue"
    )
    da_as_pct_revenue: float

    # ── EBIT ──────────────────────────────────────────────────────────────
    ebit: float = Field(..., description="EBIT = EBITDA − D&A")
    ebit_margin: float = Field(..., description="EBIT / Revenue")

    # ── Taxes ─────────────────────────────────────────────────────────────
    effective_tax_rate: float
    taxes: float = Field(..., description="Taxes = EBIT × effective_tax_rate (when EBIT > 0)")
    nopat: float = Field(..., description="NOPAT = EBIT × (1 − tax_rate)")

    # ── CapEx ─────────────────────────────────────────────────────────────
    capital_expenditures: float = Field(
        ..., description="CapEx = Revenue × capex_pct_revenue (positive = cash outflow)"
    )
    capex_as_pct_revenue: float

    # ── Net Working Capital ────────────────────────────────────────────────
    net_working_capital: float = Field(..., description="NWC = Revenue × nwc_pct_revenue")
    nwc_as_pct_revenue: float
    change_in_nwc: float = Field(
        ...,
        description="ΔNWC = NWC_t − NWC_{t-1}. Positive = cash use; negative = cash source.",
    )

    # ── FCFF ──────────────────────────────────────────────────────────────
    fcff: float = Field(
        ...,
        description="FCFF = NOPAT + D&A − CapEx − ΔNWC",
    )

    # ── Diagnostic / audit ────────────────────────────────────────────────
    assumptions_used: dict[str, Any] = Field(
        default_factory=dict,
        description="Snapshot of the per-year assumption values actually used.",
    )

    model_config = {"frozen": True}

    @property
    def fcff_yield(self) -> float | None:
        """FCFF / Revenue — free cash flow conversion rate."""
        if self.revenue and self.revenue > 0:
            return self.fcff / self.revenue
        return None


# ── Resolved assumptions (what was actually used after trend derivation) ───────

class ResolvedAssumptions(BaseModel):
    """
    The final assumption values used for each forecast year,
    after trend derivation and scenario adjustments are applied.

    Stored alongside ForecastOutput for full reproducibility.
    """
    revenue_growth_rates: list[float]     # 10 values
    ebitda_margins: list[float]           # 10 values
    ebit_margins: list[float]             # 10 values (derived from EBITDA - DA)
    effective_tax_rates: list[float]      # 10 values (constant or varying)
    da_pct_revenues: list[float]          # 10 values
    capex_pct_revenues: list[float]       # 10 values
    nwc_pct_revenues: list[float]         # 10 values

    # Provenance — how each series was derived
    revenue_growth_item: ItemAssumption
    ebitda_margin_item: ItemAssumption
    tax_rate_item: ItemAssumption
    da_item: ItemAssumption
    capex_item: ItemAssumption
    nwc_item: ItemAssumption

    model_config = {"frozen": True}


# ── Historical context (fed from Phase 2 data layer) ──────────────────────────

class HistoricalSummary(BaseModel):
    """
    Summary of the historical financial data used as the basis for the forecast.
    Attached to ForecastOutput for traceability.
    """
    ticker: str
    years_of_history: int
    base_year: int             # last historical year (year 0 of the forecast)
    base_revenue: float        # revenue in base year

    # Historical averages (for comparison with forecast)
    hist_revenue_cagr: float | None = None
    hist_ebitda_margin_avg: float | None = None
    hist_ebit_margin_avg: float | None = None
    hist_tax_rate_avg: float | None = None
    hist_da_pct_avg: float | None = None
    hist_capex_pct_avg: float | None = None
    hist_nwc_pct_avg: float | None = None
    hist_fcff_avg: float | None = None

    model_config = {"frozen": True}


# ── Complete forecast output ───────────────────────────────────────────────────

class ForecastOutput(BaseModel):
    """
    The complete 10-year forecast output for a company.

    This is the primary output of the ForecastPipeline and the primary input
    to the Phase 4 valuation engine (DCF, etc.).

    Usage:
        output = await pipeline.run(ticker="AAPL", assumptions=assumptions)
        for year in output.years:
            print(year.fiscal_year, year.revenue, year.fcff)
    """
    ticker: str
    scenario: ScenarioType
    generated_at: datetime = Field(default_factory=datetime.utcnow)

    # The forecast (10 ForecastYear objects, year_index 1..10)
    years: list[ForecastYear] = Field(..., min_length=1, max_length=20)

    # The assumptions that produced this forecast
    assumptions: ForecastAssumptions
    resolved: ResolvedAssumptions

    # Historical context
    history: HistoricalSummary

    # Warnings / flags from the engine
    warnings: list[str] = Field(default_factory=list)

    model_config = {"frozen": True}

    # ── Convenience accessors ──────────────────────────────────────────────

    @property
    def forecast_revenues(self) -> list[float]:
        return [y.revenue for y in self.years]

    @property
    def forecast_ebitdas(self) -> list[float]:
        return [y.ebitda for y in self.years]

    @property
    def forecast_ebits(self) -> list[float]:
        return [y.ebit for y in self.years]

    @property
    def forecast_fcffs(self) -> list[float]:
        return [y.fcff for y in self.years]

    @property
    def forecast_fiscal_years(self) -> list[int]:
        return [y.fiscal_year for y in self.years]

    def year(self, index: int) -> ForecastYear:
        """Get a specific forecast year by 1-based index."""
        if index < 1 or index > len(self.years):
            raise IndexError(f"Year index {index} out of range [1, {len(self.years)}]")
        return self.years[index - 1]

    def to_table(self) -> list[dict]:
        """Render as a list of row dicts suitable for a DataFrame or JSON response."""
        rows = []
        for y in self.years:
            rows.append({
                "year_index": y.year_index,
                "fiscal_year": y.fiscal_year,
                "revenue": y.revenue,
                "revenue_growth_rate": y.revenue_growth_rate,
                "ebitda": y.ebitda,
                "ebitda_margin": y.ebitda_margin,
                "depreciation_amortisation": y.depreciation_amortisation,
                "ebit": y.ebit,
                "ebit_margin": y.ebit_margin,
                "taxes": y.taxes,
                "nopat": y.nopat,
                "capital_expenditures": y.capital_expenditures,
                "net_working_capital": y.net_working_capital,
                "change_in_nwc": y.change_in_nwc,
                "fcff": y.fcff,
                "fcff_yield": y.fcff_yield,
            })
        return rows
