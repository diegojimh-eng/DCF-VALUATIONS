"""
engine/pipeline/resolver.py
----------------------------
Assumption Resolver — converts ForecastAssumptions + HistoricalSeries
into the concrete per-year values the forecast loop needs.

The resolver is the single place where:
  • Manual assumptions are validated and passed through unchanged.
  • Trend assumptions are derived by calling TrendAnalyser methods.
  • Scenario adjustments are applied (revenue_growth_adjustment, etc.).
  • The ResolvedAssumptions object is built for audit/reproducibility.

This keeps the ForecastPipeline's main loop clean: it only sees lists of
floats, not conditional logic.
"""

from __future__ import annotations

from engine.assumptions import TrendAnalyser
from engine.assumptions.models import ForecastAssumptions
from engine.forecasters import (
    CapExForecaster,
    DAForecaster,
    MarginsForecaster,
    NWCForecaster,
    RevenueForecaster,
)
from engine.models import ResolvedAssumptions
from engine.pipeline.historical_extractor import HistoricalSeries
from logger import get_logger

log = get_logger(__name__)


class AssumptionResolver:
    """
    Resolves all forecast assumptions into concrete per-year value lists.

    Each forecaster is called once; results are packed into ResolvedAssumptions.
    """

    def __init__(self, analyser: TrendAnalyser | None = None) -> None:
        self._analyser = analyser or TrendAnalyser()
        self._revenue   = RevenueForecaster(self._analyser)
        self._margins   = MarginsForecaster(self._analyser)
        self._da        = DAForecaster(self._analyser)
        self._capex     = CapExForecaster(self._analyser)
        self._nwc       = NWCForecaster(self._analyser)

    def resolve(
        self,
        assumptions: ForecastAssumptions,
        series: HistoricalSeries,
    ) -> ResolvedAssumptions:
        """
        Resolve all assumption series.

        Args:
            assumptions: Master assumption object from the analyst/API.
            series:      Historical financial data extracted from FinancialsBundle.

        Returns:
            ResolvedAssumptions with one value per forecast year for each line item.
        """
        n = assumptions.forecast_years
        log.info(
            "resolver.start",
            ticker=assumptions.ticker,
            scenario=assumptions.scenario.value,
            years=n,
        )

        # ── Revenue growth rates ────────────────────────────────────────────
        rev_rates, rev_item = self._revenue.resolve_growth_rates(
            revenue_assumptions=assumptions.revenue,
            historical_revenues=series.revenue,
            forecast_years=n,
        )
        # Apply scenario revenue adjustment
        if assumptions.revenue_growth_adjustment != 0.0:
            rev_rates = [
                max(-0.50, min(r + assumptions.revenue_growth_adjustment, 2.0))
                for r in rev_rates
            ]
            log.debug(
                "resolver.revenue_adj",
                adj=assumptions.revenue_growth_adjustment,
                first_rate=rev_rates[0],
            )

        # ── EBITDA margins ─────────────────────────────────────────────────
        ebitda_margins, ebitda_item = self._margins.resolve_ebitda_margins(
            margin_assumptions=assumptions.margins,
            historical_ebitda=series.ebitda,
            historical_revenue=series.revenue,
            forecast_years=n,
            scenario_adjustment=assumptions.ebitda_margin_adjustment,
        )

        # ── Tax rates ──────────────────────────────────────────────────────
        tax_rates, tax_item = self._margins.resolve_tax_rates(
            margin_assumptions=assumptions.margins,
            historical_tax_expense=series.tax_expense,
            historical_pretax_income=series.pretax_income,
            forecast_years=n,
            scenario_adjustment=assumptions.tax_rate_adjustment,
        )

        # ── D&A as % of revenue ────────────────────────────────────────────
        da_pcts, da_item = self._da.resolve_da_pct(
            da_assumptions=assumptions.da,
            historical_da=series.da_cfs,      # CFS D&A preferred
            historical_revenue=series.revenue,
            forecast_years=n,
        )

        # ── CapEx as % of revenue ──────────────────────────────────────────
        capex_pcts, capex_item = self._capex.resolve_capex_pct(
            capex_assumptions=assumptions.capex,
            historical_capex=series.capex,
            historical_revenue=series.revenue,
            forecast_years=n,
        )

        # ── NWC as % of revenue ────────────────────────────────────────────
        nwc_pcts, nwc_item = self._nwc.resolve_nwc_pct(
            nwc_assumptions=assumptions.nwc,
            historical_nwc=series.nwc,
            historical_revenue=series.revenue,
            forecast_years=n,
            historical_cogs_pct=series.cogs_pct_revenue,
        )

        # ── Derive EBIT margins (EBITDA margin − DA%) ──────────────────────
        ebit_margins = [
            ebitda_m - da_p
            for ebitda_m, da_p in zip(ebitda_margins, da_pcts)
        ]

        log.info(
            "resolver.complete",
            ticker=assumptions.ticker,
            rev_growth_y1=rev_rates[0] if rev_rates else None,
            ebitda_margin_y1=ebitda_margins[0] if ebitda_margins else None,
            tax_rate=tax_rates[0] if tax_rates else None,
            da_pct=da_pcts[0] if da_pcts else None,
            capex_pct=capex_pcts[0] if capex_pcts else None,
            nwc_pct=nwc_pcts[0] if nwc_pcts else None,
        )

        return ResolvedAssumptions(
            revenue_growth_rates=rev_rates,
            ebitda_margins=ebitda_margins,
            ebit_margins=ebit_margins,
            effective_tax_rates=tax_rates,
            da_pct_revenues=da_pcts,
            capex_pct_revenues=capex_pcts,
            nwc_pct_revenues=nwc_pcts,
            revenue_growth_item=rev_item,
            ebitda_margin_item=ebitda_item,
            tax_rate_item=tax_item,
            da_item=da_item,
            capex_item=capex_item,
            nwc_item=nwc_item,
        )
