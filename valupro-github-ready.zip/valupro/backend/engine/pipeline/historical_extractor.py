"""
engine/pipeline/historical_extractor.py
-----------------------------------------
Extracts and normalises the historical series the forecasting engine needs
from a Phase 2 FinancialsBundle.

The data layer returns lists of Pydantic model objects (newest-first).
This module converts them into flat float lists (newest-first) that the
TrendAnalyser and individual forecasters accept.

It also computes:
  • Net Working Capital from balance sheet components (not directly stored)
  • COGS % for inventory-day modelling
  • A HistoricalSummary for attaching to ForecastOutput

Design:
  • Never raises — returns None in place of missing fields.
  • Preserves newest-first ordering throughout.
  • All lists are the same length (padded with None for missing periods).
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field

from data.models.financial import BalanceSheet, CashFlowStatement, IncomeStatement
from data.models.responses import FinancialsBundle
from engine.models import HistoricalSummary
from logger import get_logger

log = get_logger(__name__)


@dataclass
class HistoricalSeries:
    """
    Flat lists of historical values, newest-first.
    All lists are co-indexed (same position = same fiscal year).
    """
    fiscal_years:    list[int]

    # Income statement
    revenue:         list[float | None]
    ebitda:          list[float | None]
    ebit:            list[float | None]         # operating_income
    tax_expense:     list[float | None]
    pretax_income:   list[float | None]
    net_income:      list[float | None]
    da_is:           list[float | None]         # D&A from income statement
    cost_of_revenue: list[float | None]

    # Cash flow statement
    da_cfs:          list[float | None]         # D&A from CFS (more reliable)
    capex:           list[float | None]         # usually negative from CFS

    # Balance sheet — NWC components
    total_current_assets:      list[float | None]
    total_current_liabilities: list[float | None]
    nwc:                       list[float | None]   # derived: CA - CL

    # Derived / computed
    cogs_pct_revenue: float | None = None   # median historical COGS / Revenue


class HistoricalExtractor:
    """
    Builds HistoricalSeries from a FinancialsBundle.
    """

    def extract(self, bundle: FinancialsBundle) -> HistoricalSeries:
        """
        Extract all historical series needed by the forecasting engine.

        Args:
            bundle: FinancialsBundle from DataRouter (income, BS, CFS newest-first).

        Returns:
            HistoricalSeries with aligned, newest-first lists.
        """
        income = bundle.income_statements   # newest-first
        bs     = bundle.balance_sheets
        cfs    = bundle.cash_flow_statements

        n = len(income)
        if n == 0:
            log.warning("historical_extractor.no_income_statements",
                        ticker=bundle.profile.ticker)

        # Align balance sheets and CFS to income statement fiscal years
        bs_by_year  = {s.fiscal_year: s  for s in bs}
        cfs_by_year = {s.fiscal_year: s  for s in cfs}

        fiscal_years = [s.fiscal_year for s in income]

        # ── Income statement series ────────────────────────────────────────
        revenue       = [s.revenue          for s in income]
        ebitda        = [s.ebitda           for s in income]
        ebit          = [s.operating_income for s in income]
        tax_expense   = [s.income_tax_expense for s in income]
        pretax_income = [s.pretax_income    for s in income]
        net_income    = [s.net_income       for s in income]
        da_is         = [s.depreciation_amortisation for s in income]
        cost_of_rev   = [s.cost_of_revenue  for s in income]

        # ── CFS series (aligned to income years) ──────────────────────────
        da_cfs  = [cfs_by_year.get(fy, None) and cfs_by_year[fy].depreciation_amortisation
                   if fy in cfs_by_year else None
                   for fy in fiscal_years]
        capex   = [cfs_by_year[fy].capital_expenditures
                   if fy in cfs_by_year and cfs_by_year[fy].capital_expenditures is not None
                   else None
                   for fy in fiscal_years]

        # ── Balance sheet NWC (aligned to income years) ───────────────────
        total_ca  = [bs_by_year[fy].total_current_assets
                     if fy in bs_by_year else None
                     for fy in fiscal_years]
        total_cl  = [bs_by_year[fy].total_current_liabilities
                     if fy in bs_by_year else None
                     for fy in fiscal_years]
        nwc = [
            (ca - cl) if (ca is not None and cl is not None) else None
            for ca, cl in zip(total_ca, total_cl)
        ]

        # ── Derive D&A: prefer CFS (more reliable), fall back to IS ───────
        da_best = [
            cfs_val if cfs_val is not None else is_val
            for cfs_val, is_val in zip(da_cfs, da_is)
        ]

        # ── Historical COGS % for DIO calculation ──────────────────────────
        cogs_pcts = [
            c / r for c, r in zip(cost_of_rev, revenue)
            if c is not None and r is not None and r > 0
        ]
        cogs_pct_revenue = statistics.median(cogs_pcts) if cogs_pcts else None

        log.debug(
            "historical_extractor.complete",
            ticker=bundle.profile.ticker,
            years=len(fiscal_years),
            base_year=fiscal_years[0] if fiscal_years else None,
        )

        return HistoricalSeries(
            fiscal_years=fiscal_years,
            revenue=revenue,
            ebitda=ebitda,
            ebit=ebit,
            tax_expense=tax_expense,
            pretax_income=pretax_income,
            net_income=net_income,
            da_is=da_is,
            cost_of_revenue=cost_of_rev,
            da_cfs=da_cfs,
            capex=capex,
            total_current_assets=total_ca,
            total_current_liabilities=total_cl,
            nwc=nwc,
            cogs_pct_revenue=cogs_pct_revenue,
        )

    def build_historical_summary(
        self,
        series: HistoricalSeries,
        ticker: str,
    ) -> HistoricalSummary:
        """
        Compute summary statistics for the HistoricalSummary attached to
        ForecastOutput.
        """
        revenues = [v for v in series.revenue if v is not None]
        ebitdas  = [v for v in series.ebitda  if v is not None]
        ebits    = [v for v in series.ebit    if v is not None]

        base_revenue = revenues[0] if revenues else 0.0
        base_year    = series.fiscal_years[0] if series.fiscal_years else 0

        # Revenue CAGR (oldest to newest)
        hist_cagr: float | None = None
        if len(revenues) >= 2:
            start, end = revenues[-1], revenues[0]
            n = len(revenues) - 1
            if start > 0 and n > 0:
                hist_cagr = (end / start) ** (1.0 / n) - 1.0

        def safe_margin(numerators: list[float | None], denominators: list[float | None]) -> float | None:
            ratios = [
                n_ / d for n_, d in zip(numerators, denominators)
                if n_ is not None and d is not None and d > 0
            ]
            return statistics.mean(ratios) if ratios else None

        hist_ebitda_margin = safe_margin(series.ebitda, series.revenue)
        hist_ebit_margin   = safe_margin(series.ebit,   series.revenue)

        # Tax rate
        tax_rates = [
            t / p for t, p in zip(series.tax_expense, series.pretax_income)
            if t is not None and p is not None and p > 0 and 0 <= t / p <= 0.6
        ]
        hist_tax_rate = statistics.median(tax_rates) if tax_rates else None

        hist_da_pct = safe_margin(
            [abs(v) if v is not None else None for v in series.da_cfs],
            series.revenue,
        )
        hist_capex_pct = safe_margin(
            [abs(v) if v is not None else None for v in series.capex],
            series.revenue,
        )
        hist_nwc_pct = safe_margin(series.nwc, series.revenue)

        # Historical FCFF average
        from data.models.financial import CashFlowStatement  # avoid circular at module level
        fcff_vals = [
            abs(cap or 0) * -1  # placeholder: real FCFF needs full series
            for cap in series.capex if cap is not None
        ]

        return HistoricalSummary(
            ticker=ticker,
            years_of_history=len(series.fiscal_years),
            base_year=base_year,
            base_revenue=base_revenue,
            hist_revenue_cagr=hist_cagr,
            hist_ebitda_margin_avg=hist_ebitda_margin,
            hist_ebit_margin_avg=hist_ebit_margin,
            hist_tax_rate_avg=hist_tax_rate,
            hist_da_pct_avg=hist_da_pct,
            hist_capex_pct_avg=hist_capex_pct,
            hist_nwc_pct_avg=hist_nwc_pct,
        )
