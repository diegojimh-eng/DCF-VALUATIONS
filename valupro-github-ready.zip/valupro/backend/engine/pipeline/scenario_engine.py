"""
engine/pipeline/scenario_engine.py
------------------------------------
Scenario Engine — runs Bear, Base, and Bull forecasts in one call.

Each scenario is defined by additive deltas applied to base assumptions:

  Bear: revenue growth − 3%, EBITDA margin − 2%, tax rate + 1%
  Base: no adjustments (baseline assumptions as provided)
  Bull: revenue growth + 3%, EBITDA margin + 2%, tax rate − 1%

The analyst can override these deltas by passing a custom ScenarioDeltas
configuration.

Usage:
    engine   = ScenarioEngine(pipeline)
    results  = engine.run_all(bundle, base_assumptions)

    bear_output = results.bear
    base_output = results.base
    bull_output = results.bull
"""

from __future__ import annotations

from dataclasses import dataclass

from data.models.responses import FinancialsBundle
from engine.assumptions.models import ForecastAssumptions, ScenarioType
from engine.models import ForecastOutput
from engine.pipeline.forecast_pipeline import ForecastPipeline
from logger import get_logger

log = get_logger(__name__)


@dataclass(frozen=True)
class ScenarioDeltas:
    """
    Additive adjustments applied to base assumptions to produce Bear/Bull.

    All values are deltas in the same units as the underlying assumption:
      revenue_growth_delta:  decimal (0.03 = +3% to each year's growth rate)
      ebitda_margin_delta:   decimal (0.02 = +2% to margin)
      tax_rate_delta:        decimal (0.01 = +1% to tax rate)
    """
    # Bear deltas (applied negatively for revenue/margin, positively for tax)
    bear_revenue_growth_delta: float = -0.03
    bear_ebitda_margin_delta:  float = -0.02
    bear_tax_rate_delta:       float = +0.01

    # Bull deltas (applied positively for revenue/margin, negatively for tax)
    bull_revenue_growth_delta: float = +0.03
    bull_ebitda_margin_delta:  float = +0.02
    bull_tax_rate_delta:       float = -0.01


@dataclass(frozen=True)
class ScenarioResults:
    """Three scenario outputs for a single company."""
    bear: ForecastOutput
    base: ForecastOutput
    bull: ForecastOutput

    def by_scenario(self, scenario: ScenarioType) -> ForecastOutput:
        mapping = {
            ScenarioType.BEAR: self.bear,
            ScenarioType.BASE: self.base,
            ScenarioType.BULL: self.bull,
        }
        if scenario not in mapping:
            raise ValueError(f"Unknown scenario: {scenario}")
        return mapping[scenario]

    def fcff_summary(self) -> dict:
        """Return a dict of scenario → FCFF list for quick comparison."""
        return {
            "bear": self.bear.forecast_fcffs,
            "base": self.base.forecast_fcffs,
            "bull": self.bull.forecast_fcffs,
            "fiscal_years": self.base.forecast_fiscal_years,
        }

    def revenue_summary(self) -> dict:
        return {
            "bear": self.bear.forecast_revenues,
            "base": self.base.forecast_revenues,
            "bull": self.bull.forecast_revenues,
            "fiscal_years": self.base.forecast_fiscal_years,
        }


class ScenarioEngine:
    """
    Runs Bear, Base, and Bull forecasts from a single base assumption set.

    Wraps ForecastPipeline; adds scenario adjustment logic.
    """

    def __init__(
        self,
        pipeline: ForecastPipeline,
        deltas: ScenarioDeltas | None = None,
    ) -> None:
        self._pipeline = pipeline
        self._deltas   = deltas or ScenarioDeltas()

    def run_all(
        self,
        bundle: FinancialsBundle,
        base_assumptions: ForecastAssumptions,
    ) -> ScenarioResults:
        """
        Run Bear, Base, and Bull forecasts.

        Args:
            bundle:            FinancialsBundle from DataRouter.
            base_assumptions:  Base case ForecastAssumptions.

        Returns:
            ScenarioResults with all three outputs.
        """
        log.info("scenario.run_all.start", ticker=base_assumptions.ticker)

        bear_assumptions = self._apply_bear(base_assumptions)
        bull_assumptions = self._apply_bull(base_assumptions)

        bear = self._pipeline.run(bundle, bear_assumptions)
        base = self._pipeline.run(bundle, base_assumptions)
        bull = self._pipeline.run(bundle, bull_assumptions)

        log.info(
            "scenario.run_all.complete",
            ticker=base_assumptions.ticker,
            bear_fcff_y1=bear.years[0].fcff if bear.years else None,
            base_fcff_y1=base.years[0].fcff if base.years else None,
            bull_fcff_y1=bull.years[0].fcff if bull.years else None,
        )

        return ScenarioResults(bear=bear, base=base, bull=bull)

    async def run_all_async(
        self,
        bundle: FinancialsBundle,
        base_assumptions: ForecastAssumptions,
    ) -> ScenarioResults:
        """Async wrapper for FastAPI route handlers."""
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.run_all, bundle, base_assumptions)

    # ── Scenario delta application ─────────────────────────────────────────

    def _apply_bear(self, base: ForecastAssumptions) -> ForecastAssumptions:
        d = self._deltas
        return base.model_copy(
            update={
                "scenario": ScenarioType.BEAR,
                "revenue_growth_adjustment": (
                    base.revenue_growth_adjustment + d.bear_revenue_growth_delta
                ),
                "ebitda_margin_adjustment": (
                    base.ebitda_margin_adjustment + d.bear_ebitda_margin_delta
                ),
                "tax_rate_adjustment": (
                    base.tax_rate_adjustment + d.bear_tax_rate_delta
                ),
            }
        )

    def _apply_bull(self, base: ForecastAssumptions) -> ForecastAssumptions:
        d = self._deltas
        return base.model_copy(
            update={
                "scenario": ScenarioType.BULL,
                "revenue_growth_adjustment": (
                    base.revenue_growth_adjustment + d.bull_revenue_growth_delta
                ),
                "ebitda_margin_adjustment": (
                    base.ebitda_margin_adjustment + d.bull_ebitda_margin_delta
                ),
                "tax_rate_adjustment": (
                    base.tax_rate_adjustment + d.bull_tax_rate_delta
                ),
            }
        )
