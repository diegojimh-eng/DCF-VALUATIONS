"""
engine/pipeline/forecast_pipeline.py
--------------------------------------
ForecastPipeline — the top-level orchestrator for the forecasting engine.

Execution order (dependency DAG):
  1. HistoricalExtractor   → HistoricalSeries
  2. AssumptionResolver    → ResolvedAssumptions
  3. Revenue loop          → revenues[t] = revenue[t-1] × (1 + growth[t])
  4. Per-year loop (t=1…N):
       EBITDA[t]   = revenue[t] × ebitda_margin[t]
       D&A[t]      = revenue[t] × da_pct[t]
       EBIT[t]     = EBITDA[t] − D&A[t]
       Taxes[t]    = max(EBIT[t], 0) × tax_rate[t]
       NOPAT[t]    = EBIT[t] − Taxes[t]
       CapEx[t]    = revenue[t] × capex_pct[t]
       NWC[t]      = revenue[t] × nwc_pct[t]
       ΔNWC[t]     = NWC[t] − NWC[t-1]
       FCFF[t]     = NOPAT[t] + D&A[t] − CapEx[t] − ΔNWC[t]
  5. Pack into ForecastYear objects → ForecastOutput

The pipeline is fully synchronous. The async wrapper run_async() is
provided for use in FastAPI route handlers.

Usage:
    pipeline = ForecastPipeline()
    output = pipeline.run(bundle, assumptions)

    # Or with async FastAPI:
    output = await pipeline.run_async(bundle, assumptions)
"""

from __future__ import annotations

import asyncio
from datetime import date

from data.models.responses import FinancialsBundle
from engine.assumptions import TrendAnalyser
from engine.assumptions.models import ForecastAssumptions
from engine.forecasters.fcff import FCFFCalculator, FCFFComponents
from engine.forecasters.margins import MarginsForecaster
from engine.models import ForecastOutput, ForecastYear, ResolvedAssumptions
from engine.pipeline.historical_extractor import HistoricalExtractor
from engine.pipeline.resolver import AssumptionResolver
from logger import get_logger

log = get_logger(__name__)


class ForecastPipeline:
    """
    Main entry point for the forecasting engine.

    Instantiate once and reuse — all state is per-run (held in local vars).
    """

    def __init__(self, analyser: TrendAnalyser | None = None) -> None:
        self._analyser   = analyser or TrendAnalyser()
        self._extractor  = HistoricalExtractor()
        self._resolver   = AssumptionResolver(self._analyser)
        self._fcff_calc  = FCFFCalculator()
        self._margins    = MarginsForecaster(self._analyser)

    # ── Public interface ───────────────────────────────────────────────────

    def run(
        self,
        bundle: FinancialsBundle,
        assumptions: ForecastAssumptions,
    ) -> ForecastOutput:
        """
        Execute the full forecast for a company.

        Args:
            bundle:      FinancialsBundle from DataRouter (Phase 2).
            assumptions: ForecastAssumptions (manual, trend, or hybrid).

        Returns:
            ForecastOutput with 10 ForecastYear rows and full provenance.
        """
        ticker = bundle.profile.ticker
        log.info("pipeline.run.start", ticker=ticker, scenario=assumptions.scenario.value)

        # ── Step 1: Extract historical series ──────────────────────────────
        series  = self._extractor.extract(bundle)
        history = self._extractor.build_historical_summary(series, ticker)
        warnings: list[str] = []

        if not series.revenue or all(v is None for v in series.revenue):
            warnings.append("No historical revenue data — all revenue assumptions must be manual.")

        # ── Step 2: Resolve all assumptions ───────────────────────────────
        resolved = self._resolver.resolve(assumptions, series)

        # ── Step 3: Project revenues ───────────────────────────────────────
        base_revenue = history.base_revenue
        base_fiscal_year = history.base_year

        revenues: list[float] = []
        prior = base_revenue
        for rate in resolved.revenue_growth_rates:
            projected = prior * (1.0 + rate)
            revenues.append(projected)
            prior = projected

        # ── Step 4: NWC in base year (year 0) ─────────────────────────────
        # Needed to compute ΔNWC for year 1.
        base_nwc_values = [v for v in series.nwc if v is not None]
        base_nwc = base_nwc_values[0] if base_nwc_values else base_revenue * resolved.nwc_pct_revenues[0]

        # ── Step 5: Year-by-year projection loop ──────────────────────────
        forecast_years: list[ForecastYear] = []
        prior_nwc = base_nwc

        for i, rev in enumerate(revenues):
            year_index   = i + 1
            fiscal_year  = base_fiscal_year + year_index
            period_end   = date(fiscal_year, 12, 31)

            # Per-year assumption values
            ebitda_margin = resolved.ebitda_margins[i]
            da_pct        = resolved.da_pct_revenues[i]
            tax_rate      = resolved.effective_tax_rates[i]
            capex_pct     = resolved.capex_pct_revenues[i]
            nwc_pct       = resolved.nwc_pct_revenues[i]
            growth_rate   = resolved.revenue_growth_rates[i]

            # ── Derive line items ──────────────────────────────────────────
            ebitda = rev * ebitda_margin
            da     = max(0.0, rev * da_pct)
            ebit   = ebitda - da
            taxes  = self._margins.compute_taxes(ebit, tax_rate)
            nopat  = self._margins.compute_nopat(ebit, tax_rate)
            capex  = max(0.0, rev * capex_pct)
            nwc    = rev * nwc_pct
            delta_nwc = nwc - prior_nwc

            # ── FCFF ──────────────────────────────────────────────────────
            components = FCFFComponents(
                revenue=rev,
                ebitda=ebitda,
                ebitda_margin=ebitda_margin,
                da=da,
                ebit=ebit,
                tax_rate=tax_rate,
                taxes=taxes,
                nopat=nopat,
                capex=capex,
                nwc=nwc,
                delta_nwc=delta_nwc,
            )
            fcff = self._fcff_calc.compute(components)

            # ── Warnings for edge cases ────────────────────────────────────
            if ebit < 0:
                warnings.append(f"Year {fiscal_year}: EBIT is negative ({ebit:,.0f})")
            if fcff < 0 and year_index <= 3:
                warnings.append(f"Year {fiscal_year}: Negative FCFF in early forecast ({fcff:,.0f})")

            # ── Build ForecastYear ─────────────────────────────────────────
            fy = ForecastYear(
                year_index=year_index,
                fiscal_year=fiscal_year,
                period_end_date=period_end,
                revenue=rev,
                revenue_growth_rate=growth_rate,
                ebitda=ebitda,
                ebitda_margin=ebitda_margin,
                depreciation_amortisation=da,
                da_as_pct_revenue=da_pct,
                ebit=ebit,
                ebit_margin=ebit / rev if rev > 0 else 0.0,
                effective_tax_rate=tax_rate,
                taxes=taxes,
                nopat=nopat,
                capital_expenditures=capex,
                capex_as_pct_revenue=capex_pct,
                net_working_capital=nwc,
                nwc_as_pct_revenue=nwc_pct,
                change_in_nwc=delta_nwc,
                fcff=fcff,
                assumptions_used={
                    "revenue_growth_rate": growth_rate,
                    "ebitda_margin": ebitda_margin,
                    "da_pct_revenue": da_pct,
                    "tax_rate": tax_rate,
                    "capex_pct_revenue": capex_pct,
                    "nwc_pct_revenue": nwc_pct,
                },
            )
            forecast_years.append(fy)
            prior_nwc = nwc

        log.info(
            "pipeline.run.complete",
            ticker=ticker,
            years=len(forecast_years),
            fcff_y1=forecast_years[0].fcff if forecast_years else None,
            fcff_y10=forecast_years[-1].fcff if forecast_years else None,
            warnings=len(warnings),
        )

        return ForecastOutput(
            ticker=ticker,
            scenario=assumptions.scenario,
            years=forecast_years,
            assumptions=assumptions,
            resolved=resolved,
            history=history,
            warnings=warnings,
        )

    async def run_async(
        self,
        bundle: FinancialsBundle,
        assumptions: ForecastAssumptions,
    ) -> ForecastOutput:
        """
        Async wrapper for use in FastAPI route handlers.
        The forecast computation is CPU-bound but fast (<10ms for 10 years),
        so we run it in the default thread pool to avoid blocking the event loop.
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.run, bundle, assumptions)
