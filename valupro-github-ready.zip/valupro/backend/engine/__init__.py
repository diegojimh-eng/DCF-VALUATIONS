"""
engine/ — ValuPro forecasting engine.

Public API:
    from engine import ForecastPipeline, ScenarioEngine, ForecastAssumptions
    from engine.models import ForecastOutput, ForecastYear

Typical usage:
    pipeline = ForecastPipeline()
    output   = pipeline.run(bundle, assumptions)

    # Or three scenarios at once:
    scenario_engine = ScenarioEngine(pipeline)
    results  = scenario_engine.run_all(bundle, base_assumptions)
"""

from engine.assumptions.models import (
    CapExAssumptions,
    DAAssumptions,
    ForecastAssumptions,
    ItemAssumption,
    MarginAssumptions,
    NWCAssumptions,
    RevenueAssumptions,
    ScenarioType,
    TrendMethod,
)
from engine.assumptions.trend_analyser import TrendAnalyser
from engine.models import ForecastOutput, ForecastYear, HistoricalSummary, ResolvedAssumptions
from engine.pipeline.forecast_pipeline import ForecastPipeline
from engine.pipeline.scenario_engine import ScenarioDeltas, ScenarioEngine, ScenarioResults

__all__ = [
    "CapExAssumptions",
    "DAAssumptions",
    "ForecastAssumptions",
    "ForecastOutput",
    "ForecastPipeline",
    "ForecastYear",
    "HistoricalSummary",
    "ItemAssumption",
    "MarginAssumptions",
    "NWCAssumptions",
    "ResolvedAssumptions",
    "RevenueAssumptions",
    "ScenarioDeltas",
    "ScenarioEngine",
    "ScenarioResults",
    "ScenarioType",
    "TrendAnalyser",
    "TrendMethod",
]
