"""
engine/assumptions/models.py
-----------------------------
Pydantic models that represent every configurable assumption that drives
the 10-year forecast.

Two assumption modes (can be mixed per-line-item):
  • MANUAL    — analyst provides the value explicitly
  • TREND     — engine derives the value from historical data

Every assumption field is Optional so the engine can tell the difference
between "analyst set this to 0.0" and "analyst left this blank → use trend."

Design rules:
  • All growth rates are decimals  (0.08 = 8%)
  • All margins are decimals       (0.25 = 25%)
  • All ratios-to-revenue are decimals
  • Monetary values are in the company's reporting currency (same units as
    the IncomeStatement / BalanceSheet — i.e. whatever FMP returned)
"""

from __future__ import annotations

from enum import Enum
from typing import Annotated

from pydantic import BaseModel, Field, model_validator


# ── Enums ──────────────────────────────────────────────────────────────────────

class AssumptionMode(str, Enum):
    """How each assumption was determined."""
    MANUAL = "manual"       # analyst explicitly provided the value
    TREND  = "trend"        # derived from historical data by the engine
    HYBRID = "hybrid"       # manual override applied to a trend baseline


class ScenarioType(str, Enum):
    BEAR = "bear"
    BASE = "base"
    BULL = "bull"
    CUSTOM = "custom"


class TrendMethod(str, Enum):
    """Statistical method used to derive a trend value from history."""
    CAGR          = "cagr"            # Compound Annual Growth Rate (geometric)
    MEAN          = "mean"            # Simple arithmetic mean
    MEDIAN        = "median"          # Median (robust to outliers)
    REGRESSION    = "regression"      # OLS linear regression slope
    WEIGHTED_MEAN = "weighted_mean"   # More weight to recent years


# ── Per-item assumption ────────────────────────────────────────────────────────

class ItemAssumption(BaseModel):
    """
    A single assumption for one line item.
    Carries both the value and the provenance (how it was determined).
    """
    value: float
    mode: AssumptionMode = AssumptionMode.MANUAL
    trend_method: TrendMethod | None = None   # set when mode=TREND or HYBRID
    confidence: float | None = Field(
        default=None,
        ge=0.0, le=1.0,
        description="Statistical confidence in trend-derived value (R² for regression)",
    )
    note: str | None = None   # analyst comment

    model_config = {"frozen": True}


# ── Revenue assumptions ────────────────────────────────────────────────────────

class RevenueAssumptions(BaseModel):
    """
    Year-by-year revenue growth rates for the forecast period.

    For a 10-year forecast the list must have exactly 10 entries.
    Year 1 is the first forecast year (the year after the latest historical).

    If growth_rates is None the engine will derive them from history
    using the selected trend_method.
    """
    growth_rates: list[float] | None = Field(
        default=None,
        description="10 annual revenue growth rates as decimals (e.g. 0.08 = 8%). "
                    "None → derive from history.",
    )
    # Alternative: single growth rate applied to all years
    constant_growth_rate: float | None = Field(
        default=None,
        description="Apply the same growth rate to every forecast year. "
                    "Overridden by growth_rates if both are provided.",
    )
    trend_method: TrendMethod = TrendMethod.CAGR
    # Phase-in: growth converges from near_term_growth toward long_term_growth
    near_term_growth: float | None = Field(
        default=None,
        description="Growth rate for years 1–3 of the forecast.",
    )
    long_term_growth: float | None = Field(
        default=None,
        description="Growth rate for years 8–10 of the forecast. "
                    "Linearly interpolated between near and long term.",
    )
    # Hard floor / ceiling applied after trend computation
    growth_floor: float = Field(default=-0.50, description="Minimum allowed growth rate (e.g. -0.50 = -50%)")
    growth_ceiling: float = Field(default=2.00, description="Maximum allowed growth rate (e.g. 2.00 = 200%)")

    @model_validator(mode="after")
    def validate_growth_list(self) -> "RevenueAssumptions":
        if self.growth_rates is not None and len(self.growth_rates) != 10:
            raise ValueError(
                f"growth_rates must have exactly 10 entries, got {len(self.growth_rates)}"
            )
        return self


# ── Margin assumptions ─────────────────────────────────────────────────────────

class MarginAssumptions(BaseModel):
    """
    Target margins expressed as a fraction of revenue.
    None → derive from historical average using trend_method.
    """
    # EBITDA margin trajectory
    ebitda_margin: float | None = Field(
        default=None,
        description="Target EBITDA / Revenue for all forecast years. "
                    "None → derive from history.",
    )
    # Optional per-year override (must have 10 entries if provided)
    ebitda_margin_by_year: list[float] | None = Field(
        default=None,
        description="Year-by-year EBITDA margin. Overrides ebitda_margin.",
    )
    ebitda_margin_trend_method: TrendMethod = TrendMethod.MEDIAN

    # EBIT margin (used when EBITDA and D&A are not separately modelled)
    ebit_margin: float | None = Field(
        default=None,
        description="Target EBIT / Revenue. If None, derived as EBITDA margin - DA/Revenue.",
    )

    # Tax rate
    effective_tax_rate: float | None = Field(
        default=None,
        ge=0.0, le=1.0,
        description="Blended effective tax rate applied to EBIT. None → historical median.",
    )
    tax_rate_trend_method: TrendMethod = TrendMethod.MEDIAN

    @model_validator(mode="after")
    def validate_margin_by_year(self) -> "MarginAssumptions":
        if self.ebitda_margin_by_year is not None and len(self.ebitda_margin_by_year) != 10:
            raise ValueError("ebitda_margin_by_year must have exactly 10 entries")
        return self


# ── D&A assumptions ────────────────────────────────────────────────────────────

class DAAssumptions(BaseModel):
    """
    Depreciation & Amortisation assumptions.

    Modelled as a percentage of revenue (most common approach).
    Alternatively modelled as a percentage of gross PP&E (asset-based).
    """
    da_as_pct_revenue: float | None = Field(
        default=None,
        ge=0.0, le=0.5,
        description="D&A / Revenue. None → derive from history.",
    )
    da_as_pct_revenue_by_year: list[float] | None = Field(
        default=None,
        description="Year-by-year D&A as % of revenue. Overrides da_as_pct_revenue.",
    )
    trend_method: TrendMethod = TrendMethod.MEDIAN
    # Absolute floor — D&A can't be negative
    floor_absolute: float = 0.0

    @model_validator(mode="after")
    def validate_by_year(self) -> "DAAssumptions":
        if self.da_as_pct_revenue_by_year is not None and len(self.da_as_pct_revenue_by_year) != 10:
            raise ValueError("da_as_pct_revenue_by_year must have exactly 10 entries")
        return self


# ── CapEx assumptions ──────────────────────────────────────────────────────────

class CapExAssumptions(BaseModel):
    """
    Capital Expenditure assumptions.

    Modelled as a percentage of revenue (maintenance + growth CapEx combined).
    An alternative growth_capex_pct can be added by the analyst on top of
    a maintenance_capex_pct baseline.
    """
    capex_as_pct_revenue: float | None = Field(
        default=None,
        ge=0.0, le=1.0,
        description="Total CapEx / Revenue. None → derive from history. "
                    "Note: stored as positive decimal even though cash outflow.",
    )
    capex_as_pct_revenue_by_year: list[float] | None = Field(
        default=None,
        description="Year-by-year CapEx as % of revenue.",
    )
    trend_method: TrendMethod = TrendMethod.MEDIAN
    # Separate maintenance vs growth CapEx (optional decomposition)
    maintenance_capex_pct: float | None = Field(
        default=None,
        description="Maintenance CapEx as % of revenue. Summed with growth_capex_pct.",
    )
    growth_capex_pct: float | None = Field(
        default=None,
        description="Growth / expansion CapEx as % of revenue.",
    )

    @model_validator(mode="after")
    def validate_by_year(self) -> "CapExAssumptions":
        if self.capex_as_pct_revenue_by_year is not None and len(self.capex_as_pct_revenue_by_year) != 10:
            raise ValueError("capex_as_pct_revenue_by_year must have exactly 10 entries")
        return self


# ── Net Working Capital assumptions ───────────────────────────────────────────

class NWCAssumptions(BaseModel):
    """
    Net Working Capital assumptions.

    Modelled as a percentage of revenue (NWC / Revenue).
    The year-over-year *change* in NWC is what enters the FCFF formula:
        ΔNWC = NWC_t − NWC_{t-1}

    A positive ΔNWC is a cash use (growing business absorbs WC).
    """
    nwc_as_pct_revenue: float | None = Field(
        default=None,
        description="Target NWC / Revenue. None → derive from history.",
    )
    nwc_as_pct_revenue_by_year: list[float] | None = Field(
        default=None,
        description="Year-by-year NWC as % of revenue.",
    )
    trend_method: TrendMethod = TrendMethod.MEDIAN
    # Component-level override (takes precedence over aggregate NWC)
    accounts_receivable_days: float | None = Field(
        default=None,
        description="Days Sales Outstanding (AR days). AR = Revenue / 365 × DSO.",
    )
    inventory_days: float | None = Field(
        default=None,
        description="Days Inventory Outstanding.",
    )
    accounts_payable_days: float | None = Field(
        default=None,
        description="Days Payable Outstanding.",
    )

    @model_validator(mode="after")
    def validate_by_year(self) -> "NWCAssumptions":
        if self.nwc_as_pct_revenue_by_year is not None and len(self.nwc_as_pct_revenue_by_year) != 10:
            raise ValueError("nwc_as_pct_revenue_by_year must have exactly 10 entries")
        return self


# ── Master assumption set ──────────────────────────────────────────────────────

class ForecastAssumptions(BaseModel):
    """
    The complete set of assumptions that drive a 10-year forecast.

    This is the primary input to the ForecastPipeline.
    It is serialisable (JSON-safe) for storage in the valuations table.

    Usage:
        # Fully manual
        assumptions = ForecastAssumptions(
            ticker="AAPL",
            scenario=ScenarioType.BASE,
            forecast_years=10,
            revenue=RevenueAssumptions(constant_growth_rate=0.08),
            margins=MarginAssumptions(ebitda_margin=0.28),
            da=DAAssumptions(da_as_pct_revenue=0.03),
            capex=CapExAssumptions(capex_as_pct_revenue=0.04),
            nwc=NWCAssumptions(nwc_as_pct_revenue=0.05),
        )

        # Fully trend-based (leave sub-models at defaults → all None → engine derives)
        assumptions = ForecastAssumptions(ticker="AAPL")
    """
    ticker: str
    scenario: ScenarioType = ScenarioType.BASE
    forecast_years: int = Field(default=10, ge=1, le=20)

    # Sub-assumption groups — all fields default to None (trend-based)
    revenue: RevenueAssumptions = Field(default_factory=RevenueAssumptions)
    margins: MarginAssumptions = Field(default_factory=MarginAssumptions)
    da: DAAssumptions = Field(default_factory=DAAssumptions)
    capex: CapExAssumptions = Field(default_factory=CapExAssumptions)
    nwc: NWCAssumptions = Field(default_factory=NWCAssumptions)

    # Global trend settings (applied to all sub-models that haven't overridden)
    default_trend_method: TrendMethod = TrendMethod.CAGR
    historical_years_for_trend: int = Field(
        default=5,
        ge=2, le=10,
        description="How many historical years to use when fitting trends.",
    )

    # Scenario adjustment multipliers applied after all other computation
    # (used by ScenarioEngine to shift base assumptions)
    revenue_growth_adjustment: float = Field(
        default=0.0,
        description="Additive delta applied to every revenue growth rate (e.g. +0.02 = Bull)",
    )
    ebitda_margin_adjustment: float = Field(
        default=0.0,
        description="Additive delta applied to every EBITDA margin.",
    )
    tax_rate_adjustment: float = Field(
        default=0.0,
        description="Additive delta applied to the effective tax rate.",
    )

    model_config = {"frozen": True}

    @model_validator(mode="after")
    def normalise_ticker(self) -> "ForecastAssumptions":
        object.__setattr__(self, "ticker", self.ticker.upper().strip())
        return self
