"""
engine/assumptions/trend_analyser.py
--------------------------------------
Derives forward-looking assumptions from historical financial data.

Every public method returns an ItemAssumption that carries both the
computed value and full provenance (method used, R², sample size).

Statistical methods supported (TrendMethod enum):
  CAGR          — geometric compound rate: (end/start)^(1/n) - 1
  MEAN          — simple arithmetic average of annual values
  MEDIAN        — median (robust against single-year outliers)
  REGRESSION    — OLS linear regression extrapolated one period
  WEIGHTED_MEAN — exponential weighting: recent years carry more weight

Design principles:
  • All methods return float | None; None signals insufficient data.
  • Minimum 2 data points required for any trend (3 for regression).
  • Outlier screening: values beyond 3 × IQR are soft-trimmed before fitting.
  • Every result is clipped to a financially sensible range before return.
"""

from __future__ import annotations

import math
import statistics
from typing import Sequence

import numpy as np

from engine.assumptions.models import AssumptionMode, ItemAssumption, TrendMethod
from logger import get_logger

log = get_logger(__name__)

# Minimum observations required per method
_MIN_OBS = {
    TrendMethod.CAGR: 2,
    TrendMethod.MEAN: 2,
    TrendMethod.MEDIAN: 2,
    TrendMethod.REGRESSION: 3,
    TrendMethod.WEIGHTED_MEAN: 2,
}


class TrendAnalyser:
    """
    Derives forward-looking assumptions from historical series.

    Each public method ingests a list of historical values (newest-first,
    consistent with the data layer convention) and returns an ItemAssumption.
    """

    def __init__(
        self,
        default_method: TrendMethod = TrendMethod.CAGR,
        max_years: int = 5,
        outlier_iqr_multiplier: float = 3.0,
    ) -> None:
        self._default_method = default_method
        self._max_years = max_years
        self._iqr_mult = outlier_iqr_multiplier

    # ── Public API ─────────────────────────────────────────────────────────

    def revenue_growth_rate(
        self,
        revenues: list[float | None],
        method: TrendMethod | None = None,
    ) -> ItemAssumption:
        """
        Compute a representative annual revenue growth rate from history.

        Args:
            revenues: Historical revenue values, newest-first.

        Returns:
            ItemAssumption with the fitted growth rate (decimal).
        """
        method = method or self._default_method
        clean = self._clean(revenues)
        if len(clean) < 2:
            log.warning("trend.revenue_growth.insufficient_data", n=len(clean))
            return self._fallback(0.05, "Insufficient data — using 5% default")

        # Convert to YoY growth rates (newest-first → growth from oldest to newest)
        growth_rates = self._to_yoy_growth(clean)
        if not growth_rates:
            return self._fallback(0.05, "Could not compute YoY growth rates")

        value, confidence = self._fit(growth_rates, method)
        # Clip to reasonable range
        value = max(-0.50, min(value, 1.00))
        return ItemAssumption(
            value=value,
            mode=AssumptionMode.TREND,
            trend_method=method,
            confidence=confidence,
            note=f"Fitted from {len(growth_rates)} YoY observations using {method.value}",
        )

    def ebitda_margin(
        self,
        ebitda_values: list[float | None],
        revenue_values: list[float | None],
        method: TrendMethod | None = None,
    ) -> ItemAssumption:
        """Compute a representative EBITDA margin (EBITDA / Revenue)."""
        method = method or self._default_method
        margins = self._ratio_series(ebitda_values, revenue_values)
        if not margins:
            return self._fallback(0.15, "Insufficient data — using 15% EBITDA margin")

        value, confidence = self._fit(margins, method)
        value = max(-0.50, min(value, 0.90))
        return ItemAssumption(
            value=value,
            mode=AssumptionMode.TREND,
            trend_method=method,
            confidence=confidence,
            note=f"EBITDA margin fitted from {len(margins)} observations",
        )

    def ebit_margin(
        self,
        ebit_values: list[float | None],
        revenue_values: list[float | None],
        method: TrendMethod | None = None,
    ) -> ItemAssumption:
        """Compute a representative EBIT margin (EBIT / Revenue)."""
        method = method or TrendMethod.MEDIAN
        margins = self._ratio_series(ebit_values, revenue_values)
        if not margins:
            return self._fallback(0.12, "Insufficient data — using 12% EBIT margin")

        value, confidence = self._fit(margins, method)
        value = max(-0.50, min(value, 0.90))
        return ItemAssumption(
            value=value,
            mode=AssumptionMode.TREND,
            trend_method=method,
            confidence=confidence,
            note=f"EBIT margin fitted from {len(margins)} observations",
        )

    def effective_tax_rate(
        self,
        tax_expense: list[float | None],
        pretax_income: list[float | None],
        method: TrendMethod | None = None,
    ) -> ItemAssumption:
        """
        Compute effective tax rate (income_tax_expense / pretax_income).
        Excludes periods with negative pretax income (tax rate is meaningless).
        """
        method = method or TrendMethod.MEDIAN
        rates: list[float] = []
        for t, p in zip(tax_expense, pretax_income):
            if t is not None and p is not None and p > 0:
                rate = t / p
                if 0.0 <= rate <= 0.60:   # trim unrealistic rates
                    rates.append(rate)

        if not rates:
            return self._fallback(0.21, "Insufficient data — using 21% US statutory rate")

        value, confidence = self._fit(rates, method)
        value = max(0.05, min(value, 0.50))
        return ItemAssumption(
            value=value,
            mode=AssumptionMode.TREND,
            trend_method=method,
            confidence=confidence,
            note=f"Tax rate fitted from {len(rates)} profitable-year observations",
        )

    def da_as_pct_revenue(
        self,
        da_values: list[float | None],
        revenue_values: list[float | None],
        method: TrendMethod | None = None,
    ) -> ItemAssumption:
        """D&A as a percentage of revenue."""
        method = method or TrendMethod.MEDIAN
        # D&A should be positive; some providers report as negative cash outflow
        da_abs = [abs(v) if v is not None else None for v in da_values]
        ratios = self._ratio_series(da_abs, revenue_values)
        if not ratios:
            return self._fallback(0.03, "Insufficient data — using 3% D&A/Revenue")

        value, confidence = self._fit(ratios, method)
        value = max(0.001, min(value, 0.30))
        return ItemAssumption(
            value=value,
            mode=AssumptionMode.TREND,
            trend_method=method,
            confidence=confidence,
            note=f"D&A/Revenue fitted from {len(ratios)} observations",
        )

    def capex_as_pct_revenue(
        self,
        capex_values: list[float | None],
        revenue_values: list[float | None],
        method: TrendMethod | None = None,
    ) -> ItemAssumption:
        """
        CapEx as a percentage of revenue.
        CapEx from CFS is typically negative (cash outflow); we take abs value.
        """
        method = method or TrendMethod.MEDIAN
        capex_abs = [abs(v) if v is not None else None for v in capex_values]
        ratios = self._ratio_series(capex_abs, revenue_values)
        if not ratios:
            return self._fallback(0.05, "Insufficient data — using 5% CapEx/Revenue")

        value, confidence = self._fit(ratios, method)
        value = max(0.001, min(value, 0.50))
        return ItemAssumption(
            value=value,
            mode=AssumptionMode.TREND,
            trend_method=method,
            confidence=confidence,
            note=f"CapEx/Revenue fitted from {len(ratios)} observations",
        )

    def nwc_as_pct_revenue(
        self,
        nwc_values: list[float | None],
        revenue_values: list[float | None],
        method: TrendMethod | None = None,
    ) -> ItemAssumption:
        """
        Net Working Capital as a percentage of revenue.

        NWC = Current Assets − Current Liabilities.
        If not pre-computed, the caller should derive it before passing in.
        """
        method = method or TrendMethod.MEDIAN
        ratios = self._ratio_series(nwc_values, revenue_values)
        if not ratios:
            return self._fallback(0.05, "Insufficient data — using 5% NWC/Revenue")

        value, confidence = self._fit(ratios, method)
        value = max(-0.30, min(value, 0.60))
        return ItemAssumption(
            value=value,
            mode=AssumptionMode.TREND,
            trend_method=method,
            confidence=confidence,
            note=f"NWC/Revenue fitted from {len(ratios)} observations",
        )

    def revenue_cagr_phased(
        self,
        revenues: list[float | None],
        near_term_years: int = 3,
        long_term_years: int = 3,
    ) -> tuple[float, float]:
        """
        Returns (near_term_cagr, long_term_cagr) from a revenue series.

        The long-term rate is pulled toward the near-term growth divided by 2,
        approximating the fade to a lower steady-state (Gordon Growth compatible).
        """
        clean = self._clean(revenues)
        if len(clean) < 2:
            return (0.05, 0.03)

        growth_rates = self._to_yoy_growth(clean)
        if not growth_rates:
            return (0.05, 0.03)

        near_rates = growth_rates[:near_term_years] if len(growth_rates) >= near_term_years else growth_rates
        near = statistics.mean(near_rates)
        near = max(-0.30, min(near, 0.50))

        # Long-term: fade toward 50% of near-term, floored at 1%
        long = max(0.01, near * 0.50)
        return (near, long)

    # ── Statistical fitting core ───────────────────────────────────────────

    def _fit(
        self,
        series: list[float],
        method: TrendMethod,
    ) -> tuple[float, float | None]:
        """
        Fit a representative value from a series using the given method.
        Returns (value, confidence).
        confidence = R² for regression, None for mean/median, 1.0 for CAGR.
        """
        n = len(series)
        min_n = _MIN_OBS.get(method, 2)
        if n < min_n:
            log.debug("trend.fit.insufficient", method=method.value, n=n, min_n=min_n)
            return (statistics.mean(series) if series else 0.0, None)

        trimmed = self._trim_outliers(series)

        if method == TrendMethod.MEAN:
            return (statistics.mean(trimmed), None)

        elif method == TrendMethod.MEDIAN:
            return (statistics.median(trimmed), None)

        elif method == TrendMethod.CAGR:
            return (self._cagr(trimmed), 1.0)

        elif method == TrendMethod.WEIGHTED_MEAN:
            return (self._weighted_mean(trimmed), None)

        elif method == TrendMethod.REGRESSION:
            return self._ols_extrapolate(trimmed)

        else:
            return (statistics.mean(trimmed), None)

    @staticmethod
    def _cagr(values: list[float]) -> float:
        """
        Geometric mean of a list of growth rates.
        Equivalent to: (product of (1+g) for each g)^(1/n) - 1
        """
        if len(values) < 2:
            return values[0] if values else 0.0
        product = 1.0
        for v in values:
            product *= (1.0 + v)
        return product ** (1.0 / len(values)) - 1.0

    @staticmethod
    def _weighted_mean(values: list[float]) -> float:
        """Exponential weighting — most recent year has highest weight."""
        n = len(values)
        if n == 1:
            return values[0]
        weights = [2 ** i for i in range(n)]   # oldest=1, newest=2^(n-1)
        total_weight = sum(weights)
        # values is newest-first, so reverse to align with weights oldest-first
        rev = list(reversed(values))
        return sum(w * v for w, v in zip(weights, rev)) / total_weight

    @staticmethod
    def _ols_extrapolate(values: list[float]) -> tuple[float, float]:
        """
        OLS regression of value on time, extrapolated one period forward.
        Returns (predicted_next_value, R²).
        values are newest-first; we reverse to chronological order.
        """
        y = np.array(list(reversed(values)), dtype=float)
        x = np.arange(len(y), dtype=float)
        # Fit: y = a + b*x
        n = len(y)
        x_mean, y_mean = x.mean(), y.mean()
        ss_xy = float(np.sum((x - x_mean) * (y - y_mean)))
        ss_xx = float(np.sum((x - x_mean) ** 2))
        if abs(ss_xx) < 1e-12:
            return (float(y_mean), 0.0)
        b = ss_xy / ss_xx
        a = y_mean - b * x_mean
        predicted = a + b * n   # next period = index n

        # R²
        y_hat = a + b * x
        ss_res = float(np.sum((y - y_hat) ** 2))
        ss_tot = float(np.sum((y - y_mean) ** 2))
        r2 = 1.0 - ss_res / ss_tot if ss_tot > 1e-12 else 0.0
        return (predicted, max(0.0, min(r2, 1.0)))

    # ── Data cleaning helpers ──────────────────────────────────────────────

    def _clean(self, values: list[float | None]) -> list[float]:
        """
        Remove None values and apply the max_years window.
        Preserves newest-first order.
        """
        clean = [v for v in values if v is not None]
        return clean[: self._max_years]

    def _trim_outliers(self, values: list[float]) -> list[float]:
        """
        Soft IQR-based outlier trimming.
        Values beyond median ± IQR_MULT * IQR are clamped, not removed,
        to avoid destroying the series length.
        """
        if len(values) < 4:
            return values
        arr = sorted(values)
        q1 = arr[len(arr) // 4]
        q3 = arr[(len(arr) * 3) // 4]
        iqr = q3 - q1
        if iqr < 1e-10:
            return values
        lo = q1 - self._iqr_mult * iqr
        hi = q3 + self._iqr_mult * iqr
        return [max(lo, min(v, hi)) for v in values]

    @staticmethod
    def _ratio_series(
        numerator: list[float | None],
        denominator: list[float | None],
    ) -> list[float]:
        """Compute element-wise ratios, skipping pairs where denominator ≤ 0."""
        result: list[float] = []
        for n, d in zip(numerator, denominator):
            if n is not None and d is not None and d > 0:
                result.append(n / d)
        return result

    @staticmethod
    def _to_yoy_growth(values: list[float]) -> list[float]:
        """
        Compute year-over-year growth rates from a revenue series.
        Input is newest-first; we compute growth from oldest to newest.
        Returns growth rates newest-first.
        """
        if len(values) < 2:
            return []
        chronological = list(reversed(values))
        rates: list[float] = []
        for i in range(1, len(chronological)):
            prev = chronological[i - 1]
            curr = chronological[i]
            if abs(prev) > 1e-6:
                rates.append((curr - prev) / abs(prev))
        return list(reversed(rates))   # back to newest-first

    @staticmethod
    def _fallback(value: float, reason: str) -> ItemAssumption:
        return ItemAssumption(
            value=value,
            mode=AssumptionMode.TREND,
            confidence=0.0,
            note=f"FALLBACK — {reason}",
        )
