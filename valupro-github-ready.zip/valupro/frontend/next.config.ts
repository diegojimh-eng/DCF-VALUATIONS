import type { NextConfig } from "next";

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

const nextConfig: NextConfig = {
  // Proxy /api/v1/* → FastAPI backend (dev + prod)
  async rewrites() {
    return [
      {
        source: "/api/v1/:path*",
        destination: `${API_BASE}/api/v1/:path*`,
      },
    ];
  },

  // Security headers
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options",        value: "DENY" },
          { key: "Referrer-Policy",         value: "strict-origin-when-cross-origin" },
        ],
      },
    ];
  },

  // Allow HTTPS image sources for company logos
  images: {
    remotePatterns: [{ protocol: "https", hostname: "**" }],
  },

  // Output standalone bundle for production Docker image
  output: "standalone",

  reactStrictMode: true,
};

export default nextConfig;
