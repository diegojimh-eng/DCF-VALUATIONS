# ValuPro — Deployment Guide

**Stack:** FastAPI 0.111 · Next.js 14 · PostgreSQL 16 · Redis 7 · nginx 1.25  
**Infrastructure:** Docker + docker-compose · GitHub Actions CI/CD

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Local Development](#2-local-development)
3. [Environment Variables](#3-environment-variables)
4. [Production Deployment](#4-production-deployment)
5. [CI/CD Pipeline](#5-cicd-pipeline)
6. [Production Checklist](#6-production-checklist)
7. [Testing Checklist](#7-testing-checklist)
8. [Monitoring](#8-monitoring)
9. [Security Recommendations](#9-security-recommendations)
10. [Troubleshooting](#10-troubleshooting)

---

## 1. Prerequisites

### Local development
- Docker Desktop ≥ 24.0
- Docker Compose plugin ≥ 2.20
- Python 3.12 (for running tests outside Docker)
- Node.js 22 (for running frontend outside Docker)

### Production server
- Ubuntu 22.04 LTS (recommended) or Debian 12
- 4 vCPU / 8 GB RAM minimum (8 vCPU / 16 GB recommended)
- 50 GB SSD
- Docker + Docker Compose (installed below)
- A domain name with DNS A record pointing to the server

### API keys required
| Service | Purpose | Where to get |
|---------|---------|--------------|
| **FMP** (required) | Financial data primary | financialmodelingprep.com |
| **Anthropic** (required) | AI memo generation | console.anthropic.com |
| **Alpha Vantage** (optional) | Financial data fallback | alphavantage.co |

---

## 2. Local Development

### Quick start (< 5 minutes)

```bash
# 1. Clone and enter the project
git clone https://github.com/your-org/valupro.git
cd valupro

# 2. Set up environment variables
cp backend/.env.example backend/.env
# Edit backend/.env — add FMP_API_KEY and ANTHROPIC_API_KEY at minimum

# 3. Start all services
docker compose up --build

# 4. Verify
curl http://localhost:8000/health/live       # → {"status": "ok"}
curl http://localhost:8000/health/ready      # → {"status": "ok"}
open http://localhost:3000                   # frontend dashboard

# 5. Interactive API docs (development only)
open http://localhost:8000/docs
```

### Running without Docker

```bash
# Backend
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env                         # fill in values
uvicorn main:app --reload --port 8000

# Frontend (separate terminal)
cd frontend
npm install
cp .env.example .env.local
npm run dev                                  # → http://localhost:3000
```

### Running tests

```bash
cd backend

# Unit tests only (no external services needed)
pytest -m unit -v

# All tests (requires running postgres + redis)
pytest

# With coverage report
pytest --cov=. --cov-report=html
open htmlcov/index.html

# Specific phase
pytest tests/comps/ -v
pytest tests/valuation/ -v
pytest tests/analysis/ -v
```

---

## 3. Environment Variables

### Required (application will not start without these)

| Variable | Example | Description |
|----------|---------|-------------|
| `FMP_API_KEY` | `abc123...` | Financial Modeling Prep API key |
| `ANTHROPIC_API_KEY` | `sk-ant-...` | Anthropic Claude API key |
| `API_SECRET_KEY` | `<64-char hex>` | JWT signing secret |
| `DATABASE_URL` | `postgresql+asyncpg://...` | PostgreSQL connection string |
| `REDIS_URL` | `redis://...` | Redis connection string |

### Generate production secrets

```bash
bash scripts/generate_secret.sh
```

Outputs ready-to-paste env vars:
```
API_SECRET_KEY=<random 64-char hex>
POSTGRES_PASSWORD=<random 32-char>
REDIS_PASSWORD=<random 32-char>
GRAFANA_ADMIN_PASSWORD=<random 24-char>
```

### Optional but recommended

| Variable | Default | Description |
|----------|---------|-------------|
| `CORS_ALLOWED_ORIGINS` | `http://localhost:3000` | Production frontend domains |
| `ALPHA_VANTAGE_API_KEY` | — | Fallback data provider |
| `SEC_EDGAR_USER_AGENT` | `ValuPro research@...` | Required by SEC fair-use policy |
| `SENTRY_DSN` | — | Error tracking (highly recommended) |
| `LOG_LEVEL` | `INFO` | `DEBUG` / `INFO` / `WARNING` |

---

## 4. Production Deployment

### Step 1 — Server setup

```bash
# On a fresh Ubuntu 22.04 server as root

# Install Docker
curl -fsSL https://get.docker.com | sh
systemctl enable --now docker
usermod -aG docker ubuntu          # allow non-root access (re-login required)

# Install Docker Compose plugin
mkdir -p /usr/local/lib/docker/cli-plugins
curl -SL https://github.com/docker/compose/releases/latest/download/docker-compose-linux-x86_64 \
     -o /usr/local/lib/docker/cli-plugins/docker-compose
chmod +x /usr/local/lib/docker/cli-plugins/docker-compose
docker compose version              # verify

# Create application directory
mkdir -p /opt/valupro
chown ubuntu:ubuntu /opt/valupro
```

### Step 2 — TLS certificates (Let's Encrypt)

```bash
# Install certbot
apt-get install -y certbot

# Obtain certificate (replace with your domain)
certbot certonly --standalone \
    -d app.valupro.io \
    --email ops@valupro.io \
    --agree-tos \
    --non-interactive

# Copy certs to nginx directory
mkdir -p /opt/valupro/nginx/certs
cp /etc/letsencrypt/live/app.valupro.io/fullchain.pem /opt/valupro/nginx/certs/
cp /etc/letsencrypt/live/app.valupro.io/privkey.pem   /opt/valupro/nginx/certs/
chmod 600 /opt/valupro/nginx/certs/*.pem

# Auto-renew cron (runs twice daily)
echo "0 0,12 * * * root certbot renew --quiet && \
  cp /etc/letsencrypt/live/app.valupro.io/fullchain.pem /opt/valupro/nginx/certs/ && \
  cp /etc/letsencrypt/live/app.valupro.io/privkey.pem /opt/valupro/nginx/certs/ && \
  docker compose -f /opt/valupro/docker-compose.yml -f /opt/valupro/docker-compose.prod.yml exec nginx nginx -s reload" \
  >> /etc/cron.d/certbot-valupro
```

### Step 3 — Deploy application

```bash
# As ubuntu user
cd /opt/valupro

# Clone repository
git clone https://github.com/your-org/valupro.git .

# Set up production environment
cp backend/.env.example backend/.env

# Edit .env with production values:
nano backend/.env
# Required: FMP_API_KEY, ANTHROPIC_API_KEY, API_SECRET_KEY (generated),
#           DATABASE_URL, REDIS_URL, POSTGRES_PASSWORD, REDIS_PASSWORD,
#           CORS_ALLOWED_ORIGINS=https://app.valupro.io

# Update nginx.conf with your domain
sed -i 's/app.valupro.io/your-actual-domain.com/g' nginx/nginx.conf

# Pull and start all production services
docker compose \
    -f docker-compose.yml \
    -f docker-compose.prod.yml \
    up -d --build

# Verify all containers are running
docker compose -f docker-compose.yml -f docker-compose.prod.yml ps

# Check logs
docker compose -f docker-compose.yml -f docker-compose.prod.yml logs backend --tail=50
```

### Step 4 — Verify deployment

```bash
# Health checks
curl https://app.valupro.io/health/live    # → {"status": "ok"}
curl https://app.valupro.io/health/ready   # → {"status": "ok"}

# Test the demo PDF (no API key needed)
curl https://app.valupro.io/api/v1/reports/AAPL/demo \
    --output test.pdf && ls -lh test.pdf   # → ~391 KB

# Test the demo memo (no API key needed)
curl https://app.valupro.io/api/v1/memo/AAPL/demo | python3 -m json.tool | head -20

# Security headers
curl -I https://app.valupro.io | grep -E "Strict-Transport|X-Content|X-Frame"
```

### Step 5 — Optional monitoring

```bash
# Start monitoring stack (Prometheus + Grafana)
docker compose \
    -f docker-compose.yml \
    -f docker-compose.prod.yml \
    --profile monitoring \
    up -d prometheus grafana

# Grafana at http://your-server:3001
# Default login: admin / <GRAFANA_ADMIN_PASSWORD from .env>
```

### Updating the application

```bash
cd /opt/valupro
git pull
docker compose -f docker-compose.yml -f docker-compose.prod.yml pull
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --no-deps backend
# Wait for backend health, then update frontend
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --no-deps frontend
docker image prune -f
```

---

## 5. CI/CD Pipeline

The GitHub Actions workflow at `.github/workflows/ci.yml` runs automatically.

### Pipeline stages

```
Push to any branch
    └── Backend CI (pytest + ruff + mypy)
    └── Frontend CI (tsc + eslint + next build)
    └── Security Audit (safety + npm audit + trivy)

Push to main OR release published
    └── Build & Push Docker images → ghcr.io
        └── Multi-platform: linux/amd64 + linux/arm64
        └── Tagged: branch name, SHA, semver

Release published only
    └── Deploy to Production (SSH → docker compose pull + up -d)
```

### Required GitHub secrets

Add these at `Settings → Secrets → Actions`:

| Secret | Description |
|--------|-------------|
| `DEPLOY_HOST` | Production server IP or hostname |
| `DEPLOY_USER` | SSH user (e.g. `ubuntu`) |
| `DEPLOY_SSH_KEY` | Private SSH key for the deploy user |

### Required GitHub variables

Add at `Settings → Variables → Actions`:

| Variable | Example |
|----------|---------|
| `PUBLIC_API_URL` | `https://api.valupro.io` |

### Creating a release (triggers production deploy)

```bash
git tag v1.0.0
git push origin v1.0.0
# Then create a GitHub Release from this tag
# → CI runs → images built → deployed to production
```

---

## 6. Production Checklist

### Infrastructure
- [ ] Server has ≥ 4 vCPU / 8 GB RAM
- [ ] SSD storage with ≥ 50 GB free
- [ ] Docker 24+ and Docker Compose 2.20+ installed
- [ ] UFW firewall: only ports 22 (SSH), 80, 443 open
- [ ] SSH key authentication only (password auth disabled)
- [ ] Automatic security updates enabled (`unattended-upgrades`)

### TLS / DNS
- [ ] Domain A record points to server IP
- [ ] Let's Encrypt certificate issued and installed
- [ ] Auto-renewal cron job configured
- [ ] `nginx.conf` updated with correct domain name
- [ ] HTTPS redirect (80 → 443) working
- [ ] HSTS header present (`Strict-Transport-Security`)

### Environment
- [ ] `backend/.env` created from `.env.example`
- [ ] `API_SECRET_KEY` set to a random 64-char hex string (generated)
- [ ] `POSTGRES_PASSWORD` is unique and strong
- [ ] `REDIS_PASSWORD` set (not empty in production)
- [ ] `FMP_API_KEY` is a paid plan key (free plan: 250 req/day — insufficient for production)
- [ ] `ANTHROPIC_API_KEY` has a spending limit set in the Anthropic console
- [ ] `CORS_ALLOWED_ORIGINS` set to your frontend domain only
- [ ] `APP_ENV=production` (disables `/docs` and `/openapi.json`)

### Security
- [ ] `/docs` and `/openapi.json` inaccessible in production (`curl -I https://domain/docs` → 404)
- [ ] API key authentication implemented on all routes
- [ ] Rate limiting active (`curl -I https://domain/api/v1/health/live | grep X-RateLimit`)
- [ ] No `.env` file in the Docker image (`docker run --rm backend cat .env` → file not found)
- [ ] Backend container running as non-root user (`docker exec backend whoami` → `valupro`)
- [ ] No ports 5432 or 6379 reachable from the internet

### Observability
- [ ] Health endpoints responding: `/health/live` and `/health/ready`
- [ ] Application logs flowing to stdout (visible via `docker compose logs`)
- [ ] Uptime monitor configured (UptimeRobot, Pingdom, or similar)
- [ ] Error tracking configured (Sentry DSN set)
- [ ] Disk space alert configured (alert at 80% usage)

### Backup
- [ ] PostgreSQL backup strategy (daily `pg_dump` to S3 or similar)
- [ ] Backup tested: can restore from backup file
- [ ] Redis backup configured (`--save 900 1` in prod compose)

---

## 7. Testing Checklist

### Before every deployment

```bash
cd backend

# 1. Unit tests (must pass — no external services needed)
pytest -m unit -v
# Expected: 539+ tests, all green

# 2. Integration tests (requires running services)
pytest -m integration -v
# Expected: all green (skip if services unavailable)

# 3. Smoke test: PDF generation
python3 -c "
from reports.renderer import build_report_from_mock
pdf = build_report_from_mock('AAPL')
assert len(pdf) > 100_000, f'PDF too small: {len(pdf)} bytes'
print(f'PDF OK: {len(pdf):,} bytes')
"

# 4. Smoke test: all 7 charts render
python3 -c "
import warnings; warnings.filterwarnings('ignore')
from reports.charts.forecast import revenue_chart, ebitda_chart, fcff_chart
from reports.charts.waterfall import dcf_waterfall_chart, ev_bridge_chart
from reports.charts.valuation_charts import sensitivity_heatmap, football_field_chart
print('All chart imports OK — rendering test skipped in CI (needs display)')
"

# 5. Import all packages (catch circular dependencies)
python3 -c "
from logger import get_logger
from config import get_settings
print('Core imports OK')
"
```

### After deployment (smoke tests against live environment)

```bash
BASE=https://app.valupro.io

# Liveness
curl -sf $BASE/health/live   | python3 -m json.tool

# Readiness (Redis must respond)
curl -sf $BASE/health/ready  | python3 -m json.tool

# Data health (provider status)
curl -sf $BASE/api/v1/health/data | python3 -m json.tool

# Demo PDF (no API key — tests the whole rendering pipeline)
curl -sf $BASE/api/v1/reports/AAPL/demo --output smoke_test.pdf
python3 -c "
data = open('smoke_test.pdf','rb').read()
assert data[:4] == b'%PDF', 'Not a valid PDF'
print(f'PDF smoke test OK: {len(data):,} bytes')
"

# Demo memo JSON
curl -sf $BASE/api/v1/memo/AAPL/demo | python3 -c "
import sys,json
d=json.load(sys.stdin)
assert 'sections' in d and 'recommendation' in d['sections']
assert d['sections']['recommendation']['rating'] in ['BUY','HOLD','SELL','OUTPERFORM','UNDERPERFORM','STRONG BUY']
print('Memo smoke test OK — rating:', d['sections']['recommendation']['rating'])
"

# Rate limiting (should see 429 after limit exceeded)
for i in {1..15}; do
    STATUS=$(curl -sf -o /dev/null -w '%{http_code}' $BASE/api/v1/health/live)
    echo "Request $i: $STATUS"
done
```

### Manual verification checklist

- [ ] Frontend loads at production URL
- [ ] Dashboard shows data (or graceful loading state)
- [ ] Company search returns results for "AAPL"
- [ ] PDF download produces a valid PDF (open in browser to verify)
- [ ] AI memo demo returns structured JSON (no 500 errors)
- [ ] All 7 chart types visible in demo PDF
- [ ] HTTPS enforced (HTTP redirect to HTTPS)
- [ ] No security headers missing (run through securityheaders.com)

---

## 8. Monitoring

### Built-in health endpoints

| Endpoint | Use | Auth required |
|----------|-----|---------------|
| `GET /health/live` | Liveness probe (k8s, ECS) | No |
| `GET /health/ready` | Readiness probe | No |
| `GET /api/v1/health/data` | Provider + Redis status | No |

### Recommended uptime monitoring

**UptimeRobot (free):**
1. Create account at uptimerobot.com
2. Add HTTP monitor: `https://app.valupro.io/health/live`
3. Alert: email + Slack on downtime
4. Check interval: 5 minutes

**Alerting rules to configure:**
- HTTP 5xx rate > 1% for 5 minutes → PagerDuty/Slack
- Response time > 5s for 3 checks → alert
- Disk usage > 80% → alert
- Memory usage > 85% → alert

### Key metrics to track

**Application performance:**
- `http_requests_total` — request count by status code
- `http_request_duration_seconds` — latency percentiles (p50, p95, p99)
- `valupro_dcf_computation_seconds` — DCF computation time
- `valupro_memo_generation_seconds` — AI memo latency
- `valupro_pdf_generation_seconds` — PDF render time

**Infrastructure:**
- Redis hit rate (target > 80%)
- PostgreSQL connection pool utilization (target < 70%)
- Container CPU and memory usage
- nginx upstream error rate

### Log aggregation

In production, pipe Docker logs to a log aggregator:

```bash
# Docker daemon: configure log driver in /etc/docker/daemon.json
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m",
    "max-file": "5"
  }
}

# Or ship to external: Loki, CloudWatch, Datadog
# Add to docker-compose.prod.yml service definitions:
logging:
  driver: awslogs
  options:
    awslogs-region: us-east-1
    awslogs-group: /valupro/production
```

---

## 9. Security Recommendations

### Immediate (before going live)

1. **Change all default secrets.** Run `bash scripts/generate_secret.sh` and replace every default value in `.env`.

2. **Implement API authentication.** The auth middleware skeleton is in `config.py` (`API_SECRET_KEY`, `API_TOKEN_EXPIRE_MINUTES`). Connect it to all routes using `python-jose` (already in requirements.txt).

3. **Set Anthropic spending limits.** At console.anthropic.com → Settings → Limits, set a monthly cap. Each memo costs ~$0.15 on claude-sonnet-4-6.

4. **Set FMP rate limit alerts.** Monitor your FMP dashboard for usage spikes that could indicate API key theft.

5. **Rotate API keys regularly.** Use a secrets manager (AWS Secrets Manager, HashiCorp Vault, or GitHub Secrets). Never store API keys in source code.

### Short-term (within 30 days)

6. **Enable Sentry error tracking.** Add `SENTRY_DSN` to `.env` and integrate the Sentry SDK into the FastAPI exception handler. This gives you real-time error notifications with stack traces.

7. **Add rate limiting middleware.** `slowapi` is in requirements.txt — wire it to the `RATE_LIMIT_*` config variables. Apply `@limiter.limit(cfg.rate_limit_memo)` to memo routes.

8. **Scan Docker images regularly.** Add Trivy to the CI pipeline (already in `.github/workflows/ci.yml` — enable exit code 1 for CRITICAL findings).

9. **Set resource limits.** The `deploy.resources` limits in `docker-compose.prod.yml` prevent any single container from consuming all server resources.

10. **Configure database access control.** Create a read-only database user for monitoring queries. The application user should only have the minimum permissions it needs.

### Long-term (v1.1+)

11. **Implement JWT authentication** with refresh tokens. The signing key infrastructure is in `config.py`. Use `python-jose` for token generation and validation.

12. **Add request signing for webhooks.** If you add webhook delivery (e.g., notify on valuation completion), use HMAC-SHA256 signing.

13. **Enable PostgreSQL SSL.** Add `?sslmode=require` to `DATABASE_URL` and configure the PostgreSQL server with SSL certificates.

14. **Consider a WAF.** For production with real users, Cloudflare's free tier provides WAF, DDoS protection, and analytics on top of your nginx setup with zero configuration changes.

---

## 10. Troubleshooting

### Backend won't start

```bash
# Check logs
docker compose logs backend --tail=100

# Common causes:
# 1. Missing required env var
docker compose exec backend python3 -c "from config import get_settings; s=get_settings(); print('Config OK')"

# 2. Can't connect to Redis
docker compose exec backend python3 -c "import redis.asyncio as redis; import asyncio; asyncio.run(redis.from_url('redis://redis:6379/0').ping()); print('Redis OK')"

# 3. Port 8000 already in use
lsof -i :8000
```

### PDF generation fails

```bash
# Test chart rendering
docker compose exec backend python3 -c "
import warnings; warnings.filterwarnings('ignore')
from reports.renderer import build_report_from_mock
pdf = build_report_from_mock()
print(f'PDF OK: {len(pdf):,} bytes')
"

# Check font availability
docker compose exec backend python3 -c "
import matplotlib.font_manager as fm
fonts = [f.name for f in fm.fontManager.ttflist if 'DejaVu' in f.name]
print('DejaVu fonts:', fonts[:3])
"
```

### Memo generation fails

```bash
# Test Anthropic connectivity
docker compose exec backend python3 -c "
import httpx, os
r = httpx.get('https://api.anthropic.com', timeout=5)
print('Anthropic reachable:', r.status_code)
print('API key set:', bool(os.environ.get('ANTHROPIC_API_KEY', '')))
"
```

### Frontend can't reach backend

```bash
# Check nginx upstream
docker compose exec nginx nginx -t           # test config
docker compose logs nginx --tail=50          # check access/error logs

# Check backend is responding inside the network
docker compose exec nginx curl http://backend:8000/health/live
```

### High memory usage

```bash
# Check per-container memory
docker stats --no-stream

# Python: force garbage collection (temporary fix)
docker compose exec backend python3 -c "import gc; gc.collect(); print('GC done')"

# Redis: check memory usage
docker compose exec redis redis-cli info memory | grep used_memory_human
```
